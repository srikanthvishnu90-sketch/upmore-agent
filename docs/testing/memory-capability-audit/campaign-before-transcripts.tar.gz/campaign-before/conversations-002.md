# conversations-002

All conversations are synthetic. Full production handler, mock authentication/PostgREST and disabled model; no real outbound messages or provider actions.

## C00051 · M01 · Confirmed nickname recalls the right person · PASS

Expected: [{"say":"save bria as brother"},{"say":"yes"},{"say":"send brother 40","match":"Bria Kim.*@briak","outcome":"confirm"}]

### Trial 1

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bria Kim (brother, @briak).

User: send brother 40

Upmore: Set up $40.00 to Bria Kim (brother, @briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bria Kim (brother, @briak).

User: send brother 40

Upmore: Set up $40.00 to Bria Kim (brother, @briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bria Kim (brother, @briak).

User: send brother 40

Upmore: Set up $40.00 to Bria Kim (brother, @briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00052 · M02 · Explicit remember phrasing persists an alias · PASS

Expected: [{"say":"remember Seth Rao as my sister"},{"say":"yes"},{"say":"send sister 50","match":"Seth Rao.*@sethr","outcome":"confirm"}]

### Trial 1

User: remember Seth Rao as my sister

Upmore: Save "sister" as your name for Seth Rao (@sethr)? Then "send sister 20" goes to Seth Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Seth Rao (sister, @sethr).

User: send sister 50

Upmore: Set up $50.00 to Seth Rao (sister, @sethr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: remember Seth Rao as my sister

Upmore: Save "sister" as your name for Seth Rao (@sethr)? Then "send sister 20" goes to Seth Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Seth Rao (sister, @sethr).

User: send sister 50

Upmore: Set up $50.00 to Seth Rao (sister, @sethr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: remember Seth Rao as my sister

Upmore: Save "sister" as your name for Seth Rao (@sethr)? Then "send sister 20" goes to Seth Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Seth Rao (sister, @sethr).

User: send sister 50

Upmore: Set up $50.00 to Seth Rao (sister, @sethr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00053 · M03 · Natural relationship statement needs confirmation and persists · PASS

Expected: [{"say":"my dad is Bria Kim","match":"Save"},{"say":"yes"},{"say":"send dad 60","match":"Bria Kim","outcome":"confirm"}]

### Trial 1

User: my dad is Bria Kim

Upmore: Save "dad" as your name for Bria Kim (@briak)? Then "send dad 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Bria Kim (dad, @briak).

User: send dad 60

Upmore: Set up $60.00 to Bria Kim (dad, @briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: my dad is Bria Kim

Upmore: Save "dad" as your name for Bria Kim (@briak)? Then "send dad 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Bria Kim (dad, @briak).

User: send dad 60

Upmore: Set up $60.00 to Bria Kim (dad, @briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: my dad is Bria Kim

Upmore: Save "dad" as your name for Bria Kim (@briak)? Then "send dad 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Bria Kim (dad, @briak).

User: send dad 60

Upmore: Set up $60.00 to Bria Kim (dad, @briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00054 · M04 · An alias is moved only to the newly confirmed person · PASS

Expected: [{"say":"save bria as brother"},{"say":"yes"},{"say":"brother is Seth Rao"},{"say":"yes"},{"say":"send brother 40","match":"Seth Rao","outcome":"confirm"}]

### Trial 1

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bria Kim (brother, @briak).

User: brother is Seth Rao

Upmore: Save "brother" as your name for Seth Rao (@sethr)? Then "send brother 20" goes to Seth Rao. "brother" means Bria Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Seth Rao (brother, @sethr).

User: send brother 40

Upmore: Set up $40.00 to Seth Rao (brother, @sethr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bria Kim (brother, @briak).

User: brother is Seth Rao

Upmore: Save "brother" as your name for Seth Rao (@sethr)? Then "send brother 20" goes to Seth Rao. "brother" means Bria Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Seth Rao (brother, @sethr).

User: send brother 40

Upmore: Set up $40.00 to Seth Rao (brother, @sethr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bria Kim (brother, @briak).

User: brother is Seth Rao

Upmore: Save "brother" as your name for Seth Rao (@sethr)? Then "send brother 20" goes to Seth Rao. "brother" means Bria Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Seth Rao (brother, @sethr).

User: send brother 40

Upmore: Set up $40.00 to Seth Rao (brother, @sethr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00055 · M05 · Rejected alias preserves the previous confirmed fact · PASS

Expected: [{"say":"save bria as brother"},{"say":"yes"},{"say":"brother is Seth Rao"},{"say":"no"},{"say":"send brother 40","match":"Bria Kim","outcome":"confirm"}]

### Trial 1

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bria Kim (brother, @briak).

User: brother is Seth Rao

Upmore: Save "brother" as your name for Seth Rao (@sethr)? Then "send brother 20" goes to Seth Rao. "brother" means Bria Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 40

Upmore: Set up $40.00 to Bria Kim (brother, @briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bria Kim (brother, @briak).

User: brother is Seth Rao

Upmore: Save "brother" as your name for Seth Rao (@sethr)? Then "send brother 20" goes to Seth Rao. "brother" means Bria Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 40

Upmore: Set up $40.00 to Bria Kim (brother, @briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bria Kim (brother, @briak).

User: brother is Seth Rao

Upmore: Save "brother" as your name for Seth Rao (@sethr)? Then "send brother 20" goes to Seth Rao. "brother" means Bria Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 40

Upmore: Set up $40.00 to Bria Kim (brother, @briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00056 · M06 · Amount correction preserves payee and replaces the old card · PASS

Expected: [{"say":"send bria 40"},{"say":"make it 70","match":"70.00.*Bria Kim","outcome":"confirm"},{"say":"yes","match":"70.00","outcome":"staged"},{"state":"state.send.sends.0.amount_cents","equals":7000}]

### Trial 1

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 70

Upmore: Got it. Set up $70.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $70.00; 4. Keep it private, then Pay. I'll confirm when $70.00 to Bria Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 70

Upmore: Got it. Set up $70.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $70.00; 4. Keep it private, then Pay. I'll confirm when $70.00 to Bria Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 70

Upmore: Got it. Set up $70.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $70.00; 4. Keep it private, then Pay. I'll confirm when $70.00 to Bria Kim posts; if it hasn't by tonight, I'll ask.

## C00057 · M07 · Actually correction handles a different amount · PASS

Expected: [{"say":"send bria 40"},{"say":"actually make it 100","match":"100.00.*Bria Kim","outcome":"confirm"},{"say":"yes","match":"100.00","outcome":"staged"}]

### Trial 1

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 100

Upmore: Got it. Set up $100.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Bria Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 100

Upmore: Got it. Set up $100.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Bria Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 100

Upmore: Got it. Set up $100.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Bria Kim posts; if it hasn't by tonight, I'll ask.

## C00058 · M08 · Bare currency correction retains payment context · PASS

Expected: [{"say":"send bria 40"},{"say":"$25.00 instead","match":"25.00.*Bria Kim","outcome":"confirm"},{"say":"yes","match":"25.00","outcome":"staged"}]

### Trial 1

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $25.00 instead

Upmore: Got it. Set up $25.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $25.00; 4. Keep it private, then Pay. I'll confirm when $25.00 to Bria Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $25.00 instead

Upmore: Got it. Set up $25.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $25.00; 4. Keep it private, then Pay. I'll confirm when $25.00 to Bria Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $25.00 instead

Upmore: Got it. Set up $25.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $25.00; 4. Keep it private, then Pay. I'll confirm when $25.00 to Bria Kim posts; if it hasn't by tonight, I'll ask.

## C00059 · M09 · Split total correction recomputes every share before approval · PASS

Expected: [{"say":"split 120 with bria and seth"},{"say":"make it 180","match":"60.00 each.*180.00","outcome":"confirm"},{"say":"yes","match":"60.00","outcome":"staged"}]

### Trial 1

User: split 120 with bria and seth

Upmore: Request $40.00 each from Bria Kim (@briak) and Seth Rao (@sethr) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 180

Upmore: Got it. Request $60.00 each from Bria Kim (@briak) and Seth Rao (@sethr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Bria Kim (@briak) $60.00 in Venmo, Seth Rao (@sethr) $60.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 120 with bria and seth

Upmore: Request $40.00 each from Bria Kim (@briak) and Seth Rao (@sethr) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 180

Upmore: Got it. Request $60.00 each from Bria Kim (@briak) and Seth Rao (@sethr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Bria Kim (@briak) $60.00 in Venmo, Seth Rao (@sethr) $60.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 120 with bria and seth

Upmore: Request $40.00 each from Bria Kim (@briak) and Seth Rao (@sethr) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 180

Upmore: Got it. Request $60.00 each from Bria Kim (@briak) and Seth Rao (@sethr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Bria Kim (@briak) $60.00 in Venmo, Seth Rao (@sethr) $60.00 in Venmo. I'll mark each one paid when the money lands.

## C00060 · M10 · Rent setup correction retains recipient and due day · FAIL

Expected: [{"say":"pay my rent"},{"say":"bria $1800 on the 1st via Venmo"},{"say":"make it 1900","match":"1900.00.*Bria Kim.*1st","outcome":"confirm"},{"say":"yes"},{"state":"standing.0.amount_cents","equals":190000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 1900

Upmore: Got it. Set up rent: $1,900.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,900.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"1900.00.*Bria Kim.*1st","actual":{"thread_id":"16611418-5248-4cc6-b88e-04f3eec7dd72","reply":"Got it. Set up rent: $1,900.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 1900

Upmore: Got it. Set up rent: $1,900.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,900.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"1900.00.*Bria Kim.*1st","actual":{"thread_id":"373751a4-1812-440c-9e42-1b021cdd7b6b","reply":"Got it. Set up rent: $1,900.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 1900

Upmore: Got it. Set up rent: $1,900.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,900.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"1900.00.*Bria Kim.*1st","actual":{"thread_id":"3366ea17-3dfb-467f-8ac5-1bb041b04522","reply":"Got it. Set up rent: $1,900.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

## C00061 · M11 · Details refers to the pending payment · PASS

Expected: [{"say":"send bria 40"},{"say":"details","match":"40.00.*Bria Kim","outcome":"details"}]

### Trial 1

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $40.00 to Bria Kim on Venmo $40.00 to Bria Kim (@briak) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

### Trial 2

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $40.00 to Bria Kim on Venmo $40.00 to Bria Kim (@briak) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

### Trial 3

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $40.00 to Bria Kim on Venmo $40.00 to Bria Kim (@briak) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

## C00062 · M12 · A short yes resumes a serialized split · PASS

Expected: [{"say":"split 120 with bria and seth"},{"say":"yes","match":"Bria Kim.*40.00.*Seth Rao.*40.00","outcome":"staged"}]

### Trial 1

User: split 120 with bria and seth

Upmore: Request $40.00 each from Bria Kim (@briak) and Seth Rao (@sethr) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Bria Kim (@briak) $40.00 in Venmo, Seth Rao (@sethr) $40.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 120 with bria and seth

Upmore: Request $40.00 each from Bria Kim (@briak) and Seth Rao (@sethr) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Bria Kim (@briak) $40.00 in Venmo, Seth Rao (@sethr) $40.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 120 with bria and seth

Upmore: Request $40.00 each from Bria Kim (@briak) and Seth Rao (@sethr) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Bria Kim (@briak) $40.00 in Venmo, Seth Rao (@sethr) $40.00 in Venmo. I'll mark each one paid when the money lands.

## C00063 · M13 · Cancellation that resolves the last discussed subscription · PASS

Expected: [{"say":"cancel netflix","match":"Netflix"},{"say":"cancel that","match":"Netflix"}]

### Trial 1

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 2

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 3

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

## C00064 · M14 · Stop rent refers to the confirmed standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"bria $1800 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent","match":"Rent is off","outcome":"rent_stopped"},{"state":"standing.0.status","equals":"stopped"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Bria Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Bria Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Bria Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

## C00065 · M15 · A contextual fee question retains payment identity and asks before acting · PASS

Expected: [{"say":"send bria 40"},{"say":"what's the fee on that","match":"40.00.*Bria Kim"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $40.00 to Bria Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $40.00 to Bria Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $40.00 to Bria Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00066 · M16 · Rent setup answers retain the original goal · FAIL

Expected: [{"say":"pay my rent","match":"Who"},{"say":"bria $1800 on the 1st via Venmo","match":"1800.00.*Bria Kim","outcome":"confirm"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"standing.0.payee_handle","equals":"@briak"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"1800.00.*Bria Kim","actual":{"thread_id":"ac6293bb-c43f-4b38-a0b3-aa5627317925","reply":"Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"1800.00.*Bria Kim","actual":{"thread_id":"49cb4cd0-6aec-4986-adbc-3eedc0c5fe3f","reply":"Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"1800.00.*Bria Kim","actual":{"thread_id":"03c8118c-d5c4-4351-bb9d-876e755f48f5","reply":"Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

## C00067 · M17 · New recipient handle and rail answers retain amount · PASS

Expected: [{"say":"send Dana 50"},{"say":"@danak"},{"say":"@danak"},{"say":"Venmo"},{"say":"@danak","match":"50.00.*Dana","outcome":"confirm"}]

### Trial 1

User: send Dana 50

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $50.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: send Dana 50

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $50.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: send Dana 50

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $50.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00068 · M18 · Split remembers total while asking who participated · PASS

Expected: [{"say":"split 120 with 2 friends"},{"say":"bria and seth","match":"40.00 each.*120.00","outcome":"confirm"}]

### Trial 1

User: split 120 with 2 friends

Upmore: That's $40.00 each across 3 people. Who are the 2? I'll request $40.00 from each.

User: bria and seth

Upmore: Request $40.00 each from Bria Kim (@briak) and Seth Rao (@sethr) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: split 120 with 2 friends

Upmore: That's $40.00 each across 3 people. Who are the 2? I'll request $40.00 from each.

User: bria and seth

Upmore: Request $40.00 each from Bria Kim (@briak) and Seth Rao (@sethr) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: split 120 with 2 friends

Upmore: That's $40.00 each across 3 people. Who are the 2? I'll request $40.00 from each.

User: bria and seth

Upmore: Request $40.00 each from Bria Kim (@briak) and Seth Rao (@sethr) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

## C00069 · M19 · Rent is remembered on the next independent invocation · FAIL

Expected: [{"say":"pay my rent"},{"say":"bria $1800 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent","match":"1800.00.*Bria Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Bria Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"1800.00.*Bria Kim","actual":{"thread_id":"96c71e92-f280-4858-b3b7-d17c945fe965","reply":"Rent for November: $1,800.00 to Bria Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Bria Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"1800.00.*Bria Kim","actual":{"thread_id":"b569e93e-e911-46e5-ad68-60611a31d1dc","reply":"Rent for November: $1,800.00 to Bria Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Bria Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"1800.00.*Bria Kim","actual":{"thread_id":"f575597f-5d1b-4798-856c-add12b8c9ecc","reply":"Rent for November: $1,800.00 to Bria Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

## C00070 · M20 · An interrupted alias goal remains unconfirmed · PASS

Expected: [{"say":"save bria as brother"},{"say":"no"},{"state":"recipients.0.nickname","equals":null},{"say":"send brother 40","match":"handle","outcome":"ask"}]

### Trial 1

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 40

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 2

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 40

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 3

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 40

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

## C00071 · M21 · A staged payment is remembered without claiming completion · PASS

Expected: [{"say":"send bria 40"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Bria Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $40.00 to Bria Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 2

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Bria Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $40.00 to Bria Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 3

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Bria Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $40.00 to Bria Kim for you to send in Venmo. A second yes doesn't stage it again.

## C00072 · M22 · A staged split is remembered without duplicating it · PASS

Expected: [{"say":"split 120 with bria and seth"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 120 with bria and seth

Upmore: Request $40.00 each from Bria Kim (@briak) and Seth Rao (@sethr) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Bria Kim (@briak) $40.00 in Venmo, Seth Rao (@sethr) $40.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 120 with bria and seth

Upmore: Request $40.00 each from Bria Kim (@briak) and Seth Rao (@sethr) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Bria Kim (@briak) $40.00 in Venmo, Seth Rao (@sethr) $40.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 120 with bria and seth

Upmore: Request $40.00 each from Bria Kim (@briak) and Seth Rao (@sethr) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Bria Kim (@briak) $40.00 in Venmo, Seth Rao (@sethr) $40.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C00073 · M23 · A declined payment cannot be resurrected by yes · PASS

Expected: [{"say":"send bria 40"},{"say":"no","match":"Nothing","outcome":"declined"},{"say":"yes","not":"^Staged, not sent"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 2

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 3

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

## C00074 · M24 · Stopping rent prevents the next turn from claiming an active rule · PASS

Expected: [{"say":"pay my rent"},{"say":"bria $1800 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Bria Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Bria Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Bria Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C00075 · M25 · Status follow-up recalls staged versus sent · PASS

Expected: [{"say":"send bria 40"},{"say":"yes"},{"say":"did it go through","match":"(?:not (?:yet )?(?:sent|posted)|staged|have not seen|waiting for.*post)"}]

### Trial 1

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Bria Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $40.00 to Bria Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

### Trial 2

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Bria Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $40.00 to Bria Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

### Trial 3

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Bria Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $40.00 to Bria Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

## C00076 · M26 · Unapproved nickname does not become a known fact · PASS

Expected: [{"say":"save bria as brother"},{"state":"recipients.0.nickname","equals":null},{"say":"no"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 2

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 3

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

## C00077 · M27 · Unapproved rent terms are not durable instructions · PASS

Expected: [{"say":"pay my rent"},{"say":"bria $1800 on the 1st via Venmo"},{"state":"standing.length","equals":0},{"say":"no"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

## C00078 · M28 · An expired payment card is restated and requires a fresh yes · PASS

Expected: [{"say":"send bria 40"},{"minutes":11},{"say":"yes","match":"expired.*fresh","outcome":"confirm"},{"state":"state.send.sends.length","equals":0},{"say":"yes","match":"Staged","outcome":"staged"}]

### Trial 1

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Bria Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Bria Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Bria Kim posts; if it hasn't by tonight, I'll ask.

## C00079 · M29 · An expired nickname card never writes a fact · PASS

Expected: [{"say":"save bria as brother"},{"minutes":11},{"say":"yes","match":"expired"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 2

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 3

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

## C00080 · M30 · A question containing yes does not approve a payment · PASS

Expected: [{"say":"send bria 40"},{"say":"yes but is there a fee"},{"state":"state.send.sends.length","equals":0},{"say":"no"}]

### Trial 1

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

### Trial 2

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

### Trial 3

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

## C00081 · M31 · Moving to small talk explicitly drops the old payment · PASS

Expected: [{"say":"send bria 40"},{"say":"what's a good movie","match":"dropped.*40.00"},{"say":"yes","not":"^Staged"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $40.00 to Bria Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $40.00 to Bria Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $40.00 to Bria Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00082 · M32 · Switching recipients makes the latest request authoritative · PASS

Expected: [{"say":"send bria 40"},{"say":"send seth 60","match":"60.00.*Seth Rao","outcome":"confirm"},{"say":"yes","match":"60.00.*Seth Rao","outcome":"staged"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send seth 60

Upmore: I dropped the earlier card. Set up $60.00 to Seth Rao (@sethr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @sethr; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Seth Rao posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send seth 60

Upmore: I dropped the earlier card. Set up $60.00 to Seth Rao (@sethr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @sethr; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Seth Rao posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send seth 60

Upmore: I dropped the earlier card. Set up $60.00 to Seth Rao (@sethr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @sethr; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Seth Rao posts; if it hasn't by tonight, I'll ask.

## C00083 · M33 · A payment supersedes a pending split rather than approving both · PASS

Expected: [{"say":"split 120 with bria and seth"},{"say":"send bria 40","match":"40.00.*Bria Kim","outcome":"confirm"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"state":"state.split.staged.length","equals":0}]

### Trial 1

User: split 120 with bria and seth

Upmore: Request $40.00 each from Bria Kim (@briak) and Seth Rao (@sethr) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send bria 40

Upmore: I dropped the earlier card. Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Bria Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: split 120 with bria and seth

Upmore: Request $40.00 each from Bria Kim (@briak) and Seth Rao (@sethr) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send bria 40

Upmore: I dropped the earlier card. Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Bria Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: split 120 with bria and seth

Upmore: Request $40.00 each from Bria Kim (@briak) and Seth Rao (@sethr) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send bria 40

Upmore: I dropped the earlier card. Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Bria Kim posts; if it hasn't by tonight, I'll ask.

## C00084 · M34 · Switching from payment to rent keeps the new goal · PASS

Expected: [{"say":"send bria 40"},{"say":"pay my rent","match":"Who","outcome":"ask"},{"say":"bria $1800 on the 1st via Venmo"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 2

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 3

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

## C00085 · M35 · Never mind cancels an alias confirmation without saving · PASS

Expected: [{"say":"save bria as brother"},{"say":"never mind"},{"state":"recipients.0.nickname","equals":null},{"say":"yes","not":"^Saved:"}]

### Trial 1

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 2

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 3

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

## C00086 · M36 · Confirmed aliases survive a new conversation · PASS

Expected: [{"say":"save bria as brother"},{"say":"yes"},{"thread":"B"},{"say":"send brother 40","match":"Bria Kim","outcome":"confirm"}]

### Trial 1

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bria Kim (brother, @briak).

User: send brother 40

Upmore: Set up $40.00 to Bria Kim (brother, @briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bria Kim (brother, @briak).

User: send brother 40

Upmore: Set up $40.00 to Bria Kim (brother, @briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bria Kim (brother, @briak).

User: send brother 40

Upmore: Set up $40.00 to Bria Kim (brother, @briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00087 · M37 · Standing rent survives a new conversation · FAIL

Expected: [{"say":"pay my rent"},{"say":"bria $1800 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"pay my rent","match":"1800.00.*Bria Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Bria Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"1800.00.*Bria Kim","actual":{"thread_id":"0448733e-2d22-413e-82dd-7c8c0cd31ea6","reply":"Rent for November: $1,800.00 to Bria Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Bria Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"1800.00.*Bria Kim","actual":{"thread_id":"84e68003-87c7-41c5-ab03-232f9789b3e7","reply":"Rent for November: $1,800.00 to Bria Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Bria Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"1800.00.*Bria Kim","actual":{"thread_id":"ab28a888-2175-4c9b-b170-2bbda76fb466","reply":"Rent for November: $1,800.00 to Bria Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

## C00088 · M38 · Unapproved thread A card cannot be approved in thread B · PASS

Expected: [{"say":"send bria 40"},{"thread":"B"},{"say":"yes","not":"^Staged"},{"thread":"A"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00089 · M39 · A nickname correction in another session supersedes the old meaning · PASS

Expected: [{"say":"save bria as brother"},{"say":"yes"},{"thread":"B"},{"say":"brother is Seth Rao"},{"say":"yes"},{"thread":"C"},{"say":"send brother 40","match":"Seth Rao","outcome":"confirm"}]

### Trial 1

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bria Kim (brother, @briak).

User: brother is Seth Rao

Upmore: Save "brother" as your name for Seth Rao (@sethr)? Then "send brother 20" goes to Seth Rao. "brother" means Bria Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Seth Rao (brother, @sethr).

User: send brother 40

Upmore: Set up $40.00 to Seth Rao (brother, @sethr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bria Kim (brother, @briak).

User: brother is Seth Rao

Upmore: Save "brother" as your name for Seth Rao (@sethr)? Then "send brother 20" goes to Seth Rao. "brother" means Bria Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Seth Rao (brother, @sethr).

User: send brother 40

Upmore: Set up $40.00 to Seth Rao (brother, @sethr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bria Kim (brother, @briak).

User: brother is Seth Rao

Upmore: Save "brother" as your name for Seth Rao (@sethr)? Then "send brother 20" goes to Seth Rao. "brother" means Bria Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Seth Rao (brother, @sethr).

User: send brother 40

Upmore: Set up $40.00 to Seth Rao (brother, @sethr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00090 · M40 · Stopping rent in another session prevents future offers · PASS

Expected: [{"say":"pay my rent"},{"say":"bria $1800 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"stop rent"},{"thread":"C"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Bria Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Bria Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Bria Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C00091 · M41 · Repeating a staged approval does not stage twice after restore · PASS

Expected: [{"say":"send bria 40"},{"say":"yes"},{"say":"yes","match":"already staged","outcome":"already_done"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Bria Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $40.00 to Bria Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $40.00 to Bria Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 2

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Bria Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $40.00 to Bria Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $40.00 to Bria Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 3

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Bria Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $40.00 to Bria Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $40.00 to Bria Kim for you to send in Venmo. A second yes doesn't stage it again.

## C00092 · M42 · Rent setup retry leaves exactly one standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"bria $1800 on the 1st via Venmo"},{"say":"yes"},{"say":"yes","not":"^Rent is set up"},{"state":"standing.length","equals":1}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00093 · M43 · Confirmed alias repeated is recognized as already known · PASS

Expected: [{"say":"save bria as brother"},{"say":"yes"},{"say":"save bria as brother","match":"already|Already|already means","outcome":"already_done"},{"state":"ops.length","equals":1}]

### Trial 1

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bria Kim (brother, @briak).

User: save bria as brother

Upmore: "brother" already means Bria Kim (brother, @briak). Nothing changed.

### Trial 2

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bria Kim (brother, @briak).

User: save bria as brother

Upmore: "brother" already means Bria Kim (brother, @briak). Nothing changed.

### Trial 3

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bria Kim (brother, @briak).

User: save bria as brother

Upmore: "brother" already means Bria Kim (brother, @briak). Nothing changed.

## C00094 · M44 · The same month rent is staged once across restored sessions · PASS

Expected: [{"say":"pay my rent"},{"say":"bria $1800 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"pay my rent","match":"already staged","outcome":"already_done"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Bria Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $1,800.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $1,800.00 to Bria Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $1,800.00 to Bria Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Bria Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $1,800.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $1,800.00 to Bria Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $1,800.00 to Bria Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Bria Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @briak; 3. Enter $1,800.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $1,800.00 to Bria Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $1,800.00 to Bria Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

## C00095 · M45 · Retried split approval preserves one set of requests · PASS

Expected: [{"say":"split 120 with bria and seth"},{"say":"yes"},{"say":"yes"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 120 with bria and seth

Upmore: Request $40.00 each from Bria Kim (@briak) and Seth Rao (@sethr) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Bria Kim (@briak) $40.00 in Venmo, Seth Rao (@sethr) $40.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 120 with bria and seth

Upmore: Request $40.00 each from Bria Kim (@briak) and Seth Rao (@sethr) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Bria Kim (@briak) $40.00 in Venmo, Seth Rao (@sethr) $40.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 120 with bria and seth

Upmore: Request $40.00 each from Bria Kim (@briak) and Seth Rao (@sethr) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Bria Kim (@briak) $40.00 in Venmo, Seth Rao (@sethr) $40.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C00096 · M46 · Nickname save failure is never reported as remembered · PASS

Expected: [{"say":"save bria as brother"},{"set":{"failRecipients":true}},{"say":"yes","match":"couldn't save"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 2

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 3

User: save bria as brother

Upmore: Save "brother" as your name for Bria Kim (@briak)? Then "send brother 20" goes to Bria Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

## C00097 · M47 · Rent save failure is never reported as a stored rule · PASS

Expected: [{"say":"pay my rent"},{"say":"bria $1800 on the 1st via Venmo"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*set|nothing was set up"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

## C00098 · M48 · A failed state write yields no approval card and retry is recoverable · PASS

Expected: [{"set":{"failState":true}},{"say":"send bria 40","error":"state storage unavailable"},{"set":{"failState":false}},{"say":"send bria 40","match":"40.00.*Bria Kim","outcome":"confirm"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send bria 40

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: send bria 40

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: send bria 40

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00099 · M49 · Unavailable facts cause an honest blocker and preserve the old card · PASS

Expected: [{"say":"send bria 40"},{"set":{"unreadable":true}},{"say":"yes","match":"can't read.*Nothing was changed","outcome":"unavailable"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

### Trial 2

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

### Trial 3

User: send bria 40

Upmore: Set up $40.00 to Bria Kim (@briak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

## C00100 · M50 · A failed rent correction retains the prior confirmed terms · PASS

Expected: [{"say":"pay my rent"},{"say":"bria $1800 on the 1st via Venmo"},{"say":"yes"},{"say":"rent is 1900 now"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*change|rent stays as it was"},{"state":"standing.0.amount_cents","equals":180000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 1900 now

Upmore: Change rent (amount $1,800.00 to $1,900.00): $1,900.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 1900 now

Upmore: Change rent (amount $1,800.00 to $1,900.00): $1,900.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bria $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Bria Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 1900 now

Upmore: Change rent (amount $1,800.00 to $1,900.00): $1,900.00 to Bria Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

