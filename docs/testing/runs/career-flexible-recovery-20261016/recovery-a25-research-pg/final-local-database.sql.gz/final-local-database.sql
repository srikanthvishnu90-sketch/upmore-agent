--
-- PostgreSQL database dump
--

\restrict pPa8dkprPLhdtkjloTfdcQtrRsVKiTQ7ZDhyMFRnT4Fa9nI4FGMYVfGwtV6ILo1

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg13+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- Name: career_host_commit(uuid, uuid, text, text, bigint, bigint, jsonb, jsonb, text, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_host_commit(p_user uuid, p_thread uuid, p_key text, p_hash text, p_revision bigint, p_account_version bigint, p_snapshot jsonb, p_patch jsonb, p_input text, p_response jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $_$
declare a jsonb; old_snapshot jsonb; receipt jsonb; wp jsonb; epoch bigint; next_snapshot jsonb; patch_key text;
begin
 if p_user is null or p_thread is null or p_key is null or p_hash is null or p_key !~ '^[A-Za-z0-9_-]{1,128}$' or p_hash !~ '^[a-f0-9]{64}$' or p_snapshot is null or jsonb_typeof(p_snapshot)<>'object' or octet_length(p_snapshot::text)>1048576
  or p_input is null or length(p_input)>20000 or p_response is null or jsonb_typeof(p_response->'reply') is distinct from 'string' or octet_length(p_response::text)>1048576 or jsonb_typeof(coalesce(p_patch,'{}'::jsonb))<>'object' or p_snapshot#>>'{scope,userId}' is distinct from p_user::text or jsonb_typeof(p_response)<>'object' or p_response->>'thread_id' is distinct from p_thread::text then raise exception 'invalid host commit';end if;
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 perform 1 from agent_threads where id=p_thread and user_id=p_user for update;
 if not found or exists(select 1 from agent_flow_state where thread_id=p_thread and user_id is distinct from p_user) then return jsonb_build_object('error','owned_thread_missing');end if;
 select value into a from career_watch_kv where user_id=p_user and key='career:account';a:=coalesce(a,'{"version":0,"epoch":0}'::jsonb);epoch:=coalesce((a->>'epoch')::bigint,0);
 select value into receipt from career_watch_kv where user_id=p_user and key='career:turn:'||p_thread||':'||p_key;
 if receipt is not null then
  if receipt->>'hash'<>p_hash then return jsonb_build_object('error','turn_key_conflict');end if;
  if coalesce((receipt->>'epoch')::bigint,0)<>epoch or (receipt->'response' is null or receipt->'response'='null'::jsonb) then return jsonb_build_object('error','privacy_epoch_changed');end if;
  return jsonb_build_object('response',receipt->'response','replay',true);
 end if;
 if coalesce((a->>'version')::bigint,0)<>p_account_version then return jsonb_build_object('error','revision_conflict');end if;
 select state->'career' into old_snapshot from agent_flow_state where thread_id=p_thread and user_id=p_user for update;
 if coalesce((old_snapshot->>'revision')::bigint,0)<>p_revision then return jsonb_build_object('error','revision_conflict');end if;
 for patch_key in select jsonb_object_keys(coalesce(p_patch,'{}'::jsonb)) loop
  if patch_key not in ('paused','preferred_locations','erase') then raise exception 'invalid account patch';end if;
 end loop;
 if p_patch ? 'preferred_locations' and (jsonb_typeof(p_patch->'preferred_locations')<>'array' or jsonb_array_length(p_patch->'preferred_locations')<>1 or length(p_patch#>>'{preferred_locations,0}') not between 1 and 100) then raise exception 'invalid location';end if;
 if p_patch ? 'paused' and jsonb_typeof(p_patch->'paused')<>'boolean' then raise exception 'invalid pause';end if;
 if p_patch ? 'erase' and p_patch->'erase'<>'true'::jsonb then raise exception 'invalid erasure';end if;
 if p_patch->'erase'='true'::jsonb then
  epoch:=epoch+1;
  update agent_flow_state set state=jsonb_set(coalesce(state,'{}'::jsonb),'{career}',jsonb_build_object('v',1,'scope',jsonb_build_object('userId',p_user),'revision',coalesce((state#>>'{career,revision}')::bigint,0)+1,'stores',jsonb_build_object('globalPause',jsonb_build_object('set',true,'source','account_control')))),updated_at=now() where user_id=p_user;
  delete from career_watch_kv where user_id=p_user and key not like 'career:turn:%';
  update career_watch_kv set value=jsonb_set(value,'{response}','null'::jsonb),updated_at=now() where user_id=p_user and key like 'career:turn:%';
  update career_reminder_outbox set payload=null,record=null,status='cancelled',updated_at=now() where user_id=p_user;
  a:=jsonb_build_object('epoch',epoch,'paused',true,'version',p_account_version);
 end if;
 a:=a||coalesce(p_patch-'erase','{}'::jsonb)||jsonb_build_object('version',p_account_version+1,'epoch',epoch);
 insert into career_watch_kv(user_id,key,value)values(p_user,'career:account',a)on conflict(user_id,key)do update set value=excluded.value,updated_at=now();
 if a->'paused'='true'::jsonb then update career_reminder_outbox set status='cancelled',updated_at=now() where user_id=p_user and status in ('pending','claimed','uncertain');end if;
 next_snapshot:=(case when p_patch->'erase'='true'::jsonb then jsonb_build_object('v',1,'scope',jsonb_build_object('userId',p_user),'stores',jsonb_build_object('globalPause',jsonb_build_object('set',true,'source','account_control'))) else p_snapshot end)||jsonb_build_object('revision',p_revision+1,'privacy_epoch',epoch);
 wp:=next_snapshot#>array['stores','alertWatchState','career:watch-profile:'||p_user];
 if wp is not null then
  if wp->>'user_id' is distinct from p_user::text then raise exception 'watch owner mismatch';end if;
  insert into career_watch_kv(user_id,key,value)values(p_user,'career:watch-profile:'||p_user,wp)on conflict(user_id,key)do update set value=excluded.value,updated_at=now();
 end if;
 insert into agent_flow_state(thread_id,user_id,state,updated_at)values(p_thread,p_user,jsonb_build_object('career',next_snapshot),now())
 on conflict(thread_id)do update set state=jsonb_set(coalesce(agent_flow_state.state,'{}'::jsonb),'{career}',next_snapshot),updated_at=now() where agent_flow_state.user_id=p_user;
 insert into agent_messages(thread_id,role,content)values(p_thread,'user',p_input);
 insert into agent_messages(thread_id,role,content,meta)values(p_thread,'assistant',p_response->>'reply',coalesce(p_response->'meta','{}'::jsonb)||jsonb_build_object('career',true,'career_turn_key',p_key));
 update career_reminder_outbox set seen_at=now() where user_id=p_user and status='delivered' and reminder_id in(select x->>'reminder_id' from jsonb_array_elements(coalesce(p_response->'reminders','[]'::jsonb))x);
 insert into career_watch_kv(user_id,key,value)values(p_user,'career:turn:'||p_thread||':'||p_key,jsonb_build_object('hash',p_hash,'epoch',epoch,'response',p_response));
 return jsonb_build_object('response',p_response);
end $_$;


--
-- Name: career_host_load(uuid, uuid, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_host_load(p_user uuid, p_thread uuid, p_key text, p_hash text) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $_$
declare f jsonb; a jsonb; r jsonb; w jsonb; legacy_count integer; reminders jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 if p_user is null or p_thread is null or p_key is null or p_hash is null or p_key !~ '^[A-Za-z0-9_-]{1,128}$' or p_hash !~ '^[a-f0-9]{64}$' then return jsonb_build_object('error','invalid_turn_key');end if;
 if exists(select 1 from agent_flow_state where thread_id=p_thread and user_id is distinct from p_user) or not exists(select 1 from agent_threads where id=p_thread and user_id=p_user) then return jsonb_build_object('error','owned_thread_missing');end if;
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 a:=coalesce(a,'{"version":0,"epoch":0}'::jsonb);
 select value into r from career_watch_kv where user_id=p_user and key='career:turn:'||p_thread||':'||p_key;
 if r is not null then
  if r->>'hash'<>p_hash then return jsonb_build_object('error','turn_key_conflict');end if;
  if coalesce((r->>'epoch')::bigint,0)<>coalesce((a->>'epoch')::bigint,0) or r->'response' is null or r->'response'='null'::jsonb then return jsonb_build_object('error','privacy_epoch_changed');end if;
  return jsonb_build_object('replay',r->'response');
 end if;
 select state->'career' into f from agent_flow_state where thread_id=p_thread and user_id=p_user;
 select value into w from career_watch_kv where user_id=p_user and key='career:watch-profile:'||p_user;
 if w is null and coalesce((a->>'epoch')::bigint,0)=0 then
  select count(distinct state#>array['career','stores','alertWatchState','career:watch-profile:'||p_user]) into legacy_count
   from agent_flow_state where user_id=p_user and state#>>array['career','stores','alertWatchState','career:watch-profile:'||p_user,'user_id']=p_user::text;
  if legacy_count>1 then return jsonb_build_object('error','watch_profile_conflict');end if;
  select state#>array['career','stores','alertWatchState','career:watch-profile:'||p_user] into w from agent_flow_state
   where user_id=p_user and state#>>array['career','stores','alertWatchState','career:watch-profile:'||p_user,'user_id']=p_user::text limit 1;
 end if;
 if w is not null and w->>'user_id' is distinct from p_user::text then return jsonb_build_object('error','watch_profile_conflict');end if;
 select coalesce(jsonb_agg(record),'[]'::jsonb) into reminders from (select record from career_reminder_outbox where user_id=p_user and status='delivered' and seen_at is null order by delivered_at,reminder_id limit 5) q;
 return jsonb_build_object('snapshot',f,'revision',coalesce((f->>'revision')::bigint,0),'accountVersion',coalesce((a->>'version')::bigint,0),'account',a,
  'watchState',case when w is null then '{}'::jsonb else jsonb_build_object('career:watch-profile:'||p_user,w) end,'reminders',reminders);
end $_$;


--
-- Name: career_reminder_ack(uuid, text, uuid, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_reminder_ack(p_user uuid, p_id text, p_lease uuid, p_record jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare r career_reminder_outbox; a jsonb; ledger jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 select * into r from career_reminder_outbox where user_id=p_user and reminder_id=p_id for update;
 if not found then raise exception 'missing reminder';end if;
 if r.status='delivered' and r.lease_token=p_lease then return jsonb_build_object('status','delivered','record',r.record);end if;
 if r.lease_token is distinct from p_lease or r.status not in ('claimed','uncertain') or a->'paused'='true'::jsonb or not career_reminder_allowed(p_user,r.payload) then raise exception 'reminder acknowledgement unavailable';end if;
 if p_record->>'user_id' is distinct from p_user::text or p_record->>'reminder_id' is distinct from p_id or p_record->>'channel' is distinct from 'product_inbox' or p_record->'deadline' is distinct from r.payload->'deadline' or p_record->>'url' is distinct from r.payload->>'url' or p_record->>'job_id' is distinct from r.payload->>'job_id' or p_record->>'title' is distinct from r.payload->>'title' or p_record->>'company' is distinct from r.payload->>'company' or p_record->'fit_lines' is distinct from coalesce(r.payload#>'{fit,lines}','[]'::jsonb) or p_record->'matched_fact_ids' is distinct from coalesce(r.payload#>'{fit,matched_fact_ids}','[]'::jsonb) then raise exception 'reminder evidence mismatch';end if;
 p_record:=p_record||jsonb_build_object('provenance',jsonb_build_object('kind','career_reminder_outbox','version',1,'payload_sha256',encode(sha256(convert_to(r.payload::text,'UTF8')),'hex')));
 update career_reminder_outbox set status='delivered',record=p_record,delivered_at=now(),updated_at=now() where user_id=p_user and reminder_id=p_id;
 select value into ledger from career_watch_kv where user_id=p_user and key='career:delivery-ledger:'||p_user;
 ledger:=coalesce(ledger,jsonb_build_object('user_id',p_user,'delivered_ids','[]'::jsonb,'records','[]'::jsonb));
 ledger:=ledger||jsonb_build_object('delivered_ids',coalesce(ledger->'delivered_ids','[]'::jsonb)||jsonb_build_array(p_id),'records',coalesce(ledger->'records','[]'::jsonb)||jsonb_build_array(p_record));
 insert into career_watch_kv(user_id,key,value)values(p_user,'career:delivery-ledger:'||p_user,ledger)on conflict(user_id,key)do update set value=excluded.value,updated_at=now();
 return jsonb_build_object('status','delivered','record',p_record);
end $$;


--
-- Name: career_reminder_allowed(uuid, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_reminder_allowed(p_user uuid, p_reminder jsonb) RETURNS boolean
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select exists(select 1 from career_watch_kv w where user_id=p_user and key='career:watch-profile:'||p_user
 and w.value->>'user_id'=p_user::text and coalesce(w.value#>'{opt_out,global}','false'::jsonb)<>'true'::jsonb
 and exists(select 1 from jsonb_array_elements(coalesce(w.value->'interests','[]'::jsonb)) i where i->>'interest_id'=p_reminder->>'interest_id')
 and not exists(select 1 from jsonb_array_elements_text(coalesce(w.value#>'{opt_out,companies}','[]'::jsonb)) c where lower(c)=lower(p_reminder->>'company')));
$$;


--
-- Name: career_reminder_claim(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_reminder_claim(p_user uuid, p_id text) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare r career_reminder_outbox; a jsonb; token uuid;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 select * into r from career_reminder_outbox where user_id=p_user and reminder_id=p_id for update;
 if not found then return jsonb_build_object('status','missing','claimed',false);end if;
 if (a->'paused'='true'::jsonb or not career_reminder_allowed(p_user,r.payload)) and r.status in ('pending','claimed','uncertain') then update career_reminder_outbox set status='cancelled',updated_at=now() where user_id=p_user and reminder_id=p_id;return jsonb_build_object('status','cancelled','claimed',false);end if;
 if r.status='claimed' and r.lease_until<now() then update career_reminder_outbox set status='uncertain',updated_at=now() where user_id=p_user and reminder_id=p_id;return jsonb_build_object('status','uncertain','claimed',false);end if;
 if r.status<>'pending' then return jsonb_build_object('status',r.status,'claimed',false,'record',r.record);end if;
 token:=gen_random_uuid();update career_reminder_outbox set status='claimed',lease_token=token,lease_until=now()+interval '1 minute',attempts=attempts+1,updated_at=now() where user_id=p_user and reminder_id=p_id;
 return jsonb_build_object('status','claimed','claimed',true,'leaseToken',token,'reminder',r.payload);
end $$;


--
-- Name: career_reminder_enqueue(uuid, jsonb, bigint, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_reminder_enqueue(p_user uuid, p_reminder jsonb, p_version bigint, p_epoch bigint) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare a jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 if coalesce((a->>'version')::bigint,0) is distinct from p_version or coalesce((a->>'epoch')::bigint,0) is distinct from p_epoch or a->'paused'='true'::jsonb then raise exception 'stale or paused career worker';end if;
 if p_user is null or p_reminder is null or jsonb_typeof(p_reminder)<>'object' or p_reminder->>'user_id' is distinct from p_user::text or coalesce(length(p_reminder->>'reminder_id'),0) not between 1 and 200 or octet_length(p_reminder::text)>100000 then raise exception 'invalid reminder owner';end if;
 if exists(select 1 from career_reminder_outbox where user_id=p_user and reminder_id=p_reminder->>'reminder_id') then return jsonb_build_object('stored',true);end if;
 if not career_reminder_allowed(p_user,p_reminder) then raise exception 'inactive reminder interest';end if;
 insert into career_reminder_outbox(user_id,reminder_id,payload)values(p_user,p_reminder->>'reminder_id',p_reminder)on conflict(user_id,reminder_id)do nothing;
 return jsonb_build_object('stored',true);
end $$;


--
-- Name: career_reminder_list(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_reminder_list(p_user uuid) RETURNS jsonb
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select jsonb_build_object('reminders',coalesce(jsonb_agg(payload),'[]'::jsonb)) from (select payload from career_reminder_outbox where user_id=p_user and status in ('pending','claimed','uncertain') and payload is not null order by created_at,reminder_id limit 100) q;
$$;


--
-- Name: career_reminder_status(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_reminder_status(p_user uuid, p_id text) RETURNS jsonb
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select jsonb_build_object('status',status,'record',record,'leaseToken',lease_token,'reminder',payload) from career_reminder_outbox where user_id=p_user and reminder_id=p_id;
$$;


--
-- Name: career_task_account_v1(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_account_v1(p_user uuid) RETURNS jsonb
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select jsonb_build_object('exists',exists(select 1 from career_watch_kv where user_id=p_user and key='career:account'),'account',(select value from career_watch_kv where user_id=p_user and key='career:account'));
$$;


--
-- Name: career_task_begin_effect_v1(uuid, text, uuid, text, text, text, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_begin_effect_v1(p_user uuid, p_intent text, p_lease uuid, p_task text, p_operation text, p_effect_key text, p_bindings jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $_$
declare i career_task_intents_v1;a jsonb;e career_task_effects_v1;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select * into i from career_task_intents_v1 where user_id=p_user and intent_id=p_intent for update;
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 if a is null or i.intent_id is null or i.state<>'claimed' or p_lease is distinct from i.lease_token or p_task is distinct from i.task_id or i.expires_at<=now() or i.privacy_epoch is distinct from coalesce((a->>'epoch')::bigint,0) or i.authority_account_version is distinct from (a->>'version')::bigint or (p_operation<>'destination_readback' and a->'paused'='true'::jsonb) then raise exception 'task authority revoked';end if;
 if coalesce(p_operation,'') not in ('open','form','fill','answers','atReview','armForSubmit','submit','submissionState','destination_readback','read_public_page') or (i.binding->>'action'='research' and p_operation<>'read_public_page') or (i.binding->>'action'<>'research' and p_operation='read_public_page') or (i.binding->>'action'='prepare' and p_operation in ('armForSubmit','submit')) or (i.binding->>'action'='reconcile' and p_operation<>'destination_readback') then raise exception 'task operation not authorized';end if;
 if coalesce(p_effect_key,'') !~ '^[a-f0-9]{64}$' or p_bindings is distinct from i.binding then raise exception 'task effect binding mismatch';end if;
 if p_operation<>'destination_readback' and exists(select 1 from career_task_effects_v1 where user_id=p_user and task_id=p_task and state in ('started','uncertain')) then raise exception 'task effect outcome uncertain';end if;
 if i.spent+i.reserved>=i.budget_limit then raise exception 'task budget exhausted';end if;
 insert into career_task_effects_v1(user_id,intent_id,effect_key,task_id,operation,state) values(p_user,p_intent,p_effect_key,p_task,p_operation,'reserved') returning * into e;
 update career_task_intents_v1 set reserved=reserved+1 where user_id=p_user and intent_id=p_intent;
 return jsonb_build_object('token',e.token,'effectKey',e.effect_key,'state',e.state);
end $_$;


--
-- Name: career_task_claim_v1(uuid, text, text, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_claim_v1(p_user uuid, p_intent text, p_task text, p_lease uuid DEFAULT NULL::uuid) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $_$
declare i career_task_intents_v1;a jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select * into i from career_task_intents_v1 where user_id=p_user and intent_id=p_intent for update;
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 if i.intent_id is null then raise exception 'task intent missing';end if;
 if a is null or i.privacy_epoch is distinct from coalesce((a->>'epoch')::bigint,0) or i.authority_account_version is distinct from (a->>'version')::bigint or (i.binding->>'action'<>'reconcile' and a->'paused'='true'::jsonb) or i.expires_at<=now() or i.state not in ('queued','claimed') then raise exception 'task authority revoked';end if;
 if coalesce(p_task,'') !~ '^[a-f0-9]{32}$' or (i.task_id is not null and i.task_id<>p_task) then raise exception 'task binding mismatch';end if;
 if i.state='claimed' and (p_lease is null or p_lease is distinct from i.lease_token) then raise exception 'task claim busy';end if;
 update career_task_intents_v1 set task_id=p_task,state='claimed',lease_token=coalesce(lease_token,gen_random_uuid()),updated_at=now() where user_id=p_user and intent_id=p_intent returning * into i;
 return jsonb_build_object('version','career_task_intent/v1','intentId',p_intent,'userId',p_user,'taskId',i.task_id,'accountVersion',i.authority_account_version,'privacyEpoch',i.privacy_epoch,'leaseToken',i.lease_token,'binding',i.binding,'request',i.private_input);
end $_$;


--
-- Name: career_task_consume_effect_v1(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_consume_effect_v1(p_user uuid, p_token uuid) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare e career_task_effects_v1;i career_task_intents_v1;a jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select * into e from career_task_effects_v1 where user_id=p_user and token=p_token for update;
 select * into i from career_task_intents_v1 where user_id=p_user and intent_id=e.intent_id;
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 if e.token is null or e.state<>'reserved' or i.state<>'claimed' or i.expires_at<=now() or a is null or i.authority_account_version is distinct from (a->>'version')::bigint or i.privacy_epoch is distinct from coalesce((a->>'epoch')::bigint,0) or (e.operation<>'destination_readback' and a->'paused'='true'::jsonb) then raise exception 'task effect revoked or already consumed';end if;
 update career_task_effects_v1 set state='started' where user_id=p_user and token=p_token;
 return jsonb_build_object('consumed',true,'token',p_token);
end $$;


--
-- Name: career_task_control_hook_v1(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_control_hook_v1() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare u uuid; epoch_changed boolean;
begin
 if coalesce(new.key,old.key)<>'career:account' then return null;end if;
 u:=coalesce(new.user_id,old.user_id);
 perform pg_advisory_xact_lock(hashtextextended(u::text,0));
 epoch_changed:=tg_op='DELETE' or (tg_op='UPDATE' and coalesce((new.value->>'epoch')::bigint,0)<>coalesce((old.value->>'epoch')::bigint,0));
 update career_task_intents_v1 i set state=case when exists(select 1 from career_task_effects_v1 e where e.user_id=i.user_id and e.intent_id=i.intent_id and e.state in ('started','uncertain')) then 'uncertain' else 'cancelled' end,updated_at=now()
  where i.user_id=u and i.state in ('queued','claimed','uncertain') and (tg_op='DELETE' or new.value->'paused'='true'::jsonb or i.authority_account_version is distinct from (new.value->>'version')::bigint or i.privacy_epoch is distinct from coalesce((new.value->>'epoch')::bigint,0));
 if epoch_changed then
  update career_task_intents_v1 set private_input=null,result=null,
   binding=jsonb_build_object('version','career_task_intent/v1','intent_id',intent_id,'user_id',user_id,'action',binding->>'action','task_id',task_id,'request_hash',request_hash),updated_at=now() where user_id=u;
 end if;
 return null;
end $$;


--
-- Name: career_task_effect_status_v1(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_effect_status_v1(p_user uuid, p_token uuid) RETURNS jsonb
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select coalesce((select jsonb_build_object('state',state,'token',token,'beforeSha256',before_sha256,'afterSha256',after_sha256) from career_task_effects_v1 where user_id=p_user and token=p_token),'{}'::jsonb);
$$;


--
-- Name: career_task_finish_v1(uuid, text, uuid, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_finish_v1(p_user uuid, p_intent text, p_lease uuid, p_result jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare i career_task_intents_v1;a jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select * into i from career_task_intents_v1 where user_id=p_user and intent_id=p_intent for update;
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 if i.intent_id is null or p_lease is distinct from i.lease_token then raise exception 'task result owner mismatch';end if;
 if a is null or i.privacy_epoch is distinct from coalesce((a->>'epoch')::bigint,0) or i.authority_account_version is distinct from (a->>'version')::bigint or i.state not in ('claimed','completed') then return jsonb_build_object('state','revoked');end if;
 if p_result->>'userId' is distinct from p_user::text or p_result->>'id' is distinct from i.task_id or p_result->>'version' is distinct from 'career_task/v1' or octet_length(p_result::text)>1048576 then raise exception 'invalid owned task result';end if;
 if i.state='completed' and i.result is distinct from p_result then raise exception 'task result receipt conflict';end if;
 update career_task_intents_v1 set state='completed',result=p_result,updated_at=now() where user_id=p_user and intent_id=p_intent;
 return jsonb_build_object('state','completed');
end $$;


--
-- Name: career_task_pending_v1(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_pending_v1() RETURNS jsonb
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select jsonb_build_object('intents',coalesce(jsonb_agg(jsonb_build_object('userId',i.user_id,'intentId',i.intent_id,'binding',i.binding,'request',i.private_input)),'[]'::jsonb)) from (select i.* from career_task_intents_v1 i join career_watch_kv a on a.user_id=i.user_id and a.key='career:account' where i.state='queued' and i.expires_at>now() and i.authority_account_version=(a.value->>'version')::bigint and i.privacy_epoch=coalesce((a.value->>'epoch')::bigint,0) and (i.binding->>'action'='reconcile' or a.value->'paused' is distinct from 'true'::jsonb) order by i.created_at limit 50)i;
$$;


--
-- Name: career_task_result_v1(uuid, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_result_v1(p_user uuid, p_task text DEFAULT NULL::text, p_intent text DEFAULT NULL::text) RETURNS jsonb
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select coalesce((select jsonb_build_object('task',i.result,'researchProof',case when i.binding->>'action'='research' and i.result is not null then jsonb_build_object(
  'userId',i.user_id,'taskId',i.task_id,'intentId',i.intent_id,'binding',i.binding,
  'read',(select jsonb_build_object('state',e.state,'afterSha256',e.after_sha256,'admittedAt',e.created_at) from career_task_effects_v1 e where e.user_id=i.user_id and e.intent_id=i.intent_id and e.task_id=i.task_id and e.operation='read_public_page' order by e.created_at desc limit 1)) else null end)
  from career_task_intents_v1 i join career_watch_kv a on a.user_id=i.user_id and a.key='career:account' where i.user_id=p_user and (i.task_id=p_task or i.intent_id=p_intent) and i.privacy_epoch=coalesce((a.value->>'epoch')::bigint,0) order by i.updated_at desc limit 1),' {"task":null}'::jsonb);
$$;


--
-- Name: career_task_settle_effect_v1(uuid, uuid, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_settle_effect_v1(p_user uuid, p_token uuid, p_outcome text, p_before text, p_after text) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $_$
declare e career_task_effects_v1;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select * into e from career_task_effects_v1 where user_id=p_user and token=p_token for update;
 if e.token is null or coalesce(p_outcome,'') not in ('completed','definitely_failed','uncertain') or (p_before is not null and p_before !~ '^[a-f0-9]{64}$') or (p_after is not null and p_after !~ '^[a-f0-9]{64}$') then raise exception 'invalid effect settlement';end if;
 if e.state in ('completed','definitely_failed','uncertain') then
  if e.state is distinct from p_outcome or e.before_sha256 is distinct from p_before or e.after_sha256 is distinct from p_after then raise exception 'effect receipt conflict';end if;
 elsif e.state='started' or (e.state='reserved' and p_outcome='definitely_failed') then
  update career_task_effects_v1 set state=p_outcome,before_sha256=p_before,after_sha256=p_after where user_id=p_user and token=p_token;
  update career_task_intents_v1 set reserved=greatest(reserved-1,0),spent=spent+1 where user_id=p_user and intent_id=e.intent_id;
 else raise exception 'effect was not consumed';end if;
 return jsonb_build_object('state',p_outcome,'token',p_token,'beforeSha256',p_before,'afterSha256',p_after);
end $_$;


--
-- Name: career_task_turn_commit_v1(jsonb, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_turn_commit_v1(p_base jsonb, p_intent jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $_$
declare u uuid; a jsonb; saved jsonb; row_intent career_task_intents_v1; k text; action text; payload jsonb;
begin
 u:=(p_base->>'p_user')::uuid;action:=p_intent->>'action';
 if p_intent is null or jsonb_typeof(p_intent)<>'object' or p_intent->>'version' is distinct from 'career_task_intent/v1' then raise exception 'invalid task intent version';end if;
 for k in select jsonb_object_keys(p_intent) loop
  if k not in ('version','intent_id','user_id','thread_id','turn_key','request_hash','action','task_id','event_id','artifact_id','resume_sha256','payload_sha256','profile_sha256','destination','authority_account_version','privacy_epoch','research') then raise exception 'unknown task intent field';end if;
 end loop;
 if coalesce(p_intent->>'intent_id','') !~ '^[a-f0-9]{64}$' or p_intent->>'user_id' is distinct from u::text or p_intent->>'thread_id' is distinct from p_base->>'p_thread' or p_intent->>'turn_key' is distinct from p_base->>'p_key' or p_intent->>'request_hash' is distinct from p_base->>'p_hash' or coalesce(action,'') not in ('prepare','approve','reconcile','research') or coalesce(p_intent->>'event_id','') !~ '^[A-Za-z0-9_-]{1,128}$' then raise exception 'invalid task intent binding';end if;
 if action<>'research' and p_intent ? 'research' then raise exception 'research binding on another task kind';end if;
 if action='research' and (jsonb_typeof(p_intent->'research') is distinct from 'object' or (select count(*) from jsonb_object_keys(p_intent->'research'))<>2 or p_intent#>>'{research,url}' is distinct from p_intent->>'destination' or coalesce(p_intent->>'destination','') !~ '^https://[a-z0-9.-]+/' or coalesce(length(p_intent#>>'{research,question}'),0) not between 1 and 500 or p_intent->>'task_id' is not null or p_intent->>'artifact_id' is not null or p_intent->>'resume_sha256' is not null or p_intent->>'payload_sha256' is not null or p_intent->>'profile_sha256' is not null) then raise exception 'invalid research intent';end if;
 if action='prepare' and (coalesce(p_intent->>'artifact_id','') !~ '^[A-Za-z0-9_-]{1,160}$' or coalesce(p_intent->>'resume_sha256','') !~ '^[a-f0-9]{64}$' or p_intent->>'destination' is distinct from p_base#>>'{p_snapshot,stores,posting,url}' or p_base#>>'{p_snapshot,stores,posting,canonicalKey}' is null) then raise exception 'invalid preparation intent';end if;
 if action in ('approve','reconcile') and coalesce(p_intent->>'task_id','') !~ '^[a-f0-9]{32}$' then raise exception 'invalid task identity';end if;
 if action='approve' and (coalesce(p_intent->>'resume_sha256','') !~ '^[a-f0-9]{64}$' or coalesce(p_intent->>'payload_sha256','') !~ '^[a-f0-9]{64}$' or coalesce(p_intent->>'destination','') !~ '^https?://' or p_base->>'p_input' is distinct from 'Approve browser task '||(p_intent->>'task_id')) then raise exception 'invalid task approval';end if;
 if p_intent ? 'profile_sha256' and p_intent->>'profile_sha256' is not null and p_intent->>'profile_sha256' !~ '^[a-f0-9]{64}$' then raise exception 'invalid profile binding';end if;
 perform pg_advisory_xact_lock(hashtextextended(u::text,0));
 if exists(select 1 from career_task_intents_v1 where user_id=u and event_hash=encode(sha256(convert_to(u::text||':'||(p_intent->>'event_id'),'UTF8')),'hex') and intent_id<>p_intent->>'intent_id') then return jsonb_build_object('error','task_event_conflict');end if;
 select value into a from career_watch_kv where user_id=u and key='career:account';
 select * into row_intent from career_task_intents_v1 where user_id=u and intent_id=p_intent->>'intent_id';
 if row_intent.intent_id is not null then
  if row_intent.binding is distinct from p_intent then raise exception 'immutable task intent conflict';end if;
 end if;
 -- Call the existing commit, never a fork of its transaction/control logic.
 saved:=career_host_commit(u,(p_base->>'p_thread')::uuid,p_base->>'p_key',p_base->>'p_hash',(p_base->>'p_revision')::bigint,(p_base->>'p_account_version')::bigint,p_base->'p_snapshot',p_base->'p_patch',p_base->>'p_input',p_base->'p_response');
 if saved ? 'error' then return saved;end if;
 if saved->'replay'='true'::jsonb then
  if row_intent.intent_id is null then raise exception 'replayed task receipt missing intent';end if;
  return saved;
 end if;
 select value into a from career_watch_kv where user_id=u and key='career:account';
 if a is null or (a->>'version')::bigint is distinct from (p_intent->>'authority_account_version')::bigint or coalesce((a->>'epoch')::bigint,0) is distinct from (p_intent->>'privacy_epoch')::bigint or (action<>'reconcile' and a->'paused'='true'::jsonb) then raise exception 'task authority changed';end if;
 if p_base#>>'{p_response,task,intent_id}' is distinct from p_intent->>'intent_id' or p_base#>>'{p_response,task,userId}' is distinct from u::text or p_base#>'{p_response,task,bindings}' is distinct from p_intent then raise exception 'task response binding mismatch';end if;
 payload:=case when action='research' then jsonb_build_object('eventId',p_intent->>'event_id','research',p_intent->'research') when action='prepare' then jsonb_build_object('eventId',p_intent->>'event_id','posting',p_base#>'{p_snapshot,stores,posting}','artifactId',p_intent->>'artifact_id','resumeSha256',p_intent->>'resume_sha256') else null end;
 insert into career_task_intents_v1(user_id,intent_id,thread_id,turn_key,request_hash,event_hash,binding,private_input,authority_account_version,privacy_epoch,task_id)
 values(u,p_intent->>'intent_id',(p_base->>'p_thread')::uuid,p_base->>'p_key',p_base->>'p_hash',encode(sha256(convert_to(u::text||':'||(p_intent->>'event_id'),'UTF8')),'hex'),p_intent,payload,(p_intent->>'authority_account_version')::bigint,(p_intent->>'privacy_epoch')::bigint,p_intent->>'task_id');
 return saved;
end $_$;


--
-- Name: career_watch_cycle_commit(uuid, bigint, bigint, jsonb, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_watch_cycle_commit(p_user uuid, p_version bigint, p_epoch bigint, p_writes jsonb, p_reminders jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare a jsonb; entry record; reminder jsonb; saved jsonb; version bigint:=p_version;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 if coalesce((a->>'version')::bigint,0) is distinct from p_version or coalesce((a->>'epoch')::bigint,0) is distinct from p_epoch or a->'paused'='true'::jsonb then raise exception 'stale or paused career worker';end if;
 if p_writes is null or jsonb_typeof(p_writes)<>'object' or p_reminders is null or jsonb_typeof(p_reminders)<>'array' or octet_length(p_writes::text)>4194304 or jsonb_array_length(p_reminders)>1000 then raise exception 'invalid career cycle';end if;
 for entry in select key,value from jsonb_each(p_writes) loop
  saved:=career_watch_write(p_user,entry.key,entry.value,version,p_epoch);version:=(saved->>'version')::bigint;
 end loop;
 for reminder in select value from jsonb_array_elements(p_reminders) loop perform career_reminder_enqueue(p_user,reminder,version,p_epoch);end loop;
 return jsonb_build_object('version',version,'epoch',p_epoch);
end $$;


--
-- Name: career_watch_read(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_watch_read(p_user uuid, p_key text) RETURNS jsonb
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select jsonb_build_object('value',(select value from career_watch_kv where user_id=p_user and key=p_key),'version',coalesce((a.value->>'version')::bigint,0),'epoch',coalesce((a.value->>'epoch')::bigint,0),'paused',coalesce((a.value->>'paused')::boolean,false))
 from (select (select value from career_watch_kv where user_id=p_user and key='career:account') value) a;
$$;


--
-- Name: career_watch_write(uuid, text, jsonb, bigint, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_watch_write(p_user uuid, p_key text, p_value jsonb, p_version bigint, p_epoch bigint) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare a jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select value into a from career_watch_kv where user_id=p_user and key='career:account';a:=coalesce(a,'{"version":0,"epoch":0}'::jsonb);
 if (a->>'version')::bigint is distinct from p_version or (a->>'epoch')::bigint is distinct from p_epoch or a->'paused'='true'::jsonb then raise exception 'stale or paused career worker';end if;
 if p_user is null or p_key is null or not (p_key in ('career:watch-profile:'||p_user,'career:reminder-queue:'||p_user,'career:reminder-history:'||p_user) or (p_key like 'career:jobs:snapshot:board:%' and right(p_key,37)=':'||p_user)) or p_value is null or octet_length(p_value::text)>1048576 then raise exception 'invalid watch state';end if;
 if p_key='career:watch-profile:'||p_user and p_value->>'user_id' is distinct from p_user::text then raise exception 'watch owner mismatch';end if;
 insert into career_watch_kv(user_id,key,value) values(p_user,p_key,p_value) on conflict(user_id,key) do update set value=excluded.value,updated_at=now();
 a:=a||jsonb_build_object('version',p_version+1);
 insert into career_watch_kv(user_id,key,value) values(p_user,'career:account',a) on conflict(user_id,key) do update set value=excluded.value,updated_at=now();
 return jsonb_build_object('version',p_version+1,'epoch',p_epoch);
end $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    id uuid NOT NULL
);


--
-- Name: agent_flow_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_flow_state (
    thread_id uuid NOT NULL,
    user_id uuid NOT NULL,
    state jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_flow_state_state_check CHECK ((jsonb_typeof(state) = 'object'::text)),
    CONSTRAINT agent_flow_state_state_check1 CHECK ((pg_column_size(state) < 524288)),
    CONSTRAINT agent_flow_state_state_check2 CHECK ((NOT ((state)::text ~* '"(otp|one_time_code|password|passcode|card_number|pan|cvv|ssn)"\s*:'::text)))
);


--
-- Name: agent_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    thread_id uuid NOT NULL,
    role text,
    content text,
    meta jsonb,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT agent_messages_role_check CHECK ((role = ANY (ARRAY['user'::text, 'assistant'::text, 'system'::text])))
);


--
-- Name: agent_threads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_threads (
    id uuid NOT NULL,
    user_id uuid NOT NULL
);


--
-- Name: career_reminder_outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.career_reminder_outbox (
    user_id uuid NOT NULL,
    reminder_id text NOT NULL,
    payload jsonb,
    record jsonb,
    status text DEFAULT 'pending'::text NOT NULL,
    lease_token uuid,
    lease_until timestamp with time zone,
    attempts integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    delivered_at timestamp with time zone,
    seen_at timestamp with time zone,
    CONSTRAINT career_reminder_outbox_reminder_id_check CHECK (((length(reminder_id) >= 1) AND (length(reminder_id) <= 200))),
    CONSTRAINT career_reminder_outbox_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'claimed'::text, 'uncertain'::text, 'delivered'::text, 'cancelled'::text])))
);


--
-- Name: career_task_effects_v1; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.career_task_effects_v1 (
    user_id uuid NOT NULL,
    intent_id text NOT NULL,
    effect_key text NOT NULL,
    task_id text NOT NULL,
    operation text NOT NULL,
    token uuid DEFAULT gen_random_uuid() NOT NULL,
    state text NOT NULL,
    before_sha256 text,
    after_sha256 text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT career_task_effects_v1_state_check CHECK ((state = ANY (ARRAY['reserved'::text, 'started'::text, 'completed'::text, 'definitely_failed'::text, 'uncertain'::text])))
);


--
-- Name: career_task_intents_v1; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.career_task_intents_v1 (
    user_id uuid NOT NULL,
    intent_id text NOT NULL,
    thread_id uuid NOT NULL,
    turn_key text NOT NULL,
    request_hash text NOT NULL,
    event_hash text NOT NULL,
    binding jsonb NOT NULL,
    private_input jsonb,
    result jsonb,
    authority_account_version bigint NOT NULL,
    privacy_epoch bigint NOT NULL,
    state text DEFAULT 'queued'::text NOT NULL,
    task_id text,
    lease_token uuid,
    expires_at timestamp with time zone DEFAULT (now() + '00:10:00'::interval) NOT NULL,
    spent integer DEFAULT 0 NOT NULL,
    reserved integer DEFAULT 0 NOT NULL,
    budget_limit integer DEFAULT 120 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT career_task_intents_v1_intent_id_check CHECK ((intent_id ~ '^[a-f0-9]{64}$'::text)),
    CONSTRAINT career_task_intents_v1_state_check CHECK ((state = ANY (ARRAY['queued'::text, 'claimed'::text, 'completed'::text, 'cancelled'::text, 'uncertain'::text])))
);


--
-- Name: career_watch_kv; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.career_watch_kv (
    user_id uuid NOT NULL,
    key text NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE career_watch_kv; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.career_watch_kv IS 'MI-032 alerts host wiring: generic per-user KV for the career watch/assign state (152 watch profiles, reminder queues, seat history; 151 per-board snapshots; host delivery ledger). Written/read by scripts/career/alerts-host.mjs createSupabaseStore via the service role. Design: docs/career/alerts-host-wiring.md.';


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profiles (
    id uuid NOT NULL
);


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (id) FROM stdin;
00000000-0000-4000-8000-000000000001
00000000-0000-4000-8000-000000000002
\.


--
-- Data for Name: agent_flow_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_flow_state (thread_id, user_id, state, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000005	00000000-0000-4000-8000-000000000002	{"career": {"v": 1, "scope": {"userId": "00000000-0000-4000-8000-000000000002"}, "stores": {"profile": {"facts": [{"id": "SYN-2", "kind": "education", "text": "Synthetic undergraduate education", "unproven": false}], "basics": {"name": "Synthetic Owner B"}, "constraints": {}, "preferences": {"locations": ["Boston"]}}}}}	2026-10-16 21:24:03.654823+00
00000000-0000-4000-8000-000000000003	00000000-0000-4000-8000-000000000001	{"career": {"v": 1, "scope": {"userId": "00000000-0000-4000-8000-000000000001"}, "stores": {"globalPause": {"set": true, "source": "account_control"}}, "revision": 2}}	2026-10-16 21:24:05.351278+00
00000000-0000-4000-8000-000000000004	00000000-0000-4000-8000-000000000001	{"career": {"v": 1, "scope": {"userId": "00000000-0000-4000-8000-000000000001"}, "stores": {"globalPause": {"set": true, "source": "account_control"}}, "revision": 1, "privacy_epoch": 1}}	2026-10-16 21:24:05.351278+00
\.


--
-- Data for Name: agent_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_messages (id, thread_id, role, content, meta, created_at) FROM stdin;
2a68268c-0713-46a0-a9cd-ad7d1826e8ef	00000000-0000-4000-8000-000000000003	user	Research https://docs.python.org/3/library/csv.html — Read public CSV guidance. No profile intake or applications.	\N	2026-10-16 21:24:04.138053+00
2f0ebe2c-5041-4d84-881a-247b745f0e35	00000000-0000-4000-8000-000000000003	assistant	Public read-only research is queued. No browser outcome is claimed yet. Ask Research status 3bb0328cbfe62e3ff81500477f74fc3235f76dd1e4c7353cb351dc05f39703fb for saved evidence after the worker runs. The browser task intent is queued for a separate worker. No browser action is claimed by this chat reply; its immutable intent reference is attached.	{"career": true, "intent": "career_browser_task", "contained": false, "result_status": "queued", "career_turn_key": "research"}	2026-10-16 21:24:04.138053+00
2445349c-cb29-4f73-8a03-4184c1cac460	00000000-0000-4000-8000-000000000004	user	Forget my career profile	\N	2026-10-16 21:24:05.351278+00
76595d84-df6b-4015-a99d-f633baf2955f	00000000-0000-4000-8000-000000000004	assistant	I removed your saved career profile and active career context, cleared account watches and paused career work. Existing chat/audit records may retain earlier text; it is excluded from active context. No uncertain action was retried.	{"career": true, "intent": "career_profile_erased", "contained": false, "career_turn_key": "erase-published-receipt"}	2026-10-16 21:24:05.351278+00
\.


--
-- Data for Name: agent_threads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_threads (id, user_id) FROM stdin;
00000000-0000-4000-8000-000000000003	00000000-0000-4000-8000-000000000001
00000000-0000-4000-8000-000000000004	00000000-0000-4000-8000-000000000001
00000000-0000-4000-8000-000000000005	00000000-0000-4000-8000-000000000002
\.


--
-- Data for Name: career_reminder_outbox; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.career_reminder_outbox (user_id, reminder_id, payload, record, status, lease_token, lease_until, attempts, created_at, updated_at, delivered_at, seen_at) FROM stdin;
\.


--
-- Data for Name: career_task_effects_v1; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.career_task_effects_v1 (user_id, intent_id, effect_key, task_id, operation, token, state, before_sha256, after_sha256, created_at) FROM stdin;
00000000-0000-4000-8000-000000000001	3bb0328cbfe62e3ff81500477f74fc3235f76dd1e4c7353cb351dc05f39703fb	7489a2e5b73f78bed1d13870226ab8d474cac422497f8a7e9e64c95deb7bda31	e3954ee6b44c4da577842282596d0591	read_public_page	a45e7587-2805-4c65-9f30-ac4064b474b6	completed	7489a2e5b73f78bed1d13870226ab8d474cac422497f8a7e9e64c95deb7bda31	99fc983e369ad035ac311a5f4a716aa7989aaa3e6cde23d2b0233529f44ee6ad	2026-10-16 21:24:04.601904+00
\.


--
-- Data for Name: career_task_intents_v1; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.career_task_intents_v1 (user_id, intent_id, thread_id, turn_key, request_hash, event_hash, binding, private_input, result, authority_account_version, privacy_epoch, state, task_id, lease_token, expires_at, spent, reserved, budget_limit, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000001	3bb0328cbfe62e3ff81500477f74fc3235f76dd1e4c7353cb351dc05f39703fb	00000000-0000-4000-8000-000000000003	research	3581546d34e9ecabd996cfcbfddddef880c5ffbf912abe2a5ad3da3d4ecafed8	f88ed6b5749ac4496a2d66173d7e52ea5535100dc6ff5f2a0a26ffa4a08bc488	{"action": "research", "task_id": "e3954ee6b44c4da577842282596d0591", "user_id": "00000000-0000-4000-8000-000000000001", "version": "career_task_intent/v1", "intent_id": "3bb0328cbfe62e3ff81500477f74fc3235f76dd1e4c7353cb351dc05f39703fb", "request_hash": "3581546d34e9ecabd996cfcbfddddef880c5ffbf912abe2a5ad3da3d4ecafed8"}	\N	\N	1	0	completed	e3954ee6b44c4da577842282596d0591	c1332b4c-2fc0-42e6-b62c-c44e6dddc2fc	2026-10-16 21:34:04.138053+00	1	0	120	2026-10-16 21:24:04.138053+00	2026-10-16 21:24:05.351278+00
\.


--
-- Data for Name: career_watch_kv; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.career_watch_kv (user_id, key, value, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000001	career:turn:00000000-0000-4000-8000-000000000003:research	{"hash": "3581546d34e9ecabd996cfcbfddddef880c5ffbf912abe2a5ad3da3d4ecafed8", "epoch": 0, "response": null}	2026-10-16 21:24:05.351278+00
00000000-0000-4000-8000-000000000001	career:account	{"epoch": 1, "paused": true, "version": 2}	2026-10-16 21:24:05.351278+00
00000000-0000-4000-8000-000000000001	career:turn:00000000-0000-4000-8000-000000000004:erase-published-receipt	{"hash": "360f3a6834cb4bbbbac54ee9f25084d32b1bbadc4db7f1457d6d59549a7fe338", "epoch": 1, "response": {"meta": {"career": true, "intent": "career_profile_erased", "contained": false}, "reply": "I removed your saved career profile and active career context, cleared account watches and paused career work. Existing chat/audit records may retain earlier text; it is excluded from active context. No uncertain action was retried.", "action": null, "turn_key": "erase-published-receipt", "reminders": [], "thread_id": "00000000-0000-4000-8000-000000000004", "capabilities": {"portal_browser": {"reason": "The Node browser worker is not connected to this Edge handler.", "status": "NOT_WIRED"}, "job_alert_delivery": {"reason": "No alert scheduler or delivery worker is connected to this Edge handler. Saving a watch does not start polling or deliver reminders.", "status": "NOT_WIRED"}}}}	2026-10-16 21:24:05.351278+00
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.profiles (id) FROM stdin;
00000000-0000-4000-8000-000000000001
\.


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: agent_flow_state agent_flow_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_flow_state
    ADD CONSTRAINT agent_flow_state_pkey PRIMARY KEY (thread_id);


--
-- Name: agent_messages agent_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_messages
    ADD CONSTRAINT agent_messages_pkey PRIMARY KEY (id);


--
-- Name: agent_threads agent_threads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_threads
    ADD CONSTRAINT agent_threads_pkey PRIMARY KEY (id);


--
-- Name: career_reminder_outbox career_reminder_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_reminder_outbox
    ADD CONSTRAINT career_reminder_outbox_pkey PRIMARY KEY (user_id, reminder_id);


--
-- Name: career_task_effects_v1 career_task_effects_v1_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_task_effects_v1
    ADD CONSTRAINT career_task_effects_v1_pkey PRIMARY KEY (user_id, intent_id, effect_key);


--
-- Name: career_task_effects_v1 career_task_effects_v1_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_task_effects_v1
    ADD CONSTRAINT career_task_effects_v1_token_key UNIQUE (token);


--
-- Name: career_task_intents_v1 career_task_intents_v1_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_task_intents_v1
    ADD CONSTRAINT career_task_intents_v1_pkey PRIMARY KEY (user_id, intent_id);


--
-- Name: career_task_intents_v1 career_task_intents_v1_user_id_event_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_task_intents_v1
    ADD CONSTRAINT career_task_intents_v1_user_id_event_hash_key UNIQUE (user_id, event_hash);


--
-- Name: career_task_intents_v1 career_task_intents_v1_user_id_thread_id_turn_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_task_intents_v1
    ADD CONSTRAINT career_task_intents_v1_user_id_thread_id_turn_key_key UNIQUE (user_id, thread_id, turn_key);


--
-- Name: career_watch_kv career_watch_kv_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_watch_kv
    ADD CONSTRAINT career_watch_kv_pkey PRIMARY KEY (user_id, key);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: career_reminder_unseen; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX career_reminder_unseen ON public.career_reminder_outbox USING btree (user_id, delivered_at) WHERE ((status = 'delivered'::text) AND (seen_at IS NULL));


--
-- Name: career_task_one_submit_v1; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX career_task_one_submit_v1 ON public.career_task_effects_v1 USING btree (user_id, task_id) WHERE (operation = 'submit'::text);


--
-- Name: career_watch_kv career_task_account_control_v1; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER career_task_account_control_v1 AFTER INSERT OR DELETE OR UPDATE ON public.career_watch_kv FOR EACH ROW EXECUTE FUNCTION public.career_task_control_hook_v1();


--
-- Name: agent_flow_state agent_flow_state_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_flow_state
    ADD CONSTRAINT agent_flow_state_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.agent_threads(id) ON DELETE CASCADE;


--
-- Name: agent_flow_state agent_flow_state_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_flow_state
    ADD CONSTRAINT agent_flow_state_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: agent_messages agent_messages_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_messages
    ADD CONSTRAINT agent_messages_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.agent_threads(id);


--
-- Name: agent_threads agent_threads_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_threads
    ADD CONSTRAINT agent_threads_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id);


--
-- Name: career_reminder_outbox career_reminder_outbox_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_reminder_outbox
    ADD CONSTRAINT career_reminder_outbox_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: career_task_effects_v1 career_task_effects_v1_user_id_intent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_task_effects_v1
    ADD CONSTRAINT career_task_effects_v1_user_id_intent_id_fkey FOREIGN KEY (user_id, intent_id) REFERENCES public.career_task_intents_v1(user_id, intent_id);


--
-- Name: career_task_intents_v1 career_task_intents_v1_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_task_intents_v1
    ADD CONSTRAINT career_task_intents_v1_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.agent_threads(id);


--
-- Name: career_task_intents_v1 career_task_intents_v1_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_task_intents_v1
    ADD CONSTRAINT career_task_intents_v1_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: career_watch_kv career_watch_kv_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_watch_kv
    ADD CONSTRAINT career_watch_kv_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: profiles profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id);


--
-- Name: career_task_effects_v1 career_effect_backend_v1; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY career_effect_backend_v1 ON public.career_task_effects_v1 TO service_role USING (true) WITH CHECK (true);


--
-- Name: career_reminder_outbox career_reminder_backend; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY career_reminder_backend ON public.career_reminder_outbox TO service_role USING (true) WITH CHECK (true);


--
-- Name: career_reminder_outbox; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.career_reminder_outbox ENABLE ROW LEVEL SECURITY;

--
-- Name: career_task_intents_v1 career_task_backend_v1; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY career_task_backend_v1 ON public.career_task_intents_v1 TO service_role USING (true) WITH CHECK (true);


--
-- Name: career_task_effects_v1; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.career_task_effects_v1 ENABLE ROW LEVEL SECURITY;

--
-- Name: career_task_intents_v1; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.career_task_intents_v1 ENABLE ROW LEVEL SECURITY;

--
-- Name: career_watch_kv career_watch_backend; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY career_watch_backend ON public.career_watch_kv TO service_role USING (true) WITH CHECK (true);


--
-- Name: career_watch_kv; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.career_watch_kv ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict pPa8dkprPLhdtkjloTfdcQtrRsVKiTQ7ZDhyMFRnT4Fa9nI4FGMYVfGwtV6ILo1

