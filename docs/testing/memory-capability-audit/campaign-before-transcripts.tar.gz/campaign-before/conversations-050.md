# conversations-050

All conversations are synthetic. Full production handler, mock authentication/PostgREST and disabled model; no real outbound messages or provider actions.

## C02451 · M01 · Confirmed nickname recalls the right person · PASS

Expected: [{"say":"save bill as brother"},{"say":"yes"},{"say":"send brother 100","match":"Bill Kim.*@billk","outcome":"confirm"}]

### Trial 1

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bill Kim (brother, @billk).

User: send brother 100

Upmore: Set up $100.00 to Bill Kim (brother, @billk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bill Kim (brother, @billk).

User: send brother 100

Upmore: Set up $100.00 to Bill Kim (brother, @billk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bill Kim (brother, @billk).

User: send brother 100

Upmore: Set up $100.00 to Bill Kim (brother, @billk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02452 · M02 · Explicit remember phrasing persists an alias · PASS

Expected: [{"say":"remember Quinn Rao as my sister"},{"say":"yes"},{"say":"send sister 125","match":"Quinn Rao.*@quinnr","outcome":"confirm"}]

### Trial 1

User: remember Quinn Rao as my sister

Upmore: Save "sister" as your name for Quinn Rao (@quinnr)? Then "send sister 20" goes to Quinn Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Quinn Rao (sister, @quinnr).

User: send sister 125

Upmore: Set up $125.00 to Quinn Rao (sister, @quinnr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: remember Quinn Rao as my sister

Upmore: Save "sister" as your name for Quinn Rao (@quinnr)? Then "send sister 20" goes to Quinn Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Quinn Rao (sister, @quinnr).

User: send sister 125

Upmore: Set up $125.00 to Quinn Rao (sister, @quinnr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: remember Quinn Rao as my sister

Upmore: Save "sister" as your name for Quinn Rao (@quinnr)? Then "send sister 20" goes to Quinn Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Quinn Rao (sister, @quinnr).

User: send sister 125

Upmore: Set up $125.00 to Quinn Rao (sister, @quinnr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02453 · M03 · Natural relationship statement needs confirmation and persists · PASS

Expected: [{"say":"my dad is Bill Kim","match":"Save"},{"say":"yes"},{"say":"send dad 150","match":"Bill Kim","outcome":"confirm"}]

### Trial 1

User: my dad is Bill Kim

Upmore: Save "dad" as your name for Bill Kim (@billk)? Then "send dad 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Bill Kim (dad, @billk).

User: send dad 150

Upmore: Set up $150.00 to Bill Kim (dad, @billk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: my dad is Bill Kim

Upmore: Save "dad" as your name for Bill Kim (@billk)? Then "send dad 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Bill Kim (dad, @billk).

User: send dad 150

Upmore: Set up $150.00 to Bill Kim (dad, @billk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: my dad is Bill Kim

Upmore: Save "dad" as your name for Bill Kim (@billk)? Then "send dad 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Bill Kim (dad, @billk).

User: send dad 150

Upmore: Set up $150.00 to Bill Kim (dad, @billk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02454 · M04 · An alias is moved only to the newly confirmed person · PASS

Expected: [{"say":"save bill as brother"},{"say":"yes"},{"say":"brother is Quinn Rao"},{"say":"yes"},{"say":"send brother 100","match":"Quinn Rao","outcome":"confirm"}]

### Trial 1

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bill Kim (brother, @billk).

User: brother is Quinn Rao

Upmore: Save "brother" as your name for Quinn Rao (@quinnr)? Then "send brother 20" goes to Quinn Rao. "brother" means Bill Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Quinn Rao (brother, @quinnr).

User: send brother 100

Upmore: Set up $100.00 to Quinn Rao (brother, @quinnr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bill Kim (brother, @billk).

User: brother is Quinn Rao

Upmore: Save "brother" as your name for Quinn Rao (@quinnr)? Then "send brother 20" goes to Quinn Rao. "brother" means Bill Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Quinn Rao (brother, @quinnr).

User: send brother 100

Upmore: Set up $100.00 to Quinn Rao (brother, @quinnr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bill Kim (brother, @billk).

User: brother is Quinn Rao

Upmore: Save "brother" as your name for Quinn Rao (@quinnr)? Then "send brother 20" goes to Quinn Rao. "brother" means Bill Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Quinn Rao (brother, @quinnr).

User: send brother 100

Upmore: Set up $100.00 to Quinn Rao (brother, @quinnr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02455 · M05 · Rejected alias preserves the previous confirmed fact · PASS

Expected: [{"say":"save bill as brother"},{"say":"yes"},{"say":"brother is Quinn Rao"},{"say":"no"},{"say":"send brother 100","match":"Bill Kim","outcome":"confirm"}]

### Trial 1

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bill Kim (brother, @billk).

User: brother is Quinn Rao

Upmore: Save "brother" as your name for Quinn Rao (@quinnr)? Then "send brother 20" goes to Quinn Rao. "brother" means Bill Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 100

Upmore: Set up $100.00 to Bill Kim (brother, @billk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bill Kim (brother, @billk).

User: brother is Quinn Rao

Upmore: Save "brother" as your name for Quinn Rao (@quinnr)? Then "send brother 20" goes to Quinn Rao. "brother" means Bill Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 100

Upmore: Set up $100.00 to Bill Kim (brother, @billk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bill Kim (brother, @billk).

User: brother is Quinn Rao

Upmore: Save "brother" as your name for Quinn Rao (@quinnr)? Then "send brother 20" goes to Quinn Rao. "brother" means Bill Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 100

Upmore: Set up $100.00 to Bill Kim (brother, @billk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02456 · M06 · Amount correction preserves payee and replaces the old card · FAIL

Expected: [{"say":"send bill 100"},{"say":"make it 175","match":"175.00.*Bill Kim","outcome":"confirm"},{"say":"yes","match":"175.00","outcome":"staged"},{"state":"state.send.sends.0.amount_cents","equals":17500}]

### Trial 1

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: make it 175

Upmore: Make what $175.00? Nothing is open; say it in full, like "send Maya $50".

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"175.00.*Bill Kim","actual":{"thread_id":"118b0602-b00b-4283-8d3b-8b150089587c","reply":"Make what $175.00? Nothing is open; say it in full, like \"send Maya $50\".","action":null,"route":{"route":"fallthrough_ask","flow":null,"source":"deterministic","understood":true,"understood_first":true,"outcome":"ask","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}},{"step":2,"kind":"outcome","expected":"confirm","actual":{"thread_id":"118b0602-b00b-4283-8d3b-8b150089587c","reply":"Make what $175.00? Nothing is open; say it in full, like \"send Maya $50\".","action":null,"route":{"route":"fallthrough_ask","flow":null,"source":"deterministic","understood":true,"understood_first":true,"outcome":"ask","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}},{"step":3,"kind":"reply","expected":"175.00","actual":{"thread_id":"118b0602-b00b-4283-8d3b-8b150089587c","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"staged","actual":{"thread_id":"118b0602-b00b-4283-8d3b-8b150089587c","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"state","expected":{"path":"state.send.sends.0.amount_cents","value":17500}}]

### Trial 2

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: make it 175

Upmore: Make what $175.00? Nothing is open; say it in full, like "send Maya $50".

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"175.00.*Bill Kim","actual":{"thread_id":"60d4239e-c928-47af-8a89-bdded546e697","reply":"Make what $175.00? Nothing is open; say it in full, like \"send Maya $50\".","action":null,"route":{"route":"fallthrough_ask","flow":null,"source":"deterministic","understood":true,"understood_first":true,"outcome":"ask","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}},{"step":2,"kind":"outcome","expected":"confirm","actual":{"thread_id":"60d4239e-c928-47af-8a89-bdded546e697","reply":"Make what $175.00? Nothing is open; say it in full, like \"send Maya $50\".","action":null,"route":{"route":"fallthrough_ask","flow":null,"source":"deterministic","understood":true,"understood_first":true,"outcome":"ask","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}},{"step":3,"kind":"reply","expected":"175.00","actual":{"thread_id":"60d4239e-c928-47af-8a89-bdded546e697","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"staged","actual":{"thread_id":"60d4239e-c928-47af-8a89-bdded546e697","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"state","expected":{"path":"state.send.sends.0.amount_cents","value":17500}}]

### Trial 3

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: make it 175

Upmore: Make what $175.00? Nothing is open; say it in full, like "send Maya $50".

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"175.00.*Bill Kim","actual":{"thread_id":"7f382bd0-e8b8-4f88-bbf2-5c708454060f","reply":"Make what $175.00? Nothing is open; say it in full, like \"send Maya $50\".","action":null,"route":{"route":"fallthrough_ask","flow":null,"source":"deterministic","understood":true,"understood_first":true,"outcome":"ask","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}},{"step":2,"kind":"outcome","expected":"confirm","actual":{"thread_id":"7f382bd0-e8b8-4f88-bbf2-5c708454060f","reply":"Make what $175.00? Nothing is open; say it in full, like \"send Maya $50\".","action":null,"route":{"route":"fallthrough_ask","flow":null,"source":"deterministic","understood":true,"understood_first":true,"outcome":"ask","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}},{"step":3,"kind":"reply","expected":"175.00","actual":{"thread_id":"7f382bd0-e8b8-4f88-bbf2-5c708454060f","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"staged","actual":{"thread_id":"7f382bd0-e8b8-4f88-bbf2-5c708454060f","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"state","expected":{"path":"state.send.sends.0.amount_cents","value":17500}}]

## C02457 · M07 · Actually correction handles a different amount · FAIL

Expected: [{"say":"send bill 100"},{"say":"actually make it 250","match":"250.00.*Bill Kim","outcome":"confirm"},{"say":"yes","match":"250.00","outcome":"staged"}]

### Trial 1

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: actually make it 250

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"250.00.*Bill Kim","actual":{"thread_id":"44193780-67ae-42c4-a7d7-a64848c2b12d","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":2,"kind":"outcome","expected":"confirm","actual":{"thread_id":"44193780-67ae-42c4-a7d7-a64848c2b12d","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"reply","expected":"250.00","actual":{"thread_id":"44193780-67ae-42c4-a7d7-a64848c2b12d","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"staged","actual":{"thread_id":"44193780-67ae-42c4-a7d7-a64848c2b12d","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}}]

### Trial 2

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: actually make it 250

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"250.00.*Bill Kim","actual":{"thread_id":"0fdda7a6-646f-48aa-bab5-2091f175cfc7","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":2,"kind":"outcome","expected":"confirm","actual":{"thread_id":"0fdda7a6-646f-48aa-bab5-2091f175cfc7","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"reply","expected":"250.00","actual":{"thread_id":"0fdda7a6-646f-48aa-bab5-2091f175cfc7","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"staged","actual":{"thread_id":"0fdda7a6-646f-48aa-bab5-2091f175cfc7","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}}]

### Trial 3

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: actually make it 250

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"250.00.*Bill Kim","actual":{"thread_id":"99fe6c49-4026-48b2-ac6a-4dcbcac4796c","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":2,"kind":"outcome","expected":"confirm","actual":{"thread_id":"99fe6c49-4026-48b2-ac6a-4dcbcac4796c","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"reply","expected":"250.00","actual":{"thread_id":"99fe6c49-4026-48b2-ac6a-4dcbcac4796c","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"staged","actual":{"thread_id":"99fe6c49-4026-48b2-ac6a-4dcbcac4796c","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}}]

## C02458 · M08 · Bare currency correction retains payment context · FAIL

Expected: [{"say":"send bill 100"},{"say":"$62.50 instead","match":"62.50.*Bill Kim","outcome":"confirm"},{"say":"yes","match":"62.50","outcome":"staged"}]

### Trial 1

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: $62.50 instead

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"62.50.*Bill Kim","actual":{"thread_id":"a42b3707-50c7-47be-879f-4adb62895029","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":2,"kind":"outcome","expected":"confirm","actual":{"thread_id":"a42b3707-50c7-47be-879f-4adb62895029","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"reply","expected":"62.50","actual":{"thread_id":"a42b3707-50c7-47be-879f-4adb62895029","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"staged","actual":{"thread_id":"a42b3707-50c7-47be-879f-4adb62895029","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}}]

### Trial 2

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: $62.50 instead

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"62.50.*Bill Kim","actual":{"thread_id":"735eec21-2f7b-4a94-b620-d57757ffc979","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":2,"kind":"outcome","expected":"confirm","actual":{"thread_id":"735eec21-2f7b-4a94-b620-d57757ffc979","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"reply","expected":"62.50","actual":{"thread_id":"735eec21-2f7b-4a94-b620-d57757ffc979","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"staged","actual":{"thread_id":"735eec21-2f7b-4a94-b620-d57757ffc979","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}}]

### Trial 3

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: $62.50 instead

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"62.50.*Bill Kim","actual":{"thread_id":"d7d1a851-f40c-42ea-af65-1081216e3d0a","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":2,"kind":"outcome","expected":"confirm","actual":{"thread_id":"d7d1a851-f40c-42ea-af65-1081216e3d0a","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"reply","expected":"62.50","actual":{"thread_id":"d7d1a851-f40c-42ea-af65-1081216e3d0a","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"staged","actual":{"thread_id":"d7d1a851-f40c-42ea-af65-1081216e3d0a","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}}]

## C02459 · M09 · Split total correction recomputes every share before approval · PASS

Expected: [{"say":"split 300 with bill and quinn"},{"say":"make it 450","match":"150.00 each.*450.00","outcome":"confirm"},{"say":"yes","match":"150.00","outcome":"staged"}]

### Trial 1

User: split 300 with bill and quinn

Upmore: Request $100.00 each from Bill Kim (@billk) and Quinn Rao (@quinnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 450

Upmore: Got it. Request $150.00 each from Bill Kim (@billk) and Quinn Rao (@quinnr) in Venmo: $450.00 split 3 ways, yours $150.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Bill Kim (@billk) $150.00 in Venmo, Quinn Rao (@quinnr) $150.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 300 with bill and quinn

Upmore: Request $100.00 each from Bill Kim (@billk) and Quinn Rao (@quinnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 450

Upmore: Got it. Request $150.00 each from Bill Kim (@billk) and Quinn Rao (@quinnr) in Venmo: $450.00 split 3 ways, yours $150.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Bill Kim (@billk) $150.00 in Venmo, Quinn Rao (@quinnr) $150.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 300 with bill and quinn

Upmore: Request $100.00 each from Bill Kim (@billk) and Quinn Rao (@quinnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 450

Upmore: Got it. Request $150.00 each from Bill Kim (@billk) and Quinn Rao (@quinnr) in Venmo: $450.00 split 3 ways, yours $150.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Bill Kim (@billk) $150.00 in Venmo, Quinn Rao (@quinnr) $150.00 in Venmo. I'll mark each one paid when the money lands.

## C02460 · M10 · Rent setup correction retains recipient and due day · FAIL

Expected: [{"say":"pay my rent"},{"say":"bill $4500 on the 1st via Venmo"},{"say":"make it 4750","match":"4750.00.*Bill Kim.*1st","outcome":"confirm"},{"say":"yes"},{"state":"standing.0.amount_cents","equals":475000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 4750

Upmore: Got it. Set up rent: $4,750.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,750.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"4750.00.*Bill Kim.*1st","actual":{"thread_id":"1c3dff01-3e84-4b4f-9902-c6e8310d3c59","reply":"Got it. Set up rent: $4,750.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 4750

Upmore: Got it. Set up rent: $4,750.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,750.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"4750.00.*Bill Kim.*1st","actual":{"thread_id":"b0142e79-72df-405a-bf08-8dfc71ff8cae","reply":"Got it. Set up rent: $4,750.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 4750

Upmore: Got it. Set up rent: $4,750.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,750.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"4750.00.*Bill Kim.*1st","actual":{"thread_id":"d857b321-7166-4457-9c98-dedff82441f9","reply":"Got it. Set up rent: $4,750.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

## C02461 · M11 · Details refers to the pending payment · FAIL

Expected: [{"say":"send bill 100"},{"say":"details","match":"100.00.*Bill Kim","outcome":"details"}]

### Trial 1

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: details

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"100.00.*Bill Kim","actual":{"thread_id":"42476593-1b0c-498e-96cd-0cafa0babb65","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":2,"kind":"outcome","expected":"details","actual":{"thread_id":"42476593-1b0c-498e-96cd-0cafa0babb65","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}}]

### Trial 2

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: details

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"100.00.*Bill Kim","actual":{"thread_id":"3015b4d4-b83f-4c4e-9c5f-450481fb483d","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":2,"kind":"outcome","expected":"details","actual":{"thread_id":"3015b4d4-b83f-4c4e-9c5f-450481fb483d","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}}]

### Trial 3

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: details

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"100.00.*Bill Kim","actual":{"thread_id":"1d45e0cf-0ff8-4cb4-8408-0fe11f73f7c6","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":2,"kind":"outcome","expected":"details","actual":{"thread_id":"1d45e0cf-0ff8-4cb4-8408-0fe11f73f7c6","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}}]

## C02462 · M12 · A short yes resumes a serialized split · PASS

Expected: [{"say":"split 300 with bill and quinn"},{"say":"yes","match":"Bill Kim.*100.00.*Quinn Rao.*100.00","outcome":"staged"}]

### Trial 1

User: split 300 with bill and quinn

Upmore: Request $100.00 each from Bill Kim (@billk) and Quinn Rao (@quinnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Bill Kim (@billk) $100.00 in Venmo, Quinn Rao (@quinnr) $100.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 300 with bill and quinn

Upmore: Request $100.00 each from Bill Kim (@billk) and Quinn Rao (@quinnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Bill Kim (@billk) $100.00 in Venmo, Quinn Rao (@quinnr) $100.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 300 with bill and quinn

Upmore: Request $100.00 each from Bill Kim (@billk) and Quinn Rao (@quinnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Bill Kim (@billk) $100.00 in Venmo, Quinn Rao (@quinnr) $100.00 in Venmo. I'll mark each one paid when the money lands.

## C02463 · M13 · Cancellation that resolves the last discussed subscription · PASS

Expected: [{"say":"cancel netflix","match":"Netflix"},{"say":"cancel that","match":"Netflix"}]

### Trial 1

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 2

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 3

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

## C02464 · M14 · Stop rent refers to the confirmed standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"bill $4500 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent","match":"Rent is off","outcome":"rent_stopped"},{"state":"standing.0.status","equals":"stopped"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Bill Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Bill Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Bill Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

## C02465 · M15 · A contextual fee question retains payment identity and asks before acting · FAIL

Expected: [{"say":"send bill 100"},{"say":"what's the fee on that","match":"100.00.*Bill Kim"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: what's the fee on that

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"100.00.*Bill Kim","actual":{"thread_id":"a661170d-b725-4868-bb7c-cb3bac38364a","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"state","expected":{"path":"state.send.sends.length","value":0}}]

### Trial 2

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: what's the fee on that

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"100.00.*Bill Kim","actual":{"thread_id":"bf4d136e-eb20-4f61-9f91-1a37b19e90fd","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"state","expected":{"path":"state.send.sends.length","value":0}}]

### Trial 3

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: what's the fee on that

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"100.00.*Bill Kim","actual":{"thread_id":"5d3ca175-bbf0-4aff-bf8e-b6086a401d33","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"state","expected":{"path":"state.send.sends.length","value":0}}]

## C02466 · M16 · Rent setup answers retain the original goal · FAIL

Expected: [{"say":"pay my rent","match":"Who"},{"say":"bill $4500 on the 1st via Venmo","match":"4500.00.*Bill Kim","outcome":"confirm"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"standing.0.payee_handle","equals":"@billk"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"4500.00.*Bill Kim","actual":{"thread_id":"e9673a72-2cbd-49cf-870f-4a60e6aceb76","reply":"Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"4500.00.*Bill Kim","actual":{"thread_id":"3f627b75-f4a8-4288-b6df-a99b96278862","reply":"Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"4500.00.*Bill Kim","actual":{"thread_id":"afd7fcb9-5d33-44eb-b86f-d2f15395f71b","reply":"Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

## C02467 · M17 · New recipient handle and rail answers retain amount · PASS

Expected: [{"say":"send Dana 125"},{"say":"@danak"},{"say":"@danak"},{"say":"Venmo"},{"say":"@danak","match":"125.00.*Dana","outcome":"confirm"}]

### Trial 1

User: send Dana 125

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $125.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: send Dana 125

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $125.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: send Dana 125

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $125.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02468 · M18 · Split remembers total while asking who participated · PASS

Expected: [{"say":"split 300 with 2 friends"},{"say":"bill and quinn","match":"100.00 each.*300.00","outcome":"confirm"}]

### Trial 1

User: split 300 with 2 friends

Upmore: That's $100.00 each across 3 people. Who are the 2? I'll request $100.00 from each.

User: bill and quinn

Upmore: Request $100.00 each from Bill Kim (@billk) and Quinn Rao (@quinnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: split 300 with 2 friends

Upmore: That's $100.00 each across 3 people. Who are the 2? I'll request $100.00 from each.

User: bill and quinn

Upmore: Request $100.00 each from Bill Kim (@billk) and Quinn Rao (@quinnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: split 300 with 2 friends

Upmore: That's $100.00 each across 3 people. Who are the 2? I'll request $100.00 from each.

User: bill and quinn

Upmore: Request $100.00 each from Bill Kim (@billk) and Quinn Rao (@quinnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

## C02469 · M19 · Rent is remembered on the next independent invocation · FAIL

Expected: [{"say":"pay my rent"},{"say":"bill $4500 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent","match":"4500.00.*Bill Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Bill Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"4500.00.*Bill Kim","actual":{"thread_id":"ce48ee39-151d-4a35-a12c-da157985847c","reply":"Rent for November: $4,500.00 to Bill Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Bill Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"4500.00.*Bill Kim","actual":{"thread_id":"649555e5-3a4d-4d32-8da1-fa9beb459bc2","reply":"Rent for November: $4,500.00 to Bill Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Bill Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"4500.00.*Bill Kim","actual":{"thread_id":"02456809-7fa8-4201-aa74-fdfb00b806f6","reply":"Rent for November: $4,500.00 to Bill Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

## C02470 · M20 · An interrupted alias goal remains unconfirmed · PASS

Expected: [{"say":"save bill as brother"},{"say":"no"},{"state":"recipients.0.nickname","equals":null},{"say":"send brother 100","match":"handle","outcome":"ask"}]

### Trial 1

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 100

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 2

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 100

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 3

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 100

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

## C02471 · M21 · A staged payment is remembered without claiming completion · FAIL

Expected: [{"say":"send bill 100"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"Staged, not sent","actual":{"thread_id":"cf388552-2dfa-4b7b-a713-783ffa214d3d","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":2,"kind":"outcome","expected":"staged","actual":{"thread_id":"cf388552-2dfa-4b7b-a713-783ffa214d3d","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"reply","expected":"already staged","actual":{"thread_id":"cf388552-2dfa-4b7b-a713-783ffa214d3d","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"already_done","actual":{"thread_id":"cf388552-2dfa-4b7b-a713-783ffa214d3d","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"state","expected":{"path":"state.send.sends.length","value":1}}]

### Trial 2

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"Staged, not sent","actual":{"thread_id":"484bcbfe-94f2-440a-afc7-101fcff180d9","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":2,"kind":"outcome","expected":"staged","actual":{"thread_id":"484bcbfe-94f2-440a-afc7-101fcff180d9","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"reply","expected":"already staged","actual":{"thread_id":"484bcbfe-94f2-440a-afc7-101fcff180d9","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"already_done","actual":{"thread_id":"484bcbfe-94f2-440a-afc7-101fcff180d9","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"state","expected":{"path":"state.send.sends.length","value":1}}]

### Trial 3

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"Staged, not sent","actual":{"thread_id":"a5a67530-367d-4917-899e-a113b379f8c1","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":2,"kind":"outcome","expected":"staged","actual":{"thread_id":"a5a67530-367d-4917-899e-a113b379f8c1","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"reply","expected":"already staged","actual":{"thread_id":"a5a67530-367d-4917-899e-a113b379f8c1","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"already_done","actual":{"thread_id":"a5a67530-367d-4917-899e-a113b379f8c1","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"state","expected":{"path":"state.send.sends.length","value":1}}]

## C02472 · M22 · A staged split is remembered without duplicating it · PASS

Expected: [{"say":"split 300 with bill and quinn"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 300 with bill and quinn

Upmore: Request $100.00 each from Bill Kim (@billk) and Quinn Rao (@quinnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Bill Kim (@billk) $100.00 in Venmo, Quinn Rao (@quinnr) $100.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 300 with bill and quinn

Upmore: Request $100.00 each from Bill Kim (@billk) and Quinn Rao (@quinnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Bill Kim (@billk) $100.00 in Venmo, Quinn Rao (@quinnr) $100.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 300 with bill and quinn

Upmore: Request $100.00 each from Bill Kim (@billk) and Quinn Rao (@quinnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Bill Kim (@billk) $100.00 in Venmo, Quinn Rao (@quinnr) $100.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C02473 · M23 · A declined payment cannot be resurrected by yes · FAIL

Expected: [{"say":"send bill 100"},{"say":"no","match":"Nothing","outcome":"declined"},{"say":"yes","not":"^Staged, not sent"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: no

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"outcome","expected":"declined","actual":{"thread_id":"3c308c07-4550-4998-9891-9440bc1fa873","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"state","expected":{"path":"state.send.sends.length","value":0}}]

### Trial 2

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: no

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"outcome","expected":"declined","actual":{"thread_id":"5ec1316d-95f6-47ce-b600-b6108e99f492","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"state","expected":{"path":"state.send.sends.length","value":0}}]

### Trial 3

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: no

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"outcome","expected":"declined","actual":{"thread_id":"a77eaf5b-105c-4095-b917-47bd9431689b","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"state","expected":{"path":"state.send.sends.length","value":0}}]

## C02474 · M24 · Stopping rent prevents the next turn from claiming an active rule · PASS

Expected: [{"say":"pay my rent"},{"say":"bill $4500 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Bill Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Bill Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Bill Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C02475 · M25 · Status follow-up recalls staged versus sent · FAIL

Expected: [{"say":"send bill 100"},{"say":"yes"},{"say":"did it go through","match":"(?:not (?:yet )?(?:sent|posted)|staged|have not seen|waiting for.*post)"}]

### Trial 1

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: did it go through

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":3,"kind":"reply","expected":"(?:not (?:yet )?(?:sent|posted)|staged|have not seen|waiting for.*post)","actual":{"thread_id":"96065e61-d1a2-4db1-bf99-9183830bfa14","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}}]

### Trial 2

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: did it go through

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":3,"kind":"reply","expected":"(?:not (?:yet )?(?:sent|posted)|staged|have not seen|waiting for.*post)","actual":{"thread_id":"7dde6bfd-0243-441d-93c7-48548a645db6","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}}]

### Trial 3

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: did it go through

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":3,"kind":"reply","expected":"(?:not (?:yet )?(?:sent|posted)|staged|have not seen|waiting for.*post)","actual":{"thread_id":"74f33b98-124e-4a0d-a7d2-91bdfde6db67","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}}]

## C02476 · M26 · Unapproved nickname does not become a known fact · PASS

Expected: [{"say":"save bill as brother"},{"state":"recipients.0.nickname","equals":null},{"say":"no"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 2

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 3

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

## C02477 · M27 · Unapproved rent terms are not durable instructions · PASS

Expected: [{"say":"pay my rent"},{"say":"bill $4500 on the 1st via Venmo"},{"state":"standing.length","equals":0},{"say":"no"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

## C02478 · M28 · An expired payment card is restated and requires a fresh yes · FAIL

Expected: [{"say":"send bill 100"},{"minutes":11},{"say":"yes","match":"expired.*fresh","outcome":"confirm"},{"state":"state.send.sends.length","equals":0},{"say":"yes","match":"Staged","outcome":"staged"}]

### Trial 1

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":3,"kind":"reply","expected":"expired.*fresh","actual":{"thread_id":"76a6f092-f444-49d5-b253-de5edbbbed19","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"confirm","actual":{"thread_id":"76a6f092-f444-49d5-b253-de5edbbbed19","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"state","expected":{"path":"state.send.sends.length","value":0}},{"step":5,"kind":"reply","expected":"Staged","actual":{"thread_id":"76a6f092-f444-49d5-b253-de5edbbbed19","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":5,"kind":"outcome","expected":"staged","actual":{"thread_id":"76a6f092-f444-49d5-b253-de5edbbbed19","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}}]

### Trial 2

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":3,"kind":"reply","expected":"expired.*fresh","actual":{"thread_id":"f4ec9d98-a03d-46e9-843d-7a60f993c6c9","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"confirm","actual":{"thread_id":"f4ec9d98-a03d-46e9-843d-7a60f993c6c9","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"state","expected":{"path":"state.send.sends.length","value":0}},{"step":5,"kind":"reply","expected":"Staged","actual":{"thread_id":"f4ec9d98-a03d-46e9-843d-7a60f993c6c9","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":5,"kind":"outcome","expected":"staged","actual":{"thread_id":"f4ec9d98-a03d-46e9-843d-7a60f993c6c9","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}}]

### Trial 3

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":3,"kind":"reply","expected":"expired.*fresh","actual":{"thread_id":"b50a32ce-4284-4a0e-962a-412af34edfea","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"confirm","actual":{"thread_id":"b50a32ce-4284-4a0e-962a-412af34edfea","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"state","expected":{"path":"state.send.sends.length","value":0}},{"step":5,"kind":"reply","expected":"Staged","actual":{"thread_id":"b50a32ce-4284-4a0e-962a-412af34edfea","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":5,"kind":"outcome","expected":"staged","actual":{"thread_id":"b50a32ce-4284-4a0e-962a-412af34edfea","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}}]

## C02479 · M29 · An expired nickname card never writes a fact · PASS

Expected: [{"say":"save bill as brother"},{"minutes":11},{"say":"yes","match":"expired"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 2

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 3

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

## C02480 · M30 · A question containing yes does not approve a payment · FAIL

Expected: [{"say":"send bill 100"},{"say":"yes but is there a fee"},{"state":"state.send.sends.length","equals":0},{"say":"no"}]

### Trial 1

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes but is there a fee

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: no

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":3,"kind":"state","expected":{"path":"state.send.sends.length","value":0}}]

### Trial 2

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes but is there a fee

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: no

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":3,"kind":"state","expected":{"path":"state.send.sends.length","value":0}}]

### Trial 3

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes but is there a fee

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: no

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":3,"kind":"state","expected":{"path":"state.send.sends.length","value":0}}]

## C02481 · M31 · Moving to small talk explicitly drops the old payment · FAIL

Expected: [{"say":"send bill 100"},{"say":"what's a good movie","match":"dropped.*100.00"},{"say":"yes","not":"^Staged"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: what's a good movie

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"dropped.*100.00","actual":{"thread_id":"66d5cf4d-406e-40c6-8e11-bbdbf0fd70b2","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"state","expected":{"path":"state.send.sends.length","value":0}}]

### Trial 2

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: what's a good movie

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"dropped.*100.00","actual":{"thread_id":"a7cca70d-635d-4111-a2bf-072cff24e498","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"state","expected":{"path":"state.send.sends.length","value":0}}]

### Trial 3

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: what's a good movie

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"dropped.*100.00","actual":{"thread_id":"a027e594-698b-4315-a478-5dc01e057d91","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"state","expected":{"path":"state.send.sends.length","value":0}}]

## C02482 · M32 · Switching recipients makes the latest request authoritative · PASS

Expected: [{"say":"send bill 100"},{"say":"send quinn 150","match":"150.00.*Quinn Rao","outcome":"confirm"},{"say":"yes","match":"150.00.*Quinn Rao","outcome":"staged"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: send quinn 150

Upmore: Set up $150.00 to Quinn Rao (@quinnr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnr; 3. Enter $150.00; 4. Keep it private, then Pay. I'll confirm when $150.00 to Quinn Rao posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: send quinn 150

Upmore: Set up $150.00 to Quinn Rao (@quinnr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnr; 3. Enter $150.00; 4. Keep it private, then Pay. I'll confirm when $150.00 to Quinn Rao posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: send quinn 150

Upmore: Set up $150.00 to Quinn Rao (@quinnr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnr; 3. Enter $150.00; 4. Keep it private, then Pay. I'll confirm when $150.00 to Quinn Rao posts; if it hasn't by tonight, I'll ask.

## C02483 · M33 · A payment supersedes a pending split rather than approving both · FAIL

Expected: [{"say":"split 300 with bill and quinn"},{"say":"send bill 100","match":"100.00.*Bill Kim","outcome":"confirm"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"state":"state.split.staged.length","equals":0}]

### Trial 1

User: split 300 with bill and quinn

Upmore: Request $100.00 each from Bill Kim (@billk) and Quinn Rao (@quinnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send bill 100

Upmore: (I dropped the $200.00 split request since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"100.00.*Bill Kim","actual":{"thread_id":"1b3b4a40-a488-47d0-bdfe-98a409a4855f","reply":"(I dropped the $200.00 split request since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":2,"kind":"outcome","expected":"confirm","actual":{"thread_id":"1b3b4a40-a488-47d0-bdfe-98a409a4855f","reply":"(I dropped the $200.00 split request since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"reply","expected":"Staged, not sent","actual":{"thread_id":"1b3b4a40-a488-47d0-bdfe-98a409a4855f","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"staged","actual":{"thread_id":"1b3b4a40-a488-47d0-bdfe-98a409a4855f","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}}]

### Trial 2

User: split 300 with bill and quinn

Upmore: Request $100.00 each from Bill Kim (@billk) and Quinn Rao (@quinnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send bill 100

Upmore: (I dropped the $200.00 split request since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"100.00.*Bill Kim","actual":{"thread_id":"48cdfcb7-d694-4882-ba39-ac987b67892f","reply":"(I dropped the $200.00 split request since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":2,"kind":"outcome","expected":"confirm","actual":{"thread_id":"48cdfcb7-d694-4882-ba39-ac987b67892f","reply":"(I dropped the $200.00 split request since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"reply","expected":"Staged, not sent","actual":{"thread_id":"48cdfcb7-d694-4882-ba39-ac987b67892f","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"staged","actual":{"thread_id":"48cdfcb7-d694-4882-ba39-ac987b67892f","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}}]

### Trial 3

User: split 300 with bill and quinn

Upmore: Request $100.00 each from Bill Kim (@billk) and Quinn Rao (@quinnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send bill 100

Upmore: (I dropped the $200.00 split request since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"100.00.*Bill Kim","actual":{"thread_id":"4291ec49-b13a-402c-9369-6e834ac3375a","reply":"(I dropped the $200.00 split request since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":2,"kind":"outcome","expected":"confirm","actual":{"thread_id":"4291ec49-b13a-402c-9369-6e834ac3375a","reply":"(I dropped the $200.00 split request since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"reply","expected":"Staged, not sent","actual":{"thread_id":"4291ec49-b13a-402c-9369-6e834ac3375a","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"staged","actual":{"thread_id":"4291ec49-b13a-402c-9369-6e834ac3375a","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}}]

## C02484 · M34 · Switching from payment to rent keeps the new goal · PASS

Expected: [{"say":"send bill 100"},{"say":"pay my rent","match":"Who","outcome":"ask"},{"say":"bill $4500 on the 1st via Venmo"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 2

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 3

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

## C02485 · M35 · Never mind cancels an alias confirmation without saving · PASS

Expected: [{"say":"save bill as brother"},{"say":"never mind"},{"state":"recipients.0.nickname","equals":null},{"say":"yes","not":"^Saved:"}]

### Trial 1

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 2

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 3

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

## C02486 · M36 · Confirmed aliases survive a new conversation · PASS

Expected: [{"say":"save bill as brother"},{"say":"yes"},{"thread":"B"},{"say":"send brother 100","match":"Bill Kim","outcome":"confirm"}]

### Trial 1

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bill Kim (brother, @billk).

User: send brother 100

Upmore: Set up $100.00 to Bill Kim (brother, @billk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bill Kim (brother, @billk).

User: send brother 100

Upmore: Set up $100.00 to Bill Kim (brother, @billk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bill Kim (brother, @billk).

User: send brother 100

Upmore: Set up $100.00 to Bill Kim (brother, @billk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02487 · M37 · Standing rent survives a new conversation · FAIL

Expected: [{"say":"pay my rent"},{"say":"bill $4500 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"pay my rent","match":"4500.00.*Bill Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Bill Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"4500.00.*Bill Kim","actual":{"thread_id":"0ae9aa98-b892-4133-81bf-9481c77032b4","reply":"Rent for November: $4,500.00 to Bill Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Bill Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"4500.00.*Bill Kim","actual":{"thread_id":"7e5f8022-e09b-43e9-beb2-39a0099c75c9","reply":"Rent for November: $4,500.00 to Bill Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Bill Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"4500.00.*Bill Kim","actual":{"thread_id":"c5b8b4ee-b08c-4ff9-89c8-75fe5ea7f941","reply":"Rent for November: $4,500.00 to Bill Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

## C02488 · M38 · Unapproved thread A card cannot be approved in thread B · FAIL

Expected: [{"say":"send bill 100"},{"thread":"B"},{"say":"yes","not":"^Staged"},{"thread":"A"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":5,"kind":"state","expected":{"path":"state.send.sends.length","value":0}}]

### Trial 2

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":5,"kind":"state","expected":{"path":"state.send.sends.length","value":0}}]

### Trial 3

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":5,"kind":"state","expected":{"path":"state.send.sends.length","value":0}}]

## C02489 · M39 · A nickname correction in another session supersedes the old meaning · PASS

Expected: [{"say":"save bill as brother"},{"say":"yes"},{"thread":"B"},{"say":"brother is Quinn Rao"},{"say":"yes"},{"thread":"C"},{"say":"send brother 100","match":"Quinn Rao","outcome":"confirm"}]

### Trial 1

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bill Kim (brother, @billk).

User: brother is Quinn Rao

Upmore: Save "brother" as your name for Quinn Rao (@quinnr)? Then "send brother 20" goes to Quinn Rao. "brother" means Bill Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Quinn Rao (brother, @quinnr).

User: send brother 100

Upmore: Set up $100.00 to Quinn Rao (brother, @quinnr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bill Kim (brother, @billk).

User: brother is Quinn Rao

Upmore: Save "brother" as your name for Quinn Rao (@quinnr)? Then "send brother 20" goes to Quinn Rao. "brother" means Bill Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Quinn Rao (brother, @quinnr).

User: send brother 100

Upmore: Set up $100.00 to Quinn Rao (brother, @quinnr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bill Kim (brother, @billk).

User: brother is Quinn Rao

Upmore: Save "brother" as your name for Quinn Rao (@quinnr)? Then "send brother 20" goes to Quinn Rao. "brother" means Bill Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Quinn Rao (brother, @quinnr).

User: send brother 100

Upmore: Set up $100.00 to Quinn Rao (brother, @quinnr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02490 · M40 · Stopping rent in another session prevents future offers · PASS

Expected: [{"say":"pay my rent"},{"say":"bill $4500 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"stop rent"},{"thread":"C"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Bill Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Bill Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Bill Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C02491 · M41 · Repeating a staged approval does not stage twice after restore · FAIL

Expected: [{"say":"send bill 100"},{"say":"yes"},{"say":"yes","match":"already staged","outcome":"already_done"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":3,"kind":"reply","expected":"already staged","actual":{"thread_id":"ca4779f4-8993-49df-8c13-574a189125ca","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"already_done","actual":{"thread_id":"ca4779f4-8993-49df-8c13-574a189125ca","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"reply","expected":"already staged","actual":{"thread_id":"ca4779f4-8993-49df-8c13-574a189125ca","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"outcome","expected":"already_done","actual":{"thread_id":"ca4779f4-8993-49df-8c13-574a189125ca","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":5,"kind":"state","expected":{"path":"state.send.sends.length","value":1}}]

### Trial 2

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":3,"kind":"reply","expected":"already staged","actual":{"thread_id":"a90bc4ea-b48c-457d-90af-77479b3d00b9","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"already_done","actual":{"thread_id":"a90bc4ea-b48c-457d-90af-77479b3d00b9","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"reply","expected":"already staged","actual":{"thread_id":"a90bc4ea-b48c-457d-90af-77479b3d00b9","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"outcome","expected":"already_done","actual":{"thread_id":"a90bc4ea-b48c-457d-90af-77479b3d00b9","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":5,"kind":"state","expected":{"path":"state.send.sends.length","value":1}}]

### Trial 3

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":3,"kind":"reply","expected":"already staged","actual":{"thread_id":"946b8a1b-fd23-4be0-80f2-321c80c35fbc","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"already_done","actual":{"thread_id":"946b8a1b-fd23-4be0-80f2-321c80c35fbc","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"reply","expected":"already staged","actual":{"thread_id":"946b8a1b-fd23-4be0-80f2-321c80c35fbc","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"outcome","expected":"already_done","actual":{"thread_id":"946b8a1b-fd23-4be0-80f2-321c80c35fbc","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":5,"kind":"state","expected":{"path":"state.send.sends.length","value":1}}]

## C02492 · M42 · Rent setup retry leaves exactly one standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"bill $4500 on the 1st via Venmo"},{"say":"yes"},{"say":"yes","not":"^Rent is set up"},{"state":"standing.length","equals":1}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C02493 · M43 · Confirmed alias repeated is recognized as already known · PASS

Expected: [{"say":"save bill as brother"},{"say":"yes"},{"say":"save bill as brother","match":"already|Already|already means","outcome":"already_done"},{"state":"ops.length","equals":1}]

### Trial 1

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bill Kim (brother, @billk).

User: save bill as brother

Upmore: "brother" already means Bill Kim (brother, @billk). Nothing changed.

### Trial 2

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bill Kim (brother, @billk).

User: save bill as brother

Upmore: "brother" already means Bill Kim (brother, @billk). Nothing changed.

### Trial 3

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bill Kim (brother, @billk).

User: save bill as brother

Upmore: "brother" already means Bill Kim (brother, @billk). Nothing changed.

## C02494 · M44 · The same month rent is staged once across restored sessions · PASS

Expected: [{"say":"pay my rent"},{"say":"bill $4500 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"pay my rent","match":"already staged","outcome":"already_done"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Bill Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @billk; 3. Enter $4,500.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $4,500.00 to Bill Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $4,500.00 to Bill Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Bill Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @billk; 3. Enter $4,500.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $4,500.00 to Bill Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $4,500.00 to Bill Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Bill Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @billk; 3. Enter $4,500.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $4,500.00 to Bill Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $4,500.00 to Bill Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

## C02495 · M45 · Retried split approval preserves one set of requests · PASS

Expected: [{"say":"split 300 with bill and quinn"},{"say":"yes"},{"say":"yes"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 300 with bill and quinn

Upmore: Request $100.00 each from Bill Kim (@billk) and Quinn Rao (@quinnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Bill Kim (@billk) $100.00 in Venmo, Quinn Rao (@quinnr) $100.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 300 with bill and quinn

Upmore: Request $100.00 each from Bill Kim (@billk) and Quinn Rao (@quinnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Bill Kim (@billk) $100.00 in Venmo, Quinn Rao (@quinnr) $100.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 300 with bill and quinn

Upmore: Request $100.00 each from Bill Kim (@billk) and Quinn Rao (@quinnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Bill Kim (@billk) $100.00 in Venmo, Quinn Rao (@quinnr) $100.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C02496 · M46 · Nickname save failure is never reported as remembered · PASS

Expected: [{"say":"save bill as brother"},{"set":{"failRecipients":true}},{"say":"yes","match":"couldn't save"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 2

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 3

User: save bill as brother

Upmore: Save "brother" as your name for Bill Kim (@billk)? Then "send brother 20" goes to Bill Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

## C02497 · M47 · Rent save failure is never reported as a stored rule · PASS

Expected: [{"say":"pay my rent"},{"say":"bill $4500 on the 1st via Venmo"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*set|nothing was set up"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

## C02498 · M48 · A failed state write yields no approval card and retry is recoverable · FAIL

Expected: [{"set":{"failState":true}},{"say":"send bill 100","error":"state storage unavailable"},{"set":{"failState":false}},{"say":"send bill 100","match":"100.00.*Bill Kim","outcome":"confirm"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"storage","expected":"write failure withheld the card","actual":{"thread_id":"0beba83b-4259-48c5-8068-5f4544e71834","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"reply","expected":"100.00.*Bill Kim","actual":{"thread_id":"0beba83b-4259-48c5-8068-5f4544e71834","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"outcome","expected":"confirm","actual":{"thread_id":"0beba83b-4259-48c5-8068-5f4544e71834","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":5,"kind":"state","expected":{"path":"state.send.sends.length","value":0}}]

### Trial 2

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"storage","expected":"write failure withheld the card","actual":{"thread_id":"63b6a920-a167-4339-a6d4-463f4511b4dc","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"reply","expected":"100.00.*Bill Kim","actual":{"thread_id":"63b6a920-a167-4339-a6d4-463f4511b4dc","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"outcome","expected":"confirm","actual":{"thread_id":"63b6a920-a167-4339-a6d4-463f4511b4dc","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":5,"kind":"state","expected":{"path":"state.send.sends.length","value":0}}]

### Trial 3

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"storage","expected":"write failure withheld the card","actual":{"thread_id":"8d7d7980-ef7f-45b7-802e-741dc0f63c08","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"reply","expected":"100.00.*Bill Kim","actual":{"thread_id":"8d7d7980-ef7f-45b7-802e-741dc0f63c08","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"outcome","expected":"confirm","actual":{"thread_id":"8d7d7980-ef7f-45b7-802e-741dc0f63c08","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":5,"kind":"state","expected":{"path":"state.send.sends.length","value":0}}]

## C02499 · M49 · Unavailable facts cause an honest blocker and preserve the old card · FAIL

Expected: [{"say":"send bill 100"},{"set":{"unreadable":true}},{"say":"yes","match":"can't read.*Nothing was changed","outcome":"unavailable"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":3,"kind":"reply","expected":"can't read.*Nothing was changed","actual":{"thread_id":"2737327a-f422-4a79-9a59-bcccdd4c1f95","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"unavailable","actual":{"thread_id":"2737327a-f422-4a79-9a59-bcccdd4c1f95","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"state","expected":{"path":"state.send.sends.length","value":0}}]

### Trial 2

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":3,"kind":"reply","expected":"can't read.*Nothing was changed","actual":{"thread_id":"a0aa754d-ecc5-4236-b316-7c457fcc013c","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"unavailable","actual":{"thread_id":"a0aa754d-ecc5-4236-b316-7c457fcc013c","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"state","expected":{"path":"state.send.sends.length","value":0}}]

### Trial 3

User: send bill 100

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":3,"kind":"reply","expected":"can't read.*Nothing was changed","actual":{"thread_id":"9a5fc5eb-18c2-4988-a5e7-6f410a9b9323","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"unavailable","actual":{"thread_id":"9a5fc5eb-18c2-4988-a5e7-6f410a9b9323","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"state","expected":{"path":"state.send.sends.length","value":0}}]

## C02500 · M50 · A failed rent correction retains the prior confirmed terms · PASS

Expected: [{"say":"pay my rent"},{"say":"bill $4500 on the 1st via Venmo"},{"say":"yes"},{"say":"rent is 4750 now"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*change|rent stays as it was"},{"state":"standing.0.amount_cents","equals":450000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 4750 now

Upmore: Change rent (amount $4,500.00 to $4,750.00): $4,750.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 4750 now

Upmore: Change rent (amount $4,500.00 to $4,750.00): $4,750.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: bill $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Bill Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 4750 now

Upmore: Change rent (amount $4,500.00 to $4,750.00): $4,750.00 to Bill Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

