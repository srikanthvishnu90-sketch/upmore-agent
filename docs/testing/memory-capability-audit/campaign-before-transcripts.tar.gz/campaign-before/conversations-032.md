# conversations-032

All conversations are synthetic. Full production handler, mock authentication/PostgREST and disabled model; no real outbound messages or provider actions.

## C01551 · M01 · Confirmed nickname recalls the right person · PASS

Expected: [{"say":"save finn as brother"},{"say":"yes"},{"say":"send brother 40","match":"Finn Kim.*@finnk","outcome":"confirm"}]

### Trial 1

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Finn Kim (brother, @finnk).

User: send brother 40

Upmore: Set up $40.00 to Finn Kim (brother, @finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Finn Kim (brother, @finnk).

User: send brother 40

Upmore: Set up $40.00 to Finn Kim (brother, @finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Finn Kim (brother, @finnk).

User: send brother 40

Upmore: Set up $40.00 to Finn Kim (brother, @finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01552 · M02 · Explicit remember phrasing persists an alias · PASS

Expected: [{"say":"remember Zara Rao as my sister"},{"say":"yes"},{"say":"send sister 50","match":"Zara Rao.*@zarar","outcome":"confirm"}]

### Trial 1

User: remember Zara Rao as my sister

Upmore: Save "sister" as your name for Zara Rao (@zarar)? Then "send sister 20" goes to Zara Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Zara Rao (sister, @zarar).

User: send sister 50

Upmore: Set up $50.00 to Zara Rao (sister, @zarar) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: remember Zara Rao as my sister

Upmore: Save "sister" as your name for Zara Rao (@zarar)? Then "send sister 20" goes to Zara Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Zara Rao (sister, @zarar).

User: send sister 50

Upmore: Set up $50.00 to Zara Rao (sister, @zarar) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: remember Zara Rao as my sister

Upmore: Save "sister" as your name for Zara Rao (@zarar)? Then "send sister 20" goes to Zara Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Zara Rao (sister, @zarar).

User: send sister 50

Upmore: Set up $50.00 to Zara Rao (sister, @zarar) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01553 · M03 · Natural relationship statement needs confirmation and persists · PASS

Expected: [{"say":"my dad is Finn Kim","match":"Save"},{"say":"yes"},{"say":"send dad 60","match":"Finn Kim","outcome":"confirm"}]

### Trial 1

User: my dad is Finn Kim

Upmore: Save "dad" as your name for Finn Kim (@finnk)? Then "send dad 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Finn Kim (dad, @finnk).

User: send dad 60

Upmore: Set up $60.00 to Finn Kim (dad, @finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: my dad is Finn Kim

Upmore: Save "dad" as your name for Finn Kim (@finnk)? Then "send dad 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Finn Kim (dad, @finnk).

User: send dad 60

Upmore: Set up $60.00 to Finn Kim (dad, @finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: my dad is Finn Kim

Upmore: Save "dad" as your name for Finn Kim (@finnk)? Then "send dad 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Finn Kim (dad, @finnk).

User: send dad 60

Upmore: Set up $60.00 to Finn Kim (dad, @finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01554 · M04 · An alias is moved only to the newly confirmed person · PASS

Expected: [{"say":"save finn as brother"},{"say":"yes"},{"say":"brother is Zara Rao"},{"say":"yes"},{"say":"send brother 40","match":"Zara Rao","outcome":"confirm"}]

### Trial 1

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Finn Kim (brother, @finnk).

User: brother is Zara Rao

Upmore: Save "brother" as your name for Zara Rao (@zarar)? Then "send brother 20" goes to Zara Rao. "brother" means Finn Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Zara Rao (brother, @zarar).

User: send brother 40

Upmore: Set up $40.00 to Zara Rao (brother, @zarar) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Finn Kim (brother, @finnk).

User: brother is Zara Rao

Upmore: Save "brother" as your name for Zara Rao (@zarar)? Then "send brother 20" goes to Zara Rao. "brother" means Finn Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Zara Rao (brother, @zarar).

User: send brother 40

Upmore: Set up $40.00 to Zara Rao (brother, @zarar) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Finn Kim (brother, @finnk).

User: brother is Zara Rao

Upmore: Save "brother" as your name for Zara Rao (@zarar)? Then "send brother 20" goes to Zara Rao. "brother" means Finn Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Zara Rao (brother, @zarar).

User: send brother 40

Upmore: Set up $40.00 to Zara Rao (brother, @zarar) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01555 · M05 · Rejected alias preserves the previous confirmed fact · PASS

Expected: [{"say":"save finn as brother"},{"say":"yes"},{"say":"brother is Zara Rao"},{"say":"no"},{"say":"send brother 40","match":"Finn Kim","outcome":"confirm"}]

### Trial 1

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Finn Kim (brother, @finnk).

User: brother is Zara Rao

Upmore: Save "brother" as your name for Zara Rao (@zarar)? Then "send brother 20" goes to Zara Rao. "brother" means Finn Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 40

Upmore: Set up $40.00 to Finn Kim (brother, @finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Finn Kim (brother, @finnk).

User: brother is Zara Rao

Upmore: Save "brother" as your name for Zara Rao (@zarar)? Then "send brother 20" goes to Zara Rao. "brother" means Finn Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 40

Upmore: Set up $40.00 to Finn Kim (brother, @finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Finn Kim (brother, @finnk).

User: brother is Zara Rao

Upmore: Save "brother" as your name for Zara Rao (@zarar)? Then "send brother 20" goes to Zara Rao. "brother" means Finn Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 40

Upmore: Set up $40.00 to Finn Kim (brother, @finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01556 · M06 · Amount correction preserves payee and replaces the old card · PASS

Expected: [{"say":"send finn 40"},{"say":"make it 70","match":"70.00.*Finn Kim","outcome":"confirm"},{"say":"yes","match":"70.00","outcome":"staged"},{"state":"state.send.sends.0.amount_cents","equals":7000}]

### Trial 1

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 70

Upmore: Got it. Set up $70.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $70.00; 4. Keep it private, then Pay. I'll confirm when $70.00 to Finn Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 70

Upmore: Got it. Set up $70.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $70.00; 4. Keep it private, then Pay. I'll confirm when $70.00 to Finn Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 70

Upmore: Got it. Set up $70.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $70.00; 4. Keep it private, then Pay. I'll confirm when $70.00 to Finn Kim posts; if it hasn't by tonight, I'll ask.

## C01557 · M07 · Actually correction handles a different amount · PASS

Expected: [{"say":"send finn 40"},{"say":"actually make it 100","match":"100.00.*Finn Kim","outcome":"confirm"},{"say":"yes","match":"100.00","outcome":"staged"}]

### Trial 1

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 100

Upmore: Got it. Set up $100.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Finn Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 100

Upmore: Got it. Set up $100.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Finn Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 100

Upmore: Got it. Set up $100.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Finn Kim posts; if it hasn't by tonight, I'll ask.

## C01558 · M08 · Bare currency correction retains payment context · PASS

Expected: [{"say":"send finn 40"},{"say":"$25.00 instead","match":"25.00.*Finn Kim","outcome":"confirm"},{"say":"yes","match":"25.00","outcome":"staged"}]

### Trial 1

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $25.00 instead

Upmore: Got it. Set up $25.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $25.00; 4. Keep it private, then Pay. I'll confirm when $25.00 to Finn Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $25.00 instead

Upmore: Got it. Set up $25.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $25.00; 4. Keep it private, then Pay. I'll confirm when $25.00 to Finn Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $25.00 instead

Upmore: Got it. Set up $25.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $25.00; 4. Keep it private, then Pay. I'll confirm when $25.00 to Finn Kim posts; if it hasn't by tonight, I'll ask.

## C01559 · M09 · Split total correction recomputes every share before approval · PASS

Expected: [{"say":"split 120 with finn and zara"},{"say":"make it 180","match":"60.00 each.*180.00","outcome":"confirm"},{"say":"yes","match":"60.00","outcome":"staged"}]

### Trial 1

User: split 120 with finn and zara

Upmore: Request $40.00 each from Finn Kim (@finnk) and Zara Rao (@zarar) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 180

Upmore: Got it. Request $60.00 each from Finn Kim (@finnk) and Zara Rao (@zarar) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Finn Kim (@finnk) $60.00 in Venmo, Zara Rao (@zarar) $60.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 120 with finn and zara

Upmore: Request $40.00 each from Finn Kim (@finnk) and Zara Rao (@zarar) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 180

Upmore: Got it. Request $60.00 each from Finn Kim (@finnk) and Zara Rao (@zarar) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Finn Kim (@finnk) $60.00 in Venmo, Zara Rao (@zarar) $60.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 120 with finn and zara

Upmore: Request $40.00 each from Finn Kim (@finnk) and Zara Rao (@zarar) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 180

Upmore: Got it. Request $60.00 each from Finn Kim (@finnk) and Zara Rao (@zarar) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Finn Kim (@finnk) $60.00 in Venmo, Zara Rao (@zarar) $60.00 in Venmo. I'll mark each one paid when the money lands.

## C01560 · M10 · Rent setup correction retains recipient and due day · FAIL

Expected: [{"say":"pay my rent"},{"say":"finn $1800 on the 1st via Venmo"},{"say":"make it 1900","match":"1900.00.*Finn Kim.*1st","outcome":"confirm"},{"say":"yes"},{"state":"standing.0.amount_cents","equals":190000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 1900

Upmore: Got it. Set up rent: $1,900.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,900.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"1900.00.*Finn Kim.*1st","actual":{"thread_id":"55eee2ae-ca2c-4349-9eae-d6fe648a10b5","reply":"Got it. Set up rent: $1,900.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 1900

Upmore: Got it. Set up rent: $1,900.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,900.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"1900.00.*Finn Kim.*1st","actual":{"thread_id":"d61f5d69-7559-4a97-a0ca-aa3c4c0b2719","reply":"Got it. Set up rent: $1,900.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 1900

Upmore: Got it. Set up rent: $1,900.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,900.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"1900.00.*Finn Kim.*1st","actual":{"thread_id":"889deb08-28e7-40a4-a6ea-d9b9b8cf28a8","reply":"Got it. Set up rent: $1,900.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

## C01561 · M11 · Details refers to the pending payment · PASS

Expected: [{"say":"send finn 40"},{"say":"details","match":"40.00.*Finn Kim","outcome":"details"}]

### Trial 1

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $40.00 to Finn Kim on Venmo $40.00 to Finn Kim (@finnk) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

### Trial 2

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $40.00 to Finn Kim on Venmo $40.00 to Finn Kim (@finnk) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

### Trial 3

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $40.00 to Finn Kim on Venmo $40.00 to Finn Kim (@finnk) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

## C01562 · M12 · A short yes resumes a serialized split · PASS

Expected: [{"say":"split 120 with finn and zara"},{"say":"yes","match":"Finn Kim.*40.00.*Zara Rao.*40.00","outcome":"staged"}]

### Trial 1

User: split 120 with finn and zara

Upmore: Request $40.00 each from Finn Kim (@finnk) and Zara Rao (@zarar) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Finn Kim (@finnk) $40.00 in Venmo, Zara Rao (@zarar) $40.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 120 with finn and zara

Upmore: Request $40.00 each from Finn Kim (@finnk) and Zara Rao (@zarar) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Finn Kim (@finnk) $40.00 in Venmo, Zara Rao (@zarar) $40.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 120 with finn and zara

Upmore: Request $40.00 each from Finn Kim (@finnk) and Zara Rao (@zarar) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Finn Kim (@finnk) $40.00 in Venmo, Zara Rao (@zarar) $40.00 in Venmo. I'll mark each one paid when the money lands.

## C01563 · M13 · Cancellation that resolves the last discussed subscription · PASS

Expected: [{"say":"cancel netflix","match":"Netflix"},{"say":"cancel that","match":"Netflix"}]

### Trial 1

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 2

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 3

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

## C01564 · M14 · Stop rent refers to the confirmed standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"finn $1800 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent","match":"Rent is off","outcome":"rent_stopped"},{"state":"standing.0.status","equals":"stopped"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Finn Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Finn Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Finn Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

## C01565 · M15 · A contextual fee question retains payment identity and asks before acting · PASS

Expected: [{"say":"send finn 40"},{"say":"what's the fee on that","match":"40.00.*Finn Kim"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $40.00 to Finn Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $40.00 to Finn Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $40.00 to Finn Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C01566 · M16 · Rent setup answers retain the original goal · FAIL

Expected: [{"say":"pay my rent","match":"Who"},{"say":"finn $1800 on the 1st via Venmo","match":"1800.00.*Finn Kim","outcome":"confirm"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"standing.0.payee_handle","equals":"@finnk"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"1800.00.*Finn Kim","actual":{"thread_id":"68688124-1100-4b26-8cc6-385a0aea8ecd","reply":"Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"1800.00.*Finn Kim","actual":{"thread_id":"4e34c236-83b5-4190-bff1-dd5eeb922584","reply":"Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"1800.00.*Finn Kim","actual":{"thread_id":"4a4b0a49-47af-4434-b2c1-93fe5946ae57","reply":"Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

## C01567 · M17 · New recipient handle and rail answers retain amount · PASS

Expected: [{"say":"send Dana 50"},{"say":"@danak"},{"say":"@danak"},{"say":"Venmo"},{"say":"@danak","match":"50.00.*Dana","outcome":"confirm"}]

### Trial 1

User: send Dana 50

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $50.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: send Dana 50

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $50.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: send Dana 50

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $50.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01568 · M18 · Split remembers total while asking who participated · PASS

Expected: [{"say":"split 120 with 2 friends"},{"say":"finn and zara","match":"40.00 each.*120.00","outcome":"confirm"}]

### Trial 1

User: split 120 with 2 friends

Upmore: That's $40.00 each across 3 people. Who are the 2? I'll request $40.00 from each.

User: finn and zara

Upmore: Request $40.00 each from Finn Kim (@finnk) and Zara Rao (@zarar) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: split 120 with 2 friends

Upmore: That's $40.00 each across 3 people. Who are the 2? I'll request $40.00 from each.

User: finn and zara

Upmore: Request $40.00 each from Finn Kim (@finnk) and Zara Rao (@zarar) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: split 120 with 2 friends

Upmore: That's $40.00 each across 3 people. Who are the 2? I'll request $40.00 from each.

User: finn and zara

Upmore: Request $40.00 each from Finn Kim (@finnk) and Zara Rao (@zarar) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

## C01569 · M19 · Rent is remembered on the next independent invocation · FAIL

Expected: [{"say":"pay my rent"},{"say":"finn $1800 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent","match":"1800.00.*Finn Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Finn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"1800.00.*Finn Kim","actual":{"thread_id":"02ab0781-3d21-4ae7-872b-e7b523cc111b","reply":"Rent for November: $1,800.00 to Finn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Finn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"1800.00.*Finn Kim","actual":{"thread_id":"decfa6c1-69f5-4c33-8163-0a7eb8e148a6","reply":"Rent for November: $1,800.00 to Finn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Finn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"1800.00.*Finn Kim","actual":{"thread_id":"55e98387-5e1b-4a16-9fbb-d794b7d57fdc","reply":"Rent for November: $1,800.00 to Finn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

## C01570 · M20 · An interrupted alias goal remains unconfirmed · PASS

Expected: [{"say":"save finn as brother"},{"say":"no"},{"state":"recipients.0.nickname","equals":null},{"say":"send brother 40","match":"handle","outcome":"ask"}]

### Trial 1

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 40

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 2

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 40

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 3

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 40

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

## C01571 · M21 · A staged payment is remembered without claiming completion · PASS

Expected: [{"say":"send finn 40"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Finn Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $40.00 to Finn Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 2

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Finn Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $40.00 to Finn Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 3

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Finn Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $40.00 to Finn Kim for you to send in Venmo. A second yes doesn't stage it again.

## C01572 · M22 · A staged split is remembered without duplicating it · PASS

Expected: [{"say":"split 120 with finn and zara"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 120 with finn and zara

Upmore: Request $40.00 each from Finn Kim (@finnk) and Zara Rao (@zarar) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Finn Kim (@finnk) $40.00 in Venmo, Zara Rao (@zarar) $40.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 120 with finn and zara

Upmore: Request $40.00 each from Finn Kim (@finnk) and Zara Rao (@zarar) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Finn Kim (@finnk) $40.00 in Venmo, Zara Rao (@zarar) $40.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 120 with finn and zara

Upmore: Request $40.00 each from Finn Kim (@finnk) and Zara Rao (@zarar) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Finn Kim (@finnk) $40.00 in Venmo, Zara Rao (@zarar) $40.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C01573 · M23 · A declined payment cannot be resurrected by yes · PASS

Expected: [{"say":"send finn 40"},{"say":"no","match":"Nothing","outcome":"declined"},{"say":"yes","not":"^Staged, not sent"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 2

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 3

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

## C01574 · M24 · Stopping rent prevents the next turn from claiming an active rule · PASS

Expected: [{"say":"pay my rent"},{"say":"finn $1800 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Finn Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Finn Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Finn Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C01575 · M25 · Status follow-up recalls staged versus sent · PASS

Expected: [{"say":"send finn 40"},{"say":"yes"},{"say":"did it go through","match":"(?:not (?:yet )?(?:sent|posted)|staged|have not seen|waiting for.*post)"}]

### Trial 1

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Finn Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $40.00 to Finn Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

### Trial 2

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Finn Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $40.00 to Finn Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

### Trial 3

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Finn Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $40.00 to Finn Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

## C01576 · M26 · Unapproved nickname does not become a known fact · PASS

Expected: [{"say":"save finn as brother"},{"state":"recipients.0.nickname","equals":null},{"say":"no"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 2

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 3

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

## C01577 · M27 · Unapproved rent terms are not durable instructions · PASS

Expected: [{"say":"pay my rent"},{"say":"finn $1800 on the 1st via Venmo"},{"state":"standing.length","equals":0},{"say":"no"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

## C01578 · M28 · An expired payment card is restated and requires a fresh yes · PASS

Expected: [{"say":"send finn 40"},{"minutes":11},{"say":"yes","match":"expired.*fresh","outcome":"confirm"},{"state":"state.send.sends.length","equals":0},{"say":"yes","match":"Staged","outcome":"staged"}]

### Trial 1

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Finn Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Finn Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Finn Kim posts; if it hasn't by tonight, I'll ask.

## C01579 · M29 · An expired nickname card never writes a fact · PASS

Expected: [{"say":"save finn as brother"},{"minutes":11},{"say":"yes","match":"expired"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 2

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 3

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

## C01580 · M30 · A question containing yes does not approve a payment · PASS

Expected: [{"say":"send finn 40"},{"say":"yes but is there a fee"},{"state":"state.send.sends.length","equals":0},{"say":"no"}]

### Trial 1

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

### Trial 2

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

### Trial 3

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

## C01581 · M31 · Moving to small talk explicitly drops the old payment · PASS

Expected: [{"say":"send finn 40"},{"say":"what's a good movie","match":"dropped.*40.00"},{"say":"yes","not":"^Staged"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $40.00 to Finn Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $40.00 to Finn Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $40.00 to Finn Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C01582 · M32 · Switching recipients makes the latest request authoritative · PASS

Expected: [{"say":"send finn 40"},{"say":"send zara 60","match":"60.00.*Zara Rao","outcome":"confirm"},{"say":"yes","match":"60.00.*Zara Rao","outcome":"staged"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send zara 60

Upmore: I dropped the earlier card. Set up $60.00 to Zara Rao (@zarar) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @zarar; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Zara Rao posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send zara 60

Upmore: I dropped the earlier card. Set up $60.00 to Zara Rao (@zarar) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @zarar; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Zara Rao posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send zara 60

Upmore: I dropped the earlier card. Set up $60.00 to Zara Rao (@zarar) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @zarar; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Zara Rao posts; if it hasn't by tonight, I'll ask.

## C01583 · M33 · A payment supersedes a pending split rather than approving both · PASS

Expected: [{"say":"split 120 with finn and zara"},{"say":"send finn 40","match":"40.00.*Finn Kim","outcome":"confirm"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"state":"state.split.staged.length","equals":0}]

### Trial 1

User: split 120 with finn and zara

Upmore: Request $40.00 each from Finn Kim (@finnk) and Zara Rao (@zarar) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send finn 40

Upmore: I dropped the earlier card. Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Finn Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: split 120 with finn and zara

Upmore: Request $40.00 each from Finn Kim (@finnk) and Zara Rao (@zarar) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send finn 40

Upmore: I dropped the earlier card. Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Finn Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: split 120 with finn and zara

Upmore: Request $40.00 each from Finn Kim (@finnk) and Zara Rao (@zarar) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send finn 40

Upmore: I dropped the earlier card. Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Finn Kim posts; if it hasn't by tonight, I'll ask.

## C01584 · M34 · Switching from payment to rent keeps the new goal · PASS

Expected: [{"say":"send finn 40"},{"say":"pay my rent","match":"Who","outcome":"ask"},{"say":"finn $1800 on the 1st via Venmo"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 2

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 3

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

## C01585 · M35 · Never mind cancels an alias confirmation without saving · PASS

Expected: [{"say":"save finn as brother"},{"say":"never mind"},{"state":"recipients.0.nickname","equals":null},{"say":"yes","not":"^Saved:"}]

### Trial 1

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 2

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 3

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

## C01586 · M36 · Confirmed aliases survive a new conversation · PASS

Expected: [{"say":"save finn as brother"},{"say":"yes"},{"thread":"B"},{"say":"send brother 40","match":"Finn Kim","outcome":"confirm"}]

### Trial 1

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Finn Kim (brother, @finnk).

User: send brother 40

Upmore: Set up $40.00 to Finn Kim (brother, @finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Finn Kim (brother, @finnk).

User: send brother 40

Upmore: Set up $40.00 to Finn Kim (brother, @finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Finn Kim (brother, @finnk).

User: send brother 40

Upmore: Set up $40.00 to Finn Kim (brother, @finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01587 · M37 · Standing rent survives a new conversation · FAIL

Expected: [{"say":"pay my rent"},{"say":"finn $1800 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"pay my rent","match":"1800.00.*Finn Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Finn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"1800.00.*Finn Kim","actual":{"thread_id":"33982ab8-d117-49ca-921e-bf479203652f","reply":"Rent for November: $1,800.00 to Finn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Finn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"1800.00.*Finn Kim","actual":{"thread_id":"8d0ba91d-fbef-4c0f-bdf0-ccbfd78fb848","reply":"Rent for November: $1,800.00 to Finn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Finn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"1800.00.*Finn Kim","actual":{"thread_id":"75a8cded-6034-47d7-81b3-e5b916e698b2","reply":"Rent for November: $1,800.00 to Finn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

## C01588 · M38 · Unapproved thread A card cannot be approved in thread B · PASS

Expected: [{"say":"send finn 40"},{"thread":"B"},{"say":"yes","not":"^Staged"},{"thread":"A"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C01589 · M39 · A nickname correction in another session supersedes the old meaning · PASS

Expected: [{"say":"save finn as brother"},{"say":"yes"},{"thread":"B"},{"say":"brother is Zara Rao"},{"say":"yes"},{"thread":"C"},{"say":"send brother 40","match":"Zara Rao","outcome":"confirm"}]

### Trial 1

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Finn Kim (brother, @finnk).

User: brother is Zara Rao

Upmore: Save "brother" as your name for Zara Rao (@zarar)? Then "send brother 20" goes to Zara Rao. "brother" means Finn Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Zara Rao (brother, @zarar).

User: send brother 40

Upmore: Set up $40.00 to Zara Rao (brother, @zarar) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Finn Kim (brother, @finnk).

User: brother is Zara Rao

Upmore: Save "brother" as your name for Zara Rao (@zarar)? Then "send brother 20" goes to Zara Rao. "brother" means Finn Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Zara Rao (brother, @zarar).

User: send brother 40

Upmore: Set up $40.00 to Zara Rao (brother, @zarar) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Finn Kim (brother, @finnk).

User: brother is Zara Rao

Upmore: Save "brother" as your name for Zara Rao (@zarar)? Then "send brother 20" goes to Zara Rao. "brother" means Finn Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Zara Rao (brother, @zarar).

User: send brother 40

Upmore: Set up $40.00 to Zara Rao (brother, @zarar) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01590 · M40 · Stopping rent in another session prevents future offers · PASS

Expected: [{"say":"pay my rent"},{"say":"finn $1800 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"stop rent"},{"thread":"C"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Finn Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Finn Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Finn Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C01591 · M41 · Repeating a staged approval does not stage twice after restore · PASS

Expected: [{"say":"send finn 40"},{"say":"yes"},{"say":"yes","match":"already staged","outcome":"already_done"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Finn Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $40.00 to Finn Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $40.00 to Finn Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 2

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Finn Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $40.00 to Finn Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $40.00 to Finn Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 3

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Finn Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $40.00 to Finn Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $40.00 to Finn Kim for you to send in Venmo. A second yes doesn't stage it again.

## C01592 · M42 · Rent setup retry leaves exactly one standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"finn $1800 on the 1st via Venmo"},{"say":"yes"},{"say":"yes","not":"^Rent is set up"},{"state":"standing.length","equals":1}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C01593 · M43 · Confirmed alias repeated is recognized as already known · PASS

Expected: [{"say":"save finn as brother"},{"say":"yes"},{"say":"save finn as brother","match":"already|Already|already means","outcome":"already_done"},{"state":"ops.length","equals":1}]

### Trial 1

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Finn Kim (brother, @finnk).

User: save finn as brother

Upmore: "brother" already means Finn Kim (brother, @finnk). Nothing changed.

### Trial 2

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Finn Kim (brother, @finnk).

User: save finn as brother

Upmore: "brother" already means Finn Kim (brother, @finnk). Nothing changed.

### Trial 3

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Finn Kim (brother, @finnk).

User: save finn as brother

Upmore: "brother" already means Finn Kim (brother, @finnk). Nothing changed.

## C01594 · M44 · The same month rent is staged once across restored sessions · PASS

Expected: [{"say":"pay my rent"},{"say":"finn $1800 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"pay my rent","match":"already staged","outcome":"already_done"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Finn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $1,800.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $1,800.00 to Finn Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $1,800.00 to Finn Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Finn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $1,800.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $1,800.00 to Finn Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $1,800.00 to Finn Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Finn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnk; 3. Enter $1,800.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $1,800.00 to Finn Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $1,800.00 to Finn Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

## C01595 · M45 · Retried split approval preserves one set of requests · PASS

Expected: [{"say":"split 120 with finn and zara"},{"say":"yes"},{"say":"yes"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 120 with finn and zara

Upmore: Request $40.00 each from Finn Kim (@finnk) and Zara Rao (@zarar) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Finn Kim (@finnk) $40.00 in Venmo, Zara Rao (@zarar) $40.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 120 with finn and zara

Upmore: Request $40.00 each from Finn Kim (@finnk) and Zara Rao (@zarar) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Finn Kim (@finnk) $40.00 in Venmo, Zara Rao (@zarar) $40.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 120 with finn and zara

Upmore: Request $40.00 each from Finn Kim (@finnk) and Zara Rao (@zarar) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Finn Kim (@finnk) $40.00 in Venmo, Zara Rao (@zarar) $40.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C01596 · M46 · Nickname save failure is never reported as remembered · PASS

Expected: [{"say":"save finn as brother"},{"set":{"failRecipients":true}},{"say":"yes","match":"couldn't save"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 2

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 3

User: save finn as brother

Upmore: Save "brother" as your name for Finn Kim (@finnk)? Then "send brother 20" goes to Finn Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

## C01597 · M47 · Rent save failure is never reported as a stored rule · PASS

Expected: [{"say":"pay my rent"},{"say":"finn $1800 on the 1st via Venmo"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*set|nothing was set up"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

## C01598 · M48 · A failed state write yields no approval card and retry is recoverable · PASS

Expected: [{"set":{"failState":true}},{"say":"send finn 40","error":"state storage unavailable"},{"set":{"failState":false}},{"say":"send finn 40","match":"40.00.*Finn Kim","outcome":"confirm"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send finn 40

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: send finn 40

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: send finn 40

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01599 · M49 · Unavailable facts cause an honest blocker and preserve the old card · PASS

Expected: [{"say":"send finn 40"},{"set":{"unreadable":true}},{"say":"yes","match":"can't read.*Nothing was changed","outcome":"unavailable"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

### Trial 2

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

### Trial 3

User: send finn 40

Upmore: Set up $40.00 to Finn Kim (@finnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

## C01600 · M50 · A failed rent correction retains the prior confirmed terms · PASS

Expected: [{"say":"pay my rent"},{"say":"finn $1800 on the 1st via Venmo"},{"say":"yes"},{"say":"rent is 1900 now"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*change|rent stays as it was"},{"state":"standing.0.amount_cents","equals":180000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 1900 now

Upmore: Change rent (amount $1,800.00 to $1,900.00): $1,900.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 1900 now

Upmore: Change rent (amount $1,800.00 to $1,900.00): $1,900.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: finn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Finn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 1900 now

Upmore: Change rent (amount $1,800.00 to $1,900.00): $1,900.00 to Finn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

