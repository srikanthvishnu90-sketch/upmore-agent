# Seven-dimension conversation campaign

Actual local agent-chat handler. Authentication and PostgREST are synthetic. Provider model disabled, no actual delivery or financial rail. Mechanical workflow metrics have narrower scope than semantic awareness/fluency. Cases are parameterized variants across 100 scenario families, not 3,500 independent capabilities.

Build: 2e4fea0c30a36534b83dfe97dd9f5b64883566cd. Router source SHA-256: 99754033f649238368d95be3d2e53fc88d6ffadc0807e2aaa84d7c4255a9a568.
Executed 3500 scenario variants across 100 families, 3 trials each; 2179 unique input conversations.
PASS 2319; FAIL 241; BLOCKED 940. Blocked/unrun cases are never passes.
Local wall time: 1472.6 seconds; not a live-model latency benchmark.

| Dimension | Pass | Fail | Evaluated | Blocked | Not run | Not applicable | % of evaluated |
| --- | --- | --- | --- | --- | --- | --- | --- |
| capability | 2319 | 241 | 2560 | 940 | 0 | 0 | 90.6 |
| awareness | 1117 | 193 | 1310 | 940 | 0 | 1250 | 85.3 |
| fluency | 0 | 0 | 0 | 1000 | 2500 | 0 | unmeasured |
| memory | 2319 | 181 | 2500 | 1000 | 0 | 0 | 92.8 |
| planning | 413 | 87 | 500 | 1000 | 0 | 2000 | 82.6 |
| tool_grounding | 2500 | 0 | 2500 | 1000 | 0 | 0 | 100.0 |
| recovery_safety | 1201 | 49 | 1250 | 1000 | 0 | 1250 | 96.1 |

Fluency needs an independent semantic judge. Surface checks are recorded per trial but are not substituted for a fluency score. Model-backed semantic memory remains blocked; deterministic workflow memory has its own scope. No combined "perfection" score is manufactured.

## Every conversation

- [conversations-001.md](conversations-001.md) · 50 scenarios · [complete trial/state JSONL](conversations-001.jsonl)
- [conversations-002.md](conversations-002.md) · 50 scenarios · [complete trial/state JSONL](conversations-002.jsonl)
- [conversations-003.md](conversations-003.md) · 50 scenarios · [complete trial/state JSONL](conversations-003.jsonl)
- [conversations-004.md](conversations-004.md) · 50 scenarios · [complete trial/state JSONL](conversations-004.jsonl)
- [conversations-005.md](conversations-005.md) · 50 scenarios · [complete trial/state JSONL](conversations-005.jsonl)
- [conversations-006.md](conversations-006.md) · 50 scenarios · [complete trial/state JSONL](conversations-006.jsonl)
- [conversations-007.md](conversations-007.md) · 50 scenarios · [complete trial/state JSONL](conversations-007.jsonl)
- [conversations-008.md](conversations-008.md) · 50 scenarios · [complete trial/state JSONL](conversations-008.jsonl)
- [conversations-009.md](conversations-009.md) · 50 scenarios · [complete trial/state JSONL](conversations-009.jsonl)
- [conversations-010.md](conversations-010.md) · 50 scenarios · [complete trial/state JSONL](conversations-010.jsonl)
- [conversations-011.md](conversations-011.md) · 50 scenarios · [complete trial/state JSONL](conversations-011.jsonl)
- [conversations-012.md](conversations-012.md) · 50 scenarios · [complete trial/state JSONL](conversations-012.jsonl)
- [conversations-013.md](conversations-013.md) · 50 scenarios · [complete trial/state JSONL](conversations-013.jsonl)
- [conversations-014.md](conversations-014.md) · 50 scenarios · [complete trial/state JSONL](conversations-014.jsonl)
- [conversations-015.md](conversations-015.md) · 50 scenarios · [complete trial/state JSONL](conversations-015.jsonl)
- [conversations-016.md](conversations-016.md) · 50 scenarios · [complete trial/state JSONL](conversations-016.jsonl)
- [conversations-017.md](conversations-017.md) · 50 scenarios · [complete trial/state JSONL](conversations-017.jsonl)
- [conversations-018.md](conversations-018.md) · 50 scenarios · [complete trial/state JSONL](conversations-018.jsonl)
- [conversations-019.md](conversations-019.md) · 50 scenarios · [complete trial/state JSONL](conversations-019.jsonl)
- [conversations-020.md](conversations-020.md) · 50 scenarios · [complete trial/state JSONL](conversations-020.jsonl)
- [conversations-021.md](conversations-021.md) · 50 scenarios · [complete trial/state JSONL](conversations-021.jsonl)
- [conversations-022.md](conversations-022.md) · 50 scenarios · [complete trial/state JSONL](conversations-022.jsonl)
- [conversations-023.md](conversations-023.md) · 50 scenarios · [complete trial/state JSONL](conversations-023.jsonl)
- [conversations-024.md](conversations-024.md) · 50 scenarios · [complete trial/state JSONL](conversations-024.jsonl)
- [conversations-025.md](conversations-025.md) · 50 scenarios · [complete trial/state JSONL](conversations-025.jsonl)
- [conversations-026.md](conversations-026.md) · 50 scenarios · [complete trial/state JSONL](conversations-026.jsonl)
- [conversations-027.md](conversations-027.md) · 50 scenarios · [complete trial/state JSONL](conversations-027.jsonl)
- [conversations-028.md](conversations-028.md) · 50 scenarios · [complete trial/state JSONL](conversations-028.jsonl)
- [conversations-029.md](conversations-029.md) · 50 scenarios · [complete trial/state JSONL](conversations-029.jsonl)
- [conversations-030.md](conversations-030.md) · 50 scenarios · [complete trial/state JSONL](conversations-030.jsonl)
- [conversations-031.md](conversations-031.md) · 50 scenarios · [complete trial/state JSONL](conversations-031.jsonl)
- [conversations-032.md](conversations-032.md) · 50 scenarios · [complete trial/state JSONL](conversations-032.jsonl)
- [conversations-033.md](conversations-033.md) · 50 scenarios · [complete trial/state JSONL](conversations-033.jsonl)
- [conversations-034.md](conversations-034.md) · 50 scenarios · [complete trial/state JSONL](conversations-034.jsonl)
- [conversations-035.md](conversations-035.md) · 50 scenarios · [complete trial/state JSONL](conversations-035.jsonl)
- [conversations-036.md](conversations-036.md) · 50 scenarios · [complete trial/state JSONL](conversations-036.jsonl)
- [conversations-037.md](conversations-037.md) · 50 scenarios · [complete trial/state JSONL](conversations-037.jsonl)
- [conversations-038.md](conversations-038.md) · 50 scenarios · [complete trial/state JSONL](conversations-038.jsonl)
- [conversations-039.md](conversations-039.md) · 50 scenarios · [complete trial/state JSONL](conversations-039.jsonl)
- [conversations-040.md](conversations-040.md) · 50 scenarios · [complete trial/state JSONL](conversations-040.jsonl)
- [conversations-041.md](conversations-041.md) · 50 scenarios · [complete trial/state JSONL](conversations-041.jsonl)
- [conversations-042.md](conversations-042.md) · 50 scenarios · [complete trial/state JSONL](conversations-042.jsonl)
- [conversations-043.md](conversations-043.md) · 50 scenarios · [complete trial/state JSONL](conversations-043.jsonl)
- [conversations-044.md](conversations-044.md) · 50 scenarios · [complete trial/state JSONL](conversations-044.jsonl)
- [conversations-045.md](conversations-045.md) · 50 scenarios · [complete trial/state JSONL](conversations-045.jsonl)
- [conversations-046.md](conversations-046.md) · 50 scenarios · [complete trial/state JSONL](conversations-046.jsonl)
- [conversations-047.md](conversations-047.md) · 50 scenarios · [complete trial/state JSONL](conversations-047.jsonl)
- [conversations-048.md](conversations-048.md) · 50 scenarios · [complete trial/state JSONL](conversations-048.jsonl)
- [conversations-049.md](conversations-049.md) · 50 scenarios · [complete trial/state JSONL](conversations-049.jsonl)
- [conversations-050.md](conversations-050.md) · 50 scenarios · [complete trial/state JSONL](conversations-050.jsonl)
- [conversations-051.md](conversations-051.md) · 50 scenarios · [complete trial/state JSONL](conversations-051.jsonl)
- [conversations-052.md](conversations-052.md) · 50 scenarios · [complete trial/state JSONL](conversations-052.jsonl)
- [conversations-053.md](conversations-053.md) · 50 scenarios · [complete trial/state JSONL](conversations-053.jsonl)
- [conversations-054.md](conversations-054.md) · 50 scenarios · [complete trial/state JSONL](conversations-054.jsonl)
- [conversations-055.md](conversations-055.md) · 50 scenarios · [complete trial/state JSONL](conversations-055.jsonl)
- [conversations-056.md](conversations-056.md) · 50 scenarios · [complete trial/state JSONL](conversations-056.jsonl)
- [conversations-057.md](conversations-057.md) · 50 scenarios · [complete trial/state JSONL](conversations-057.jsonl)
- [conversations-058.md](conversations-058.md) · 50 scenarios · [complete trial/state JSONL](conversations-058.jsonl)
- [conversations-059.md](conversations-059.md) · 50 scenarios · [complete trial/state JSONL](conversations-059.jsonl)
- [conversations-060.md](conversations-060.md) · 50 scenarios · [complete trial/state JSONL](conversations-060.jsonl)
- [conversations-061.md](conversations-061.md) · 50 scenarios · [complete trial/state JSONL](conversations-061.jsonl)
- [conversations-062.md](conversations-062.md) · 50 scenarios · [complete trial/state JSONL](conversations-062.jsonl)
- [conversations-063.md](conversations-063.md) · 50 scenarios · [complete trial/state JSONL](conversations-063.jsonl)
- [conversations-064.md](conversations-064.md) · 50 scenarios · [complete trial/state JSONL](conversations-064.jsonl)
- [conversations-065.md](conversations-065.md) · 50 scenarios · [complete trial/state JSONL](conversations-065.jsonl)
- [conversations-066.md](conversations-066.md) · 50 scenarios · [complete trial/state JSONL](conversations-066.jsonl)
- [conversations-067.md](conversations-067.md) · 50 scenarios · [complete trial/state JSONL](conversations-067.jsonl)
- [conversations-068.md](conversations-068.md) · 50 scenarios · [complete trial/state JSONL](conversations-068.jsonl)
- [conversations-069.md](conversations-069.md) · 50 scenarios · [complete trial/state JSONL](conversations-069.jsonl)
- [conversations-070.md](conversations-070.md) · 50 scenarios · [complete trial/state JSONL](conversations-070.jsonl)

## Reproduce

deno run --allow-read --allow-write --allow-run --allow-env tests/memory-audit/campaign.ts --out /tmp/upmore-campaign --workflow-variants 50 --semantic-variants 20 --trials 3

## Failed families

- M06: 1/50 failed; preserve transcripts and diagnose the source path before changing an assertion.
- M07: 1/50 failed; preserve transcripts and diagnose the source path before changing an assertion.
- M08: 1/50 failed; preserve transcripts and diagnose the source path before changing an assertion.
- M10: 40/50 failed; preserve transcripts and diagnose the source path before changing an assertion.
- M11: 1/50 failed; preserve transcripts and diagnose the source path before changing an assertion.
- M15: 1/50 failed; preserve transcripts and diagnose the source path before changing an assertion.
- M16: 40/50 failed; preserve transcripts and diagnose the source path before changing an assertion.
- M17: 4/50 failed; preserve transcripts and diagnose the source path before changing an assertion.
- M19: 40/50 failed; preserve transcripts and diagnose the source path before changing an assertion.
- M21: 1/50 failed; preserve transcripts and diagnose the source path before changing an assertion.
- M23: 1/50 failed; preserve transcripts and diagnose the source path before changing an assertion.
- M25: 1/50 failed; preserve transcripts and diagnose the source path before changing an assertion.
- M28: 1/50 failed; preserve transcripts and diagnose the source path before changing an assertion.
- M30: 1/50 failed; preserve transcripts and diagnose the source path before changing an assertion.
- M31: 1/50 failed; preserve transcripts and diagnose the source path before changing an assertion.
- M32: 1/50 failed; preserve transcripts and diagnose the source path before changing an assertion.
- M33: 1/50 failed; preserve transcripts and diagnose the source path before changing an assertion.
- M37: 40/50 failed; preserve transcripts and diagnose the source path before changing an assertion.
- M38: 1/50 failed; preserve transcripts and diagnose the source path before changing an assertion.
- M41: 1/50 failed; preserve transcripts and diagnose the source path before changing an assertion.
- M48: 1/50 failed; preserve transcripts and diagnose the source path before changing an assertion.
- M49: 1/50 failed; preserve transcripts and diagnose the source path before changing an assertion.
- S17: 20/20 failed; preserve transcripts and diagnose the source path before changing an assertion.
- S24: 20/20 failed; preserve transcripts and diagnose the source path before changing an assertion.
- S25: 20/20 failed; preserve transcripts and diagnose the source path before changing an assertion.
