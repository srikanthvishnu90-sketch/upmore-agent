# conversations-010

All conversations are synthetic. Full production handler, mock authentication/PostgREST and disabled model; no real outbound messages or provider actions.

## C00451 · M01 · Confirmed nickname recalls the right person · PASS

Expected: [{"say":"save jules as brother"},{"say":"yes"},{"say":"send brother 100","match":"Jules Kim.*@julesk","outcome":"confirm"}]

### Trial 1

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Jules Kim (brother, @julesk).

User: send brother 100

Upmore: Set up $100.00 to Jules Kim (brother, @julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Jules Kim (brother, @julesk).

User: send brother 100

Upmore: Set up $100.00 to Jules Kim (brother, @julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Jules Kim (brother, @julesk).

User: send brother 100

Upmore: Set up $100.00 to Jules Kim (brother, @julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00452 · M02 · Explicit remember phrasing persists an alias · PASS

Expected: [{"say":"remember Anika Rao as my sister"},{"say":"yes"},{"say":"send sister 125","match":"Anika Rao.*@anikar","outcome":"confirm"}]

### Trial 1

User: remember Anika Rao as my sister

Upmore: Save "sister" as your name for Anika Rao (@anikar)? Then "send sister 20" goes to Anika Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Anika Rao (sister, @anikar).

User: send sister 125

Upmore: Set up $125.00 to Anika Rao (sister, @anikar) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: remember Anika Rao as my sister

Upmore: Save "sister" as your name for Anika Rao (@anikar)? Then "send sister 20" goes to Anika Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Anika Rao (sister, @anikar).

User: send sister 125

Upmore: Set up $125.00 to Anika Rao (sister, @anikar) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: remember Anika Rao as my sister

Upmore: Save "sister" as your name for Anika Rao (@anikar)? Then "send sister 20" goes to Anika Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Anika Rao (sister, @anikar).

User: send sister 125

Upmore: Set up $125.00 to Anika Rao (sister, @anikar) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00453 · M03 · Natural relationship statement needs confirmation and persists · PASS

Expected: [{"say":"my dad is Jules Kim","match":"Save"},{"say":"yes"},{"say":"send dad 150","match":"Jules Kim","outcome":"confirm"}]

### Trial 1

User: my dad is Jules Kim

Upmore: Save "dad" as your name for Jules Kim (@julesk)? Then "send dad 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Jules Kim (dad, @julesk).

User: send dad 150

Upmore: Set up $150.00 to Jules Kim (dad, @julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: my dad is Jules Kim

Upmore: Save "dad" as your name for Jules Kim (@julesk)? Then "send dad 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Jules Kim (dad, @julesk).

User: send dad 150

Upmore: Set up $150.00 to Jules Kim (dad, @julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: my dad is Jules Kim

Upmore: Save "dad" as your name for Jules Kim (@julesk)? Then "send dad 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Jules Kim (dad, @julesk).

User: send dad 150

Upmore: Set up $150.00 to Jules Kim (dad, @julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00454 · M04 · An alias is moved only to the newly confirmed person · PASS

Expected: [{"say":"save jules as brother"},{"say":"yes"},{"say":"brother is Anika Rao"},{"say":"yes"},{"say":"send brother 100","match":"Anika Rao","outcome":"confirm"}]

### Trial 1

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Jules Kim (brother, @julesk).

User: brother is Anika Rao

Upmore: Save "brother" as your name for Anika Rao (@anikar)? Then "send brother 20" goes to Anika Rao. "brother" means Jules Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Anika Rao (brother, @anikar).

User: send brother 100

Upmore: Set up $100.00 to Anika Rao (brother, @anikar) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Jules Kim (brother, @julesk).

User: brother is Anika Rao

Upmore: Save "brother" as your name for Anika Rao (@anikar)? Then "send brother 20" goes to Anika Rao. "brother" means Jules Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Anika Rao (brother, @anikar).

User: send brother 100

Upmore: Set up $100.00 to Anika Rao (brother, @anikar) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Jules Kim (brother, @julesk).

User: brother is Anika Rao

Upmore: Save "brother" as your name for Anika Rao (@anikar)? Then "send brother 20" goes to Anika Rao. "brother" means Jules Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Anika Rao (brother, @anikar).

User: send brother 100

Upmore: Set up $100.00 to Anika Rao (brother, @anikar) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00455 · M05 · Rejected alias preserves the previous confirmed fact · PASS

Expected: [{"say":"save jules as brother"},{"say":"yes"},{"say":"brother is Anika Rao"},{"say":"no"},{"say":"send brother 100","match":"Jules Kim","outcome":"confirm"}]

### Trial 1

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Jules Kim (brother, @julesk).

User: brother is Anika Rao

Upmore: Save "brother" as your name for Anika Rao (@anikar)? Then "send brother 20" goes to Anika Rao. "brother" means Jules Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 100

Upmore: Set up $100.00 to Jules Kim (brother, @julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Jules Kim (brother, @julesk).

User: brother is Anika Rao

Upmore: Save "brother" as your name for Anika Rao (@anikar)? Then "send brother 20" goes to Anika Rao. "brother" means Jules Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 100

Upmore: Set up $100.00 to Jules Kim (brother, @julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Jules Kim (brother, @julesk).

User: brother is Anika Rao

Upmore: Save "brother" as your name for Anika Rao (@anikar)? Then "send brother 20" goes to Anika Rao. "brother" means Jules Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 100

Upmore: Set up $100.00 to Jules Kim (brother, @julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00456 · M06 · Amount correction preserves payee and replaces the old card · PASS

Expected: [{"say":"send jules 100"},{"say":"make it 175","match":"175.00.*Jules Kim","outcome":"confirm"},{"say":"yes","match":"175.00","outcome":"staged"},{"state":"state.send.sends.0.amount_cents","equals":17500}]

### Trial 1

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 175

Upmore: Got it. Set up $175.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $175.00; 4. Keep it private, then Pay. I'll confirm when $175.00 to Jules Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 175

Upmore: Got it. Set up $175.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $175.00; 4. Keep it private, then Pay. I'll confirm when $175.00 to Jules Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 175

Upmore: Got it. Set up $175.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $175.00; 4. Keep it private, then Pay. I'll confirm when $175.00 to Jules Kim posts; if it hasn't by tonight, I'll ask.

## C00457 · M07 · Actually correction handles a different amount · PASS

Expected: [{"say":"send jules 100"},{"say":"actually make it 250","match":"250.00.*Jules Kim","outcome":"confirm"},{"say":"yes","match":"250.00","outcome":"staged"}]

### Trial 1

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 250

Upmore: Got it. Set up $250.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $250.00; 4. Keep it private, then Pay. I'll confirm when $250.00 to Jules Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 250

Upmore: Got it. Set up $250.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $250.00; 4. Keep it private, then Pay. I'll confirm when $250.00 to Jules Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 250

Upmore: Got it. Set up $250.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $250.00; 4. Keep it private, then Pay. I'll confirm when $250.00 to Jules Kim posts; if it hasn't by tonight, I'll ask.

## C00458 · M08 · Bare currency correction retains payment context · PASS

Expected: [{"say":"send jules 100"},{"say":"$62.50 instead","match":"62.50.*Jules Kim","outcome":"confirm"},{"say":"yes","match":"62.50","outcome":"staged"}]

### Trial 1

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $62.50 instead

Upmore: Got it. Set up $62.50 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $62.50; 4. Keep it private, then Pay. I'll confirm when $62.50 to Jules Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $62.50 instead

Upmore: Got it. Set up $62.50 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $62.50; 4. Keep it private, then Pay. I'll confirm when $62.50 to Jules Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $62.50 instead

Upmore: Got it. Set up $62.50 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $62.50; 4. Keep it private, then Pay. I'll confirm when $62.50 to Jules Kim posts; if it hasn't by tonight, I'll ask.

## C00459 · M09 · Split total correction recomputes every share before approval · PASS

Expected: [{"say":"split 300 with jules and anika"},{"say":"make it 450","match":"150.00 each.*450.00","outcome":"confirm"},{"say":"yes","match":"150.00","outcome":"staged"}]

### Trial 1

User: split 300 with jules and anika

Upmore: Request $100.00 each from Jules Kim (@julesk) and Anika Rao (@anikar) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 450

Upmore: Got it. Request $150.00 each from Jules Kim (@julesk) and Anika Rao (@anikar) in Venmo: $450.00 split 3 ways, yours $150.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Jules Kim (@julesk) $150.00 in Venmo, Anika Rao (@anikar) $150.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 300 with jules and anika

Upmore: Request $100.00 each from Jules Kim (@julesk) and Anika Rao (@anikar) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 450

Upmore: Got it. Request $150.00 each from Jules Kim (@julesk) and Anika Rao (@anikar) in Venmo: $450.00 split 3 ways, yours $150.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Jules Kim (@julesk) $150.00 in Venmo, Anika Rao (@anikar) $150.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 300 with jules and anika

Upmore: Request $100.00 each from Jules Kim (@julesk) and Anika Rao (@anikar) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 450

Upmore: Got it. Request $150.00 each from Jules Kim (@julesk) and Anika Rao (@anikar) in Venmo: $450.00 split 3 ways, yours $150.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Jules Kim (@julesk) $150.00 in Venmo, Anika Rao (@anikar) $150.00 in Venmo. I'll mark each one paid when the money lands.

## C00460 · M10 · Rent setup correction retains recipient and due day · FAIL

Expected: [{"say":"pay my rent"},{"say":"jules $4500 on the 1st via Venmo"},{"say":"make it 4750","match":"4750.00.*Jules Kim.*1st","outcome":"confirm"},{"say":"yes"},{"state":"standing.0.amount_cents","equals":475000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 4750

Upmore: Got it. Set up rent: $4,750.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,750.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"4750.00.*Jules Kim.*1st","actual":{"thread_id":"3bfeb971-9b1a-4f29-afff-0a763a077c38","reply":"Got it. Set up rent: $4,750.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 4750

Upmore: Got it. Set up rent: $4,750.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,750.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"4750.00.*Jules Kim.*1st","actual":{"thread_id":"53d08625-1cac-425a-a338-97805f016902","reply":"Got it. Set up rent: $4,750.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 4750

Upmore: Got it. Set up rent: $4,750.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,750.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"4750.00.*Jules Kim.*1st","actual":{"thread_id":"ed47415d-d99f-41cc-a568-8e9ff7028107","reply":"Got it. Set up rent: $4,750.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

## C00461 · M11 · Details refers to the pending payment · PASS

Expected: [{"say":"send jules 100"},{"say":"details","match":"100.00.*Jules Kim","outcome":"details"}]

### Trial 1

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $100.00 to Jules Kim on Venmo $100.00 to Jules Kim (@julesk) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

### Trial 2

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $100.00 to Jules Kim on Venmo $100.00 to Jules Kim (@julesk) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

### Trial 3

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $100.00 to Jules Kim on Venmo $100.00 to Jules Kim (@julesk) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

## C00462 · M12 · A short yes resumes a serialized split · PASS

Expected: [{"say":"split 300 with jules and anika"},{"say":"yes","match":"Jules Kim.*100.00.*Anika Rao.*100.00","outcome":"staged"}]

### Trial 1

User: split 300 with jules and anika

Upmore: Request $100.00 each from Jules Kim (@julesk) and Anika Rao (@anikar) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Jules Kim (@julesk) $100.00 in Venmo, Anika Rao (@anikar) $100.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 300 with jules and anika

Upmore: Request $100.00 each from Jules Kim (@julesk) and Anika Rao (@anikar) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Jules Kim (@julesk) $100.00 in Venmo, Anika Rao (@anikar) $100.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 300 with jules and anika

Upmore: Request $100.00 each from Jules Kim (@julesk) and Anika Rao (@anikar) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Jules Kim (@julesk) $100.00 in Venmo, Anika Rao (@anikar) $100.00 in Venmo. I'll mark each one paid when the money lands.

## C00463 · M13 · Cancellation that resolves the last discussed subscription · PASS

Expected: [{"say":"cancel netflix","match":"Netflix"},{"say":"cancel that","match":"Netflix"}]

### Trial 1

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 2

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 3

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

## C00464 · M14 · Stop rent refers to the confirmed standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"jules $4500 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent","match":"Rent is off","outcome":"rent_stopped"},{"state":"standing.0.status","equals":"stopped"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Jules Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Jules Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Jules Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

## C00465 · M15 · A contextual fee question retains payment identity and asks before acting · PASS

Expected: [{"say":"send jules 100"},{"say":"what's the fee on that","match":"100.00.*Jules Kim"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $100.00 to Jules Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $100.00 to Jules Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $100.00 to Jules Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00466 · M16 · Rent setup answers retain the original goal · FAIL

Expected: [{"say":"pay my rent","match":"Who"},{"say":"jules $4500 on the 1st via Venmo","match":"4500.00.*Jules Kim","outcome":"confirm"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"standing.0.payee_handle","equals":"@julesk"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"4500.00.*Jules Kim","actual":{"thread_id":"e757032b-037a-4008-9fc2-4a9a7646f58b","reply":"Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"4500.00.*Jules Kim","actual":{"thread_id":"84530a49-12f2-49ca-b4b0-7859fe863b06","reply":"Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"4500.00.*Jules Kim","actual":{"thread_id":"44f44c40-d30c-4005-bb83-704a7c0d709b","reply":"Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

## C00467 · M17 · New recipient handle and rail answers retain amount · PASS

Expected: [{"say":"send Dana 125"},{"say":"@danak"},{"say":"@danak"},{"say":"Venmo"},{"say":"@danak","match":"125.00.*Dana","outcome":"confirm"}]

### Trial 1

User: send Dana 125

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $125.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: send Dana 125

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $125.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: send Dana 125

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $125.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00468 · M18 · Split remembers total while asking who participated · PASS

Expected: [{"say":"split 300 with 2 friends"},{"say":"jules and anika","match":"100.00 each.*300.00","outcome":"confirm"}]

### Trial 1

User: split 300 with 2 friends

Upmore: That's $100.00 each across 3 people. Who are the 2? I'll request $100.00 from each.

User: jules and anika

Upmore: Request $100.00 each from Jules Kim (@julesk) and Anika Rao (@anikar) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: split 300 with 2 friends

Upmore: That's $100.00 each across 3 people. Who are the 2? I'll request $100.00 from each.

User: jules and anika

Upmore: Request $100.00 each from Jules Kim (@julesk) and Anika Rao (@anikar) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: split 300 with 2 friends

Upmore: That's $100.00 each across 3 people. Who are the 2? I'll request $100.00 from each.

User: jules and anika

Upmore: Request $100.00 each from Jules Kim (@julesk) and Anika Rao (@anikar) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

## C00469 · M19 · Rent is remembered on the next independent invocation · FAIL

Expected: [{"say":"pay my rent"},{"say":"jules $4500 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent","match":"4500.00.*Jules Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Jules Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"4500.00.*Jules Kim","actual":{"thread_id":"2cc9398f-6eeb-4af0-b008-37a3623401f6","reply":"Rent for November: $4,500.00 to Jules Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Jules Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"4500.00.*Jules Kim","actual":{"thread_id":"d0156865-c255-4014-81ef-39542c399e6b","reply":"Rent for November: $4,500.00 to Jules Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Jules Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"4500.00.*Jules Kim","actual":{"thread_id":"ad2b0e36-f54a-48ed-b2fb-b85f2a9674fa","reply":"Rent for November: $4,500.00 to Jules Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

## C00470 · M20 · An interrupted alias goal remains unconfirmed · PASS

Expected: [{"say":"save jules as brother"},{"say":"no"},{"state":"recipients.0.nickname","equals":null},{"say":"send brother 100","match":"handle","outcome":"ask"}]

### Trial 1

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 100

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 2

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 100

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 3

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 100

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

## C00471 · M21 · A staged payment is remembered without claiming completion · PASS

Expected: [{"say":"send jules 100"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Jules Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $100.00 to Jules Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 2

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Jules Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $100.00 to Jules Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 3

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Jules Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $100.00 to Jules Kim for you to send in Venmo. A second yes doesn't stage it again.

## C00472 · M22 · A staged split is remembered without duplicating it · PASS

Expected: [{"say":"split 300 with jules and anika"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 300 with jules and anika

Upmore: Request $100.00 each from Jules Kim (@julesk) and Anika Rao (@anikar) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Jules Kim (@julesk) $100.00 in Venmo, Anika Rao (@anikar) $100.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 300 with jules and anika

Upmore: Request $100.00 each from Jules Kim (@julesk) and Anika Rao (@anikar) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Jules Kim (@julesk) $100.00 in Venmo, Anika Rao (@anikar) $100.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 300 with jules and anika

Upmore: Request $100.00 each from Jules Kim (@julesk) and Anika Rao (@anikar) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Jules Kim (@julesk) $100.00 in Venmo, Anika Rao (@anikar) $100.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C00473 · M23 · A declined payment cannot be resurrected by yes · PASS

Expected: [{"say":"send jules 100"},{"say":"no","match":"Nothing","outcome":"declined"},{"say":"yes","not":"^Staged, not sent"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 2

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 3

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

## C00474 · M24 · Stopping rent prevents the next turn from claiming an active rule · PASS

Expected: [{"say":"pay my rent"},{"say":"jules $4500 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Jules Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Jules Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Jules Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C00475 · M25 · Status follow-up recalls staged versus sent · PASS

Expected: [{"say":"send jules 100"},{"say":"yes"},{"say":"did it go through","match":"(?:not (?:yet )?(?:sent|posted)|staged|have not seen|waiting for.*post)"}]

### Trial 1

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Jules Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $100.00 to Jules Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

### Trial 2

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Jules Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $100.00 to Jules Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

### Trial 3

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Jules Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $100.00 to Jules Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

## C00476 · M26 · Unapproved nickname does not become a known fact · PASS

Expected: [{"say":"save jules as brother"},{"state":"recipients.0.nickname","equals":null},{"say":"no"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 2

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 3

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

## C00477 · M27 · Unapproved rent terms are not durable instructions · PASS

Expected: [{"say":"pay my rent"},{"say":"jules $4500 on the 1st via Venmo"},{"state":"standing.length","equals":0},{"say":"no"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

## C00478 · M28 · An expired payment card is restated and requires a fresh yes · PASS

Expected: [{"say":"send jules 100"},{"minutes":11},{"say":"yes","match":"expired.*fresh","outcome":"confirm"},{"state":"state.send.sends.length","equals":0},{"say":"yes","match":"Staged","outcome":"staged"}]

### Trial 1

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Jules Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Jules Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Jules Kim posts; if it hasn't by tonight, I'll ask.

## C00479 · M29 · An expired nickname card never writes a fact · PASS

Expected: [{"say":"save jules as brother"},{"minutes":11},{"say":"yes","match":"expired"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 2

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 3

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

## C00480 · M30 · A question containing yes does not approve a payment · PASS

Expected: [{"say":"send jules 100"},{"say":"yes but is there a fee"},{"state":"state.send.sends.length","equals":0},{"say":"no"}]

### Trial 1

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

### Trial 2

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

### Trial 3

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

## C00481 · M31 · Moving to small talk explicitly drops the old payment · PASS

Expected: [{"say":"send jules 100"},{"say":"what's a good movie","match":"dropped.*100.00"},{"say":"yes","not":"^Staged"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $100.00 to Jules Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $100.00 to Jules Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $100.00 to Jules Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00482 · M32 · Switching recipients makes the latest request authoritative · PASS

Expected: [{"say":"send jules 100"},{"say":"send anika 150","match":"150.00.*Anika Rao","outcome":"confirm"},{"say":"yes","match":"150.00.*Anika Rao","outcome":"staged"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send anika 150

Upmore: I dropped the earlier card. Set up $150.00 to Anika Rao (@anikar) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @anikar; 3. Enter $150.00; 4. Keep it private, then Pay. I'll confirm when $150.00 to Anika Rao posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send anika 150

Upmore: I dropped the earlier card. Set up $150.00 to Anika Rao (@anikar) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @anikar; 3. Enter $150.00; 4. Keep it private, then Pay. I'll confirm when $150.00 to Anika Rao posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send anika 150

Upmore: I dropped the earlier card. Set up $150.00 to Anika Rao (@anikar) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @anikar; 3. Enter $150.00; 4. Keep it private, then Pay. I'll confirm when $150.00 to Anika Rao posts; if it hasn't by tonight, I'll ask.

## C00483 · M33 · A payment supersedes a pending split rather than approving both · PASS

Expected: [{"say":"split 300 with jules and anika"},{"say":"send jules 100","match":"100.00.*Jules Kim","outcome":"confirm"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"state":"state.split.staged.length","equals":0}]

### Trial 1

User: split 300 with jules and anika

Upmore: Request $100.00 each from Jules Kim (@julesk) and Anika Rao (@anikar) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send jules 100

Upmore: I dropped the earlier card. Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Jules Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: split 300 with jules and anika

Upmore: Request $100.00 each from Jules Kim (@julesk) and Anika Rao (@anikar) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send jules 100

Upmore: I dropped the earlier card. Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Jules Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: split 300 with jules and anika

Upmore: Request $100.00 each from Jules Kim (@julesk) and Anika Rao (@anikar) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send jules 100

Upmore: I dropped the earlier card. Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Jules Kim posts; if it hasn't by tonight, I'll ask.

## C00484 · M34 · Switching from payment to rent keeps the new goal · PASS

Expected: [{"say":"send jules 100"},{"say":"pay my rent","match":"Who","outcome":"ask"},{"say":"jules $4500 on the 1st via Venmo"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 2

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 3

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

## C00485 · M35 · Never mind cancels an alias confirmation without saving · PASS

Expected: [{"say":"save jules as brother"},{"say":"never mind"},{"state":"recipients.0.nickname","equals":null},{"say":"yes","not":"^Saved:"}]

### Trial 1

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 2

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 3

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

## C00486 · M36 · Confirmed aliases survive a new conversation · PASS

Expected: [{"say":"save jules as brother"},{"say":"yes"},{"thread":"B"},{"say":"send brother 100","match":"Jules Kim","outcome":"confirm"}]

### Trial 1

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Jules Kim (brother, @julesk).

User: send brother 100

Upmore: Set up $100.00 to Jules Kim (brother, @julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Jules Kim (brother, @julesk).

User: send brother 100

Upmore: Set up $100.00 to Jules Kim (brother, @julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Jules Kim (brother, @julesk).

User: send brother 100

Upmore: Set up $100.00 to Jules Kim (brother, @julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00487 · M37 · Standing rent survives a new conversation · FAIL

Expected: [{"say":"pay my rent"},{"say":"jules $4500 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"pay my rent","match":"4500.00.*Jules Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Jules Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"4500.00.*Jules Kim","actual":{"thread_id":"b945d077-8b46-46f8-9aca-2ba885d9733d","reply":"Rent for November: $4,500.00 to Jules Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Jules Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"4500.00.*Jules Kim","actual":{"thread_id":"c1485b6d-be1e-44f7-b38d-cc3a1633eef0","reply":"Rent for November: $4,500.00 to Jules Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Jules Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"4500.00.*Jules Kim","actual":{"thread_id":"0d9b0be6-fd3a-4997-aea7-f45b96ee0cd7","reply":"Rent for November: $4,500.00 to Jules Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

## C00488 · M38 · Unapproved thread A card cannot be approved in thread B · PASS

Expected: [{"say":"send jules 100"},{"thread":"B"},{"say":"yes","not":"^Staged"},{"thread":"A"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00489 · M39 · A nickname correction in another session supersedes the old meaning · PASS

Expected: [{"say":"save jules as brother"},{"say":"yes"},{"thread":"B"},{"say":"brother is Anika Rao"},{"say":"yes"},{"thread":"C"},{"say":"send brother 100","match":"Anika Rao","outcome":"confirm"}]

### Trial 1

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Jules Kim (brother, @julesk).

User: brother is Anika Rao

Upmore: Save "brother" as your name for Anika Rao (@anikar)? Then "send brother 20" goes to Anika Rao. "brother" means Jules Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Anika Rao (brother, @anikar).

User: send brother 100

Upmore: Set up $100.00 to Anika Rao (brother, @anikar) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Jules Kim (brother, @julesk).

User: brother is Anika Rao

Upmore: Save "brother" as your name for Anika Rao (@anikar)? Then "send brother 20" goes to Anika Rao. "brother" means Jules Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Anika Rao (brother, @anikar).

User: send brother 100

Upmore: Set up $100.00 to Anika Rao (brother, @anikar) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Jules Kim (brother, @julesk).

User: brother is Anika Rao

Upmore: Save "brother" as your name for Anika Rao (@anikar)? Then "send brother 20" goes to Anika Rao. "brother" means Jules Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Anika Rao (brother, @anikar).

User: send brother 100

Upmore: Set up $100.00 to Anika Rao (brother, @anikar) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00490 · M40 · Stopping rent in another session prevents future offers · PASS

Expected: [{"say":"pay my rent"},{"say":"jules $4500 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"stop rent"},{"thread":"C"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Jules Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Jules Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Jules Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C00491 · M41 · Repeating a staged approval does not stage twice after restore · PASS

Expected: [{"say":"send jules 100"},{"say":"yes"},{"say":"yes","match":"already staged","outcome":"already_done"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Jules Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $100.00 to Jules Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $100.00 to Jules Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 2

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Jules Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $100.00 to Jules Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $100.00 to Jules Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 3

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Jules Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $100.00 to Jules Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $100.00 to Jules Kim for you to send in Venmo. A second yes doesn't stage it again.

## C00492 · M42 · Rent setup retry leaves exactly one standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"jules $4500 on the 1st via Venmo"},{"say":"yes"},{"say":"yes","not":"^Rent is set up"},{"state":"standing.length","equals":1}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00493 · M43 · Confirmed alias repeated is recognized as already known · PASS

Expected: [{"say":"save jules as brother"},{"say":"yes"},{"say":"save jules as brother","match":"already|Already|already means","outcome":"already_done"},{"state":"ops.length","equals":1}]

### Trial 1

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Jules Kim (brother, @julesk).

User: save jules as brother

Upmore: "brother" already means Jules Kim (brother, @julesk). Nothing changed.

### Trial 2

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Jules Kim (brother, @julesk).

User: save jules as brother

Upmore: "brother" already means Jules Kim (brother, @julesk). Nothing changed.

### Trial 3

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Jules Kim (brother, @julesk).

User: save jules as brother

Upmore: "brother" already means Jules Kim (brother, @julesk). Nothing changed.

## C00494 · M44 · The same month rent is staged once across restored sessions · PASS

Expected: [{"say":"pay my rent"},{"say":"jules $4500 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"pay my rent","match":"already staged","outcome":"already_done"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Jules Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $4,500.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $4,500.00 to Jules Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $4,500.00 to Jules Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Jules Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $4,500.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $4,500.00 to Jules Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $4,500.00 to Jules Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Jules Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesk; 3. Enter $4,500.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $4,500.00 to Jules Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $4,500.00 to Jules Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

## C00495 · M45 · Retried split approval preserves one set of requests · PASS

Expected: [{"say":"split 300 with jules and anika"},{"say":"yes"},{"say":"yes"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 300 with jules and anika

Upmore: Request $100.00 each from Jules Kim (@julesk) and Anika Rao (@anikar) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Jules Kim (@julesk) $100.00 in Venmo, Anika Rao (@anikar) $100.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 300 with jules and anika

Upmore: Request $100.00 each from Jules Kim (@julesk) and Anika Rao (@anikar) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Jules Kim (@julesk) $100.00 in Venmo, Anika Rao (@anikar) $100.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 300 with jules and anika

Upmore: Request $100.00 each from Jules Kim (@julesk) and Anika Rao (@anikar) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Jules Kim (@julesk) $100.00 in Venmo, Anika Rao (@anikar) $100.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C00496 · M46 · Nickname save failure is never reported as remembered · PASS

Expected: [{"say":"save jules as brother"},{"set":{"failRecipients":true}},{"say":"yes","match":"couldn't save"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 2

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 3

User: save jules as brother

Upmore: Save "brother" as your name for Jules Kim (@julesk)? Then "send brother 20" goes to Jules Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

## C00497 · M47 · Rent save failure is never reported as a stored rule · PASS

Expected: [{"say":"pay my rent"},{"say":"jules $4500 on the 1st via Venmo"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*set|nothing was set up"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

## C00498 · M48 · A failed state write yields no approval card and retry is recoverable · PASS

Expected: [{"set":{"failState":true}},{"say":"send jules 100","error":"state storage unavailable"},{"set":{"failState":false}},{"say":"send jules 100","match":"100.00.*Jules Kim","outcome":"confirm"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send jules 100

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: send jules 100

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: send jules 100

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00499 · M49 · Unavailable facts cause an honest blocker and preserve the old card · PASS

Expected: [{"say":"send jules 100"},{"set":{"unreadable":true}},{"say":"yes","match":"can't read.*Nothing was changed","outcome":"unavailable"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

### Trial 2

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

### Trial 3

User: send jules 100

Upmore: Set up $100.00 to Jules Kim (@julesk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

## C00500 · M50 · A failed rent correction retains the prior confirmed terms · PASS

Expected: [{"say":"pay my rent"},{"say":"jules $4500 on the 1st via Venmo"},{"say":"yes"},{"say":"rent is 4750 now"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*change|rent stays as it was"},{"state":"standing.0.amount_cents","equals":450000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 4750 now

Upmore: Change rent (amount $4,500.00 to $4,750.00): $4,750.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 4750 now

Upmore: Change rent (amount $4,500.00 to $4,750.00): $4,750.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: jules $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Jules Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 4750 now

Upmore: Change rent (amount $4,500.00 to $4,750.00): $4,750.00 to Jules Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

