# conversations-048

All conversations are synthetic. Full production handler, mock authentication/PostgREST and disabled model; no real outbound messages or provider actions.

## C02351 · M01 · Confirmed nickname recalls the right person · PASS

Expected: [{"say":"save yumi as brother"},{"say":"yes"},{"say":"send brother 60","match":"Yumi Kim.*@yumik","outcome":"confirm"}]

### Trial 1

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Yumi Kim (brother, @yumik).

User: send brother 60

Upmore: Set up $60.00 to Yumi Kim (brother, @yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Yumi Kim (brother, @yumik).

User: send brother 60

Upmore: Set up $60.00 to Yumi Kim (brother, @yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Yumi Kim (brother, @yumik).

User: send brother 60

Upmore: Set up $60.00 to Yumi Kim (brother, @yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02352 · M02 · Explicit remember phrasing persists an alias · PASS

Expected: [{"say":"remember Omar Rao as my sister"},{"say":"yes"},{"say":"send sister 75","match":"Omar Rao.*@omarr","outcome":"confirm"}]

### Trial 1

User: remember Omar Rao as my sister

Upmore: Save "sister" as your name for Omar Rao (@omarr)? Then "send sister 20" goes to Omar Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Omar Rao (sister, @omarr).

User: send sister 75

Upmore: Set up $75.00 to Omar Rao (sister, @omarr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: remember Omar Rao as my sister

Upmore: Save "sister" as your name for Omar Rao (@omarr)? Then "send sister 20" goes to Omar Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Omar Rao (sister, @omarr).

User: send sister 75

Upmore: Set up $75.00 to Omar Rao (sister, @omarr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: remember Omar Rao as my sister

Upmore: Save "sister" as your name for Omar Rao (@omarr)? Then "send sister 20" goes to Omar Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Omar Rao (sister, @omarr).

User: send sister 75

Upmore: Set up $75.00 to Omar Rao (sister, @omarr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02353 · M03 · Natural relationship statement needs confirmation and persists · PASS

Expected: [{"say":"my dad is Yumi Kim","match":"Save"},{"say":"yes"},{"say":"send dad 90","match":"Yumi Kim","outcome":"confirm"}]

### Trial 1

User: my dad is Yumi Kim

Upmore: Save "dad" as your name for Yumi Kim (@yumik)? Then "send dad 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Yumi Kim (dad, @yumik).

User: send dad 90

Upmore: Set up $90.00 to Yumi Kim (dad, @yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: my dad is Yumi Kim

Upmore: Save "dad" as your name for Yumi Kim (@yumik)? Then "send dad 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Yumi Kim (dad, @yumik).

User: send dad 90

Upmore: Set up $90.00 to Yumi Kim (dad, @yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: my dad is Yumi Kim

Upmore: Save "dad" as your name for Yumi Kim (@yumik)? Then "send dad 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Yumi Kim (dad, @yumik).

User: send dad 90

Upmore: Set up $90.00 to Yumi Kim (dad, @yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02354 · M04 · An alias is moved only to the newly confirmed person · PASS

Expected: [{"say":"save yumi as brother"},{"say":"yes"},{"say":"brother is Omar Rao"},{"say":"yes"},{"say":"send brother 60","match":"Omar Rao","outcome":"confirm"}]

### Trial 1

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Yumi Kim (brother, @yumik).

User: brother is Omar Rao

Upmore: Save "brother" as your name for Omar Rao (@omarr)? Then "send brother 20" goes to Omar Rao. "brother" means Yumi Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Omar Rao (brother, @omarr).

User: send brother 60

Upmore: Set up $60.00 to Omar Rao (brother, @omarr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Yumi Kim (brother, @yumik).

User: brother is Omar Rao

Upmore: Save "brother" as your name for Omar Rao (@omarr)? Then "send brother 20" goes to Omar Rao. "brother" means Yumi Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Omar Rao (brother, @omarr).

User: send brother 60

Upmore: Set up $60.00 to Omar Rao (brother, @omarr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Yumi Kim (brother, @yumik).

User: brother is Omar Rao

Upmore: Save "brother" as your name for Omar Rao (@omarr)? Then "send brother 20" goes to Omar Rao. "brother" means Yumi Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Omar Rao (brother, @omarr).

User: send brother 60

Upmore: Set up $60.00 to Omar Rao (brother, @omarr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02355 · M05 · Rejected alias preserves the previous confirmed fact · PASS

Expected: [{"say":"save yumi as brother"},{"say":"yes"},{"say":"brother is Omar Rao"},{"say":"no"},{"say":"send brother 60","match":"Yumi Kim","outcome":"confirm"}]

### Trial 1

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Yumi Kim (brother, @yumik).

User: brother is Omar Rao

Upmore: Save "brother" as your name for Omar Rao (@omarr)? Then "send brother 20" goes to Omar Rao. "brother" means Yumi Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 60

Upmore: Set up $60.00 to Yumi Kim (brother, @yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Yumi Kim (brother, @yumik).

User: brother is Omar Rao

Upmore: Save "brother" as your name for Omar Rao (@omarr)? Then "send brother 20" goes to Omar Rao. "brother" means Yumi Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 60

Upmore: Set up $60.00 to Yumi Kim (brother, @yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Yumi Kim (brother, @yumik).

User: brother is Omar Rao

Upmore: Save "brother" as your name for Omar Rao (@omarr)? Then "send brother 20" goes to Omar Rao. "brother" means Yumi Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 60

Upmore: Set up $60.00 to Yumi Kim (brother, @yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02356 · M06 · Amount correction preserves payee and replaces the old card · PASS

Expected: [{"say":"send yumi 60"},{"say":"make it 105","match":"105.00.*Yumi Kim","outcome":"confirm"},{"say":"yes","match":"105.00","outcome":"staged"},{"state":"state.send.sends.0.amount_cents","equals":10500}]

### Trial 1

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 105

Upmore: Got it. Set up $105.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $105.00; 4. Keep it private, then Pay. I'll confirm when $105.00 to Yumi Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 105

Upmore: Got it. Set up $105.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $105.00; 4. Keep it private, then Pay. I'll confirm when $105.00 to Yumi Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 105

Upmore: Got it. Set up $105.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $105.00; 4. Keep it private, then Pay. I'll confirm when $105.00 to Yumi Kim posts; if it hasn't by tonight, I'll ask.

## C02357 · M07 · Actually correction handles a different amount · PASS

Expected: [{"say":"send yumi 60"},{"say":"actually make it 150","match":"150.00.*Yumi Kim","outcome":"confirm"},{"say":"yes","match":"150.00","outcome":"staged"}]

### Trial 1

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 150

Upmore: Got it. Set up $150.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $150.00; 4. Keep it private, then Pay. I'll confirm when $150.00 to Yumi Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 150

Upmore: Got it. Set up $150.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $150.00; 4. Keep it private, then Pay. I'll confirm when $150.00 to Yumi Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 150

Upmore: Got it. Set up $150.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $150.00; 4. Keep it private, then Pay. I'll confirm when $150.00 to Yumi Kim posts; if it hasn't by tonight, I'll ask.

## C02358 · M08 · Bare currency correction retains payment context · PASS

Expected: [{"say":"send yumi 60"},{"say":"$37.50 instead","match":"37.50.*Yumi Kim","outcome":"confirm"},{"say":"yes","match":"37.50","outcome":"staged"}]

### Trial 1

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $37.50 instead

Upmore: Got it. Set up $37.50 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $37.50; 4. Keep it private, then Pay. I'll confirm when $37.50 to Yumi Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $37.50 instead

Upmore: Got it. Set up $37.50 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $37.50; 4. Keep it private, then Pay. I'll confirm when $37.50 to Yumi Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $37.50 instead

Upmore: Got it. Set up $37.50 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $37.50; 4. Keep it private, then Pay. I'll confirm when $37.50 to Yumi Kim posts; if it hasn't by tonight, I'll ask.

## C02359 · M09 · Split total correction recomputes every share before approval · PASS

Expected: [{"say":"split 180 with yumi and omar"},{"say":"make it 270","match":"90.00 each.*270.00","outcome":"confirm"},{"say":"yes","match":"90.00","outcome":"staged"}]

### Trial 1

User: split 180 with yumi and omar

Upmore: Request $60.00 each from Yumi Kim (@yumik) and Omar Rao (@omarr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 270

Upmore: Got it. Request $90.00 each from Yumi Kim (@yumik) and Omar Rao (@omarr) in Venmo: $270.00 split 3 ways, yours $90.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Yumi Kim (@yumik) $90.00 in Venmo, Omar Rao (@omarr) $90.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 180 with yumi and omar

Upmore: Request $60.00 each from Yumi Kim (@yumik) and Omar Rao (@omarr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 270

Upmore: Got it. Request $90.00 each from Yumi Kim (@yumik) and Omar Rao (@omarr) in Venmo: $270.00 split 3 ways, yours $90.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Yumi Kim (@yumik) $90.00 in Venmo, Omar Rao (@omarr) $90.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 180 with yumi and omar

Upmore: Request $60.00 each from Yumi Kim (@yumik) and Omar Rao (@omarr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 270

Upmore: Got it. Request $90.00 each from Yumi Kim (@yumik) and Omar Rao (@omarr) in Venmo: $270.00 split 3 ways, yours $90.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Yumi Kim (@yumik) $90.00 in Venmo, Omar Rao (@omarr) $90.00 in Venmo. I'll mark each one paid when the money lands.

## C02360 · M10 · Rent setup correction retains recipient and due day · FAIL

Expected: [{"say":"pay my rent"},{"say":"yumi $2700 on the 1st via Venmo"},{"say":"make it 2850","match":"2850.00.*Yumi Kim.*1st","outcome":"confirm"},{"say":"yes"},{"state":"standing.0.amount_cents","equals":285000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 2850

Upmore: Got it. Set up rent: $2,850.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,850.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"2850.00.*Yumi Kim.*1st","actual":{"thread_id":"30fdf202-67d1-4c51-8a3a-3a877c200a3e","reply":"Got it. Set up rent: $2,850.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 2850

Upmore: Got it. Set up rent: $2,850.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,850.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"2850.00.*Yumi Kim.*1st","actual":{"thread_id":"48574c8c-a863-4fb5-aaf8-2f832276568b","reply":"Got it. Set up rent: $2,850.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 2850

Upmore: Got it. Set up rent: $2,850.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,850.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"2850.00.*Yumi Kim.*1st","actual":{"thread_id":"c8d84563-a7e8-4279-916f-d87ca678aae2","reply":"Got it. Set up rent: $2,850.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

## C02361 · M11 · Details refers to the pending payment · PASS

Expected: [{"say":"send yumi 60"},{"say":"details","match":"60.00.*Yumi Kim","outcome":"details"}]

### Trial 1

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $60.00 to Yumi Kim on Venmo $60.00 to Yumi Kim (@yumik) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

### Trial 2

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $60.00 to Yumi Kim on Venmo $60.00 to Yumi Kim (@yumik) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

### Trial 3

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $60.00 to Yumi Kim on Venmo $60.00 to Yumi Kim (@yumik) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

## C02362 · M12 · A short yes resumes a serialized split · PASS

Expected: [{"say":"split 180 with yumi and omar"},{"say":"yes","match":"Yumi Kim.*60.00.*Omar Rao.*60.00","outcome":"staged"}]

### Trial 1

User: split 180 with yumi and omar

Upmore: Request $60.00 each from Yumi Kim (@yumik) and Omar Rao (@omarr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Yumi Kim (@yumik) $60.00 in Venmo, Omar Rao (@omarr) $60.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 180 with yumi and omar

Upmore: Request $60.00 each from Yumi Kim (@yumik) and Omar Rao (@omarr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Yumi Kim (@yumik) $60.00 in Venmo, Omar Rao (@omarr) $60.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 180 with yumi and omar

Upmore: Request $60.00 each from Yumi Kim (@yumik) and Omar Rao (@omarr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Yumi Kim (@yumik) $60.00 in Venmo, Omar Rao (@omarr) $60.00 in Venmo. I'll mark each one paid when the money lands.

## C02363 · M13 · Cancellation that resolves the last discussed subscription · PASS

Expected: [{"say":"cancel netflix","match":"Netflix"},{"say":"cancel that","match":"Netflix"}]

### Trial 1

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 2

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 3

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

## C02364 · M14 · Stop rent refers to the confirmed standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"yumi $2700 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent","match":"Rent is off","outcome":"rent_stopped"},{"state":"standing.0.status","equals":"stopped"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Yumi Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Yumi Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Yumi Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

## C02365 · M15 · A contextual fee question retains payment identity and asks before acting · PASS

Expected: [{"say":"send yumi 60"},{"say":"what's the fee on that","match":"60.00.*Yumi Kim"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $60.00 to Yumi Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $60.00 to Yumi Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $60.00 to Yumi Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C02366 · M16 · Rent setup answers retain the original goal · FAIL

Expected: [{"say":"pay my rent","match":"Who"},{"say":"yumi $2700 on the 1st via Venmo","match":"2700.00.*Yumi Kim","outcome":"confirm"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"standing.0.payee_handle","equals":"@yumik"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"2700.00.*Yumi Kim","actual":{"thread_id":"9921f4f7-053e-48d6-84c8-ab694dd444c2","reply":"Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"2700.00.*Yumi Kim","actual":{"thread_id":"a8248f98-1549-4b76-8ec7-00d74e5ce90c","reply":"Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"2700.00.*Yumi Kim","actual":{"thread_id":"1d74644d-14f2-4c1c-b612-bd32d103d696","reply":"Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

## C02367 · M17 · New recipient handle and rail answers retain amount · PASS

Expected: [{"say":"send Dana 75"},{"say":"@danak"},{"say":"@danak"},{"say":"Venmo"},{"say":"@danak","match":"75.00.*Dana","outcome":"confirm"}]

### Trial 1

User: send Dana 75

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $75.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: send Dana 75

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $75.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: send Dana 75

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $75.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02368 · M18 · Split remembers total while asking who participated · PASS

Expected: [{"say":"split 180 with 2 friends"},{"say":"yumi and omar","match":"60.00 each.*180.00","outcome":"confirm"}]

### Trial 1

User: split 180 with 2 friends

Upmore: That's $60.00 each across 3 people. Who are the 2? I'll request $60.00 from each.

User: yumi and omar

Upmore: Request $60.00 each from Yumi Kim (@yumik) and Omar Rao (@omarr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: split 180 with 2 friends

Upmore: That's $60.00 each across 3 people. Who are the 2? I'll request $60.00 from each.

User: yumi and omar

Upmore: Request $60.00 each from Yumi Kim (@yumik) and Omar Rao (@omarr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: split 180 with 2 friends

Upmore: That's $60.00 each across 3 people. Who are the 2? I'll request $60.00 from each.

User: yumi and omar

Upmore: Request $60.00 each from Yumi Kim (@yumik) and Omar Rao (@omarr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

## C02369 · M19 · Rent is remembered on the next independent invocation · FAIL

Expected: [{"say":"pay my rent"},{"say":"yumi $2700 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent","match":"2700.00.*Yumi Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Yumi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"2700.00.*Yumi Kim","actual":{"thread_id":"507d9207-de2d-419f-b84d-9b2074346923","reply":"Rent for November: $2,700.00 to Yumi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Yumi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"2700.00.*Yumi Kim","actual":{"thread_id":"5ec4625c-7463-475a-8624-460c00ab0483","reply":"Rent for November: $2,700.00 to Yumi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Yumi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"2700.00.*Yumi Kim","actual":{"thread_id":"7bd0eca5-3de5-4aa8-ae4d-e536e3086d0b","reply":"Rent for November: $2,700.00 to Yumi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

## C02370 · M20 · An interrupted alias goal remains unconfirmed · PASS

Expected: [{"say":"save yumi as brother"},{"say":"no"},{"state":"recipients.0.nickname","equals":null},{"say":"send brother 60","match":"handle","outcome":"ask"}]

### Trial 1

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 60

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 2

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 60

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 3

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 60

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

## C02371 · M21 · A staged payment is remembered without claiming completion · PASS

Expected: [{"say":"send yumi 60"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Yumi Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $60.00 to Yumi Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 2

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Yumi Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $60.00 to Yumi Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 3

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Yumi Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $60.00 to Yumi Kim for you to send in Venmo. A second yes doesn't stage it again.

## C02372 · M22 · A staged split is remembered without duplicating it · PASS

Expected: [{"say":"split 180 with yumi and omar"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 180 with yumi and omar

Upmore: Request $60.00 each from Yumi Kim (@yumik) and Omar Rao (@omarr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Yumi Kim (@yumik) $60.00 in Venmo, Omar Rao (@omarr) $60.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 180 with yumi and omar

Upmore: Request $60.00 each from Yumi Kim (@yumik) and Omar Rao (@omarr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Yumi Kim (@yumik) $60.00 in Venmo, Omar Rao (@omarr) $60.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 180 with yumi and omar

Upmore: Request $60.00 each from Yumi Kim (@yumik) and Omar Rao (@omarr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Yumi Kim (@yumik) $60.00 in Venmo, Omar Rao (@omarr) $60.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C02373 · M23 · A declined payment cannot be resurrected by yes · PASS

Expected: [{"say":"send yumi 60"},{"say":"no","match":"Nothing","outcome":"declined"},{"say":"yes","not":"^Staged, not sent"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 2

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 3

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

## C02374 · M24 · Stopping rent prevents the next turn from claiming an active rule · PASS

Expected: [{"say":"pay my rent"},{"say":"yumi $2700 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Yumi Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Yumi Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Yumi Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C02375 · M25 · Status follow-up recalls staged versus sent · PASS

Expected: [{"say":"send yumi 60"},{"say":"yes"},{"say":"did it go through","match":"(?:not (?:yet )?(?:sent|posted)|staged|have not seen|waiting for.*post)"}]

### Trial 1

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Yumi Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $60.00 to Yumi Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

### Trial 2

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Yumi Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $60.00 to Yumi Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

### Trial 3

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Yumi Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $60.00 to Yumi Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

## C02376 · M26 · Unapproved nickname does not become a known fact · PASS

Expected: [{"say":"save yumi as brother"},{"state":"recipients.0.nickname","equals":null},{"say":"no"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 2

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 3

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

## C02377 · M27 · Unapproved rent terms are not durable instructions · PASS

Expected: [{"say":"pay my rent"},{"say":"yumi $2700 on the 1st via Venmo"},{"state":"standing.length","equals":0},{"say":"no"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

## C02378 · M28 · An expired payment card is restated and requires a fresh yes · PASS

Expected: [{"say":"send yumi 60"},{"minutes":11},{"say":"yes","match":"expired.*fresh","outcome":"confirm"},{"state":"state.send.sends.length","equals":0},{"say":"yes","match":"Staged","outcome":"staged"}]

### Trial 1

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Yumi Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Yumi Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Yumi Kim posts; if it hasn't by tonight, I'll ask.

## C02379 · M29 · An expired nickname card never writes a fact · PASS

Expected: [{"say":"save yumi as brother"},{"minutes":11},{"say":"yes","match":"expired"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 2

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 3

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

## C02380 · M30 · A question containing yes does not approve a payment · PASS

Expected: [{"say":"send yumi 60"},{"say":"yes but is there a fee"},{"state":"state.send.sends.length","equals":0},{"say":"no"}]

### Trial 1

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

### Trial 2

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

### Trial 3

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

## C02381 · M31 · Moving to small talk explicitly drops the old payment · PASS

Expected: [{"say":"send yumi 60"},{"say":"what's a good movie","match":"dropped.*60.00"},{"say":"yes","not":"^Staged"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $60.00 to Yumi Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $60.00 to Yumi Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $60.00 to Yumi Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C02382 · M32 · Switching recipients makes the latest request authoritative · PASS

Expected: [{"say":"send yumi 60"},{"say":"send omar 90","match":"90.00.*Omar Rao","outcome":"confirm"},{"say":"yes","match":"90.00.*Omar Rao","outcome":"staged"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send omar 90

Upmore: I dropped the earlier card. Set up $90.00 to Omar Rao (@omarr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omarr; 3. Enter $90.00; 4. Keep it private, then Pay. I'll confirm when $90.00 to Omar Rao posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send omar 90

Upmore: I dropped the earlier card. Set up $90.00 to Omar Rao (@omarr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omarr; 3. Enter $90.00; 4. Keep it private, then Pay. I'll confirm when $90.00 to Omar Rao posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send omar 90

Upmore: I dropped the earlier card. Set up $90.00 to Omar Rao (@omarr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omarr; 3. Enter $90.00; 4. Keep it private, then Pay. I'll confirm when $90.00 to Omar Rao posts; if it hasn't by tonight, I'll ask.

## C02383 · M33 · A payment supersedes a pending split rather than approving both · PASS

Expected: [{"say":"split 180 with yumi and omar"},{"say":"send yumi 60","match":"60.00.*Yumi Kim","outcome":"confirm"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"state":"state.split.staged.length","equals":0}]

### Trial 1

User: split 180 with yumi and omar

Upmore: Request $60.00 each from Yumi Kim (@yumik) and Omar Rao (@omarr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send yumi 60

Upmore: I dropped the earlier card. Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Yumi Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: split 180 with yumi and omar

Upmore: Request $60.00 each from Yumi Kim (@yumik) and Omar Rao (@omarr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send yumi 60

Upmore: I dropped the earlier card. Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Yumi Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: split 180 with yumi and omar

Upmore: Request $60.00 each from Yumi Kim (@yumik) and Omar Rao (@omarr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send yumi 60

Upmore: I dropped the earlier card. Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Yumi Kim posts; if it hasn't by tonight, I'll ask.

## C02384 · M34 · Switching from payment to rent keeps the new goal · PASS

Expected: [{"say":"send yumi 60"},{"say":"pay my rent","match":"Who","outcome":"ask"},{"say":"yumi $2700 on the 1st via Venmo"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 2

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 3

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

## C02385 · M35 · Never mind cancels an alias confirmation without saving · PASS

Expected: [{"say":"save yumi as brother"},{"say":"never mind"},{"state":"recipients.0.nickname","equals":null},{"say":"yes","not":"^Saved:"}]

### Trial 1

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 2

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 3

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

## C02386 · M36 · Confirmed aliases survive a new conversation · PASS

Expected: [{"say":"save yumi as brother"},{"say":"yes"},{"thread":"B"},{"say":"send brother 60","match":"Yumi Kim","outcome":"confirm"}]

### Trial 1

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Yumi Kim (brother, @yumik).

User: send brother 60

Upmore: Set up $60.00 to Yumi Kim (brother, @yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Yumi Kim (brother, @yumik).

User: send brother 60

Upmore: Set up $60.00 to Yumi Kim (brother, @yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Yumi Kim (brother, @yumik).

User: send brother 60

Upmore: Set up $60.00 to Yumi Kim (brother, @yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02387 · M37 · Standing rent survives a new conversation · FAIL

Expected: [{"say":"pay my rent"},{"say":"yumi $2700 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"pay my rent","match":"2700.00.*Yumi Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Yumi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"2700.00.*Yumi Kim","actual":{"thread_id":"406f7273-3fb7-4687-8176-60f36dfe461a","reply":"Rent for November: $2,700.00 to Yumi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Yumi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"2700.00.*Yumi Kim","actual":{"thread_id":"2f859fe8-339d-48ea-a675-2117f342827f","reply":"Rent for November: $2,700.00 to Yumi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Yumi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"2700.00.*Yumi Kim","actual":{"thread_id":"da5bed01-c9b2-46b3-84f9-dd55a7c4cebb","reply":"Rent for November: $2,700.00 to Yumi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

## C02388 · M38 · Unapproved thread A card cannot be approved in thread B · PASS

Expected: [{"say":"send yumi 60"},{"thread":"B"},{"say":"yes","not":"^Staged"},{"thread":"A"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C02389 · M39 · A nickname correction in another session supersedes the old meaning · PASS

Expected: [{"say":"save yumi as brother"},{"say":"yes"},{"thread":"B"},{"say":"brother is Omar Rao"},{"say":"yes"},{"thread":"C"},{"say":"send brother 60","match":"Omar Rao","outcome":"confirm"}]

### Trial 1

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Yumi Kim (brother, @yumik).

User: brother is Omar Rao

Upmore: Save "brother" as your name for Omar Rao (@omarr)? Then "send brother 20" goes to Omar Rao. "brother" means Yumi Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Omar Rao (brother, @omarr).

User: send brother 60

Upmore: Set up $60.00 to Omar Rao (brother, @omarr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Yumi Kim (brother, @yumik).

User: brother is Omar Rao

Upmore: Save "brother" as your name for Omar Rao (@omarr)? Then "send brother 20" goes to Omar Rao. "brother" means Yumi Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Omar Rao (brother, @omarr).

User: send brother 60

Upmore: Set up $60.00 to Omar Rao (brother, @omarr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Yumi Kim (brother, @yumik).

User: brother is Omar Rao

Upmore: Save "brother" as your name for Omar Rao (@omarr)? Then "send brother 20" goes to Omar Rao. "brother" means Yumi Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Omar Rao (brother, @omarr).

User: send brother 60

Upmore: Set up $60.00 to Omar Rao (brother, @omarr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02390 · M40 · Stopping rent in another session prevents future offers · PASS

Expected: [{"say":"pay my rent"},{"say":"yumi $2700 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"stop rent"},{"thread":"C"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Yumi Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Yumi Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Yumi Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C02391 · M41 · Repeating a staged approval does not stage twice after restore · PASS

Expected: [{"say":"send yumi 60"},{"say":"yes"},{"say":"yes","match":"already staged","outcome":"already_done"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Yumi Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $60.00 to Yumi Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $60.00 to Yumi Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 2

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Yumi Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $60.00 to Yumi Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $60.00 to Yumi Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 3

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Yumi Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $60.00 to Yumi Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $60.00 to Yumi Kim for you to send in Venmo. A second yes doesn't stage it again.

## C02392 · M42 · Rent setup retry leaves exactly one standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"yumi $2700 on the 1st via Venmo"},{"say":"yes"},{"say":"yes","not":"^Rent is set up"},{"state":"standing.length","equals":1}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C02393 · M43 · Confirmed alias repeated is recognized as already known · PASS

Expected: [{"say":"save yumi as brother"},{"say":"yes"},{"say":"save yumi as brother","match":"already|Already|already means","outcome":"already_done"},{"state":"ops.length","equals":1}]

### Trial 1

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Yumi Kim (brother, @yumik).

User: save yumi as brother

Upmore: "brother" already means Yumi Kim (brother, @yumik). Nothing changed.

### Trial 2

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Yumi Kim (brother, @yumik).

User: save yumi as brother

Upmore: "brother" already means Yumi Kim (brother, @yumik). Nothing changed.

### Trial 3

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Yumi Kim (brother, @yumik).

User: save yumi as brother

Upmore: "brother" already means Yumi Kim (brother, @yumik). Nothing changed.

## C02394 · M44 · The same month rent is staged once across restored sessions · PASS

Expected: [{"say":"pay my rent"},{"say":"yumi $2700 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"pay my rent","match":"already staged","outcome":"already_done"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Yumi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $2,700.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $2,700.00 to Yumi Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $2,700.00 to Yumi Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Yumi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $2,700.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $2,700.00 to Yumi Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $2,700.00 to Yumi Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Yumi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @yumik; 3. Enter $2,700.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $2,700.00 to Yumi Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $2,700.00 to Yumi Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

## C02395 · M45 · Retried split approval preserves one set of requests · PASS

Expected: [{"say":"split 180 with yumi and omar"},{"say":"yes"},{"say":"yes"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 180 with yumi and omar

Upmore: Request $60.00 each from Yumi Kim (@yumik) and Omar Rao (@omarr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Yumi Kim (@yumik) $60.00 in Venmo, Omar Rao (@omarr) $60.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 180 with yumi and omar

Upmore: Request $60.00 each from Yumi Kim (@yumik) and Omar Rao (@omarr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Yumi Kim (@yumik) $60.00 in Venmo, Omar Rao (@omarr) $60.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 180 with yumi and omar

Upmore: Request $60.00 each from Yumi Kim (@yumik) and Omar Rao (@omarr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Yumi Kim (@yumik) $60.00 in Venmo, Omar Rao (@omarr) $60.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C02396 · M46 · Nickname save failure is never reported as remembered · PASS

Expected: [{"say":"save yumi as brother"},{"set":{"failRecipients":true}},{"say":"yes","match":"couldn't save"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 2

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 3

User: save yumi as brother

Upmore: Save "brother" as your name for Yumi Kim (@yumik)? Then "send brother 20" goes to Yumi Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

## C02397 · M47 · Rent save failure is never reported as a stored rule · PASS

Expected: [{"say":"pay my rent"},{"say":"yumi $2700 on the 1st via Venmo"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*set|nothing was set up"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

## C02398 · M48 · A failed state write yields no approval card and retry is recoverable · PASS

Expected: [{"set":{"failState":true}},{"say":"send yumi 60","error":"state storage unavailable"},{"set":{"failState":false}},{"say":"send yumi 60","match":"60.00.*Yumi Kim","outcome":"confirm"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send yumi 60

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: send yumi 60

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: send yumi 60

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02399 · M49 · Unavailable facts cause an honest blocker and preserve the old card · PASS

Expected: [{"say":"send yumi 60"},{"set":{"unreadable":true}},{"say":"yes","match":"can't read.*Nothing was changed","outcome":"unavailable"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

### Trial 2

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

### Trial 3

User: send yumi 60

Upmore: Set up $60.00 to Yumi Kim (@yumik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

## C02400 · M50 · A failed rent correction retains the prior confirmed terms · PASS

Expected: [{"say":"pay my rent"},{"say":"yumi $2700 on the 1st via Venmo"},{"say":"yes"},{"say":"rent is 2850 now"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*change|rent stays as it was"},{"state":"standing.0.amount_cents","equals":270000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 2850 now

Upmore: Change rent (amount $2,700.00 to $2,850.00): $2,850.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 2850 now

Upmore: Change rent (amount $2,700.00 to $2,850.00): $2,850.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: yumi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Yumi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 2850 now

Upmore: Change rent (amount $2,700.00 to $2,850.00): $2,850.00 to Yumi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

