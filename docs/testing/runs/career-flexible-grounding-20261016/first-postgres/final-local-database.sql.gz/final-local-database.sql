--
-- PostgreSQL database dump
--

\restrict ydjx2u6jDCfrSr2XD0DJvKHpo9EIjkxesKV3FT5uGfmNEOCpNYFbRd4ednRHJdM

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg13+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$select null::uuid$$;


--
-- Name: agent_model_call_record(uuid, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_model_call_record(p_call uuid, p_usage jsonb) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $_$
declare slot public.agent_model_calls; k text; amount bigint;
begin
  select * into slot from public.agent_model_calls where id=p_call for update;
  if not found then raise exception 'model reservation unavailable'; end if;
  if jsonb_typeof(p_usage) is distinct from 'object' then raise exception 'invalid token usage'; end if;
  if (select count(*) from jsonb_object_keys(p_usage))<>4 then raise exception 'invalid token usage'; end if;
  foreach k in array array['input_tokens','output_tokens','cache_read_tokens','cache_write_tokens'] loop
    if jsonb_typeof(p_usage->k) is distinct from 'number' or (p_usage->>k)!~'^[0-9]+$' then raise exception 'invalid token usage'; end if;
    amount:=(p_usage->>k)::bigint;
    if amount>10000000 then raise exception 'invalid token usage'; end if;
  end loop;
  if slot.state='recorded' then
    if slot.usage is distinct from p_usage then raise exception 'conflicting token usage'; end if;
    return;
  end if;
  update public.agent_model_calls set state='recorded',usage=p_usage where id=p_call;
  insert into public.agent_usage(user_id,thread_id,model,call_id,input_tokens,output_tokens,cache_read_tokens,cache_write_tokens)
    values(slot.user_id,slot.thread_id,slot.model,slot.id,(p_usage->>'input_tokens')::integer,(p_usage->>'output_tokens')::integer,
      (p_usage->>'cache_read_tokens')::integer,(p_usage->>'cache_write_tokens')::integer);
end;
$_$;


--
-- Name: agent_model_call_reserve(uuid, uuid, uuid, integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_model_call_reserve(p_user uuid, p_thread uuid, p_request uuid, p_step integer, p_model text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare old public.agent_model_calls; slot public.agent_model_calls; n bigint;
begin
  if p_user is null or p_thread is null or p_request is null or p_step is null or p_step not between 0 and 15
    or p_model is null or length(p_model) not between 1 and 100 then raise exception 'invalid model reservation'; end if;
  perform 1 from auth.users where id=p_user for update;
  if not found or not exists(select 1 from public.agent_threads where id=p_thread and user_id=p_user)
    then raise exception 'conversation owner mismatch'; end if;
  select * into old from public.agent_model_calls where user_id=p_user and request_id=p_request and step=p_step;
  if found then
    if old.thread_id<>p_thread or old.model<>p_model then raise exception 'model reservation changed'; end if;
    return jsonb_build_object('ok',false,'state','already_reserved','call_id',old.id);
  end if;
  select (select count(*) from public.agent_model_calls where user_id=p_user and created_at>=date_trunc('month',now() at time zone 'UTC') at time zone 'UTC')+
    (select count(*) from public.agent_usage where user_id=p_user and call_id is null and created_at>=date_trunc('month',now() at time zone 'UTC') at time zone 'UTC') into n;
  if n>=900 then return jsonb_build_object('ok',false,'state','monthly_limit'); end if;
  insert into public.agent_model_calls(user_id,thread_id,request_id,step,model) values(p_user,p_thread,p_request,p_step,p_model) returning * into slot;
  return jsonb_build_object('ok',true,'state','reserved','call_id',slot.id);
end;
$$;


--
-- Name: career_host_commit(uuid, uuid, text, text, bigint, bigint, jsonb, jsonb, text, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_host_commit(p_user uuid, p_thread uuid, p_key text, p_hash text, p_revision bigint, p_account_version bigint, p_snapshot jsonb, p_patch jsonb, p_input text, p_response jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $_$
declare a jsonb; old_snapshot jsonb; receipt jsonb; wp jsonb; epoch bigint; next_snapshot jsonb; patch_key text;
begin
 if p_user is null or p_thread is null or p_key is null or p_hash is null or p_key !~ '^[A-Za-z0-9_-]{1,128}$' or p_hash !~ '^[a-f0-9]{64}$' or p_snapshot is null or jsonb_typeof(p_snapshot)<>'object' or octet_length(p_snapshot::text)>1048576
  or p_input is null or length(p_input)>20000 or p_response is null or jsonb_typeof(p_response->'reply') is distinct from 'string' or octet_length(p_response::text)>1048576 or jsonb_typeof(coalesce(p_patch,'{}'::jsonb))<>'object' or p_snapshot#>>'{scope,userId}' is distinct from p_user::text or jsonb_typeof(p_response)<>'object' or p_response->>'thread_id' is distinct from p_thread::text then raise exception 'invalid host commit';end if;
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 perform 1 from agent_threads where id=p_thread and user_id=p_user for update;
 if not found or exists(select 1 from agent_flow_state where thread_id=p_thread and user_id is distinct from p_user) then return jsonb_build_object('error','owned_thread_missing');end if;
 select value into a from career_watch_kv where user_id=p_user and key='career:account';a:=coalesce(a,'{"version":0,"epoch":0}'::jsonb);epoch:=coalesce((a->>'epoch')::bigint,0);
 select value into receipt from career_watch_kv where user_id=p_user and key='career:turn:'||p_thread||':'||p_key;
 if receipt is not null then
  if receipt->>'hash'<>p_hash then return jsonb_build_object('error','turn_key_conflict');end if;
  if coalesce((receipt->>'epoch')::bigint,0)<>epoch or (receipt->'response' is null or receipt->'response'='null'::jsonb) then return jsonb_build_object('error','privacy_epoch_changed');end if;
  return jsonb_build_object('response',receipt->'response','replay',true);
 end if;
 if coalesce((a->>'version')::bigint,0)<>p_account_version then return jsonb_build_object('error','revision_conflict');end if;
 select state->'career' into old_snapshot from agent_flow_state where thread_id=p_thread and user_id=p_user for update;
 if coalesce((old_snapshot->>'revision')::bigint,0)<>p_revision then return jsonb_build_object('error','revision_conflict');end if;
 for patch_key in select jsonb_object_keys(coalesce(p_patch,'{}'::jsonb)) loop
  if patch_key not in ('paused','preferred_locations','erase') then raise exception 'invalid account patch';end if;
 end loop;
 if p_patch ? 'preferred_locations' and (jsonb_typeof(p_patch->'preferred_locations')<>'array' or jsonb_array_length(p_patch->'preferred_locations')<>1 or length(p_patch#>>'{preferred_locations,0}') not between 1 and 100) then raise exception 'invalid location';end if;
 if p_patch ? 'paused' and jsonb_typeof(p_patch->'paused')<>'boolean' then raise exception 'invalid pause';end if;
 if p_patch ? 'erase' and p_patch->'erase'<>'true'::jsonb then raise exception 'invalid erasure';end if;
 if p_patch->'erase'='true'::jsonb then
  epoch:=epoch+1;
  update agent_flow_state set state=jsonb_set(coalesce(state,'{}'::jsonb),'{career}',jsonb_build_object('v',1,'scope',jsonb_build_object('userId',p_user),'revision',coalesce((state#>>'{career,revision}')::bigint,0)+1,'stores',jsonb_build_object('globalPause',jsonb_build_object('set',true,'source','account_control')))),updated_at=now() where user_id=p_user;
  delete from career_watch_kv where user_id=p_user and key not like 'career:turn:%';
  update career_watch_kv set value=jsonb_set(value,'{response}','null'::jsonb),updated_at=now() where user_id=p_user and key like 'career:turn:%';
  update career_reminder_outbox set payload=null,record=null,status='cancelled',updated_at=now() where user_id=p_user;
  a:=jsonb_build_object('epoch',epoch,'paused',true,'version',p_account_version);
 end if;
 a:=a||coalesce(p_patch-'erase','{}'::jsonb)||jsonb_build_object('version',p_account_version+1,'epoch',epoch);
 insert into career_watch_kv(user_id,key,value)values(p_user,'career:account',a)on conflict(user_id,key)do update set value=excluded.value,updated_at=now();
 if a->'paused'='true'::jsonb then update career_reminder_outbox set status='cancelled',updated_at=now() where user_id=p_user and status in ('pending','claimed','uncertain');end if;
 next_snapshot:=(case when p_patch->'erase'='true'::jsonb then jsonb_build_object('v',1,'scope',jsonb_build_object('userId',p_user),'stores',jsonb_build_object('globalPause',jsonb_build_object('set',true,'source','account_control'))) else p_snapshot end)||jsonb_build_object('revision',p_revision+1,'privacy_epoch',epoch);
 wp:=next_snapshot#>array['stores','alertWatchState','career:watch-profile:'||p_user];
 if wp is not null then
  if wp->>'user_id' is distinct from p_user::text then raise exception 'watch owner mismatch';end if;
  insert into career_watch_kv(user_id,key,value)values(p_user,'career:watch-profile:'||p_user,wp)on conflict(user_id,key)do update set value=excluded.value,updated_at=now();
 end if;
 insert into agent_flow_state(thread_id,user_id,state,updated_at)values(p_thread,p_user,jsonb_build_object('career',next_snapshot),now())
 on conflict(thread_id)do update set state=jsonb_set(coalesce(agent_flow_state.state,'{}'::jsonb),'{career}',next_snapshot),updated_at=now() where agent_flow_state.user_id=p_user;
 insert into agent_messages(thread_id,role,content)values(p_thread,'user',p_input);
 insert into agent_messages(thread_id,role,content,meta)values(p_thread,'assistant',p_response->>'reply',coalesce(p_response->'meta','{}'::jsonb)||jsonb_build_object('career',true,'career_turn_key',p_key));
 update career_reminder_outbox set seen_at=now() where user_id=p_user and status='delivered' and reminder_id in(select x->>'reminder_id' from jsonb_array_elements(coalesce(p_response->'reminders','[]'::jsonb))x);
 insert into career_watch_kv(user_id,key,value)values(p_user,'career:turn:'||p_thread||':'||p_key,jsonb_build_object('hash',p_hash,'epoch',epoch,'response',p_response));
 return jsonb_build_object('response',p_response);
end $_$;


--
-- Name: career_host_load(uuid, uuid, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_host_load(p_user uuid, p_thread uuid, p_key text, p_hash text) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $_$
declare f jsonb; a jsonb; r jsonb; w jsonb; legacy_count integer; reminders jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 if p_user is null or p_thread is null or p_key is null or p_hash is null or p_key !~ '^[A-Za-z0-9_-]{1,128}$' or p_hash !~ '^[a-f0-9]{64}$' then return jsonb_build_object('error','invalid_turn_key');end if;
 if exists(select 1 from agent_flow_state where thread_id=p_thread and user_id is distinct from p_user) or not exists(select 1 from agent_threads where id=p_thread and user_id=p_user) then return jsonb_build_object('error','owned_thread_missing');end if;
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 a:=coalesce(a,'{"version":0,"epoch":0}'::jsonb);
 select value into r from career_watch_kv where user_id=p_user and key='career:turn:'||p_thread||':'||p_key;
 if r is not null then
  if r->>'hash'<>p_hash then return jsonb_build_object('error','turn_key_conflict');end if;
  if coalesce((r->>'epoch')::bigint,0)<>coalesce((a->>'epoch')::bigint,0) or r->'response' is null or r->'response'='null'::jsonb then return jsonb_build_object('error','privacy_epoch_changed');end if;
  return jsonb_build_object('replay',r->'response');
 end if;
 select state->'career' into f from agent_flow_state where thread_id=p_thread and user_id=p_user;
 select value into w from career_watch_kv where user_id=p_user and key='career:watch-profile:'||p_user;
 if w is null and coalesce((a->>'epoch')::bigint,0)=0 then
  select count(distinct state#>array['career','stores','alertWatchState','career:watch-profile:'||p_user]) into legacy_count
   from agent_flow_state where user_id=p_user and state#>>array['career','stores','alertWatchState','career:watch-profile:'||p_user,'user_id']=p_user::text;
  if legacy_count>1 then return jsonb_build_object('error','watch_profile_conflict');end if;
  select state#>array['career','stores','alertWatchState','career:watch-profile:'||p_user] into w from agent_flow_state
   where user_id=p_user and state#>>array['career','stores','alertWatchState','career:watch-profile:'||p_user,'user_id']=p_user::text limit 1;
 end if;
 if w is not null and w->>'user_id' is distinct from p_user::text then return jsonb_build_object('error','watch_profile_conflict');end if;
 select coalesce(jsonb_agg(record),'[]'::jsonb) into reminders from (select record from career_reminder_outbox where user_id=p_user and status='delivered' and seen_at is null order by delivered_at,reminder_id limit 5) q;
 return jsonb_build_object('snapshot',f,'revision',coalesce((f->>'revision')::bigint,0),'accountVersion',coalesce((a->>'version')::bigint,0),'account',a,
  'watchState',case when w is null then '{}'::jsonb else jsonb_build_object('career:watch-profile:'||p_user,w) end,'reminders',reminders);
end $_$;


--
-- Name: career_model_budget_consume_v1(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_model_budget_consume_v1(p_user uuid, p_ticket uuid) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare r career_model_reservations_v1;c career_model_campaign_v1;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select * into r from career_model_reservations_v1 where id=p_ticket and user_id=p_user for update;
 select * into c from career_model_campaign_v1 where campaign='owner-shared-5usd' for update;
 if r.id is null or r.state<>'reserved' or r.expires_at<=now() or c.campaign is null or not c.reconciled or c.expires_at<=now() or c.provider is distinct from r.provider or c.model is distinct from r.model or c.price_key is distinct from r.price_key or not career_model_context_current_v1(p_user,r.thread_id,r.revision,r.account_version,r.epoch) then return jsonb_build_object('ok',false,'reason','context_changed');end if;
 -- Admission is not dispatch. Recheck the global stop under the same campaign
 -- lock used by settlement, including tickets granted before another owner
 -- tripped it. A refused reserved ticket can still settle as not_sent.
 if (select count(*) from (select 1 from career_model_reservations_v1 where state='unknown' or (state='started' and expires_at<=now()) limit 3) uncertain)>=3 then return jsonb_build_object('ok',false,'reason','usage_review_required');end if;
 update career_model_reservations_v1 set state='started' where id=r.id;
 return jsonb_build_object('ok',true,'ticket',r.id);
end $$;


--
-- Name: career_model_budget_reserve_v1(uuid, uuid, text, text, text, bigint, bigint, bigint, text, text, text, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_model_budget_reserve_v1(p_user uuid, p_thread uuid, p_key text, p_hash text, p_payload text, p_revision bigint, p_version bigint, p_epoch bigint, p_provider text, p_model text, p_price text, p_bound bigint) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $_$
declare c career_model_campaign_v1;r career_model_reservations_v1;
begin
 if p_user is null or p_thread is null or coalesce(p_key,'') !~ '^[A-Za-z0-9_-]{1,128}$' or coalesce(p_hash,'') !~ '^[a-f0-9]{64}$' or coalesce(p_payload,'') !~ '^[a-f0-9]{64}$' or coalesce(p_bound,0) not between 1 and 25000 or p_revision is null or p_version is null or p_epoch is null then return jsonb_build_object('ok',false,'reason','invalid_request');end if;
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 if not career_model_context_current_v1(p_user,p_thread,p_revision,p_version,p_epoch) then return jsonb_build_object('ok',false,'reason','context_changed');end if;
 select * into c from career_model_campaign_v1 where campaign='owner-shared-5usd' for update;
 if c.campaign is null or not c.reconciled or c.expires_at<=now() or c.provider is distinct from p_provider or c.model is distinct from p_model or c.price_key is distinct from p_price then return jsonb_build_object('ok',false,'reason','budget_unavailable');end if;
 select * into r from career_model_reservations_v1 where user_id=p_user and thread_id=p_thread and turn_key=p_key;
 if r.id is not null then return jsonb_build_object('ok',false,'reason',case when r.request_hash<>p_hash or r.payload_hash<>p_payload then 'turn_key_conflict' else 'already_reserved' end);end if;
 -- A crashed caller may never settle its started ticket. After the receipt
 -- deadline it is uncertain too; its full bound remains charged.
 if (select count(*) from (select 1 from career_model_reservations_v1 where state='unknown' or (state='started' and expires_at<=now()) limit 3) uncertain)>=3 then return jsonb_build_object('ok',false,'reason','usage_review_required');end if;
 if c.opening_micros+c.current_micros+p_bound>c.limit_micros then return jsonb_build_object('ok',false,'reason','budget_exhausted');end if;
 insert into career_model_reservations_v1(user_id,thread_id,turn_key,request_hash,payload_hash,provider,model,price_key,revision,account_version,epoch,bound_micros)values(p_user,p_thread,p_key,p_hash,p_payload,p_provider,p_model,p_price,p_revision,p_version,p_epoch,p_bound) returning * into r;
 update career_model_campaign_v1 set current_micros=current_micros+p_bound where campaign=c.campaign;
 return jsonb_build_object('ok',true,'ticket',r.id,'boundMicros',r.bound_micros);
end $_$;


--
-- Name: career_model_budget_settle_v1(uuid, uuid, text, bigint, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_model_budget_settle_v1(p_user uuid, p_ticket uuid, p_outcome text, p_cost bigint, p_usage jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare r career_model_reservations_v1;charged bigint;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select * into r from career_model_reservations_v1 where id=p_ticket and user_id=p_user for update;
 if r.id is null or coalesce(p_outcome,'') not in ('recorded','unknown','not_sent') then raise exception 'invalid owned model settlement';end if;
 if (p_outcome='not_sent' and (r.state not in ('reserved','not_sent') or p_cost is distinct from 0)) or (p_outcome='recorded' and (r.state not in ('started','recorded') or p_cost is null or p_cost<0 or p_cost>r.bound_micros or jsonb_typeof(p_usage) is distinct from 'object')) or (p_outcome='unknown' and r.state not in ('started','unknown')) then raise exception 'invalid model effect outcome';end if;
 charged:=case when p_outcome='unknown' then r.bound_micros else p_cost end;
 if r.state in ('recorded','unknown','not_sent') then
  if r.state<>p_outcome or r.cost_micros is distinct from charged or r.usage is distinct from p_usage then raise exception 'model settlement conflict';end if;
 else
  perform 1 from career_model_campaign_v1 where campaign='owner-shared-5usd' for update;
  if not found then raise exception 'model campaign missing during settlement';end if;
  update career_model_campaign_v1 set current_micros=current_micros-r.bound_micros+charged where campaign='owner-shared-5usd';
  update career_model_reservations_v1 set state=p_outcome,cost_micros=charged,usage=p_usage where id=r.id;
 end if;
 return jsonb_build_object('ok',true,'state',p_outcome,'contextCurrent',career_model_context_current_v1(p_user,r.thread_id,r.revision,r.account_version,r.epoch));
end $$;


--
-- Name: career_model_context_current_v1(uuid, uuid, bigint, bigint, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_model_context_current_v1(p_user uuid, p_thread uuid, p_revision bigint, p_version bigint, p_epoch bigint) RETURNS boolean
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select exists(select 1 from agent_threads t left join agent_flow_state f on f.thread_id=t.id and f.user_id=p_user left join career_watch_kv a on a.user_id=p_user and a.key='career:account'
 where t.id=p_thread and t.user_id=p_user and coalesce((f.state#>>'{career,revision}')::bigint,0)=p_revision and coalesce((a.value->>'version')::bigint,0)=p_version and coalesce((a.value->>'epoch')::bigint,0)=p_epoch and a.value->'paused' is distinct from 'true'::jsonb);
$$;


--
-- Name: career_model_context_read_v2(uuid, uuid, bigint, bigint, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_model_context_read_v2(p_user uuid, p_thread uuid, p_revision bigint, p_version bigint, p_epoch bigint) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare barrier bigint; dialogue jsonb; draft jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 if not career_model_context_current_v1(p_user,p_thread,p_revision,p_version,p_epoch) then return jsonb_build_object('ok',false,'reason','context_changed');end if;
 select coalesce(max((value#>>'{response,meta,career_dialogue,account_version}')::bigint),0) into barrier
 from career_watch_kv where user_id=p_user and key like 'career:turn:%' and value->>'epoch'=p_epoch::text
 and value#>>'{response,meta,career_dialogue,version}'='career_dialogue/v2' and value#>>'{response,meta,career_dialogue,barrier}'='true';
 select coalesce(jsonb_agg(x.body order by x.n),'[]'::jsonb) into dialogue from (
 select (value#>>'{response,meta,career_dialogue,account_version}')::bigint n,
 jsonb_build_object('user',left(value#>>'{response,meta,career_dialogue,user_text}',1200),'assistant',left(value#>>'{response,reply}',1800)) body
 from career_watch_kv where user_id=p_user and key like 'career:turn:'||p_thread||':%' and value->>'epoch'=p_epoch::text
 and value#>>'{response,meta,career_dialogue,version}'='career_dialogue/v2'
 and (value#>>'{response,meta,career_dialogue,account_version}')::bigint>barrier
 and (value#>>'{response,meta,career_dialogue,account_version}')::bigint<=p_version
 order by n desc limit 8) x;
 select value#>'{response,meta,career_model,current_draft}' into draft from career_watch_kv
 where user_id=p_user and key like 'career:turn:'||p_thread||':%' and value->>'epoch'=p_epoch::text
 and value#>>'{response,meta,career_dialogue,version}'='career_dialogue/v2'
 and (value#>>'{response,meta,career_dialogue,account_version}')::bigint>barrier
 and (value#>>'{response,meta,career_dialogue,account_version}')::bigint<=p_version
 and value#>>'{response,meta,career_model,current_draft,status}'='draft_not_sent'
 order by (value#>>'{response,meta,career_dialogue,account_version}')::bigint desc limit 1;
 return jsonb_build_object('ok',true,'user_id',p_user,'thread_id',p_thread,'revision',p_revision,'account_version',p_version,'epoch',p_epoch,'barrier_version',barrier,'dialogue',dialogue,'current_draft',draft);
end $$;


--
-- Name: career_reminder_ack(uuid, text, uuid, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_reminder_ack(p_user uuid, p_id text, p_lease uuid, p_record jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare r career_reminder_outbox; a jsonb; ledger jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 select * into r from career_reminder_outbox where user_id=p_user and reminder_id=p_id for update;
 if not found then raise exception 'missing reminder';end if;
 if r.status='delivered' and r.lease_token=p_lease then return jsonb_build_object('status','delivered','record',r.record);end if;
 if r.lease_token is distinct from p_lease or r.status not in ('claimed','uncertain') or a->'paused'='true'::jsonb or not career_reminder_allowed(p_user,r.payload) then raise exception 'reminder acknowledgement unavailable';end if;
 if p_record->>'user_id' is distinct from p_user::text or p_record->>'reminder_id' is distinct from p_id or p_record->>'channel' is distinct from 'product_inbox' or p_record->'deadline' is distinct from r.payload->'deadline' or p_record->>'url' is distinct from r.payload->>'url' or p_record->>'job_id' is distinct from r.payload->>'job_id' or p_record->>'title' is distinct from r.payload->>'title' or p_record->>'company' is distinct from r.payload->>'company' or p_record->'fit_lines' is distinct from coalesce(r.payload#>'{fit,lines}','[]'::jsonb) or p_record->'matched_fact_ids' is distinct from coalesce(r.payload#>'{fit,matched_fact_ids}','[]'::jsonb) then raise exception 'reminder evidence mismatch';end if;
 p_record:=p_record||jsonb_build_object('provenance',jsonb_build_object('kind','career_reminder_outbox','version',1,'payload_sha256',encode(sha256(convert_to(r.payload::text,'UTF8')),'hex')));
 update career_reminder_outbox set status='delivered',record=p_record,delivered_at=now(),updated_at=now() where user_id=p_user and reminder_id=p_id;
 select value into ledger from career_watch_kv where user_id=p_user and key='career:delivery-ledger:'||p_user;
 ledger:=coalesce(ledger,jsonb_build_object('user_id',p_user,'delivered_ids','[]'::jsonb,'records','[]'::jsonb));
 ledger:=ledger||jsonb_build_object('delivered_ids',coalesce(ledger->'delivered_ids','[]'::jsonb)||jsonb_build_array(p_id),'records',coalesce(ledger->'records','[]'::jsonb)||jsonb_build_array(p_record));
 insert into career_watch_kv(user_id,key,value)values(p_user,'career:delivery-ledger:'||p_user,ledger)on conflict(user_id,key)do update set value=excluded.value,updated_at=now();
 return jsonb_build_object('status','delivered','record',p_record);
end $$;


--
-- Name: career_reminder_allowed(uuid, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_reminder_allowed(p_user uuid, p_reminder jsonb) RETURNS boolean
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select exists(select 1 from career_watch_kv w where user_id=p_user and key='career:watch-profile:'||p_user
 and w.value->>'user_id'=p_user::text and coalesce(w.value#>'{opt_out,global}','false'::jsonb)<>'true'::jsonb
 and exists(select 1 from jsonb_array_elements(coalesce(w.value->'interests','[]'::jsonb)) i where i->>'interest_id'=p_reminder->>'interest_id')
 and not exists(select 1 from jsonb_array_elements_text(coalesce(w.value#>'{opt_out,companies}','[]'::jsonb)) c where lower(c)=lower(p_reminder->>'company')));
$$;


--
-- Name: career_reminder_claim(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_reminder_claim(p_user uuid, p_id text) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare r career_reminder_outbox; a jsonb; token uuid;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 select * into r from career_reminder_outbox where user_id=p_user and reminder_id=p_id for update;
 if not found then return jsonb_build_object('status','missing','claimed',false);end if;
 if (a->'paused'='true'::jsonb or not career_reminder_allowed(p_user,r.payload)) and r.status in ('pending','claimed','uncertain') then update career_reminder_outbox set status='cancelled',updated_at=now() where user_id=p_user and reminder_id=p_id;return jsonb_build_object('status','cancelled','claimed',false);end if;
 if r.status='claimed' and r.lease_until<now() then update career_reminder_outbox set status='uncertain',updated_at=now() where user_id=p_user and reminder_id=p_id;return jsonb_build_object('status','uncertain','claimed',false);end if;
 if r.status<>'pending' then return jsonb_build_object('status',r.status,'claimed',false,'record',r.record);end if;
 token:=gen_random_uuid();update career_reminder_outbox set status='claimed',lease_token=token,lease_until=now()+interval '1 minute',attempts=attempts+1,updated_at=now() where user_id=p_user and reminder_id=p_id;
 return jsonb_build_object('status','claimed','claimed',true,'leaseToken',token,'reminder',r.payload);
end $$;


--
-- Name: career_reminder_enqueue(uuid, jsonb, bigint, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_reminder_enqueue(p_user uuid, p_reminder jsonb, p_version bigint, p_epoch bigint) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare a jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 if coalesce((a->>'version')::bigint,0) is distinct from p_version or coalesce((a->>'epoch')::bigint,0) is distinct from p_epoch or a->'paused'='true'::jsonb then raise exception 'stale or paused career worker';end if;
 if p_user is null or p_reminder is null or jsonb_typeof(p_reminder)<>'object' or p_reminder->>'user_id' is distinct from p_user::text or coalesce(length(p_reminder->>'reminder_id'),0) not between 1 and 200 or octet_length(p_reminder::text)>100000 then raise exception 'invalid reminder owner';end if;
 if exists(select 1 from career_reminder_outbox where user_id=p_user and reminder_id=p_reminder->>'reminder_id') then return jsonb_build_object('stored',true);end if;
 if not career_reminder_allowed(p_user,p_reminder) then raise exception 'inactive reminder interest';end if;
 insert into career_reminder_outbox(user_id,reminder_id,payload)values(p_user,p_reminder->>'reminder_id',p_reminder)on conflict(user_id,reminder_id)do nothing;
 return jsonb_build_object('stored',true);
end $$;


--
-- Name: career_reminder_list(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_reminder_list(p_user uuid) RETURNS jsonb
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select jsonb_build_object('reminders',coalesce(jsonb_agg(payload),'[]'::jsonb)) from (select payload from career_reminder_outbox where user_id=p_user and status in ('pending','claimed','uncertain') and payload is not null order by created_at,reminder_id limit 100) q;
$$;


--
-- Name: career_reminder_status(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_reminder_status(p_user uuid, p_id text) RETURNS jsonb
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select jsonb_build_object('status',status,'record',record,'leaseToken',lease_token,'reminder',payload) from career_reminder_outbox where user_id=p_user and reminder_id=p_id;
$$;


--
-- Name: career_task_account_v1(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_account_v1(p_user uuid) RETURNS jsonb
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select jsonb_build_object('exists',exists(select 1 from career_watch_kv where user_id=p_user and key='career:account'),'account',(select value from career_watch_kv where user_id=p_user and key='career:account'));
$$;


--
-- Name: career_task_begin_effect_v1(uuid, text, uuid, text, text, text, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_begin_effect_v1(p_user uuid, p_intent text, p_lease uuid, p_task text, p_operation text, p_effect_key text, p_bindings jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $_$
declare i career_task_intents_v1;a jsonb;e career_task_effects_v1;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select * into i from career_task_intents_v1 where user_id=p_user and intent_id=p_intent for update;
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 if a is null or i.intent_id is null or i.state<>'claimed' or p_lease is distinct from i.lease_token or p_task is distinct from i.task_id or i.expires_at<=now() or i.privacy_epoch is distinct from coalesce((a->>'epoch')::bigint,0) or i.authority_account_version is distinct from (a->>'version')::bigint or (p_operation<>'destination_readback' and a->'paused'='true'::jsonb) then raise exception 'task authority revoked';end if;
 if coalesce(p_operation,'') not in ('open','form','fill','answers','atReview','armForSubmit','submit','submissionState','destination_readback','read_public_page') or (i.binding->>'action'='research' and p_operation<>'read_public_page') or (i.binding->>'action'<>'research' and p_operation='read_public_page') or (i.binding->>'action'='prepare' and p_operation in ('armForSubmit','submit')) or (i.binding->>'action'='reconcile' and p_operation<>'destination_readback') then raise exception 'task operation not authorized';end if;
 if coalesce(p_effect_key,'') !~ '^[a-f0-9]{64}$' or p_bindings is distinct from i.binding then raise exception 'task effect binding mismatch';end if;
 if p_operation<>'destination_readback' and exists(select 1 from career_task_effects_v1 where user_id=p_user and task_id=p_task and state in ('started','uncertain')) then raise exception 'task effect outcome uncertain';end if;
 if i.spent+i.reserved>=i.budget_limit then raise exception 'task budget exhausted';end if;
 insert into career_task_effects_v1(user_id,intent_id,effect_key,task_id,operation,state) values(p_user,p_intent,p_effect_key,p_task,p_operation,'reserved') returning * into e;
 update career_task_intents_v1 set reserved=reserved+1 where user_id=p_user and intent_id=p_intent;
 return jsonb_build_object('token',e.token,'effectKey',e.effect_key,'state',e.state);
end $_$;


--
-- Name: career_task_claim_v1(uuid, text, text, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_claim_v1(p_user uuid, p_intent text, p_task text, p_lease uuid DEFAULT NULL::uuid) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $_$
declare i career_task_intents_v1;a jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select * into i from career_task_intents_v1 where user_id=p_user and intent_id=p_intent for update;
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 if i.intent_id is null then raise exception 'task intent missing';end if;
 if a is null or i.privacy_epoch is distinct from coalesce((a->>'epoch')::bigint,0) or i.authority_account_version is distinct from (a->>'version')::bigint or (i.binding->>'action'<>'reconcile' and a->'paused'='true'::jsonb) or i.expires_at<=now() or i.state not in ('queued','claimed') then raise exception 'task authority revoked';end if;
 if coalesce(p_task,'') !~ '^[a-f0-9]{32}$' or (i.task_id is not null and i.task_id<>p_task) then raise exception 'task binding mismatch';end if;
 if i.state='claimed' and (p_lease is null or p_lease is distinct from i.lease_token) then raise exception 'task claim busy';end if;
 update career_task_intents_v1 set task_id=p_task,state='claimed',lease_token=coalesce(lease_token,gen_random_uuid()),updated_at=now() where user_id=p_user and intent_id=p_intent returning * into i;
 return jsonb_build_object('version','career_task_intent/v1','intentId',p_intent,'userId',p_user,'taskId',i.task_id,'accountVersion',i.authority_account_version,'privacyEpoch',i.privacy_epoch,'leaseToken',i.lease_token,'binding',i.binding,'request',i.private_input);
end $_$;


--
-- Name: career_task_consume_effect_v1(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_consume_effect_v1(p_user uuid, p_token uuid) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare e career_task_effects_v1;i career_task_intents_v1;a jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select * into e from career_task_effects_v1 where user_id=p_user and token=p_token for update;
 select * into i from career_task_intents_v1 where user_id=p_user and intent_id=e.intent_id;
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 if e.token is null or e.state<>'reserved' or i.state<>'claimed' or i.expires_at<=now() or a is null or i.authority_account_version is distinct from (a->>'version')::bigint or i.privacy_epoch is distinct from coalesce((a->>'epoch')::bigint,0) or (e.operation<>'destination_readback' and a->'paused'='true'::jsonb) then raise exception 'task effect revoked or already consumed';end if;
 update career_task_effects_v1 set state='started' where user_id=p_user and token=p_token;
 return jsonb_build_object('consumed',true,'token',p_token);
end $$;


--
-- Name: career_task_control_hook_v1(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_control_hook_v1() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare u uuid; epoch_changed boolean;
begin
 if coalesce(new.key,old.key)<>'career:account' then return null;end if;
 u:=coalesce(new.user_id,old.user_id);
 perform pg_advisory_xact_lock(hashtextextended(u::text,0));
 epoch_changed:=tg_op='DELETE' or (tg_op='UPDATE' and coalesce((new.value->>'epoch')::bigint,0)<>coalesce((old.value->>'epoch')::bigint,0));
 update career_task_intents_v1 i set state=case when exists(select 1 from career_task_effects_v1 e where e.user_id=i.user_id and e.intent_id=i.intent_id and e.state in ('started','uncertain')) then 'uncertain' else 'cancelled' end,updated_at=now()
  where i.user_id=u and i.state in ('queued','claimed','uncertain') and (tg_op='DELETE' or new.value->'paused'='true'::jsonb or i.authority_account_version is distinct from (new.value->>'version')::bigint or i.privacy_epoch is distinct from coalesce((new.value->>'epoch')::bigint,0));
 if epoch_changed then
  update career_task_intents_v1 set private_input=null,result=null,
   binding=jsonb_build_object('version','career_task_intent/v1','intent_id',intent_id,'user_id',user_id,'action',binding->>'action','task_id',task_id,'request_hash',request_hash),updated_at=now() where user_id=u;
 end if;
 return null;
end $$;


--
-- Name: career_task_effect_status_v1(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_effect_status_v1(p_user uuid, p_token uuid) RETURNS jsonb
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select coalesce((select jsonb_build_object('state',state,'token',token,'beforeSha256',before_sha256,'afterSha256',after_sha256) from career_task_effects_v1 where user_id=p_user and token=p_token),'{}'::jsonb);
$$;


--
-- Name: career_task_finish_v1(uuid, text, uuid, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_finish_v1(p_user uuid, p_intent text, p_lease uuid, p_result jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare i career_task_intents_v1;a jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select * into i from career_task_intents_v1 where user_id=p_user and intent_id=p_intent for update;
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 if i.intent_id is null or p_lease is distinct from i.lease_token then raise exception 'task result owner mismatch';end if;
 if a is null or i.privacy_epoch is distinct from coalesce((a->>'epoch')::bigint,0) or i.authority_account_version is distinct from (a->>'version')::bigint or i.state not in ('claimed','completed') then return jsonb_build_object('state','revoked');end if;
 if p_result->>'userId' is distinct from p_user::text or p_result->>'id' is distinct from i.task_id or p_result->>'version' is distinct from 'career_task/v1' or octet_length(p_result::text)>1048576 then raise exception 'invalid owned task result';end if;
 if i.state='completed' and i.result is distinct from p_result then raise exception 'task result receipt conflict';end if;
 update career_task_intents_v1 set state='completed',result=p_result,updated_at=now() where user_id=p_user and intent_id=p_intent;
 return jsonb_build_object('state','completed');
end $$;


--
-- Name: career_task_pending_v1(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_pending_v1() RETURNS jsonb
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select jsonb_build_object('intents',coalesce(jsonb_agg(jsonb_build_object('userId',i.user_id,'intentId',i.intent_id,'binding',i.binding,'request',i.private_input)),'[]'::jsonb)) from (select i.* from career_task_intents_v1 i join career_watch_kv a on a.user_id=i.user_id and a.key='career:account' where i.state='queued' and i.expires_at>now() and i.authority_account_version=(a.value->>'version')::bigint and i.privacy_epoch=coalesce((a.value->>'epoch')::bigint,0) and (i.binding->>'action'='reconcile' or a.value->'paused' is distinct from 'true'::jsonb) order by i.created_at limit 50)i;
$$;


--
-- Name: career_task_result_v1(uuid, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_result_v1(p_user uuid, p_task text DEFAULT NULL::text, p_intent text DEFAULT NULL::text) RETURNS jsonb
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select coalesce((select jsonb_build_object('task',i.result,'researchProof',case when i.binding->>'action'='research' and i.result is not null then jsonb_build_object(
  'userId',i.user_id,'taskId',i.task_id,'intentId',i.intent_id,'binding',i.binding,
  'read',(select jsonb_build_object('state',e.state,'afterSha256',e.after_sha256,'admittedAt',e.created_at) from career_task_effects_v1 e where e.user_id=i.user_id and e.intent_id=i.intent_id and e.task_id=i.task_id and e.operation='read_public_page' order by e.created_at desc limit 1)) else null end)
  from career_task_intents_v1 i join career_watch_kv a on a.user_id=i.user_id and a.key='career:account' where i.user_id=p_user and (i.task_id=p_task or i.intent_id=p_intent) and i.privacy_epoch=coalesce((a.value->>'epoch')::bigint,0) order by i.updated_at desc limit 1),' {"task":null}'::jsonb);
$$;


--
-- Name: career_task_settle_effect_v1(uuid, uuid, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_settle_effect_v1(p_user uuid, p_token uuid, p_outcome text, p_before text, p_after text) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $_$
declare e career_task_effects_v1;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select * into e from career_task_effects_v1 where user_id=p_user and token=p_token for update;
 if e.token is null or coalesce(p_outcome,'') not in ('completed','definitely_failed','uncertain') or (p_before is not null and p_before !~ '^[a-f0-9]{64}$') or (p_after is not null and p_after !~ '^[a-f0-9]{64}$') then raise exception 'invalid effect settlement';end if;
 if e.state in ('completed','definitely_failed','uncertain') then
  if e.state is distinct from p_outcome or e.before_sha256 is distinct from p_before or e.after_sha256 is distinct from p_after then raise exception 'effect receipt conflict';end if;
 elsif e.state='started' or (e.state='reserved' and p_outcome='definitely_failed') then
  update career_task_effects_v1 set state=p_outcome,before_sha256=p_before,after_sha256=p_after where user_id=p_user and token=p_token;
  update career_task_intents_v1 set reserved=greatest(reserved-1,0),spent=spent+1 where user_id=p_user and intent_id=e.intent_id;
 else raise exception 'effect was not consumed';end if;
 return jsonb_build_object('state',p_outcome,'token',p_token,'beforeSha256',p_before,'afterSha256',p_after);
end $_$;


--
-- Name: career_task_turn_commit_v1(jsonb, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_turn_commit_v1(p_base jsonb, p_intent jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $_$
declare u uuid; a jsonb; saved jsonb; row_intent career_task_intents_v1; k text; action text; payload jsonb;
begin
 u:=(p_base->>'p_user')::uuid;action:=p_intent->>'action';
 if p_intent is null or jsonb_typeof(p_intent)<>'object' or p_intent->>'version' is distinct from 'career_task_intent/v1' then raise exception 'invalid task intent version';end if;
 for k in select jsonb_object_keys(p_intent) loop
  if k not in ('version','intent_id','user_id','thread_id','turn_key','request_hash','action','task_id','event_id','artifact_id','resume_sha256','payload_sha256','profile_sha256','destination','authority_account_version','privacy_epoch','research') then raise exception 'unknown task intent field';end if;
 end loop;
 if coalesce(p_intent->>'intent_id','') !~ '^[a-f0-9]{64}$' or p_intent->>'user_id' is distinct from u::text or p_intent->>'thread_id' is distinct from p_base->>'p_thread' or p_intent->>'turn_key' is distinct from p_base->>'p_key' or p_intent->>'request_hash' is distinct from p_base->>'p_hash' or coalesce(action,'') not in ('prepare','approve','reconcile','research') or coalesce(p_intent->>'event_id','') !~ '^[A-Za-z0-9_-]{1,128}$' then raise exception 'invalid task intent binding';end if;
 if action<>'research' and p_intent ? 'research' then raise exception 'research binding on another task kind';end if;
 if action='research' and (jsonb_typeof(p_intent->'research') is distinct from 'object' or (select count(*) from jsonb_object_keys(p_intent->'research'))<>2 or p_intent#>>'{research,url}' is distinct from p_intent->>'destination' or coalesce(p_intent->>'destination','') !~ '^https://[a-z0-9.-]+/' or coalesce(length(p_intent#>>'{research,question}'),0) not between 1 and 500 or p_intent->>'task_id' is not null or p_intent->>'artifact_id' is not null or p_intent->>'resume_sha256' is not null or p_intent->>'payload_sha256' is not null or p_intent->>'profile_sha256' is not null) then raise exception 'invalid research intent';end if;
 if action='prepare' and (coalesce(p_intent->>'artifact_id','') !~ '^[A-Za-z0-9_-]{1,160}$' or coalesce(p_intent->>'resume_sha256','') !~ '^[a-f0-9]{64}$' or p_intent->>'destination' is distinct from p_base#>>'{p_snapshot,stores,posting,url}' or p_base#>>'{p_snapshot,stores,posting,canonicalKey}' is null) then raise exception 'invalid preparation intent';end if;
 if action in ('approve','reconcile') and coalesce(p_intent->>'task_id','') !~ '^[a-f0-9]{32}$' then raise exception 'invalid task identity';end if;
 if action='approve' and (coalesce(p_intent->>'resume_sha256','') !~ '^[a-f0-9]{64}$' or coalesce(p_intent->>'payload_sha256','') !~ '^[a-f0-9]{64}$' or coalesce(p_intent->>'destination','') !~ '^https?://' or p_base->>'p_input' is distinct from 'Approve browser task '||(p_intent->>'task_id')) then raise exception 'invalid task approval';end if;
 if p_intent ? 'profile_sha256' and p_intent->>'profile_sha256' is not null and p_intent->>'profile_sha256' !~ '^[a-f0-9]{64}$' then raise exception 'invalid profile binding';end if;
 perform pg_advisory_xact_lock(hashtextextended(u::text,0));
 if exists(select 1 from career_task_intents_v1 where user_id=u and event_hash=encode(sha256(convert_to(u::text||':'||(p_intent->>'event_id'),'UTF8')),'hex') and intent_id<>p_intent->>'intent_id') then return jsonb_build_object('error','task_event_conflict');end if;
 select value into a from career_watch_kv where user_id=u and key='career:account';
 select * into row_intent from career_task_intents_v1 where user_id=u and intent_id=p_intent->>'intent_id';
 if row_intent.intent_id is not null then
  if row_intent.binding is distinct from p_intent then raise exception 'immutable task intent conflict';end if;
 end if;
 -- Call the existing commit, never a fork of its transaction/control logic.
 saved:=career_host_commit(u,(p_base->>'p_thread')::uuid,p_base->>'p_key',p_base->>'p_hash',(p_base->>'p_revision')::bigint,(p_base->>'p_account_version')::bigint,p_base->'p_snapshot',p_base->'p_patch',p_base->>'p_input',p_base->'p_response');
 if saved ? 'error' then return saved;end if;
 if saved->'replay'='true'::jsonb then
  if row_intent.intent_id is null then raise exception 'replayed task receipt missing intent';end if;
  return saved;
 end if;
 select value into a from career_watch_kv where user_id=u and key='career:account';
 if a is null or (a->>'version')::bigint is distinct from (p_intent->>'authority_account_version')::bigint or coalesce((a->>'epoch')::bigint,0) is distinct from (p_intent->>'privacy_epoch')::bigint or (action<>'reconcile' and a->'paused'='true'::jsonb) then raise exception 'task authority changed';end if;
 if p_base#>>'{p_response,task,intent_id}' is distinct from p_intent->>'intent_id' or p_base#>>'{p_response,task,userId}' is distinct from u::text or p_base#>'{p_response,task,bindings}' is distinct from p_intent then raise exception 'task response binding mismatch';end if;
 payload:=case when action='research' then jsonb_build_object('eventId',p_intent->>'event_id','research',p_intent->'research') when action='prepare' then jsonb_build_object('eventId',p_intent->>'event_id','posting',p_base#>'{p_snapshot,stores,posting}','artifactId',p_intent->>'artifact_id','resumeSha256',p_intent->>'resume_sha256') else null end;
 insert into career_task_intents_v1(user_id,intent_id,thread_id,turn_key,request_hash,event_hash,binding,private_input,authority_account_version,privacy_epoch,task_id)
 values(u,p_intent->>'intent_id',(p_base->>'p_thread')::uuid,p_base->>'p_key',p_base->>'p_hash',encode(sha256(convert_to(u::text||':'||(p_intent->>'event_id'),'UTF8')),'hex'),p_intent,payload,(p_intent->>'authority_account_version')::bigint,(p_intent->>'privacy_epoch')::bigint,p_intent->>'task_id');
 return saved;
end $_$;


--
-- Name: career_watch_cycle_commit(uuid, bigint, bigint, jsonb, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_watch_cycle_commit(p_user uuid, p_version bigint, p_epoch bigint, p_writes jsonb, p_reminders jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare a jsonb; entry record; reminder jsonb; saved jsonb; version bigint:=p_version;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 if coalesce((a->>'version')::bigint,0) is distinct from p_version or coalesce((a->>'epoch')::bigint,0) is distinct from p_epoch or a->'paused'='true'::jsonb then raise exception 'stale or paused career worker';end if;
 if p_writes is null or jsonb_typeof(p_writes)<>'object' or p_reminders is null or jsonb_typeof(p_reminders)<>'array' or octet_length(p_writes::text)>4194304 or jsonb_array_length(p_reminders)>1000 then raise exception 'invalid career cycle';end if;
 for entry in select key,value from jsonb_each(p_writes) loop
  saved:=career_watch_write(p_user,entry.key,entry.value,version,p_epoch);version:=(saved->>'version')::bigint;
 end loop;
 for reminder in select value from jsonb_array_elements(p_reminders) loop perform career_reminder_enqueue(p_user,reminder,version,p_epoch);end loop;
 return jsonb_build_object('version',version,'epoch',p_epoch);
end $$;


--
-- Name: career_watch_read(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_watch_read(p_user uuid, p_key text) RETURNS jsonb
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select jsonb_build_object('value',(select value from career_watch_kv where user_id=p_user and key=p_key),'version',coalesce((a.value->>'version')::bigint,0),'epoch',coalesce((a.value->>'epoch')::bigint,0),'paused',coalesce((a.value->>'paused')::boolean,false))
 from (select (select value from career_watch_kv where user_id=p_user and key='career:account') value) a;
$$;


--
-- Name: career_watch_write(uuid, text, jsonb, bigint, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_watch_write(p_user uuid, p_key text, p_value jsonb, p_version bigint, p_epoch bigint) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare a jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select value into a from career_watch_kv where user_id=p_user and key='career:account';a:=coalesce(a,'{"version":0,"epoch":0}'::jsonb);
 if (a->>'version')::bigint is distinct from p_version or (a->>'epoch')::bigint is distinct from p_epoch or a->'paused'='true'::jsonb then raise exception 'stale or paused career worker';end if;
 if p_user is null or p_key is null or not (p_key in ('career:watch-profile:'||p_user,'career:reminder-queue:'||p_user,'career:reminder-history:'||p_user) or (p_key like 'career:jobs:snapshot:board:%' and right(p_key,37)=':'||p_user)) or p_value is null or octet_length(p_value::text)>1048576 then raise exception 'invalid watch state';end if;
 if p_key='career:watch-profile:'||p_user and p_value->>'user_id' is distinct from p_user::text then raise exception 'watch owner mismatch';end if;
 insert into career_watch_kv(user_id,key,value) values(p_user,p_key,p_value) on conflict(user_id,key) do update set value=excluded.value,updated_at=now();
 a:=a||jsonb_build_object('version',p_version+1);
 insert into career_watch_kv(user_id,key,value) values(p_user,'career:account',a) on conflict(user_id,key) do update set value=excluded.value,updated_at=now();
 return jsonb_build_object('version',p_version+1,'epoch',p_epoch);
end $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    id uuid NOT NULL
);


--
-- Name: agent_flow_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_flow_state (
    thread_id uuid NOT NULL,
    user_id uuid NOT NULL,
    state jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_flow_state_state_check CHECK ((jsonb_typeof(state) = 'object'::text)),
    CONSTRAINT agent_flow_state_state_check1 CHECK ((pg_column_size(state) < 524288)),
    CONSTRAINT agent_flow_state_state_check2 CHECK ((NOT ((state)::text ~* '"(otp|one_time_code|password|passcode|card_number|pan|cvv|ssn)"\s*:'::text)))
);


--
-- Name: agent_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    thread_id uuid NOT NULL,
    role text,
    content text,
    meta jsonb,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT agent_messages_role_check CHECK ((role = ANY (ARRAY['user'::text, 'assistant'::text, 'system'::text])))
);


--
-- Name: agent_model_calls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_model_calls (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    thread_id uuid NOT NULL,
    request_id uuid NOT NULL,
    step integer NOT NULL,
    model text NOT NULL,
    state text DEFAULT 'reserved'::text NOT NULL,
    usage jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_model_calls_check CHECK ((((state = 'reserved'::text) AND (usage IS NULL)) OR ((state = 'recorded'::text) AND (usage IS NOT NULL) AND (jsonb_typeof(usage) = 'object'::text)))),
    CONSTRAINT agent_model_calls_model_check CHECK (((length(model) >= 1) AND (length(model) <= 100))),
    CONSTRAINT agent_model_calls_state_check CHECK ((state = ANY (ARRAY['reserved'::text, 'recorded'::text]))),
    CONSTRAINT agent_model_calls_step_check CHECK (((step >= 0) AND (step <= 15)))
);


--
-- Name: agent_threads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_threads (
    id uuid NOT NULL,
    user_id uuid NOT NULL
);


--
-- Name: agent_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_usage (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    thread_id uuid NOT NULL,
    model text NOT NULL,
    input_tokens integer DEFAULT 0 NOT NULL,
    output_tokens integer DEFAULT 0 NOT NULL,
    cache_read_tokens integer DEFAULT 0 NOT NULL,
    cache_write_tokens integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    call_id uuid
);


--
-- Name: career_model_campaign_v1; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.career_model_campaign_v1 (
    campaign text NOT NULL,
    provider text NOT NULL,
    model text NOT NULL,
    price_key text NOT NULL,
    limit_micros bigint NOT NULL,
    opening_micros bigint NOT NULL,
    current_micros bigint DEFAULT 0 NOT NULL,
    reconciled boolean DEFAULT false NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT career_model_campaign_v1_campaign_check CHECK ((campaign = 'owner-shared-5usd'::text)),
    CONSTRAINT career_model_campaign_v1_check CHECK (((opening_micros + current_micros) <= limit_micros)),
    CONSTRAINT career_model_campaign_v1_current_micros_check CHECK ((current_micros >= 0)),
    CONSTRAINT career_model_campaign_v1_limit_micros_check CHECK (((limit_micros >= 1) AND (limit_micros <= 5000000))),
    CONSTRAINT career_model_campaign_v1_opening_micros_check CHECK ((opening_micros >= 0)),
    CONSTRAINT career_model_campaign_v1_price_key_check CHECK ((price_key ~ '^[a-f0-9]{64}$'::text)),
    CONSTRAINT career_model_campaign_v1_provider_check CHECK ((provider = 'openai'::text))
);


--
-- Name: career_model_reservations_v1; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.career_model_reservations_v1 (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    thread_id uuid NOT NULL,
    turn_key text NOT NULL,
    request_hash text NOT NULL,
    payload_hash text NOT NULL,
    provider text NOT NULL,
    model text NOT NULL,
    price_key text NOT NULL,
    revision bigint NOT NULL,
    account_version bigint NOT NULL,
    epoch bigint NOT NULL,
    bound_micros bigint NOT NULL,
    state text DEFAULT 'reserved'::text NOT NULL,
    cost_micros bigint,
    usage jsonb,
    expires_at timestamp with time zone DEFAULT (now() + '00:00:30'::interval) NOT NULL,
    CONSTRAINT career_model_reservations_v1_bound_micros_check CHECK (((bound_micros >= 1) AND (bound_micros <= 25000))),
    CONSTRAINT career_model_reservations_v1_state_check CHECK ((state = ANY (ARRAY['reserved'::text, 'started'::text, 'recorded'::text, 'unknown'::text, 'not_sent'::text])))
);


--
-- Name: career_reminder_outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.career_reminder_outbox (
    user_id uuid NOT NULL,
    reminder_id text NOT NULL,
    payload jsonb,
    record jsonb,
    status text DEFAULT 'pending'::text NOT NULL,
    lease_token uuid,
    lease_until timestamp with time zone,
    attempts integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    delivered_at timestamp with time zone,
    seen_at timestamp with time zone,
    CONSTRAINT career_reminder_outbox_reminder_id_check CHECK (((length(reminder_id) >= 1) AND (length(reminder_id) <= 200))),
    CONSTRAINT career_reminder_outbox_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'claimed'::text, 'uncertain'::text, 'delivered'::text, 'cancelled'::text])))
);


--
-- Name: career_task_effects_v1; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.career_task_effects_v1 (
    user_id uuid NOT NULL,
    intent_id text NOT NULL,
    effect_key text NOT NULL,
    task_id text NOT NULL,
    operation text NOT NULL,
    token uuid DEFAULT gen_random_uuid() NOT NULL,
    state text NOT NULL,
    before_sha256 text,
    after_sha256 text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT career_task_effects_v1_state_check CHECK ((state = ANY (ARRAY['reserved'::text, 'started'::text, 'completed'::text, 'definitely_failed'::text, 'uncertain'::text])))
);


--
-- Name: career_task_intents_v1; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.career_task_intents_v1 (
    user_id uuid NOT NULL,
    intent_id text NOT NULL,
    thread_id uuid NOT NULL,
    turn_key text NOT NULL,
    request_hash text NOT NULL,
    event_hash text NOT NULL,
    binding jsonb NOT NULL,
    private_input jsonb,
    result jsonb,
    authority_account_version bigint NOT NULL,
    privacy_epoch bigint NOT NULL,
    state text DEFAULT 'queued'::text NOT NULL,
    task_id text,
    lease_token uuid,
    expires_at timestamp with time zone DEFAULT (now() + '00:10:00'::interval) NOT NULL,
    spent integer DEFAULT 0 NOT NULL,
    reserved integer DEFAULT 0 NOT NULL,
    budget_limit integer DEFAULT 120 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT career_task_intents_v1_intent_id_check CHECK ((intent_id ~ '^[a-f0-9]{64}$'::text)),
    CONSTRAINT career_task_intents_v1_state_check CHECK ((state = ANY (ARRAY['queued'::text, 'claimed'::text, 'completed'::text, 'cancelled'::text, 'uncertain'::text])))
);


--
-- Name: career_watch_kv; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.career_watch_kv (
    user_id uuid NOT NULL,
    key text NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE career_watch_kv; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.career_watch_kv IS 'MI-032 alerts host wiring: generic per-user KV for the career watch/assign state (152 watch profiles, reminder queues, seat history; 151 per-board snapshots; host delivery ledger). Written/read by scripts/career/alerts-host.mjs createSupabaseStore via the service role. Design: docs/career/alerts-host-wiring.md.';


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profiles (
    id uuid NOT NULL
);


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (id) FROM stdin;
00000000-0000-4000-8000-0000000000a1
00000000-0000-4000-8000-0000000000a2
\.


--
-- Data for Name: agent_flow_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_flow_state (thread_id, user_id, state, updated_at) FROM stdin;
00000000-0000-4000-8000-0000000000b2	00000000-0000-4000-8000-0000000000a2	{"career": {"v": 1, "scope": {"userId": "00000000-0000-4000-8000-0000000000a2"}, "stores": {"profile": {"id": "profile-1", "facts": [{"id": "SYN-BOUNDARY-PROJECT", "kind": "project", "text": "Built a synthetic calculator.", "unproven": false}], "basics": {}, "constraints": {"graduationDate": "2035"}, "preferences": {"locations": []}, "_careerTrackStore": {"rows": []}}, "conversationState": {"v": 1, "mode": null, "facts": {}, "sources": [], "hypotheticals": []}}}}	2026-10-16 07:50:02.049994+00
00000000-0000-4000-8000-0000000000b1	00000000-0000-4000-8000-0000000000a1	{"career": {"v": 1, "scope": {"userId": "00000000-0000-4000-8000-0000000000a1"}, "stores": {"profile": {"id": "profile-1", "facts": [{"id": "SYN-BOUNDARY-PROJECT", "kind": "project", "text": "Organized spreadsheet rows for a class assignment.", "unproven": false}], "basics": {}, "constraints": {"graduationDate": "2032"}, "preferences": {"locations": []}, "_careerTrackStore": {"rows": []}}, "trackStore": {"rows": []}, "conversationState": {"v": 1, "mode": "interview", "facts": {}, "sources": [], "question": "Tell me about a class or work project where something went wrong: what did you do, and what happened?", "hypotheticals": []}}, "revision": 1, "privacy_epoch": 0}}	2026-10-16 07:50:06.107553+00
\.


--
-- Data for Name: agent_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_messages (id, thread_id, role, content, meta, created_at) FROM stdin;
3af6eca3-782e-45ff-975b-022863793056	00000000-0000-4000-8000-0000000000b1	user	Help me practice an interview answer.	\N	2026-10-16 07:50:06.107553+00
6d581b77-205f-4942-bebf-ddb6a9bca8fc	00000000-0000-4000-8000-0000000000b1	assistant	AI coaching is unavailable for this turn. Let's practice one answer at a time. Tell me about a class or work project where something went wrong: what did you do, and what happened?	{"career": true, "intent": "conversation_interview", "contained": false, "career_model": {"status": "budget_denied", "provider_calls": 0}, "result_status": "prepared", "career_dialogue": {"epoch": 0, "barrier": false, "version": "career_dialogue/v2", "revision": 1, "user_text": "Help me practice an interview answer.", "account_version": 1}, "career_turn_key": "flex-turn"}	2026-10-16 07:50:06.107553+00
\.


--
-- Data for Name: agent_model_calls; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_model_calls (id, user_id, thread_id, request_id, step, model, state, usage, created_at) FROM stdin;
87061c9a-d404-4535-ba35-9b14e661cc52	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5dde715f-fea5-4103-97c3-2d3d60434c37	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
019fa092-1a77-43f0-9d3f-dbbb25e0ee49	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ea04954a-d48d-41c9-ade2-1a57748cb984	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
324e5f35-82c0-49f8-a436-7f0553139aee	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a0467c67-9311-47c9-9a06-25c904ec3de5	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6a8939fb-51b1-4905-9264-02e47445bfb0	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	96aa5714-de58-4c88-aa09-143c73b2a642	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
5883e610-5e78-4b4c-8089-2c15d2d23da5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	52a02cd9-6168-45fe-ab56-4fa5d90559d6	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
bc8deff7-23cd-471b-a866-146a0c75a770	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	956c48f2-6820-4c92-8207-6790fae5c05e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
5fd58634-325f-437c-bef9-10d2427fd083	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e080ef95-ad9c-49ca-b36c-385d48071dd7	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
920d5171-ce10-4f15-8b57-69dd074b7fab	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1220fbf0-3341-4737-8bf0-df6e8f0d6ec8	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ad86ea06-fa18-4609-a90c-c8f1eb05f7e5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	516781f1-153f-4b3a-87ba-70627b853398	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4bc43e48-f599-42cb-bd40-259e82a8e0ce	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	516bbe65-cf64-4b13-bc76-3a5710b7e455	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7d000625-3e61-4431-aef3-08bd4dfea32e	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2a30188d-5e94-4d2f-a99a-14e354f5d244	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
514e87ec-e5b7-43e3-9b2c-6c9034394cc2	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	40cfa491-1f6b-4937-8db7-39ac23edfa52	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e6803cc2-4b2c-4df5-8565-fdbac95828a3	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e19f891e-8af1-49f1-82ac-26bd40610130	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f2a2d947-a082-48f9-84a1-1310df9c4669	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	06df14e9-4296-49ce-b1e2-3bc647c5adf0	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
26dbf9f3-ac75-4e3b-99b2-90c540608ad9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b2c2da08-6ec5-4f83-9c6f-4b2c2456f7d2	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
794a6384-1fc2-4e3f-a152-4ff43dec86cb	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d40e5860-8c3b-417e-8300-d3623f6a8953	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
edc45584-b48d-4193-9340-bdc01742fb84	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b2f57168-7864-4f75-9b66-51731e8e95ba	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2f7e92df-e3d7-431c-80ca-89388e4d97e3	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b61f8158-3431-4704-bceb-1cea247cc14e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9d601f3a-91a2-4e44-ad77-a0310ef4a51b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e8f9995e-0299-424f-901f-3d8cdabdaacd	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6955178b-7e68-4fa9-8e44-f5f47d00f6a0	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2a65a33f-d022-43f5-b48f-0b2e84a82f9c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3abe8690-ed8e-487d-8bdb-f30f748938fb	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	cb0ca106-1454-490b-84d0-39d5c35700cf	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f0514981-8314-4b5e-ab67-1cdb1a34d29c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	6468882d-4f7d-4a48-83ec-76c506a06926	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4ae85822-6ff8-419d-8a65-ad3b8ca8f9e6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	7b0d8285-9e04-4caa-af9e-188f88c5c676	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c435978f-f7b3-4c22-82f6-2198e5c55a84	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a9df774f-88cd-4d44-a849-826bc5b83dcc	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e91a89f5-e083-47ea-ab25-87ddd2ce8c03	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5cf60ac2-6709-4c1c-82d4-42ed6a9ff591	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
cb7c95aa-51e0-40d1-99c1-05a7b077840c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	fea50279-5c5a-4425-8108-a083277c39aa	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6c448efa-ace1-44f1-b0dc-115f10624286	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ded85c4a-8972-43f2-b557-7b23a7121213	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1ba5342a-9a83-4765-9093-76609f15fa05	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	26a9203a-b0dd-4f24-848f-45c090f5c5d6	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6eb9d7fa-0e7b-4011-a192-0c447bc29735	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	fcb48b0d-92fd-412f-984d-4c76a27f6545	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
78c9fa09-4e62-4209-a36f-a277a7ef9cb8	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c816ba16-dab6-43f9-b9ec-c963d144affe	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
8c448921-aa0e-46c4-ad48-24a937507ce8	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c751919f-31ad-42f0-8bf4-b1b05078da8d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ae2532cb-8046-4498-8751-e390b96ee6ba	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	97712646-f490-4e66-9590-f3125c51106f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2069ba5e-d758-43a6-b8cc-0a414734c3e2	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	9067ca63-0a9b-4128-9954-1e69abc3d8c6	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
fcb5093f-0532-4d2a-b547-2533ce8c8cb6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	772f866c-24c8-41be-95f7-2530340835d9	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
57e2daac-362e-430c-ac7d-a400fa65bccd	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	fac74db7-ebff-4a18-8625-9a7787706068	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
af7f4a1a-cb4c-404e-aa4a-551a0eaf9faa	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b32f74f4-93a6-49cc-b009-be6995993455	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
8065af1f-fb6f-406b-aea0-aab2e2acb80c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	608ec81d-597f-40dc-addf-420bf36e4b50	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b53737c8-609f-46d5-9fad-81abb75407ed	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	0cba4505-bd95-4cce-8d3e-35fddf3e8156	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e21d5a68-b63f-4e8b-9944-ef08e2d8080a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4bfb331d-d3c3-4a67-a3a2-8ab891605966	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e60c5209-3d8c-40e3-b0d9-470c8ba635b6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1f504977-869e-4f1c-8107-e3fb679a321e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
388dce81-aed2-4a65-997a-69d0ef2d9f94	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	cb243d56-c770-47de-949c-5d455f2044dd	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9c5d9aa0-3c2a-4092-9068-f0d722e96767	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a83eda49-d72a-4710-a382-88c3d3cca6ed	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7615fb31-1058-4d1d-8839-768037210799	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b2088f06-b984-422a-9b84-37c9dd0de771	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
081c5b93-c103-4a87-b01e-8cf757092adf	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4e93f24f-e9ed-4e42-88ad-c9330b79690e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
30e67b18-55d1-4c28-aba2-19b50105bcd1	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e3f4027e-428e-4980-8a5e-adb3fba44a92	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4e2f3571-9bc2-4b68-9bcc-fc72152f764d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	42744ea7-adaf-4345-b407-621b47e4b8e4	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4c159213-2a6f-49c6-b2d5-9e83c28e64d8	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	db57175f-5c6c-4d3e-bc2b-f64b24c0952d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
868b17ba-0218-4922-b3bb-dff08ad032aa	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	9d9e4dd9-f5a2-44ed-87da-2182007f658f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2383f2b2-b3ea-4762-89ed-e02f53c2a230	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e485f283-88dd-4e02-ae84-68d4a58b983c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a73f80dd-6ff7-4bff-9873-5c195ab682bf	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e43eefaf-300e-449b-ab80-48d7b607bea8	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
eeaa91ab-abed-41c5-95a9-d950b0da0b8c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a2864051-ec60-4969-ad78-56374cfcddf4	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
73248229-128d-4675-8471-f7ba22be3824	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	acb789a2-5adc-4f42-b5ea-eb786457499a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7135571b-6bd2-43a5-a2ca-44c9457eef1b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	00c3bbb7-e90b-4620-824c-f1ec98bb7c24	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
8800c555-1ea9-4e37-b3b6-ecc8b09345a0	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e83c78b7-426f-4f3f-98aa-3bdc55fefa37	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
68c00b51-ad32-4183-8215-32a1c9b430fb	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c112c02d-8a86-4b64-97e5-9a70751983b8	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7d535d96-5e7b-42c2-b752-1b44c30a7666	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4648fb04-913f-4f42-8784-d295ad1e532e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
16937697-0d36-4329-851c-d33301bf81e4	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	de82f8e3-28d8-46aa-8383-a4d69b511415	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
98461b24-c3a2-48ad-9c58-dd8a22e94a5f	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5504d7d3-ca47-43f3-bb5d-0b8bb3682066	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c2cb4491-1472-49e6-a6fc-b40206dd8b96	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	47458101-a9d2-4b9c-8664-f5e5c9cd67a7	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
681c38b5-541b-4c49-99a4-98759e740251	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5e819e8e-f8aa-4821-9277-740d224c55a2	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b8d528d9-eb4f-49fb-87fb-fd2403040e67	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	9e7aa2df-f46b-4fb9-9305-b4f8539e03c1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6ae38d73-bf55-4fb5-9be1-0d3b216c18c5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e28e22fb-6cbb-4dd9-96df-e73aff950880	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
47cf28af-c888-4e49-88ea-f687581d8584	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c516f824-3c7d-4a41-90b3-b8b266a7d9d1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
bf64b810-2815-4a07-882b-d631eb514068	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b5a01ca2-342f-4bb5-8b00-76aaaa90cb9c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0298acc3-db7f-463d-99f0-52cd64aa7a71	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5b964e99-0054-4984-8fc5-046cc59245b1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
80be84c1-e2d8-4fac-99c0-85ab0a1cc5d2	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b2cc6afa-a272-4bea-b179-f4bedeed1ab3	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c05d3050-9ec2-4a2b-a154-d49d9d223c12	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	0e8cd90d-a98a-4c7b-8f23-a154183263d3	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
79ac5ccf-d7e4-44c8-a455-41b194d34751	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	14765821-ba87-4f67-adc1-01d2073822b1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
74b800de-38b4-41cb-9037-3dc78ec6ea16	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8478e253-2332-4926-9ef5-f9bc2af974d8	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6563f285-3bf4-4b7e-8d22-1e5d313ec8a7	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2d9efec2-c087-461e-b0ae-18970d5fe5d0	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4d5e95a9-a7f7-4196-867d-6d826b1673da	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c63e64aa-993b-4e65-a604-36c063a80cc1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
982d6971-23e4-404c-8077-d24680c451db	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	73930fdb-fdae-4ddc-8930-87c15f692e25	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f24e7e8c-f0b3-43dd-8794-45149e165002	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5ac24790-a664-4b54-9abb-977c8f9e0213	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
8b9ca548-d48d-48b1-9345-2c70961e8515	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a66dbb79-af3b-4dc7-9fa2-8124c58d6075	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f842d008-8eb4-4b0c-ac2d-4ecfc581bfa0	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	499def49-de20-49e1-969e-d194e083000a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6310218d-e0fb-4d2a-9bef-795e88fe019a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	26f313b7-eeaf-484b-8255-439a2e2bdd55	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c094b0ca-2e6e-46e9-a286-feda788278b9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c953aff1-d7a9-4771-a6a9-613c551d116a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
690c3bee-156d-45aa-a591-a5c1894ece81	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1b688a28-9736-46a9-8fc1-59ea0767907f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
dc129f4d-4c6b-41ae-9882-1f57ce867143	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	aac80714-9f20-43be-8844-d531c0e6170a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6a3c22b6-0b0e-43ae-af42-04b46bb12d6b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	57a11bf7-519e-4506-ac06-4eb0c5a2b544	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d611b740-b081-4704-9f49-e4dd9828be3b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	cbc9f33c-231d-463a-8114-e95046855b4e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
21ddfcfa-d8d7-4fb8-8dd9-b24c2345e82f	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	06258f9f-afac-452f-bdef-1f6ca961ba95	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
fa576089-9e30-4fa8-a94b-c3ff7cef42a8	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	7b429bca-1a93-45cd-a2f5-33c857fe2afc	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a0c59379-3aeb-43bb-819d-fa4e6e24e198	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d347794d-5201-4ff2-9ac8-67aa04d3399f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
05cccae8-845e-4dbe-b1d9-78d03922f8e7	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	0de76168-606f-4113-8379-ea87417efb99	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
83e6173d-9ea9-4838-a492-dbde3a8e3d27	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	83a47666-81b2-4438-9d5b-3d051819b9df	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
362c1fc5-3d77-4a9a-a56a-15c9d82d9dfb	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	02b770e3-0380-4d70-b44b-dbf93970e6e4	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
070f098c-b03c-456a-b350-ecfe5b2f07f8	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	13365c90-3661-47ae-96df-c799bf075de0	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
48f3679b-cd86-4638-ba42-17183d51cc2a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	34bc4d30-a58f-42a5-a36c-32d61781f0d0	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
66570581-1eca-4765-b74a-c65ae28e6ed0	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	92eb81de-f035-4fb0-a969-4487645ff521	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c295afca-28d1-4e56-b2b9-929093357eb5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	dfd7a021-10d6-4b54-a726-f167bfe0a855	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
78d98c21-82f2-4e3c-a341-5cbc1655af9f	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a31fc76d-efaf-4ccb-b9a0-56b66e1064ef	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
bbd46a0c-7fdf-47f6-ad8b-4665db1c749d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	867eaac6-1d64-4681-a857-6770d233734a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3c3ce638-526d-4c1c-a090-90049b9eeea9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ddcc0fb2-163e-4650-8ed6-6d528a0b5c09	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
69d076eb-2884-4a35-b20c-5c216402c5fc	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2c0cc555-1b6d-4845-9d59-64ebe49eb675	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
45d9e697-1805-453e-af12-99f004e6456d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8b2196b5-4328-4b7c-b8f1-54845ad1d60f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d78ba2c2-e39d-4a26-b34f-e12361e92bca	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	6385a826-e073-4592-8b1d-80690eaabd35	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2dff1c84-e07b-44df-b19f-83a3b40875a9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5eed9064-7d46-413d-a1ed-5226bcbc4501	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
36bced03-44bf-45e5-89bd-8e062215a6e3	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	06ce9510-2ae4-49d3-aa7c-05a6fa63ea93	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b2e1fed9-0fc5-41f8-8fef-ef45cea6af2c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8bdee384-5b2b-459d-80ca-08ddabb9647b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2265fe46-038e-419a-9a8b-f87d7058c15d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	988a305d-3655-4a4b-8751-690df6b92b8c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
95b9bd7d-78e5-4710-b5cb-03b9037a7698	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	3e242d5a-1f24-45f0-bb19-bc2dd65cd516	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4e90fa41-16f0-43b6-9ce0-5f109e9d9905	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ecabfe6d-92a7-4445-a054-335f90497157	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3f799729-7036-4595-9aa3-932e41c98366	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	eb6223fa-ca0e-46f1-8076-dbfbfc89cb8e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
019744f6-2fe2-4c70-b6bf-16e3960f441a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4eb33380-f524-4de5-9193-0fad93aa2069	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
af0e7a5a-1505-4247-9171-99a90096f7ba	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	513f7205-5509-4524-be82-d6b926699651	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
5e90f83c-4b5e-4fdb-b379-b057c09bb687	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	714d0f85-86b1-428b-bca1-4169ae749de5	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3da72642-0412-4838-ade2-ef0aace70558	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e4dabeaf-80c3-456f-942f-a7a0f0696c12	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
efdfdb7d-6dbb-40c0-91a5-881ee697f982	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	9606ed56-707e-4eab-ac49-72807bffc6dc	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
74d2bf62-faa6-44f7-ac34-37bd1c150315	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	293bf780-7d9b-43ab-b855-98688fe51edf	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
bca6013d-773b-42c5-896f-7ac7cb141295	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	9ab96e90-ce3d-469d-96e8-7c3fef17663a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
91194574-b42a-4386-8283-c914d1f5ec21	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8fb87026-d4c7-49cb-ace1-65e789ea4907	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
dd4ccbd8-5d7e-4785-91eb-5072faaaa714	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	13a29762-eb2a-43ac-bbea-820638fddcb3	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1d83e884-3de7-4541-8bf0-7e089fb71fa3	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1e9d6ea1-a3dd-4227-abcb-4b396aee9b5b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d7965b08-361e-4f6e-9436-03bfcdd13da3	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	53aaf4bf-f604-4dce-b894-b0814ff35ef1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4f405689-2f88-4560-965d-bb09a0ce8c71	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b675954b-9743-4687-b6b7-ca0a6946a650	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
37d9c444-5157-48ad-ad83-9d887881747e	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	db2f09ee-8d52-421b-82e5-caed547101ba	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
63283500-f30a-4b59-94cd-45f44c38b815	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	dcfba75f-c61b-4754-8528-e0708acc4699	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c0aaa96b-f1bc-491e-8138-1da7b1957ea5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	45073ec8-3d6a-44b3-9e98-b496219ba9a4	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
92879ba4-5b01-4cf1-8373-c3dbc853abd3	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8d729820-efaf-40eb-abd5-b4aad99a7bb3	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e5b02796-5ac0-45f0-95ce-ffcef4534441	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ab58a022-41c7-41ba-8b97-fa07a13d2a43	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9de66843-81fe-46cf-8702-bbd780b2c592	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4b320426-4792-41f9-bd11-3f819e8e9834	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
70f51b49-2b18-4b1d-985d-6171b2761a04	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	44512a86-a677-48e6-89a5-e2e62f8225ea	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6aa93b3f-e4bb-410c-88a1-b08d413cee41	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	0a640770-2358-439b-b616-f7765aefc129	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2e475119-a5f1-40a5-b2a1-62bee0ee0fbd	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e39fab13-e084-4673-a65a-6a4e3fa2ce58	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f8d313db-b36c-48e1-9966-0fd01b1b0b15	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	aa7649dd-bacf-46f2-a5cb-32b026367c5e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2b3e68cb-8214-4015-95fa-6c281f195da1	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	08b0ca4e-7d7f-4a37-9eb7-bad9bc88cec3	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f58084a6-af44-4bf9-982b-30f768a9a107	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	f4f0dde0-c4e2-455b-8823-9120dc1ff31f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
73a69159-8252-4f6d-a2a9-19d734266795	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	65933ba2-17f6-47a5-907a-afb4b4c7aa03	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
03529c26-06e1-4d9f-8f81-9854852c14f2	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	eeb3e72d-c64d-40b4-98e3-c0c38a50d5dd	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c9072336-19e3-4a9f-91a3-a6d118e74fd6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b141904d-2a50-42d5-8f9b-b73aad3d2489	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e8048856-a49b-448c-95b1-81ff8d814b89	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b5e5e31f-c50b-43fa-b279-67d788a20c54	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c0a0911c-6343-4b6e-8d8f-93e2b51aa8c4	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	cb4dc6fd-489a-401d-ad4f-9ecc073da363	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
147cf802-8787-46ea-9ffa-be7073772f6f	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2315a763-df19-47bd-bb09-911dca4e2ec8	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1e1361bb-9a80-4f60-b41e-45806c87de52	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c1967406-3e0e-4edb-8644-595a9d58f987	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0cc1af76-8199-4d99-b782-8a48315a7189	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d919e460-b007-4738-9bbf-58ad55f1973c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
8587c8d2-a7f2-4fdc-b191-8f9513706181	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	f02a093b-28ce-46e3-89a7-16d46212f87b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6f57a9a4-60eb-4e3a-808c-002a07f4c2b5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	39d533b8-a775-465a-8cb9-6ea6ee0f5188	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0a962f9d-e400-4e93-8ab3-9ee04bb88044	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ae172148-37b3-4c29-9a57-4b4eb394dc04	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2613f25b-57d6-4900-b169-1505000f3162	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	09fcafbc-0a39-4413-87f8-c3c117701792	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
588e4473-dd5e-4c9e-88a7-afddffd3aadb	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	3e2e182d-1469-4ec5-b9a1-07c9d6a8ec8f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
60b81fe0-399b-4ed4-8ffb-289d8b0a3fd5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	db814347-b380-4931-b96d-4fd56587b594	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e0eb705b-d3a1-4fd4-a4b5-f362a5793e76	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b7a568c5-c34d-429c-a0b0-df2eca103ef5	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3a58e5f5-262c-45ff-ab54-b979d4185ce3	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e4c7997b-b5fe-496c-b123-a9fe0f9e3e54	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d73c571c-158f-4bd1-8d45-ad41ec1c82b3	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	dd18d18f-9f8e-45d8-a84d-f29e34d572c4	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
5d03e601-e140-43ff-b271-82fb11339b4b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	581d0d3b-dc2e-4c34-b1e2-4beca94a9b27	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0a7b842e-6ada-4670-909c-2daa91f4f8f5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ab735117-57f2-402e-b126-2e6d8ff45e3e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
63777352-b5e7-4f3e-869d-283c6b8de789	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d60d4d04-cc2a-423a-a505-f7d06b629721	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
86dbad69-3804-40a7-8211-713d5cf826e3	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	fc521a2a-a43d-4fac-89bf-836e31d7cbe1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
410c32b1-99d8-49fe-9b99-d7eaa7dd5cec	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	7d9a120a-a298-41c7-af01-53378991e163	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4c02264c-7e5c-4c06-8ba0-87a8e1d30968	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5a5d5ea8-97cc-4d00-900c-b644ce5bf9b1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
734a473a-246b-4f52-b4ac-96f1e101a28e	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	472d7983-3ae3-4ecb-a478-b87e6a6efcc4	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6cf9dbd7-9752-4dd6-bab0-c256cb0a6d28	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	80041578-7497-424e-a762-fdbf9ebe6da4	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f7faf379-9b4e-43f8-95ce-25360d4ad2d8	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	271d28b4-94f7-4534-91c1-7a151f4cb000	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9f97b488-163d-4509-bfc4-1c034a0f61ff	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	f003f892-c9c2-4f96-8d14-0a167df9b7cc	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b3633cbb-60d0-4734-8901-feacda18bd1f	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c599cd5f-86e8-4d09-bb18-ccb257a26803	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
37ee8a3f-6416-4315-85ea-7357a552abc9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a5b39163-3b2b-42ca-8ff6-c569a159afdb	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e3385bb9-1118-4278-92b5-86caddcf184e	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a3c5aec7-9bd9-4855-8335-2ad6b1cf6011	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
018e4a7d-537a-46bb-bed5-f5784f4ae7d9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c072a65c-222a-4a36-8caf-5e4b89d0a0e3	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4de0e2e5-49a7-410e-bb90-93520e0a2d20	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a7e26633-c04e-4d7c-82be-a29e7d9a9232	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
dd119c35-de6f-4bca-a06e-7575e1c1057b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b2520f5b-672b-4117-acc9-2525bf9d998c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
bd04bb85-e48f-49e9-a277-b1478607d975	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5ad6ba85-6152-4706-81e9-da108a51219a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
fca3b96e-b1a2-4022-82bf-c4330fe13a76	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4daa977d-8743-4c6e-8900-9c6a4904aa9c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ba8f9b76-b721-40c5-89fc-7a888d3c7875	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e1128e3e-144c-481d-bbc9-dabe5d8922ba	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e5a0549e-1c0d-4f7b-9e36-cd5f676b71ea	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	106d8494-f502-4c23-bd5f-5e0ef3809302	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e0a449c5-ace1-428a-a83b-6a543106cd00	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	496b047f-248b-4a91-8cf3-404c61889599	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e45ddb7d-e7f9-48e9-90ee-65e1ef4622ea	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1d1da7d3-dce5-47fc-ad2d-124d54f9a397	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
fc3a6f2c-b7c6-4f5a-b5bc-6d5ad6224d2b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	fb4baf8f-2b7e-4afd-9a56-4c9b36e24e47	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
04214d2b-b7e1-4ee2-a0db-a7efa1c13806	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	133815fc-e30d-496c-904e-b77026593901	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6282433b-926a-48d0-b8cb-82a7a89ab40b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ee661d86-c75c-429d-a2af-c7883b595cb0	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2e7e23d1-cb87-44f8-beb9-de386616d6e8	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c56baaee-0190-4a4a-868c-85546db0bb85	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
caf34544-cf51-4c5f-a6b4-c4f63a951bd7	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	fbe43361-5299-43b8-862d-1284e55bf324	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ff4ac52d-2e1d-4b26-a209-f1d063537926	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8839c1b0-99ef-4759-8275-380133a3b368	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f388475f-1f29-4be5-9762-3a60b7185760	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8ef99dbf-6e3b-47f0-a1ec-662f6d17e6a9	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c0dfbcb8-6c7f-4224-bb8b-53941e6bd384	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c4a537f7-3043-4b83-8329-b6bafe7ef1db	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3c92a16a-8ce7-46b5-a752-cea039932808	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c82f5fb6-7212-4d11-9636-836ee40eacf1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3614ca63-fc62-45a2-9327-a00f75659986	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5eb7f05e-a025-4898-9c8f-00d0864f833c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2ac714a1-e5c5-496b-819c-049976c97726	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d5765f7f-f080-4b73-b130-5a00b1a8e3de	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
712cdd35-a319-4e88-b2b8-3783ffeb0ef9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2cb634f5-1467-4fa7-9216-e9b61283c9bb	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f5bb9ee5-06a3-4169-a153-9962ba58a382	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	6a0682e5-8ae0-4da1-ab31-86b57dadf383	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e7f75f4a-ea4f-4133-9477-6f0e36189d4a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	29ab0ef9-b7f6-4c52-b123-a4d3c6379126	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b498d089-cdde-4942-a999-8070febd7bed	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	95f5df51-9fb2-4015-9726-10a9461bef72	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a6eb2d83-ee99-4d21-8013-815b9056e1a3	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	75ddfc2e-e598-48bd-b975-89716396cfa1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4981ef99-8e76-4854-a309-3613e65724e9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8ed56e20-d444-4b0c-b57d-122065b094cd	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
5022ed0b-35d6-4f38-8374-0abffc927412	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4694d93b-da5c-4299-9f67-e1a4537e23cd	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
104c146f-2f8a-4604-a592-13a9486baed7	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8575b8c4-b9d0-4b6b-81ef-7ae8a57c6b6b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9a7e307c-7716-4e62-a6d0-20e0e860ee4a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1dafe9e4-717b-42e0-9a11-64e28f75e5ee	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
999c82ae-c85a-4f60-ade8-832fad72ba2b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5c06d41e-2553-4fa8-976a-40f942fb9abc	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
759b4706-398c-4e6c-8118-b96717b5f55a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	9e3edee6-a53e-444d-ab7e-9793d4e15aac	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9391fc36-af3d-488c-a209-00e99e9844c8	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ed9f063e-3a73-4ed1-b2a7-df319da8209f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4d288f6e-6a70-4687-a7d5-cf7ab1011718	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	12179881-d30f-49a2-ab4a-ba4ad1cf4b53	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
82fd01fe-b556-46aa-accb-43bb1b6f7ea9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1d16fd1c-1406-4908-87e0-c0f59709b6fb	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3e549dfe-31de-4341-a597-a92bf94391c8	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	517ef0b1-9a63-4648-9ab7-a4106384f479	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a98e13ab-5d54-4935-b2e8-ca031da46a52	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	73e11f3b-d1f0-4029-aee3-fa7b182afe9b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a1968a6a-07b6-4fc9-98c2-ad34bfa66cf1	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e2251d37-ba28-4697-98d6-350c7cb29911	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
aa3d20fe-da4d-46bc-a420-da1d77203e3a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	992cf754-d117-427e-8b75-da691306a35d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
da5af6de-d151-4257-90f9-95a8392595c8	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	49ddfead-d174-45fb-9bfd-bfac0098a1e6	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
5a615ba6-19e3-41d2-8bbc-555fe0bd7086	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ddf1a3bb-99a7-4c5e-b365-050429da0bb9	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d84bccc1-9361-4b5c-8eed-cbe52eb1922c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ddc4676f-f8c8-4041-8390-35a8b71e31c9	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4efee7c9-eaa4-4b30-bc9d-49d3b8a28ed5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	6c27ef44-0a29-4477-b30d-45b06b0c990e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1f996874-c7c8-40c8-8c56-324f2b2b6120	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	69cea68e-e999-43d1-a962-866a849ec9e9	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e8391a92-e739-4f1d-91dd-71cb1ba111c9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c7fd4081-228b-47c1-bf69-0772217a6221	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b847b16e-84ad-4cea-8872-2d83cf5ed271	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	db29d6a8-67bb-422c-8b2b-b12f81872360	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2e806817-7562-4cf4-8e06-74522be5c271	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2e191d3c-3f55-40db-bd4d-8e5f4e611479	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b33ba829-cb0b-418d-b955-9092c02a9fc3	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2aa75ddd-1400-4955-a608-c5914ee3edb9	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b67d36ed-f72f-4865-8057-e99c66a297af	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a33d94c7-5a38-4238-b841-c313ade96069	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ffddf589-8f95-4d11-979d-d3e6a4c17412	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	0059975d-3df7-49ce-9cc4-b54e8e6b18a0	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b49793ea-dcd1-4ea0-ad11-4f84f99372af	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	46b6bb26-0208-412e-8f55-537f05af0284	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0532953e-0235-4733-8edb-4da807556579	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	67d5b322-10d6-40e3-928a-b6679dfc65c6	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c77cfcc8-f995-4ec4-b3f2-9769964c37c6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d6a65b2c-631f-4a7f-8b3a-46a8feabb264	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d2c8b6d9-0763-4619-be91-a4ce65101f91	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	bb0dda35-1f71-4dfe-87d7-033cd342ecbc	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
97f94e3d-c3dd-4abb-b5bf-ffcb97c6fc12	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ccbcae13-bb3f-4fd6-92f2-79be8d670cbd	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
8bdb939d-8f00-4354-a27e-d83ca0af3176	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	823e8f68-9ed5-425a-8f02-7718353502e0	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
35be9f1a-c855-45ee-90ca-2567525c3d1e	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c7c29889-bd95-438b-ac48-e701725d5d35	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
bf873f8f-8f4e-4952-9f97-dd4a10eefb76	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	9b6759b8-d0a8-4b95-a333-66c1b7d5beea	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c1c6e5f4-27c9-4615-a25e-ed330f7b97e8	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	3cf09460-5c5b-4a52-99db-c8893e57f051	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
94051a87-1156-4472-aa8e-6ab0719bd8fd	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	9221f7ea-59f6-4276-9774-9a2db637cfbe	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d1b34af8-18ce-42eb-b5cc-1720354f3227	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	bea9b396-691d-4f13-a722-a719cff70d9e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f149ffa4-e234-4256-b268-b137fa531bba	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	69136977-d52e-4fc9-aaec-3e8eb996dc33	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a8336e4c-5df0-4559-afb5-209910818caf	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	eebeb873-032e-46d1-816a-dd7423b3e4af	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c8f88ada-a57c-4087-ab33-34b5c85cb278	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	bb762742-6572-486b-a65b-eeb27253155c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2f7b3a6d-00c5-49b9-99a6-ee470f616777	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2623d1bf-094e-4480-b26e-90e85db77317	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c15c0479-3ac8-4668-894f-fcc4c748c259	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	0e227203-98a5-459c-953b-8dd6d9d4938e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
88fad5f1-4df3-4e82-8802-4cb2f9566584	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8df9bb40-ac6f-4db7-ac7e-3198d2dd11bd	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
77499a06-49e2-4aca-83c0-ea94a248adf5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b5e39e40-5798-40ec-9089-0cb89725552f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
664e571f-32dd-4fbb-81c6-0fe36ccedbcb	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	705dc363-55d1-4642-a43e-5c94e67004ad	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
8b16aff2-a347-4494-9a69-921cf8e328e6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2b3d276f-27a4-494a-91a9-e9a938d2a31c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ad935200-2d3d-46ce-9161-62f1b9a901b9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	40fdb031-8d14-4701-bc7b-324110302c50	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
12f17e8d-8d25-4496-8081-259a4d7a1667	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8f8fabc2-c310-4647-9285-cb8b0263de24	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e7a4eea8-a6ac-4b17-a3f1-717428435914	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	eca04176-22a3-418a-be36-d53bea7685dd	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4d6981a4-2bb7-4cc9-b360-a92ed2f7b0cb	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	62dd710d-99a6-40d3-8f71-eee334d5ec87	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
424420a6-ccb7-45e0-9eab-1570107c6e6a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	cb783cc0-8405-4c65-a8a9-20d5412e5484	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
df76e3c5-9397-4cbd-ad55-f97a54a212f9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8e681b78-8471-4b55-8159-00543323d20d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
8154f453-65fb-4147-aa27-3c4f0be25a2f	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	be4f23c8-fbc2-4acc-8ab1-49acbae29294	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
fe563eb5-2c02-49b1-b767-8037d6f3b11b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c6dda001-52d3-45ca-9245-4d52bc155757	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
cd1207c4-6294-4192-b8ac-ecfa3a641796	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	f2e6c615-3de9-4ec4-adff-827c9e0b3e56	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
37497b76-dcd3-49e9-81e8-527d27e69395	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c4855c33-947e-411b-8d6f-e275b68f14c5	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
34e0dff9-204e-4824-b849-da3db37064cf	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	edcba94a-4d74-49b8-95ac-4ffeb2c5771b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
bd36e915-9164-47a8-8b74-3a24ea7b73bf	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	101c31a2-f6c5-46c2-86af-4d12da9d3e5e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
471d224e-6911-4b46-9d38-e79cbbcd3ab4	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	f1fc8529-7a19-44ef-b227-f1dd019fdffc	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e637cbbe-c803-446a-9e6b-4be88df754c6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	02ec3276-d591-4e69-9ba6-6986ec429c9e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7462de45-67df-4e78-87e5-891beb3b723f	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	99a11f50-ffb2-4012-9de3-751a659a311a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a85c71c7-25d9-4161-8836-b08304d484db	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	432ebdbb-a581-4d28-8d13-a2daaac8fe6e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
833addde-0496-4437-b58e-d7245893e404	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	73d01492-37eb-4277-bf9f-9f2118d93b41	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
625911b9-5467-401c-897d-f9da0a8be217	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1b640283-8756-4bec-977a-a859baa57dd8	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
177b76ff-5d19-4092-9913-8236fd8944cc	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	35f33c67-ea5e-49c9-8e74-91da9c263543	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f724571b-5de3-41cd-9cc7-466a58997327	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5c871593-adaf-4264-9f8c-58f37b78d939	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
964cf8dc-8564-4f46-a1f3-224d7b99da76	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2b82a624-d399-44b0-b2ee-1ec20ba329bd	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
38e0969a-7fbf-4b13-a5ee-7edf5071dee9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	104272ff-fcad-462a-aa74-4dd6cc22308e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a3e36e72-e724-4ba0-b072-aacd47b69e33	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	48ff477d-c1df-4fa8-bddc-0945e1f5a946	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0443dffe-c1ff-4572-a219-3fe0c2ad738e	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4adf6069-7b78-4f19-88eb-2fe7a49d3eca	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c81c159c-28ab-42ec-90bb-c878d1de3d41	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	af7725ee-640c-4b60-b604-d6577519d7eb	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
124c7581-74a5-48a6-9df5-fdeb4b425a67	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e9163ba6-1c38-42aa-b53e-fff82d0f9297	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
fe3289ef-876a-4486-8843-d97763178d55	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d48983c2-fa76-4527-8946-9841334902e3	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a1f69f32-1f89-43db-8681-582ecc747bf4	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1f0058df-9185-4c1f-a59f-2134f391ad0c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3ff1caac-f939-44d6-86f0-240bbc4e598b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8e1d5207-efea-4132-bb37-0be160443e36	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7225da0f-9021-4f58-aad5-782964b4d5ed	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4bd4a365-2857-4146-a961-058ab23f869f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c325d02d-c3cd-4eb6-9b8b-837d2db7c534	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e84c8f70-d81b-4729-a304-12c2e8a32767	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
abeef2d9-519a-4229-94bd-de39c9ac8988	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	0ccbf519-e535-450a-b64d-93cb56f21193	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ec051519-063e-4198-9458-ad2d779f21f9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d613decd-e370-499e-90f0-1615dbf1b817	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
597b45b2-3397-46e0-9b3c-21fb29835b3c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	25fe8891-9ebe-4f32-bbbf-7e0bfa60d9ff	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
df1b3558-5dce-4ca8-b9e2-a241ad53cbc0	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b964aafc-ddd3-4744-9a00-d5c45f2448d1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
378641c8-348b-4585-b3f4-66bf1ddb1dc9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	30e9b418-f357-460f-bab9-a825a5a2889a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
39ed16c3-a6d4-4682-b3c0-e31c083e133e	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	669d31cc-9a89-4585-8348-a24a95d4aeda	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
356414f9-cab7-4d1d-93b7-7276746705d5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ce4591a6-7b8e-44bb-a65a-d8a79a275efa	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
927de7f1-45ae-4aa9-a463-a6a079926e51	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1e44a52e-34b1-4a62-91c5-4f47b6524bf1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4d9ff15d-72b6-40f2-a67e-dbaece62e8ea	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	56f1eb78-1a4a-4894-b1ab-50bb949f4967	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9636d4da-471b-4fe6-9ae4-2e1f2e44fbcd	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	881bdea3-6d27-4ab4-b4b1-f7c9de2b5d1c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
98bd2c8e-ce5b-43fc-a79d-e495defb2546	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	9f1a370b-6855-453b-b392-ad1902df3402	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
68061744-c755-465b-96d3-42b313cf51d7	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c98c6ce1-95fd-4a08-a434-5eac8efc047d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
746e83e5-524c-4b80-a8f2-b71d7799494b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	3ef5b600-2e0b-43b5-8659-1a8d3f13ab7e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
8195c773-3e0c-4dfd-8417-ad2a3c5f41d3	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c960931c-81cf-4225-ba06-8b17086a2d51	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
8233671f-415f-4cad-b04e-5f117d3753c2	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ad991bd6-2382-48dd-a801-9854e2468b5a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ccc285de-8592-4b09-960d-922bf11b828c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	0a3b45d4-248e-4996-896b-42b79bfba99a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7388e094-7537-4055-a7e5-05905a7b5fc6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	18dbdb9a-58b5-4577-b31d-8e87ca4baf07	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b633213e-a934-4846-a38b-75f0b41a6f03	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	f7528550-9b98-4fa6-87c8-660aef7117f1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f6303519-fe66-46d6-a52b-d8e8b2c840de	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	63bab987-e0b7-4df9-add5-ad108c06f0c0	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
80b60cd2-4756-42a5-83b5-01501228ee8e	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	50889f22-d220-4632-a298-d562295d8c84	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a12e80ec-bb10-4c79-8a98-5058a524775d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b3230544-83f9-482c-a850-5cbd82f8acaf	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7d8eb7b2-19c8-4a9b-b024-451cc2204995	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e27dc476-0cf5-4edb-985f-097b714ec172	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f2c180ef-bca7-49f9-be0d-3fad72262bec	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	66963b16-74a0-4144-afc1-89a6e59f5f1b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a9add6aa-389a-4a37-8f8b-a74731c57dc0	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	86204052-4569-494f-aeb7-3d4459910bed	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
797470bd-5d60-478c-a5d6-b64c300ba299	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	be092891-025d-49b6-a45d-cf9640202ef3	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f60c253f-5f84-4836-a5a0-10edfb7d6231	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	25a718c6-704b-41e8-bbac-a0c9cf06ee9c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3cb95036-7208-40cf-aefd-d23a6ebedded	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c4af8949-03ef-4a2b-bcc2-630165d3741e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
fbd60ac0-e1c8-458e-9753-556dd8b2494c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	fbe42fba-25c5-4767-8021-e63735f60b5f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6c767d3c-1a2a-4dde-9c50-44f7022f4c41	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	7cc99349-82c5-4cc5-85dd-373cc8084880	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c06274ce-66e9-4654-bf86-25c214c4a83e	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	7c1d00aa-af87-435e-a032-83661b0236ec	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b5c0b0fa-f8a1-413d-bc3a-bbaabd6857c3	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	76c7eafc-ded2-4eeb-8d94-d36c1ddcd4e4	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
8065f61c-49a7-43c7-8399-b26345f0f064	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a388fa78-cd3c-49ad-a943-14a49d124754	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
00745862-0a13-4ba6-9977-0633bbf18c07	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5ce19e97-a737-40af-af66-b649dd20b29e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
182e3add-8c75-469b-889f-52c763fb48db	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	96c53d66-52a9-49cc-b0f5-f5eb0b351ac5	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
780e82c3-d19b-4b35-8eab-9be0a4db3d5c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	926d8f26-7230-43f8-97a3-56fb90a220cd	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
5287bb9c-2b86-4eba-84dd-ef3db0df0626	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	af9f1e97-cda7-49d8-a113-639b5017fb47	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
cf122103-3778-4463-8fae-c3cec3e5644d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	382ecc91-6dce-4c52-96c5-420ef8a461d7	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e3a9b7f2-4e07-487b-b0d6-c9aad6b37bcd	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a080c17b-c8b3-4cef-800b-2924caa7c0ce	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1f137486-2c61-4937-8a96-3ca9abf56fc1	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8562525d-4e38-40cb-ad86-ea07fdd5c8e7	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9d9b0ae4-2b2a-47ef-9199-2a6199b788e7	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	252dced8-93ac-49a3-af1e-d32d0554e654	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b38b4452-b712-4c14-8310-aefa7b8b1f61	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c5f37ebc-3c37-4199-a79a-3462d634af13	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e88a7ede-e190-49e0-a84c-e8169f3ec636	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	83ce4704-e5cb-48a1-b304-278e5ab08df9	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
92d28beb-a2c1-424f-9506-a3724d5cc85d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b69cffe3-2989-4728-a7c4-76da451dc9c9	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ff969832-cd9e-48d9-9536-403bcba2dc78	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	dd531e8a-8fb2-4b76-8dea-9462080a65d4	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b10b6016-8376-48ac-ae7c-5d0137f50f78	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e9864ce0-278f-484c-b19b-eb50a4d16ae2	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
431d0e7f-9824-424e-918e-0e8f0c403cea	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	0fe483ad-1eb5-494b-a659-7ce688edf732	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3778f87c-fdfa-495e-a37a-5af1c56ebbcb	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	15ab232f-dd07-4861-b5c1-b280d471de98	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
72ab33b1-a688-4a19-9bf9-21b418ac1009	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	72eb4983-eb3d-4bc4-8f39-05a752f52875	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
10b8791d-0f4d-47ba-ad18-8f9689067602	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	776ba73a-a7fc-4ff8-806a-8c740fa3126a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d1a9627b-cf07-45b6-b70c-4266766bc7ee	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ab801d4c-8e16-44f7-b803-c8b611200506	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
766730c2-2201-4843-b1ec-561caac21e4c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	19818e33-a943-4306-a9bc-5237da14323c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ea0f0f24-8b2a-46bf-a716-d5559144e19e	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d8751359-f406-4fa3-87b2-d2e00e7bc816	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7c633807-e220-46ac-8794-3dd199bd95c3	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	85452012-b862-4962-83ab-9f1b556d644a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
56d528fb-1b19-42e9-8f05-eb58488ac278	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	93ad5cfd-d0fe-4d29-9e22-28ce2c1bb42c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9b593b5c-7ce3-4346-a20e-1ed8c9f8af20	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	88f8d8fc-ff1a-409b-b6ed-6fade0ead023	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ce70a5e1-ce42-4e31-ae16-4506bd484da9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4562930a-526f-4c2e-a058-835dd23df7c8	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2ade8580-1459-4826-85f6-4d57704111ee	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ddeda804-6276-4383-b3ae-82f42f925224	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
dfc12278-a337-4de1-be28-90b457f08862	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1e66d4fa-bec2-441c-9c4f-2055b4992508	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e852123f-2e02-4d05-ad99-3d2650717e78	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8c3d430f-c3a3-4c0b-9f66-a2a4044dd42c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
78f60026-dc92-468a-8df3-304a8e02961a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	20457d25-9a25-4639-8be5-ddacfc23f6e1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
acb30b6c-8792-4bb9-a910-b6bb15be929d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1598c10a-973a-4a7a-9faa-ac7f2947ee65	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
220b20a6-a356-4b72-a609-35e77cd208a1	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e4e97f23-c8e4-4a12-8cf1-b174413b4918	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
54684f3f-cef0-4f17-b647-2d727d04c7f7	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	074417a5-7234-4f44-96c2-9aff654d093c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
fd8be754-5363-4ffc-a088-916566549638	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a3b1bbf3-ede2-45ec-bae1-b1db8ab86ca2	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b1d0dbe9-0f09-4028-bdfb-c766215f4123	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	229f41d8-359e-4184-8f33-2f6b017aa6c8	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
99db7105-18f3-4d16-bdfa-9f5b8a40456d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	40dbdf61-7765-4ae3-aa9f-21ceabaf207f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
5e5a2dab-b7bd-4776-9acc-202f08e0ac98	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e7001a3f-5ce3-4e42-80e9-5a933f5ec3e1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
96d37a55-a6dc-44ab-ac45-9e8e55e6779b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	35da86a5-77ff-4e86-b89f-403655b83152	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c0237355-9696-4aab-b546-8f2e7ffe546a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	fb4e2c4b-3585-4c89-b452-1a8973b06e59	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
89e939b0-4c3b-46c3-ae8a-34c6c64672c4	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b29a4fbe-6506-45dc-bfca-36e2252b9fcc	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b3c2e6b5-b984-4f9f-887c-d90be07c7b11	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	174f8cdd-b380-4b8c-8e24-7c8449422262	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
528d9972-b4db-48b4-b343-f6b3f755e9a2	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	6d91d0ef-9018-4421-92d8-1a902c1414c1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0b90b2b2-30e1-4621-94f8-73b926bab74c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	6e3dd3c0-48a4-4f6c-a05b-c66e4e9a4d3b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6b4f8e82-ecfb-4ff1-8b8c-bb32f7adcb6a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	0ed6d73a-d5dc-4c71-855d-6b1157fe0031	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6ae98c0d-15a0-4ef3-b39b-5350f0bb58fc	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	19b67a42-1a9d-4cc5-bbb6-22f4e9e9d71b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ed6b8573-516d-4d8a-a2e6-6ddbb621fb04	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	f030ab73-3634-465d-b886-a1a359be5f67	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
381679ec-580e-4321-a811-3eceeac0b569	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d064499a-dc97-44ad-a458-c5d696274768	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7e20459c-d45d-469b-bb5f-9d1310b32081	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	97db42d1-e238-4891-a330-719e4b60c9a5	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
5b856f86-f0ae-481a-8736-0754f0a4657b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	dff404ad-4a90-43ec-b131-c6a448df3183	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4e021b45-bd6d-4955-a06d-79950558e47a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	41828f2e-8bae-4e65-9104-68180f84ba13	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
fc9dbfcb-a32a-46e3-921d-390ac62b0951	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	32b1b148-4995-4e9b-a2d0-4b4b097564d5	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
342595bd-b11c-4c69-96c1-89ae5fdb7a7b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	39138e96-80ae-40b5-8ef7-a6b426cecc76	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d1f382d6-ad2e-4255-a9b4-05af6c59ff97	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	dd122d1a-3dd6-4bac-a99e-daf223b42517	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
afccfc7e-ba34-41d1-af24-45a01e0dcc35	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d9003b57-eb1c-47e2-bdd6-a33262057e26	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
30ed23d0-3061-4ac7-be0a-98da9a3fb49b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	09c1cc15-6402-42d3-b10b-c3938a8645bc	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
02b46de5-3fd3-49e4-8ad8-cd70bff44457	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c3e42a4e-8e82-4366-9028-e2d33ea74f75	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2f4e288f-cd98-4cc1-a852-4fa6639651e4	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	77ee09fb-92f2-4f0d-a440-cf6c63ea8b1f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
46f4343e-4db9-43f2-acd2-3b394dd61c2a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	61c5806c-2471-49c3-b43e-cce37064af3b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
bbf04764-3e7c-408e-98e9-f7c80884da26	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	cfc0e51a-1945-44fa-8421-17bcc0d92b44	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ff9c29ce-54d1-4ef6-a5aa-5c670acdafd3	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	7c4bb622-5a5a-4a9d-ad29-7e040a119ea0	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
5dff0e2e-e263-4f8a-a726-2ccb495508d2	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c7c2f492-ffd8-449a-b31d-92e66c9c2cac	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ddbdce5e-ce8e-49c1-b714-9b5ddfd601bc	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	fd37cbf1-3ab9-41e0-8299-13c7dd474072	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0fc7a104-934a-4418-b08b-4c3c9a7497b2	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c0279e7f-a468-4794-8d4a-3dd8ca5688eb	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
62baaac7-2319-4eb7-aef4-308afb10fba2	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c09a6632-edc3-4e33-aa21-2dc9bf3eafcb	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4f5af556-303d-44e2-b811-3fcfd92dec58	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	125dd5ed-5b89-4cf2-93b1-6434984ac541	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
56166135-f5fd-475d-acff-866896d70203	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	535087db-aacf-4474-987c-c8a4eadfc12a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
608243ad-622c-4c42-84bd-db14b93dd0a7	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	73838562-a536-4425-ac07-be4bbf1692ec	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
eaf8abc8-ef8c-4bb2-aa0a-c925eec5dd80	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8e54d316-7287-42e3-9e67-13fb8bee2e2d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c5156ce9-802f-4ddc-83ce-81621d0699ab	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	907f488c-9288-4c66-ad46-f2bd99238c34	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c3c15b1d-4598-486a-bda3-e7b7c0f94b44	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c32e53fd-0c3c-4ef4-89a7-ad5a26c090aa	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3787d6a7-9c63-4073-a3ac-3130a9931464	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d6b97499-c702-4b93-9ec4-aff870912ea6	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4ed776fd-7e55-4407-ac5e-48603f641ce5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b03dde29-5629-43b4-99b6-e8d9d6f5f8f7	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
bb796b5f-1316-4a81-b501-79720150b899	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	aaeb45b5-cd29-4660-90e4-2cd85b05a282	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f42d02c1-e58a-45ba-8877-4371a96cdb06	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	714c946e-5429-4621-9dfa-c24dab203b35	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
25934b10-dc70-4ee9-bc62-d2dccd35fa1b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8f680353-895b-4701-810a-8c7a088bb142	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
15432c92-73cf-4a83-a7a9-6afc590798a5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	cf08ad94-a8d0-45d6-8c04-9d9b3a0e2c46	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
be10c289-645d-410f-b593-20967db71e52	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	51b6de90-788e-4416-b428-0391c7b393bf	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0334f49a-56de-436a-8da2-d540536d0702	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5c7b411a-479f-43f7-b258-de02c00fd8a2	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
fc37d533-418e-4959-8064-0e0538f9eccc	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5ae6ea91-f311-4a61-a004-e264f7fc8f09	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
989b8d86-9602-4e07-acea-2d7f5e749f58	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5861eba0-abcb-4045-b72f-eb16e95fd124	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b263ee26-b312-4bb7-960b-185a536b107a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	6805695c-f25b-4a14-94dd-56a4d31523b3	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
192515d7-e474-4faa-a097-433bde27fdee	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1c6ad070-0248-4487-bd24-6ea63847bf0f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
585c0629-c2ce-479c-b49b-31b011689b85	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	53846622-7aa4-47e8-969f-e68d7fc50b52	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2cc325d7-5d18-4161-9a65-794b80351a30	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	6ad55207-66d7-40a1-a7a1-b958639c9926	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b339d240-2c11-4b57-82f1-fa986ca6156a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	34e58d93-1c05-4441-9391-367caa1b4830	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
760597a4-78a4-462d-b2bc-e41de5bdde49	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	75638621-50a1-4596-8017-42316c8f337c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ddf5187d-8c90-4d59-bcb9-6adc085b1b5c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b0e36451-11da-4557-889b-0f0f78d3ee5c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
5b50d543-3b7b-4ade-b99a-ee13f18a6372	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8ee79d8a-fffe-49b8-9959-6b7c4e86c2bd	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
603a8b35-c6b2-4248-b77e-5597f8a2c668	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5bafcc5d-3808-4a80-abb0-6586165b4276	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3ff1b98e-014f-48e2-82c3-709cd8602cbb	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	0bee960c-8f6f-4aef-888b-6d08a1475555	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e8a6bfea-03ae-431f-a235-a27bac778ca6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5c93ebab-6c64-41f9-9c9e-9074dd506e73	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
73eb473d-b9dd-4dff-bed1-716b44d9613c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	25d133ab-e87c-465b-867c-2ab733395845	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4d493533-4e9d-4b37-8c45-ca2d75d4ad35	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b127c39f-48bf-4b37-8179-2acca6f32817	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3da254cf-c454-4e33-ad95-9ccf424d5735	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	caabb925-6cac-4111-b3c1-49392d200cc8	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
bc4461ad-6a13-4cbd-bcaf-b048db0b70ab	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	7c51ea34-9386-40f2-8f19-afd762800dfe	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
47e6ac2e-4b92-45fb-8bac-cf284c1479dd	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	7de3e06d-1622-49ff-b1c5-c11d0bee2bda	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6c6f1fa7-6291-4e4f-8a3a-9a41856d5a02	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	3794ea32-0848-4ad8-8fb5-584dddfc11a1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7c45c5c3-6e0f-4f40-abe8-ac49cc533e2c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	6f2597d2-f3bc-4c51-86d6-43a23ae1ae70	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
bf637783-565a-47dd-bf58-824f75a37c0b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	cc68b11e-55f3-4d0d-aeb1-2cd978ac22f6	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
68544c4e-d3b3-4b67-aea1-37b44e8f2238	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	f4496b43-4417-4f93-b3eb-ea07da21fdd1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ee849f66-11a9-472d-be57-c79870149b65	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	7534c64b-f192-4c3c-8836-23a756d17c02	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
23d7903d-4802-4bbb-873b-5dea474c6c70	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ce856d99-70aa-4ff3-97e1-e5ea1620befe	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
fd440e62-515a-4d16-86ca-b9d1cfccf53b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	48781337-2faa-4fd1-84d8-f8f0c3ec71c6	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6c56fa73-3186-4bc9-a3db-71bf479a999d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	f3be9927-7f80-4cb5-aaca-df3c83e587af	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
700de2aa-5fec-44cc-bd5c-500ea209746e	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e942cafc-49f9-4ba9-a24b-26e3cac6860a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ee9ed746-b44b-4054-bac8-5eb414355c43	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	105c37a8-d02e-4272-aeaf-7d31cc98af8c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e6312363-47e9-4ac9-936a-9da0b4a2d4ee	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e34304a0-5d96-4b82-9755-0f6d8bcf67b6	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
78674c54-c522-42aa-9d4f-0fe8ccc8020a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a41ec4bb-dc3c-44f8-ac6e-405d25e78e46	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
db4eec4e-e5fb-4e50-af0e-e53c5208c29b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	20d183c2-5722-42d9-a4fc-cb89a9dee3e1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f5416f11-395f-49ae-b4da-216ab8a0ec88	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b063eeb9-807a-4330-afe3-2c4ee9864a06	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a689e742-f63b-48d7-96c2-dc98bc5d4de4	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	dab75929-f1cf-4f10-8a61-2d6870cf8334	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
838cd773-2015-417c-812d-d0b4e8f5cec2	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1dc19bba-5c03-4563-9d0e-643adc2a0e1a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
442f16f0-ef5b-4c01-9ffb-fa2b61fe8c45	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	cac1574c-d918-429a-b96b-32c3af459938	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6e2afed8-ed2a-4ab9-bcf8-1f909cbf0820	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	0b3fbcbf-78d0-4d51-85c9-f04965a8bf82	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
53990a70-7bc9-4f19-8675-077a5e8e3d17	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c8dc18c5-4d75-46f4-a6a2-db03ea474880	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
be2ae06a-db1d-4afe-91bf-0d533df3fe58	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	64b9047b-4623-4408-a935-12b52ce9e2b5	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3fd67def-713f-4b73-83c7-a91e04d399f2	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4991821f-c08e-4157-a303-7ac6c4fd4d02	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
20e27b33-9e18-4ba3-ad63-99bec5cdf09c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e1745bcb-6f9d-48b4-9b9c-1ed3a71f3cb0	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0cac3e92-d17f-45b9-a423-44b286729446	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1a9928a5-0625-4592-859c-eb07e5cb982e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2c701a00-fef6-411f-a689-8c39407fd0ab	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	64002f95-30da-4fd0-b895-b7ef520c7255	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f33a323b-869d-41de-9269-df5c995b3946	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b364e626-b73b-45a8-ab9b-964c2fc39f02	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c7728b3a-9a26-408e-a733-34c0260700fb	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	7c6363f4-671c-4309-9ebb-6f572b767eca	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ab455d08-ba47-4b16-9d0e-15b316ca773f	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	fb0afc0e-bbae-4871-9b8a-39398e5411f2	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
10e9ad22-5b9a-4652-8b03-3afd202349c2	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	6342b8d9-f2c1-4913-b717-46dc7fd8644e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
131a7c85-30a9-4027-b04c-cffa18c6b9f5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	9d728f33-443e-4bf7-b22d-ed26afff45e6	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ae77dfb7-e825-45ad-b866-a68c77011c7f	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d63c9102-57a8-46e4-91c2-e68056e957ed	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9e8adbde-50fd-4d5d-af53-16c34369b50d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	9e4cf719-1912-4c2b-9284-01a9e59b7730	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
65f7cb7d-a612-4373-85e5-609fd1d39ca5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	bcc828f6-c7f5-49fe-bdab-f21a4cff8e37	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d2707b20-8a4e-4dcd-9685-5e8ea4f3ae69	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	7fcb6aa3-d99b-44cb-b547-bbf566e63cbb	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
db67e193-3fb8-4937-b409-769dde9cd672	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d38652d8-a642-44be-bb70-39b0bddb8d13	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3e867ad4-16ec-4e5f-8ac5-a80932e29201	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b06d060d-84cd-4c82-b719-07226c2dad75	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7dadd0d3-6780-4082-ad31-e4cac09d027c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	9998a5a6-2d38-4415-b364-0ce4c4d0c024	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ec5c1be9-c441-4c54-90cc-44acceab112f	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	f55019a5-2c88-48ba-8f36-6a1a7a1fa232	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
27b5509f-4ef8-4050-8f06-4c4a3a424921	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b3122b25-9787-46de-86a2-3f1b1a8cab77	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
8a466421-0bb2-4345-93ec-13f62b204c1d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b8d4dd21-4a13-477f-813f-930b8ffa4e65	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
54e01378-8467-4f71-aad8-70f62199f96b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	13b851e4-3ac2-4767-bb04-d619c1922d38	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
94aa5ed6-0661-4a94-948b-e4792e616200	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	aa800262-7e4c-4512-ac8c-292c07b6161a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0fb5ef59-4b8d-4add-98a5-ec97d37988c5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a8744732-9347-4df9-8ba8-bfa4d7bf9671	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3e47875b-9fc2-41f9-b312-adbcaae94139	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	3a19003f-0d13-49c1-9243-5e29b4e1703d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
03dcb66e-6d3d-424d-8660-c41ebbb171b8	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	356ed032-a700-485c-b997-a70cd3a57176	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
51dcbaac-aa40-4a12-aba1-979ed9b9a610	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	9f12dca4-9590-4d0a-9ec8-636573ea7e04	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
759542f1-2994-461f-aa13-cdf2af24f02d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	18c1fc65-4f56-4b6e-a93e-87000b1a05aa	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
62865797-8af6-45f1-b535-1a91944714d9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1dfda575-fb52-48cb-ad07-9fd32804938a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
8a68a07e-d660-476a-b28c-6901d13b7ac0	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8f7e476d-6216-4aea-9edc-6d98c038af57	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d3cdc125-3beb-4d51-8d7e-7e460884c5a3	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ef762fcd-c562-4088-a6e4-a0ed8a724210	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e5767791-416f-4748-99b9-1a1ce1ad242d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	05b1d64d-ae49-4049-9e26-974d4ab58bf2	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
93bf64f8-7cee-402c-97b4-48064c3b5756	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	62df5d2a-80b5-4636-a4d3-32cf2d03818b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c8f86e13-ffb3-401b-ac81-6b00dbde059f	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	0fef2fcf-cd4b-4e10-9d0f-0304f2812bca	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6dc99b2a-7a90-4545-bd9a-ce29d7ea3e3d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ae0a8449-3da9-43a8-b827-1f961bdbb5a5	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c2ea3f76-57d6-4524-b1db-51b94737729e	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	592fc8ef-b3fc-4ceb-9a5f-c88a273fdb94	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ec69ebf0-aa0a-48a5-a232-e4401140e844	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	12e6fa1e-6046-4ef0-b13a-34e685724ac2	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9fbfea93-9f9a-453d-869b-2700c9532420	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b23ad382-734d-4a18-a6db-edc2b2097296	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
fe731922-ca00-492f-a01b-1a44c6f4c37b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a886165e-c2ea-4174-b1e1-8133a980548f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
00d6ee5a-1d81-4a92-963f-7a8bb51737be	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	43859af0-b1ae-4e36-bbd2-a5fc2d09408a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d8190b43-eac8-4eb7-ab1a-e261d8a5ec65	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	89d607e5-3cd7-4745-b5bf-5b4b50015312	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a5a7b962-ec0a-4689-a304-a6d69d488516	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2005bd98-26d1-431c-bcda-9a91ce9f2dd5	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e39c5bb8-9e40-4419-960f-d452328111f6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	23a1afe4-1430-48fd-8d96-30659cf44603	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
dd67733f-0760-4bdf-9d5d-72acbcb6a59b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	54abb60e-9d20-41d9-aa44-5a111a678fb5	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f4ab7114-dc13-4303-a632-79c07222aeeb	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2e26d1d8-8951-421f-940f-7ecb9610251e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d3d594d4-7513-4ce4-a729-00765313f2b2	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	95c91c89-2e62-4ac7-94c5-5e3c6911776d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
46dc6a52-f044-417f-9cf0-c4ac5ec0d0c6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	880f1485-9801-443d-8093-152d4f7ef4bc	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
634e8aab-8785-426c-bcb1-3e906a6f24e6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	dc28144c-fbf1-48c1-918e-bf055283be0b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
79746ea8-cada-4eef-86a0-327828835125	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e8b7d03c-521d-4e90-aa93-56f1a89bb474	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ec7ff6ea-c088-4eff-9d64-5b06e2272c45	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d3038486-907b-4f36-8ca1-d30ec926b63c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3ae0e364-5288-4e9a-b61b-d78f9e6d5c52	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	12724e90-5a2f-4d64-bd25-7743fe770b9d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0a12418f-359d-4bc2-b70f-2578d1611d4d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5e45c5de-e5b8-4566-b039-24d1c6f701b9	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a5f3eb1d-9573-4d45-b960-9e73be7873fe	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c3edafbd-8e28-4f21-81c7-0300dcdc88b7	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7a4615a7-fe29-4177-9843-26b479e9ebc5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ee80d763-235c-4ce8-a8ab-750202f53a5b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f3be17f6-6bb1-463d-b9c7-73ef849182d7	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e1cabde4-b091-4ef7-84ce-cbc7bf83ea69	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e14f3771-24eb-48a1-a8df-f42b8c0871fa	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e5f24656-cc86-49cb-9e4d-5c0bc0032961	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
abfdafac-65c3-4732-bd4b-77cee0c69921	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	cc48dc7a-3224-4b6e-8ed1-d76106c69dbd	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
fbd1b9f9-c7be-4065-8610-9b2185d47d9e	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	9a6d25c4-4642-49a0-8c87-72b10ada64c8	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e7e7b654-b080-4061-a6da-e0d4ea5d0287	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e118e9eb-6815-422e-bb95-0cf829c4a18d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7aa063c4-1b5c-4b70-8975-88787e09c8de	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	9487b236-9da7-4185-9d3a-079bea7ff64a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
68c36b4e-b57a-42c3-b744-bac1e4e8d465	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4d25c92a-3e5c-429c-b0ed-013641bca850	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2207e072-98a5-4a18-8f45-78c67efecae1	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2a38bf36-3824-4eaa-bde3-1edd6946a450	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
bc269a4c-891e-443b-9238-ed3cbaac7c5f	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4b49b123-7903-4a7e-9fe1-fade1b9d58b4	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
77283f0b-de7c-4c2f-83f2-a7ce488a5c56	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	3d328c2e-bcd3-4511-97c9-eec37d15d096	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d09dcbf3-be69-4420-809e-c4c6e530266c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	213fff74-348d-4a11-9510-ace009662744	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
867249c9-b2ed-4258-9dd3-de60182461e0	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	6e2778c3-b527-4387-89f9-f0d28f504545	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9c0bdac5-d738-48cd-8206-63b0b427be6c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	3a1cb824-1314-426a-826e-54a7d192d20f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9b831d18-1366-41c4-9bfa-c4968c6cbb6c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	0b2ea385-982e-4fb2-ba22-6cddea3a5fdd	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
83be9d26-7d8f-42be-b9d5-aea2a2dde52b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d2112b3e-407e-4e75-b581-8c70d30ea668	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2bd9c3d8-473e-4559-8bcd-f6ac9e1a19eb	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	bd9de959-7518-40ed-bd69-8cd1e0179053	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
5f279060-bd04-440d-bfc4-876fb93ac8d1	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e559f831-c8c3-414c-b97c-9fda7e689c25	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1eba4801-1bc4-4238-908e-7b5e18083d3e	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b740a1a5-2e77-4eb7-867d-056825c7f550	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
20dd6016-c80f-42c2-9896-7772ea5467fd	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	7eb0a01b-051a-4f0e-a175-6f77fbdebe40	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1d1b16e1-1635-4031-ac06-7c0de063f3ce	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	62a94fbe-6774-497f-9789-eef6a48f8278	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
675d6c4a-afdc-4ff8-9b84-93ce8716b757	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	77354aeb-459e-4c72-83b7-ad8e85935842	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
661ee103-6679-4433-bcbc-9cc6c6cf044c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	53fa678a-da87-46e4-b592-6e248f486192	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0a960a71-97a4-483e-b99d-92eda97897e4	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8c72554c-f708-4c0a-9004-f89c1e970b13	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e10541a2-3afe-425c-baa6-5c7c46c52e31	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ac3613e4-467b-45bd-b20a-ffb59e257fd5	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3ea70e5c-7aef-4a7a-8953-21658b1cb6e9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	557883cc-0b44-418a-a73d-cd7ec1dc731d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
44f5fa0a-327c-43a0-bd63-7a70421d6ec7	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2a544227-8483-470d-a5da-839c85fa601d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9a762c1c-cb48-4906-807e-cf252176c866	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	bf2b883e-48c7-4efb-99ca-1ed0edf24984	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6111e4fc-722d-4925-aeda-b43008e1d711	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b625e061-9459-43fb-8a01-200d1c26ee68	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3ab94d86-a9dd-4c3a-9d1d-10255354bb8e	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a34399a9-1921-45ed-afbe-b8aa2493476a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d0ed4628-4573-49fe-adcc-27badbc80f8d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c18f0b2c-bdd4-4450-b729-36854040370c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d2a46071-ee2c-4093-9774-8d2fa2c9d833	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	22fcd6b8-125b-4980-b1e8-f3391da9fa6e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
dec6d944-7993-4ce0-88e6-45580f696de5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1f2569ff-e8c4-43fc-8249-18026b18d106	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1468d424-249c-4505-a407-26108018bcac	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	527765d6-308c-4b15-aed5-811b71722ede	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
151b3ddb-09be-4a72-8287-06a13c001e54	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	7de42de4-0544-46b8-a6df-0d82aeee6909	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7b76dcf9-84e8-43fe-8e96-d323cb29aae0	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	600ef4d2-637e-49d2-9ece-8feea337031a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
82a306a2-6fb7-487d-8d08-dd4ae59cd7c7	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	be236c59-f7b1-4501-abf0-60b750fa604d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1f5a431f-570f-470e-ab51-c873eaf7c458	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	492fb2d0-1371-41ff-a0a7-b98489aa5493	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
72b4131a-e32d-484c-8f0a-693657c08512	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8aa90245-bfa3-4e19-8e7e-b2bce1e82351	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a5efe0d5-516e-41f2-ac24-d425f4b578e8	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e03a4a71-61ce-4896-a608-5b1ee56084fb	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2892d230-3b0d-4b2b-8461-d0a800e7c96d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	91eb2e5d-451c-47b6-92d9-d83fd83c4c8c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ad506d40-2f4d-46da-8500-8206e5770a80	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	bbffce06-7b95-4ab8-b62b-b2186ae9678a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
8c898299-d6d2-41ae-9b38-af6f4f80d158	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b84bbb7a-ffb6-4050-a855-248cff7b0afb	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
963e5525-2505-4279-8c72-b7bb4da816f9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	183d9fa2-c943-4ba1-841a-985d1a881d82	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
5283a93e-ca51-4391-b83c-593d73c4e7d4	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	33336cb1-ed0c-446d-9545-37da9325510d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
5eafb2d4-6875-4919-9084-869e806ef688	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	35962f13-f802-499b-a2b5-820c5a768faa	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a7919784-6126-4c61-a8b9-f3ff1993a8f7	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	bf155b46-4255-4419-bd59-3aa1dd41664d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0e5d089a-439d-4b12-9295-62143948b46b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	03d75ec8-d7a6-43bc-bd0e-a8f14f09c394	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a535154f-2b0e-4e0a-8da4-a08447905466	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1c84cb3c-25ef-4c86-a7c9-5423d7502a29	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
40d2fde4-3318-40c5-8b8c-e9d4e6e182aa	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2a837a87-d6d5-4bc0-ad83-25a939a8533f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
fc982697-08e6-421c-a993-c3e7c5db882a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5fec9c3b-8274-4e4d-bfdd-01ecefe611ca	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f81b2d8b-bd19-43c0-bfe1-e939f62210e9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	9773faab-ec25-432d-8a75-71ad67981e34	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7140d42e-9847-4a97-876e-e309aee6f8c2	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	34177c0f-dcd0-4265-a450-a7a82174797f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
100d5801-ac18-4f88-8f5e-d01eab0c6081	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	df37ea8a-962e-4a95-a689-7fc1090c352f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
53c5095f-7aa0-4a67-bd53-5fa6c7ff997f	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a4eef4f8-4a59-4361-90ff-54ef61b14b65	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
47f33f80-f11f-4d39-bdf5-819665766db8	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8f3f8038-82de-48da-a932-6520c97bab21	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6646b6de-d7c1-4515-ad69-da896871dedf	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ea78e86b-882a-419f-9361-ec377a2a9e0a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a9008b6b-f2cf-428d-9de4-61d68844aa29	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	df3a1a97-5d6e-4fbf-a0f4-51d2b449dfbf	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
beaced92-2c72-4518-8dbc-c48bcdd242e2	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	29c40f6e-52a3-4b15-9e88-d832132386f1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1787e977-ac65-4b4e-b742-444249c85c79	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	11aeb1f8-2930-4efa-a678-3f2047b5b699	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d34319cc-0b44-47df-97dc-ab83b112a0b3	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	0dfb557e-9532-478e-885a-82ad2dd5e9d8	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d270a409-dd41-4158-a3a6-233fd18937a9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	aa299fbb-8d5a-43a7-87d2-5b80f50486f2	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b935b1c5-1d2e-47b3-b38b-fc30a1133d80	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4eda8898-2dc8-499a-8b87-1cf139520d5a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
07910a40-9dc8-487d-846a-0275def28e47	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	3638ef10-3460-4fc6-8c30-e8bd29c17ce4	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0ea6b31d-06d7-40f7-8983-7005b2f998fe	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	26030a40-055b-4d44-9ee8-2c070f22e260	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c5127884-c6b3-4819-834a-ac55f8429212	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a49dbc46-b9a6-4562-b05d-3d00f3a88cdb	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6cc041cd-8717-4a84-8ac3-6851b9b7416f	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a3beb3b9-974f-4cc7-8a59-0bdd7de64a2f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
149be5d8-8428-4495-899e-8b4dd01337dc	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	706260e0-80b6-4fa9-84cc-e445f90bfdf6	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ac2a079f-6c5a-4fdb-b9e4-909650e8a6a6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	db08d783-4f01-492b-98d9-b94ff1b1d6c8	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
350d69a7-7ab0-4340-b3a1-7a2b7c643d8b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	24e8cda6-7132-4cbe-8f37-494abfcd4477	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6020486e-55f7-43ea-ba89-e22896a0d077	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	df46beb6-2e15-466c-8f01-5832a188c031	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
884ecc8e-506c-4bf6-9aee-83cb450dd34d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	05b9c07a-6442-46f3-8f50-f2d184af1d58	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d1d60791-be71-4cfd-9ac7-0769712d50bd	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b4470cbe-d435-4be4-bca6-6686aced16e3	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7cee332f-07d3-4da8-99e2-071867b67baf	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	fbab522a-beca-43c1-87b7-16b436ee5e77	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e1a7250f-133e-4767-8ecc-f2a02ccec5e8	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8b1626ef-7d3c-42aa-a4cf-d9d2a46d9177	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7fcc32ff-9ffc-42a6-91b1-ce09f2c46c95	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8cc5f0e3-cf7b-4e89-8e01-61294719f363	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
49708381-889f-45a2-b719-68ed9762349c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a5f403a5-4821-4dc8-871e-170885350a60	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ab092498-1007-4957-85d2-dfd1d9a8d0f9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b3b618c3-19ab-4842-a62f-b63d1382fb06	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b3f26c98-8f10-4aa6-92d4-acfc2cad859c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e50b34e6-c32c-4d87-a3ce-257ee7fc1298	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
da4edaec-96cd-499c-a303-271c1a9dfeee	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	88df758f-f059-4549-b6ed-0fa24a86e794	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0ec2d26e-d744-47d5-bcbb-4520034b9f5d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d200cbde-8727-435e-815e-be9463b5e063	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
22f8fa00-1020-4bda-abd7-ed55286cc3c6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c0e87c74-0154-46d4-a5ea-802a7b352dd4	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3437692b-66c8-42a9-a3f6-fc62d9640246	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	fdf749d7-4878-4385-a7ab-482c3f80f0bb	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
96c56962-0d98-471c-a797-79a4af037de5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b27cfcd3-9d81-40cb-b0c3-a548a449fa99	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
be8ed345-14eb-4f90-b25a-495b67b5d7cb	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5da87695-c380-4be3-afca-941f9151857c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
305583b9-2ad7-4e59-a8f2-36cac188293a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1546f825-e113-4001-acd1-939314c6f302	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
75ac40b4-4d26-40af-9056-bb389de10ad9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5b30455d-66bc-441a-aa95-7a0046e3b634	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
176ae478-3c08-4c8d-b719-bd0518686d12	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d5b5e5bc-6ec5-4ff7-b95f-23fd9116589b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
291e3bec-54f3-4da7-bbea-babf54e46a3f	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	83ba624d-e547-4ba1-8523-539cfa6dc8b1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ff0469f2-dd0a-4b5b-a02c-fcac597970d8	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	926d1044-5f3d-4b6d-bfb7-78216e8bf4fc	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c3da4f4d-a597-4c52-afcb-6f3d3e11794e	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d8f5f376-7632-4d74-a2b8-b3ad516f6165	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ffee8883-4805-4907-870a-f50c31bdf9ae	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	86431191-a0c3-4c9e-85c4-0780c19c5f32	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
228407a4-81bd-4503-96b0-76c2975c7809	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	05bef065-86ac-471e-81f8-8098ce3f2eee	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a9996735-b4af-47b1-a23a-6e63cd4aaac9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c5e0fc52-2437-40a3-8855-8fe5dda3567a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
79d672c4-a618-452f-a953-6a1445ad43a8	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	119e6f57-c847-4934-9503-b6bd047273e2	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9e234ce4-d060-466b-8969-1215bfee9e6d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4d7f22da-2687-42fc-910f-58e22dcd68cb	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ba3819a0-b4ec-49f1-97c5-d18f7575ef36	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	62deddcf-ec65-400c-ac58-1c64443adf03	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
98dea49e-0f77-4ee8-9705-c05ccff8b127	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	69dd1113-0713-4cd9-bce1-bc9ac13be1e0	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
28a00b81-0d64-4163-9e5b-efedd41790f8	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d7473a57-14b2-41d5-a203-f65a5f2455ec	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
95a66601-369f-40d0-830a-b590b2e55a2d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d3249ff4-e294-49d9-abcb-c213ccbd8308	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
65ead830-0b65-434e-af1c-0b10c3ade00c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8674b45f-3710-415b-9d4d-702a5e7b40c0	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
63f81f4b-a1ed-41ac-98d4-260d49b78d1c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	9cf17ee1-bace-41e1-ad32-a2e5293cf83e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f09d0965-bae3-404b-a3e9-95f75f028a35	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	3e907403-974d-48e0-97be-1ebe8400befd	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
235d5cdb-97a9-4507-b691-2dc135253299	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ba3ac34b-7e59-493b-b335-fd2c5c15605f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
480a6695-a3eb-4f3f-a4b5-e4e509aa9a48	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	f0b387b3-c04e-41c1-b1db-0e0726e4746f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
bdc653c5-aac8-435b-8be1-56a3f82dbef9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	39baac7d-32ba-425e-9b15-962a5a17acd7	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
504060fc-4799-4fac-926d-ecd3718a682b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	6ae91e99-2f96-4491-b466-325cf9d6ee49	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0d05b77c-5360-4f20-90b2-d795f8a5a440	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	65f34475-8ba7-4f22-be00-dbda6179ed72	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c34e7456-a74f-441d-96b7-f784fc030bab	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	18a50565-a53b-49ab-8bec-5d032be1972d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
378a77ae-661f-439d-99a1-6038df0d6216	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ec1404e6-96a2-4827-af8e-58a1c1260fcf	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d8e6cbe2-cd3f-4c46-90ca-d32ca51fa34b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	6935b8aa-c38e-493c-8930-9fc79adc5c7f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a770c0fa-d275-4e4b-98b3-448175a62f36	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	fdcfd1ce-0d91-46b3-bab9-4307fcfa39f6	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ebb48cfb-8c35-4146-8ee7-4ce5a2fef8fe	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a0033b2e-2379-4c98-8a02-39dd12024e63	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
46eb2ebf-2d6a-4026-b814-55e8bc7d6da8	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2c1bdd66-3241-421f-ae0e-48e54e410fae	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
36127a7e-3927-4978-88e7-f307b4596eac	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	39480fb9-91d6-46dc-ad9f-10c493cd5155	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4a83b160-8809-4d3e-9a58-f1b869a7ccc2	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	3896b2f1-3ee8-4f43-b749-d2a356b2fd54	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a0b0e16a-0d21-4572-a89d-bf5851eb23eb	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b1764808-c77b-462c-8012-c7674d4ab5e0	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
da643936-e5aa-4a1d-8e7e-a88bf3354486	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c6fe6e50-f1b4-4437-b8e6-9dc45971ff6f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
bc4e5574-2e4c-44e1-b197-d71fa5d33888	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	f20dda65-fe30-460f-8a8a-c59fec70537e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
82aa1118-433d-4bb4-bc4d-2de45444f951	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	19d00f7b-05ac-4f82-a8ce-31936e4eecb4	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
365aad94-a00b-499c-97f1-6a8fcf5d6fa4	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a42d6851-1ad7-4d63-91a8-f19a2eb66b07	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1584ce97-2cea-43de-b824-1cdb012fda81	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5c3ca2af-d918-4339-8c61-a828470cc7d2	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ddfc84cd-f75b-4931-b57c-a759fae91bd9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e6e82601-6b68-4b14-935d-ef48f3b99a67	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
26a43b93-3d57-4b86-bbca-f68c39d78b41	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b847fb8c-ba07-4327-8113-9b244590e23e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0b9450f5-4ba3-42ae-95b9-cc40504fae58	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	10238d18-b9f0-4ce5-a98c-b06f07add957	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3c197757-0715-4000-97f5-7d2491ebb1ba	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d69493b5-e293-4ece-a22f-048ab3db4149	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0ceeae16-5a40-4d5c-b039-c186cf6ca5fa	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	44ac7373-32c0-47a1-bfdf-f5d3a9d2523a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1aacc65e-ae24-49e2-a2f3-db9606f676c5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c546295d-77a2-40ec-bb19-5b05c833b5fe	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3c2e7bf3-e40b-49e1-a207-4c87edabeb6d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1e6c3022-405d-499c-9e63-ddc8269bf930	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3f55992d-f1be-4358-85d8-81f1c879dac5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	bd3ec339-bb4b-432a-8d50-1284732f613c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
79d65e15-8762-443e-b162-d905701232be	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ed7d9f06-7163-4265-9356-8be1cbf88892	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
19efe595-4404-4ca6-8f94-61b3099634a3	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a0d7d72e-056d-42c2-9b17-43328c30cda6	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
8c374bca-5a7e-472e-86b7-cbf820e75b66	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	92a2a305-d3a7-4fc0-b075-26d95123b1fe	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
410070d6-0e9d-49a1-a0dd-d608b6d6e4db	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a8428ed8-ffcf-41db-af14-5e529aa2d816	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
07381e8c-6e5f-4523-94eb-f2bc13757b65	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	0e2b5bfd-be8f-4b9b-9526-4fc1999cd73f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
30bb5e32-dfb1-423b-ae47-aba00751dbc1	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	73005c3f-d904-4103-be2b-794c25c747af	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7a7d1798-a8de-4247-99ec-13b7cd69a984	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	32a9e9af-3936-4514-a908-a27e7f052491	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3e8c9236-9120-4f70-be03-06708691cf87	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	3b615cce-47fa-40bd-ab8c-c26a41a86c41	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
fd44b041-d3b9-4e61-b530-4ae9aaa407c1	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	826f811f-b31c-470f-a648-874d79a6f038	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d449c601-9f1c-468f-9790-6c1b889d1f42	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b60c0c6e-ecc4-459c-ad1b-4e8f1adce16a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
668f243d-4610-4557-82ba-9b2048444469	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8188ecb6-6f55-45d1-afd2-df07078f0e7c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3bb089d6-2fb1-4e15-8db8-334860561817	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c89681fc-d64c-40da-8586-1094582eceba	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d57725ef-3fc4-490e-bc3d-c41bcd01a401	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8882bae5-7d15-4e1c-937b-8b42bd20f1e4	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ecf8ecf2-b49d-455e-ac5b-c2f5d2f74945	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	08172a3d-93cb-47c1-bb98-1404a8b4ab80	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
09e867b5-da47-485f-b5e5-703caea8bef6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5043992b-938f-4d41-8688-1d6b52e95ddf	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
8c909e5e-1dc4-4647-a85e-028a23efbb44	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	58ff98b3-38d3-4a01-88e6-f28df924f246	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d1a2f0c4-5d63-43f4-b697-0e455f5846bb	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8e3f3cce-7b8c-4773-9ae5-2556d6b283cf	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
fcf93ea9-3e98-4051-8528-ab5feabbeda7	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	0ba14e6b-4741-4b94-b556-d322e6b72c31	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7fb46f7f-7ae3-4701-ab56-d9b87d58b4e8	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	fd35c85f-e1a5-48e4-a400-fd03f70fa6b0	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d7cca5af-314b-4f49-bb8d-b37ffa15413b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	533884dc-9e4e-43a4-bcba-6188f4f9235d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
717e6333-b24e-4b1b-8059-dfd19d7678ad	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	45eb70be-0cfd-471e-b803-c07b3963780f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
eb0de394-86bc-4ce8-b86b-6152ad13737c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	f3c25f3e-1200-4f5e-b60f-6b4c438adee3	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
88f48b1f-530f-416e-915a-6d7d9ebbb955	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4933718a-ea02-4478-b104-7e78c207b3a4	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f6ccd444-5914-4af5-9372-53c906d18f8d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	00631a73-ed1e-4fd0-b4a3-d460af9da56b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
fbf0080d-3708-4c02-a7f8-b46b1a496dcf	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d0fd46bd-0527-47a1-9299-80c1211a12e9	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
762b5c1c-2325-4e22-a7fd-87bf2f9ba0c6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	3f070061-84c1-47cd-99c5-27c3f125b99a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
318edbae-3ad5-4f70-ade6-69f5ec455ee8	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	44eeb74a-9a65-4833-beab-0a4a562e4c0c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ab5e1390-c24a-41f6-bd1a-b6b85cb45357	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	89a1262b-9859-4501-ae1a-f7b2f1369533	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9c9921a6-21dc-4765-8900-cf985a1704c1	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1bdd1b0c-4dcc-4d22-a13d-d21ab6a07b69	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ca4eb1b5-645f-4ced-8c5d-cc02f5500dbd	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ba52bc0f-705c-4d15-ac0b-0b4c0e3c83de	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
cc9dd9d5-cc84-4fd4-8c97-5c8837b3eadb	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	69d06883-bd03-4edc-b789-494273aa175e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4bcdbb82-3707-461d-9f25-93a894440994	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c0d91a6b-0e01-4444-9063-75c5e58142e5	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
59766a19-9521-4f3d-83f2-f48ad6b7ce2a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	31ca8bdc-332b-4eb2-af72-d746241f58b5	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
abb83636-a9cc-46a7-8683-20782047a135	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	328bebf2-5be4-4d00-889a-7790003470e4	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4252ee3d-4bda-4f8f-b07e-2d082eb64be6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e4eb0d0a-9eaa-432a-8566-8c4e05bb3ba7	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
409c2051-9732-4a63-841c-d04b469c0082	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d5328e99-fe41-42ae-a473-2a0bd1a25248	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6849ce3e-27dd-4707-9e8e-98b0db6266c6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	69cb9cd5-7017-4d96-9b4f-42932adfaa42	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
8caa331e-013e-4868-9f6c-9036a841fd7f	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	7466454d-0083-4df6-baea-dd21ae09b81d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b7f0a40a-b8a1-4090-a447-ca22867e0e3c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c5a22435-3b4d-4bd0-b214-4f36b2ca2f4d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
71a79ae9-869a-4f04-8f3d-6993590419de	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	f85472e7-cacc-4604-b295-e86a41cff22f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ddb7a33e-696a-443a-b3a0-f9bed264ca83	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c7053832-1339-4245-a39f-973f87af37f1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
91da4edf-1e24-4291-8eb3-a7c0fcd49152	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	eb3a429e-92c7-4fac-a079-ba1b0e27776a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
bfa1b538-d951-4cf2-9a69-9297ab9bd467	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	7a332ce1-a662-4b77-a4dd-2b64da8021c4	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7313ecae-367e-46e9-be3a-d5b253aba992	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	51053f7e-82d6-4234-995f-ed706c764e04	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
057bc330-2044-4b91-813b-8df2c2bcc707	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	14958bd5-5b0a-4a0d-8264-982b4ef42170	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4c6991d0-7205-4ff1-992a-9417b0443993	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c5598a70-a81e-44b8-b25f-81de33591ab5	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
5050a2a1-c7d6-462c-a3ed-da8ff1e08d61	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	3f63d1e6-1b4e-458e-8b73-8f5844c1a16e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
143db624-a9cd-49dd-983f-3d6f63896f8b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	46b48465-6040-47ea-b7ff-6d0c9878f4ef	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d6c030f0-1cf5-4e2a-9bda-abf9a3a1bcc7	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8c73d8fe-7a65-48d9-92ac-718a588ba920	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f020e32a-1c25-4bbb-a304-550bc5208066	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	27a59427-ea65-4511-adb7-87364f0c43a3	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3403a852-7b8d-4a7a-88bb-7b03078b87ec	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	0fe93ea2-3a79-4140-9f0a-2eb413c749ce	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
52b2d6bd-2d49-4d26-9307-d9c26a799fc3	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5502d2fd-9a87-4907-a91d-cda2c21903c8	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
127bc006-a564-4497-950d-3785a629b9cd	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	f129bb36-b836-4fa3-9c9e-9b1a37127175	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3dd8737b-cfd4-455a-9fce-e1317d37bd9c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	31217275-3a26-4638-bdc4-dd40cd434b02	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e79c32c1-fa57-4f6a-978c-4739aa3bc501	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	3120f1ed-bdfc-4d16-9108-3bebd75ff033	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ea87c458-1139-451c-bc3a-c9d77bbde5d7	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	9fd3e2cd-d455-4dab-be7e-50bd1b14e878	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1290097e-4911-49f5-bb7a-dc3b8bf88a43	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c739c5db-bc27-4850-94b2-6c5537b66ea1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
975a00cd-ace3-4216-bdfe-3ba9df80b2ab	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	7b95397c-e633-4278-8d4d-83aa65fc5e13	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
faccdf9f-35ab-4c07-8ad9-87bb0f19f0f3	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	75f9ef32-061c-4a1e-b646-b9748a3ac907	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
be2ec48d-1eb0-4da4-ab22-d13888d854cb	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	3586ded0-81b1-465c-bb70-32c2d81c2bb7	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
39cb3cde-3d59-46d6-82b2-a157de023eef	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c6416951-5bc2-4a10-95f3-db335159fe96	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
96769b24-9343-4835-9053-776590496e07	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d3cf8a25-7940-44a2-ab25-c5295b938bd2	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
27ee6468-dbae-46bc-b471-3ec8ce144315	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	6ba610e2-3772-4923-a857-7f61609bb7b1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ed0b4d33-19f4-4d4a-ac8a-10f80108a291	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5f073258-4a29-4f73-b2a1-6593a1e9c368	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3579d984-7d79-43c6-b97c-2b9893c3ac9a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	01583066-4ae3-4c12-923b-29fdd928584e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
93643ecc-9fe3-46a8-bf3c-d46d294f9a89	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a8d286fb-9807-412c-9b70-889e355d616a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a42a61b4-e1f6-4525-b60b-58e956e14cc2	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	7c5f046e-109f-4046-aa7b-b776f8c82ea3	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4104829a-9190-4d84-9558-0364e9faa705	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	862aa4d3-492e-48ae-8135-c87715d64c24	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9548ca81-8808-4b01-b0ab-9628635dd528	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b60d387d-b4b2-4f0b-830d-7da7ddccffa2	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9ee581b7-cfab-4c5b-bc7a-b61e6d0e9931	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4638c546-7d6e-455d-859d-6de4d92df77b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
68c8aff5-266c-4594-8c69-28e80b22e612	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8553308e-2442-4aa3-a296-494e262f11ac	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4fa9b018-4f4c-4e2e-8793-5e484d0b3832	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e2db2482-2523-400e-98dd-0cba2aee2248	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
fc948147-4b9b-457e-b373-5960d27248f2	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e4b067d2-8a49-48d1-9866-bf3dce8346de	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9c72e433-a346-44b9-b142-c16eff220fc2	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4ea3595b-7ba4-4859-8089-e9f3fc9b72a8	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c7b2434e-f044-4e57-b7c1-722803bbb7d3	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	efa0a95b-fbc3-4b9c-bf75-bb7ff1bbd2ba	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b3b742fa-567b-4361-a4f6-2e645655824d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	dd8158fe-ce99-4eea-8467-e861cd08df54	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
094d853b-ebd2-40e4-9bfc-148ad355d80c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	943e0bc6-c81c-4289-8ae4-6c4d9034a126	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0a07f08e-31cf-448d-bca3-5e3ae4dd1868	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1600e1c9-066d-4c66-860a-3759180b118b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
539706b5-5b8c-4a2c-97de-24dd4a69e452	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	6ac94899-b0d8-4ecf-a481-638f62c12182	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6f2a0bca-6d48-417d-8516-9d495a854064	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	18a793a9-0ff4-4a45-a1da-606b6f284ed4	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
73a67ad8-1174-4dcf-b3e8-e3d4e315c6b7	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e81a93aa-f442-4454-8aab-2edb7caea2eb	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
5aa7b3fd-0ace-418d-902e-5ff106450111	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ff600fc3-5350-4d5b-b2f9-9404f9038ba0	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7be79d6a-0e6a-48d1-bf9e-eabd554b7898	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8b8b14a8-f2e1-45b1-98ff-22bf77e34b50	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
bb8d39b5-ce98-4af8-8cfd-359c0b7ea221	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d379efb6-f517-40c2-8f65-a8da4e48ded7	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f54fd1ec-a89c-4460-b642-15621ccd43c7	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a42f49ee-2b2e-43a5-825a-29151bfca683	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7a60faed-1c9c-475a-86cc-ebe9f71e5992	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ae72ab2a-af51-4c0b-a231-15cb41bcb97a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
129001ea-1944-41a9-9cb0-f7c2bf9982f1	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	61405748-0dab-4cbc-9f51-c9d7151b8af6	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b8cf7ce9-a473-41f2-90f3-0318854c7caa	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8161f1fe-d8f3-44f6-9a58-5405cedc2968	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1cb6a657-8221-4a16-9a42-9c56185deeb6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	7c272e6a-77bf-4104-abc5-f8cf7024b4c7	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a8972596-853a-48ac-8acf-1425e0e4c4e5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b59d8ebf-4c8b-4a34-8bd7-eb8fa272a020	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e8e19bf0-33a9-4ca1-b95b-a46e9d9be678	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e4f2c810-cae4-48d4-8302-fd530041d8cc	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2fae3fc3-a700-4098-bfd2-933dbc3af730	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	897ecaf5-9a28-405f-a407-ab7b9bdb34b4	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
bf06a5ac-5ff7-40cc-8840-928328974145	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	73faabe6-f1db-440b-ab97-f277353d4d3e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ee1ff24a-ce75-46f4-a4ec-c61b8e7409ad	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ac718ac8-10c1-471e-893c-b0039214b7a5	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
aa1f13dc-11bd-4a0a-a48b-678bd19835b8	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	11062a07-5a0a-4cec-9a76-649f66b68120	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1919cc6a-e22c-4604-a3a8-7e807a58f3d4	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2aed1437-d4b4-4159-9cf0-c75f6080cccb	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d6211494-f5ed-4259-b0e3-55720af41609	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5cc548e3-462e-443e-9882-a535fc6d85e9	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a41a4629-45e4-49c3-adb2-e75c953f1f1f	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	dc064044-4c7e-4da1-b072-3a67165e47b2	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
8c73c539-64b4-4e56-b45e-28caf685f1b9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4c1879be-294b-4d0e-a598-a0caae92f498	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
bfb3b07e-afb6-4624-b3e5-07bb814041ce	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	23c4fa2f-e6fb-4981-88d3-3013828f874b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
dfc6ed4e-3fbc-4351-a962-aec3f97e2c03	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	164eefb1-a674-4f22-8cd8-0be15e37395a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
59859bde-884e-4661-b193-7eb684253dcc	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ec9302b2-9654-4e09-ba38-2d3263c9fc68	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f001a095-1706-4aa2-9711-dd9e097549a9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ac5eb610-4cce-48d9-984d-06005ca7266c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3dfd8c7d-e769-4075-a36c-35d834b7d636	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c7489d22-02e4-449b-9bff-aae4d2921592	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2fd2fde1-6691-42ec-be65-26a4874cf126	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4c39876c-3d4e-4ac3-9b81-d25cd9ef6eea	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
049bbf91-6039-4f06-828e-4c24b5768400	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1ae3a8b1-ad12-4670-b5b1-541117111948	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f5c8a0e6-2bc7-411c-a27e-ed48e4f15216	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	61e15a91-2be2-4b73-b15c-6dd073084b1c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c5880702-64b0-4e6a-a6de-021e16693532	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	0d2bbfd2-076e-4c62-b712-1e23adc6968c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9c98f571-1af5-4b08-a96a-c33868b56f2a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	eee20026-84d1-491c-88b4-9dfcbb97299b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
54cb3e30-2d86-4d9e-8d86-eb2bec244970	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8de76f51-8703-4c09-9b7c-797c753f5310	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c42e60ff-41c7-4954-977a-5db8b7e2a923	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8e8c1c40-d54b-43fe-8e1b-7bd55962fc98	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0a87f4aa-e836-47f2-9a20-ecd990e9281a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	24813e98-1477-4c3a-be68-6981d30dfa66	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4aada02e-c05a-4bbf-857d-5b9aca12262f	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4f8a159a-02c3-4cf7-9094-fc7697cb34b9	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0032a3ba-c95e-44a0-8a0a-e7a67dc4a3af	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	9e4c8638-c41a-4476-8cfe-706aa34f39d2	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7356a531-44b7-4b9b-b477-44e444ba5d97	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	32a08d4f-9536-477e-9e44-28d6d1c6ab4c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
816b380a-ce38-4a78-b6fd-255f61817bc0	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c0aa8128-0a46-4c51-a5bd-1a2806b4171b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
80c92252-eab1-4f0f-95fe-a49a5004114b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	55a6a98a-183d-4a01-b563-50fcf176eed6	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
61839c61-030d-49e8-838c-aeb53843706e	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	bc79522a-96dd-4866-9e4b-2960c90524f1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9e65c392-f4d3-4a83-81ca-178280183214	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	fe4111da-43e6-41fb-b103-4c65b836d1d7	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
29810478-af72-4afb-9ba2-9766dda81a75	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	475d26a0-39a8-45b0-9b3a-3b79aedd503c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
659e231c-c504-4bc8-921e-ebf0b252fa99	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	81460aeb-5f90-4b9b-8eac-508d2c135423	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
8a46e945-32fa-4a9c-9ca9-3306941896f6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	500e6a06-2cd2-4e99-9c87-ac2926f319c3	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
880dfad8-1750-41fa-96b6-a0e9f44881f1	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e26ed1a4-2154-4b0a-9b1d-194fb8a8e436	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3d31c8e5-df0b-478a-9733-5808fd0cc461	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d70c1a69-d126-4b7a-b2b1-3179d9885722	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a7503cfd-d539-4ea1-b2fb-cd205b095583	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2ff5c71a-7266-49df-8fa1-262dbab2ea06	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1d2535a1-2768-4cfc-ab1f-d6c6f9dbe62d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	cf1521f2-bb7e-4fdf-98da-ef5addb629fe	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
54ebc837-762e-4feb-8175-36bd672cf4fb	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	01e0aeef-f0d4-49a9-b379-44e91023b7d0	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0ecd0aef-9175-4d3f-851d-9ba701c93796	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b3f89c70-d6fd-4b35-959c-8c4c0ec56ea6	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6ec73541-2bfe-4da7-903f-218771ddbfdd	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ba9ee90f-74b1-4f0e-a439-858dae8463d4	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9564b175-37d0-41db-934c-656616eb06d3	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d3584641-da75-479f-b422-d7359c33fd84	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
bbb6f1aa-6b83-44ef-8ace-e9bf7aed6e29	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	7a08134c-a7a8-4ff9-95f8-0b52979e3300	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f01a162d-8689-441a-8a28-c03ee246147c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ba9f224f-6b13-4a7c-b37c-06ea70d802f1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e8042686-32f6-4046-a759-92b0f9e78908	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	f1b00fab-2fb4-4383-8365-a8427e463c5e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
308a1f83-4c87-4abe-b3dc-246b96fb1223	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	886e7079-2b11-4780-b35d-848568398431	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7635f33b-6baf-45e7-bcc0-c751d3e4d5a5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	f857be9a-2fa9-4c7d-9b10-81bac1ad1153	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1951c5d8-e601-48ca-8eb6-e084db3776db	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2d242504-7cf8-4501-81bf-e352171dee49	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a0f2be41-7727-486d-a376-1ba66a06e24d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	f72f56f1-92d8-4cd1-ab41-bec3763399f1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
10665c7f-0e3f-4d6c-a2ba-d46bbf3b6959	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	6edde5a6-150a-4390-9308-d74b714229fc	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
31c74ffc-6b3b-428a-9b95-fc0c0a9ce447	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b757ffea-fbff-45da-b4d7-35f876f80fdf	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7e04472b-78bb-4a56-a90b-a67a25887a17	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a93630a0-817b-47f4-98ac-feb7f7f3c1eb	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e1775470-9296-479d-bce8-a6d16dbe35bb	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b6b783c4-ad7f-4d64-805f-aee5ec4b90e2	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e1849a11-2f88-4435-b09d-83972c4a8486	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	6c040c36-a3da-49f9-bfc1-3c2387a10d54	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d9c15fc9-9c5a-4514-a6b9-1f940b8bc301	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1407f1f4-cc03-4b68-9d4b-dbdc4163a2c3	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3d060db9-54db-4f05-9a72-689e94389ebc	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	018be1fe-5cc5-43b6-82a3-c3da36e7382b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
8bcb262b-f2b0-4dbd-9bc5-d6d04e7895e7	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	441d2974-76e9-41ff-9c3b-b89c6cf4c79e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
36cf6659-f5c0-4195-a2a4-e0570df3a3ce	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	204eaffd-7e44-43eb-9768-c2ee4bf338c8	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
cd1aa7f1-0d98-4b50-9999-728eec8c919e	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	cb6f5edc-8835-4d37-8cb5-f9e5db97ee44	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3ad6a871-cda5-4409-9239-7b383412a496	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	88b263b3-02d9-4a17-8070-fc7dc9eb7185	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
cd13d61e-f3fd-4f71-ad58-c2b289532d79	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	35d72950-37f0-4518-b46a-464fa3c5d533	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ff8406c1-3944-4373-88ca-f39018e2d31b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ba833489-8273-4f60-944a-b999058078eb	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
5de6d871-f388-4ede-8898-24521f395e51	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d8b58cdc-3dca-42ad-9c78-299c01a7cddc	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
88a0be82-03e6-4519-b2f4-5b6bbadca798	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	bde99d6e-2a57-4393-baf7-ea5e8914e513	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7d2fc69f-6a8f-4b5f-9973-bab89229d355	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	01a8c937-f603-4530-af20-4a9a4e280cfe	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
89b26b96-faf0-4199-8577-4f2487df15ef	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2179bcd2-248f-45ae-afec-8a0d56e8262a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a8e4c9b7-8828-4c63-bc7a-975ce36d5e00	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8eb2bb42-dcf7-4256-9853-4d30d071e9b9	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
734d7e58-bdd5-4000-8231-0de1edf82f93	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	0adc1c3c-b197-4329-aa06-1895dcd80eab	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
dd36b483-7dbc-471c-9387-370c69e42655	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4b9d096a-4ee9-4610-9e9b-ce6c8b9edacd	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ec3c803b-c4ac-452b-b8c7-3a51581cfb73	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	73e15ca4-d43a-4af2-a48f-34e43de94863	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
668f74e2-b88c-49c9-8250-3c42d6010a93	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	190beb95-abc6-4f41-ac9a-17382f4b802d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d03f5938-94fb-4202-9f8a-7ab712987005	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	f9aeb450-7da5-4790-b708-5683a2dddfc8	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
22949589-a5ec-446f-9a76-f58cda8e80e5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	6fd04a9e-65dc-4f8c-b2da-8ca8f2e6c5b0	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
661aa17b-58bf-496e-ac92-983366338817	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d10734ef-2c73-4376-946e-776277ebc93a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c41ecdc1-9926-4046-9086-91ef8d6950a3	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2a12534f-d919-45fc-be61-b4099729ba84	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7351fcdc-ef75-4a3b-baa9-2166f52e4f98	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	55ac5268-e3bd-4bdd-ad1c-ad1f9c0f7b4d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4240d6df-5ed3-4efe-a20e-a3ea022f6915	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	3f3f5a45-afae-402c-a5a0-c873a42f0e1d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
fe3e81ef-a8c3-4e6d-a4eb-941aecfdbce2	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ca20dfe8-fc15-4377-8bef-51a209787989	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
95187d4a-48df-4f00-976e-2a54d108d287	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	7a25bc79-c9ad-48d4-9d67-40f495efd143	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6bc425fe-dd92-471c-b74d-468c8e849c6c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1f7af000-fed6-43a9-8f7b-b12af7931a4e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7b21f6b2-3e4d-4cae-af63-a7c271c313ff	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	502afee7-27f7-4650-b915-89639f90280f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6915da6a-6e49-432f-b912-347d454da613	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	3f2a9bd4-4b91-48b3-8ab7-f4ab1e09f18c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
87447fec-ff3e-45d5-93c5-f968207951c6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	bad5a900-2b0f-42a9-a0fb-3e786d5cffed	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ae2320f9-241f-4439-b042-5894e08380e1	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	18438f49-052c-427c-a203-868885523ac1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1b888610-1ed7-479d-8c9d-6eb3b688ccbb	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a160b3b6-3b75-450a-a594-8a97aa87f21d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
18a35801-f39e-478b-8cc7-103906542298	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	544b9f0d-968d-4523-b310-449b940f30c7	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
81f99cb4-870c-4863-9654-2f5be90836ca	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	69a3a0e6-d58d-43ea-91c4-9c9607f42db5	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
21e91829-4148-4497-8e48-1638a4815ff0	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	06a99e1d-75ab-4baa-ae10-55a2424d0a29	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
93b6ccce-6da2-484d-bddd-1c50d502ca96	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	403db892-0536-4a2f-85bc-c8be88253dba	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a4d34c67-94da-44ee-ad0f-a24f4518eb3d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	6cfceeee-75cd-4a3d-8ade-75b51f6e24ca	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2ae8f3d6-a8f7-442b-b735-b6df2f9a99b5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	fcc649cf-7921-4f71-a50f-8f02e0a9894b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4040e459-6bcc-42fa-8f1f-8d81dd2992e8	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b0a6ed38-0549-4f47-817d-63e66660b904	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a1097eaa-a170-4fa9-bee7-63b3a93f0160	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4f0fcdf2-6910-4839-a05a-5ae3b7f90df6	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
8ba43e67-70ba-4957-8224-6d3e6ef4d530	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8632e05a-dd17-4b1b-8fcc-cfb6743bf30e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7c03898a-5629-441f-ac06-f802bbdcd3de	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	47353df4-87b4-4c54-8101-27e82a4a1778	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
935b4521-7f9e-4f15-8938-1df7f7880a37	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	aca3eeec-f6ae-484d-a2dd-1da7fd156785	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
346a41c0-0573-4060-ba29-ea0ebdf595b5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2bd6e1a3-a9a3-4db5-be1b-68f856c600d8	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
509f6cca-caec-43f8-9c84-06939f6bab25	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1a3c4f5d-6a40-480a-889b-3425ac75cd72	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
49ece4b6-fbef-45fa-8494-5123846e6850	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	9d2d9a18-81f6-4fd5-bbc9-cb67736d301d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
82832784-080c-4fb5-b898-a78b17e06f3d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8fd397e8-c664-495d-b7b9-9f27dc15706e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
92461ac4-dd6c-4c49-a3ef-3bc42ad0132f	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ac6b651c-460a-4dd7-8a5b-682e97b58116	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4488f2a1-cf52-4fa1-9902-4373ffd510b7	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	9fbc3dec-6deb-45e9-82f2-78c3e04d7fdd	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0acca607-c121-4f19-b1e6-dc021d15f08f	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	057bc3cd-d7c6-4a7d-97b6-4dc3e852e627	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4ff559b0-6f92-4294-8370-903e9b19299b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a7630af9-c5a0-4e1f-995b-af5b1a38f43b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
422ab8a6-93be-498d-a1b0-6771007cb13d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b98eccfc-23a6-4d6f-8ee6-563d239f156c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
24bbf02e-4d1e-48d6-a256-36012865989f	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	809b3ecf-945c-4824-8301-0d06f7a454d2	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b7595a67-08cc-42e4-961b-f8c4b54e78dd	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	eaa7039f-79c1-4337-955b-b2850682dc27	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b1a3c29c-5444-4ac7-9e52-541e243d7cca	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	27ff48dc-c70b-484a-ae26-72d36c76df34	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9db8e846-e986-4723-97b4-1a6fe8cac894	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ff69115b-03b8-4cb8-a8f5-d621aedc64fb	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9ed7c4cb-77ba-4322-8fa0-f24a073d0f06	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c29e6992-efd1-4cef-99a5-628cd93134d8	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
504b8b12-1279-4cf0-a2ed-45bbd3028cb6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d96ce054-0520-45b0-ad57-5163ab835d45	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2074d271-ca29-4e2f-ae31-e14db27a9588	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	dbca6599-e5ac-4b6a-be7c-0f68413bc483	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3923ff88-5645-490f-b046-7a02bfd5b150	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	95e5889d-1509-45e2-ade5-8734e82461b9	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ec4c88c6-bdf8-4505-9f0e-b973b957645c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a1890c64-fd0e-4143-a757-0566c17b7754	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
53a01a9e-dee8-421a-9052-6ee3731fb936	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	cb0f94b4-456b-4014-a9e8-9f12387dcc05	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d4abf915-8c6c-4ced-902a-6bfa5c482f35	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1d38499f-a19d-4d09-9d29-30de896a29e4	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d7382a65-9bcd-461f-992f-54b65fd2b762	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	fa61c098-b35b-413f-8b69-8bf8cc5a2e0e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
92f317a2-626a-4c20-91ec-e84708f0028d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	6609b377-5cea-494e-85cf-8475e4039ca8	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
025e8fc5-54da-4017-b021-43279744a084	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4088d294-ee8f-4a83-a401-952ec30b2658	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
38267bc4-32b8-46b9-ba4a-0a142e04dca5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	86c6772d-b3fe-41c6-a843-08aa6f551f1c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d42d1a45-36c6-4962-a27d-1d9f983bcb87	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8f2d6fa6-13d8-4ffd-b020-3350f1579015	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0670d4c1-ad6d-4e71-9d21-626fb1e16814	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	65a707bc-647d-426a-9a86-3fe537d2b92b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9f6da77d-a23e-4ed5-875f-2f83e1a45049	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	6a33f1e5-61df-4152-94f9-120c78ef0bfd	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b6d9e951-c6d4-4359-ac37-0ce31b74b90c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2e8c28f5-42da-4d52-972a-b0dbf1b45671	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2659d3d4-58aa-457c-88f3-cf9962a66c7d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	26d487b5-284c-4186-8d17-ea9f66412c49	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1d959467-fee4-49ff-a10b-84db156cfbae	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	104b17da-e82d-4c2f-a9bf-963e40fc068b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b8e17f6f-074c-4896-ad3d-eb54503098b4	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8fc2f3dc-de8c-4fd6-831e-afc443eec3e7	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b927e523-b221-4f62-b270-913e15545b35	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ef084a12-cc3a-4d54-b98a-a790b9b505f5	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b3736f90-d560-45e0-94df-a3a274d68ef7	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	6ec69e1b-343e-4f50-9af4-6c176cafbcee	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
392226a5-62e9-45ce-934a-a17a9e872af2	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	fdfe378f-fa40-45b6-ace9-5f6ad992b924	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
102ef62f-236a-4f31-99e7-5ef8a2d4d75f	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	3b08c1f9-2cfd-488e-a9e6-369558a158bd	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4ea489f9-9812-4c63-ad72-789ee1920db0	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	7a1dda60-ac12-4fca-9ab3-804dfc83ff62	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a5b3999d-f84a-4b71-a4d3-298274833937	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	436396a6-cc06-402f-9a6f-2cf4475705d0	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1f03901e-0843-447e-b4f2-1867ccd3d8f9	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	38b9cb8c-0493-49f4-931e-96f1dd161b28	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
8999faf9-cd98-4370-87a5-b9d3c8667b13	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	7ac6eb32-dea2-4c74-98e7-e7b96329895b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4cd0ba0f-fbbd-400b-97dc-98beb88aec09	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	fed22329-30ed-431e-8352-4853caa4b00c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
05115efb-02ee-4195-87d8-23493d975342	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	84a63cea-f71e-4fdb-a956-83353ad1c990	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
416546a2-3582-4d37-b43f-4ba343ed5c5a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	70d65ac7-890f-4c65-860c-4e0e03ee2751	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c9dc2887-ee0b-45d5-85ec-04db47f0bd7f	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	fd78f273-c8f9-46ad-8274-84785ad865e6	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
fb3a7f93-8342-4eea-b39e-72642df025dd	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	e8515ff3-2d73-4f32-ad69-abc62c539d75	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1e89e57c-cce0-4788-bc17-dbb9df5c0c33	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	828e2f6d-e3d2-43a8-9b95-949e70751afa	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9dbc233a-18e7-4ad0-8bc7-92ea1097049b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c793ff53-4b44-40ba-9bef-f5740cc90eba	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3a337b8a-576a-44c0-8392-6b8bf41af0e6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	34b20780-df85-485e-bf1c-d2b5de58d81c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
aefaf12b-56ec-42b9-babf-6f04a8ae043a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8c83410d-51e6-4fcf-aae8-69214721f38a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
bb5ea477-6617-4315-91a5-91d028473310	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	cec014b3-3149-418a-9a22-19659111bb9a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d9e56ac6-4a62-495e-9301-e11ddb948872	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ade4fe76-f7e6-4e3f-8489-be1e162a4b30	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b42dd322-6fd8-4279-87d7-4b5bbc18555b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b90ac2df-279e-4c6c-a41a-d73d1dd68633	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0a6ddf72-44ef-4f30-9e54-b6fa7de8b1d3	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	0ac0ad3b-08c7-4f8c-8bdf-4a4d82d3ee61	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
5e97c6f4-7167-469a-a546-d0763bbf00dc	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2722aadf-3a5b-47b2-afb1-de1ba4dacb98	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1b199113-304f-4af3-ad20-edf76e493e93	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d9ed2b79-2383-47b7-81e1-680ae2a61bc5	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0f347eb1-45e1-45da-83e9-03b36606e679	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a7e36604-1a52-4983-afea-3fb645bd9023	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0ea7e5a5-468e-4987-b6b0-ac5c84bd7bc2	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c140f592-8cfd-45bb-9d69-726b0431b3ea	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
5c90f8ac-d9a0-4466-9a9a-c23caaa2ce98	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a3964d44-5844-456b-a323-8257d6bb9b7a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
12508cd6-1662-430f-ab83-a64eb4aae839	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	90895361-e507-4e4e-bb2d-9a5703de1b01	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
804487d5-3030-4566-a3ec-34b4ee58eee7	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	203bf7dd-7775-44da-8d68-1e2bc2e97ffc	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b64fbf1b-4f52-4717-aea0-fe76ac8b3d47	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1ca37bb5-012a-41a1-afd4-3a8c5f5a02d8	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f691b0ee-9c3c-4028-9cc9-99ecf34d96a6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4b4fa22d-f009-4458-b34d-9c4b2c72c908	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
8b5a5328-b345-44a5-8baf-d5434d313951	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	3dda9320-e84c-46f4-99ce-4819808a08cd	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c8539183-d9ab-46c1-a92e-936d29d872c1	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	53d459b4-1874-4a0c-b2c7-20eab2615122	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d0d1e932-eecb-4ba4-b02d-3f822e86765e	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	20db9c4c-9c11-4506-ba61-c9e36aaafa91	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
54ca492f-709a-4abe-b999-cd653f2e6616	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1e941720-8e98-47a3-a1b0-a44d6147b4b5	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
099e20e5-f44f-460c-91f5-70e2bdeccafd	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	9dc0b93b-0166-48a8-bdc4-cc4efa2d4881	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1bba9b16-daa0-430d-8fe0-85245799bb3d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	bf0a7833-e627-4a3d-8226-f2bcb5652f0a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6564df11-8f8f-4cb5-9d77-bcc768a745ea	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	bfb9873a-1545-415c-85a7-f8920c885f33	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1d17ce50-49f7-4d60-aaba-4c8f73340001	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	30ad0872-181d-451a-8b4c-b91551026dc3	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
7c44fb41-4352-4b30-9f12-87d2ca6fa028	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a45df307-db10-478f-9f12-21ba42ea83a6	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
89494409-53c6-45a7-b1a7-e0d14c35e664	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	78aeabed-adbc-4f6f-b00d-df1cec926f12	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
e9f84cc5-ed76-4918-a30e-ec861cd2693b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a3f3efd3-5fff-448f-b9e9-5b67ada3518e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ece22d5c-2dc2-4ed6-a095-3ad0ebd74168	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	cbfffc74-67d8-4fe8-8772-8fcb2abeab28	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b29dfe3f-20c6-4c6f-92f5-488722056606	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	9b860ced-c60e-443f-ab97-44e2059c624a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
043f7fc4-cf81-473e-9734-6155bb0b9d4f	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	03ba6cb8-9667-4704-ae9f-1710258cdebc	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f2f4a299-2186-49a5-9299-066f47a5299a	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	47924732-dce5-4c67-ba72-733aabc6ebce	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f09febb6-a77d-425f-8282-dd7ed21baee5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b6fd2e40-242c-4a69-b5ff-25bca0d129db	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
b53ec5de-dde6-4ca0-a41a-60b64bfeb373	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ec5b091c-b82c-46b5-859a-69571ca2846f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f151d08f-0f1f-4a59-873e-ef47b61edd06	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d10e2dfb-829e-4cf1-bffa-67beb32cd3fb	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1dcff74d-16fd-427f-8897-d5964a0c4d68	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b66e16e2-f85a-49c6-8823-166dd5565dfb	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ce53a9ce-783f-4da0-9929-6cebc347297d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	ab290746-f678-4baf-ab52-f37f631d6617	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ed5b1dba-417d-430f-82af-2cb81f9941d8	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	05259974-5edf-4db2-93d3-2511742256d9	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
58ec4cbe-edfb-4e8f-8a75-fc688e425fee	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4907b92e-005b-4763-babd-59364f54971c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
cfaa4b16-a65c-4ae1-8b29-75ba14f17435	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	55ed18ed-1dbc-47fb-9d77-ae3a5e421ac3	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c5c87d92-45ba-4f0e-b7cf-22fe5dae32c7	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	fed65fd9-d973-430d-9f71-5dce670352e9	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1ec45791-c3c4-42fe-9d79-ade8c09ac2a1	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d6a9a8df-5a6f-4cc7-8ef7-311881041b70	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2fa3edb2-ec15-407a-8543-ec60402a5489	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a4515ef8-6f3e-4827-a78d-ed8907b842ee	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
5994fb91-bbaa-4963-ac56-e74f8e541636	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	7dca052f-a3f8-4ec6-9786-9cc2d8011e7e	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ea25d13b-4a61-491d-a02e-83765dfc16a7	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	f03bc85b-8380-472f-99e1-33c4453edded	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ebd15544-1dc7-4c68-876f-676b1b299b76	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a34d8aff-b153-41e3-8cec-10df63fb711c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
1668f810-6218-4fd5-89e0-05f8d76b2f30	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	abe0b568-8081-4e81-9ca7-56a018ebac03	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
781f5078-351d-41d0-a730-327c4ac11ab3	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	bfa42732-31a2-4c1a-998b-0128c0744edd	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9a651c71-2671-41e3-b4c3-d325554086f6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2dfcb535-7b64-4e8a-8884-8668d8cd3f63	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d6854a9e-532b-4180-827d-c43e100bc03e	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	fb935463-555c-4c7f-a372-35e1ec8deaad	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
d84365c4-f67e-4418-ad58-aa8cfea8d03b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	c60e11f0-ac2f-47dd-bb97-d52de4eb4d71	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
0691cd65-1e18-46f9-89f5-3550c2564af0	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	dacb3c38-cc03-4880-846e-ee6de7107bb8	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
5443d9a4-85e2-4f8d-b1cf-1d6898dcc437	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	25478fd2-f0ea-426a-88b8-b7b3dab69126	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
618e57c9-9979-4333-8769-7fdde1e0063d	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d18f2502-9985-4bad-b7f8-3a1045fd0be9	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6613bd15-b9d2-47cb-a9ca-73d7cfc74857	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5f2c4161-84ac-4482-86fa-7304bbf7df2d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c84c59de-bb38-4c0b-bc20-d42cb8c77d94	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	8d05eee2-67c7-4e78-985b-47585dcecabb	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
a7767b82-c5ba-44a8-a7ed-2c14889d6cb2	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	b9cc8cfa-5880-4f82-b4d7-b438d6696a58	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
de97951a-25c6-4984-bc2a-42204ffb8802	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	69896298-e999-4887-a2bf-628b7d189dab	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c7331786-529b-4964-b556-642c974c30e5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	7c3ae863-bf18-4967-9b90-4be570d8c9b1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
90ab0223-28bd-4ddf-b1c4-5941e98d6458	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a46b69b8-cb10-4a00-be23-04c83a3f66b4	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
dc05ec8f-2a2d-406e-aae0-2dc5328d006e	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4d3f8b83-8fa2-4970-b930-7e0388324106	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
ce9f7308-3144-4905-8623-c46f4b3b1efc	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	75b0860b-47f8-4a65-8056-f1fe16d9abe8	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
87574546-0b73-42a3-ac81-8413046c92e6	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	d22fac81-103e-4277-88b8-2b78042dfa5d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
908ff0de-948b-4fa2-a6ce-6d596a84f45b	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	9203caea-b207-48be-b30f-5f56d012b578	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
72398aa9-ea13-4236-8795-c19d4c4283c7	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4d8ac4ef-1e31-4632-a1cb-206d62dc2f67	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
90271aa8-ba76-46f0-84e6-27a4bd473b4c	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	234a4e7d-d2e8-4e0c-965b-67d8f4078bff	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
947609e5-2db8-427f-8db7-b70ca912ecaf	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	02213125-ebc8-442b-9924-af0926a65a8c	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4732cb1b-f710-45a7-9f11-0d9457fab5b7	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	4733d503-7b88-4ee0-86a2-45c4323c19aa	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
6ee9e246-9de3-42fe-bed8-b35ee6ec0329	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	516816fa-ef44-464e-ba68-d50eff3ee0f1	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
eb3d6945-3566-4676-8175-6e2ddc3cf986	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	3157c744-359c-4389-9b2f-1df81e30807f	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f6edd678-2189-4c4f-a061-4c72d0eb0163	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	139f64e8-5e2f-42c9-af91-042de4c43152	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
8f15d5a6-017e-40ae-be82-37ed58a02d48	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2386c7f0-c91d-4014-a4e9-8dc7d7dc70d3	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
09acb6cc-787d-43e7-ad4f-d57ea6a6d0f5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	6ed48f1f-02e5-4cd0-95c0-5bd7243c2938	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4a27a5f5-db84-43c9-b533-4f5d83133c15	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	a1734cbb-74d6-42e8-8279-b73774bbc539	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
2849a49f-3318-4f4a-b813-27858a1e0eb8	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	1d4bc8e7-8df0-4afc-a012-742ffe5abfd6	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
45a15773-64c8-4982-934a-d2e137e72694	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	23dd756d-b8fa-4a0d-8d92-9100cdc188c8	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
265e3fe3-ce18-4484-a1a1-54d0a1d52711	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	2fad7000-25f4-41e4-baa5-8ad4c8c115d0	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
cddb3ad9-39e4-4393-b6ab-2cf4ec451843	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	0eb6c115-798c-4368-8baa-69a3dde83c81	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
428a40f4-9514-436b-bf29-71cd2b97c494	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	442ebfd2-2a4d-4128-bdbb-33693e5e30ae	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
3e9be28d-32a6-40c8-99be-77d828bcebdd	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	029fef24-6987-40e0-bc46-f16739f3971b	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
08a60a82-5e67-407a-ba1d-c4c9c17cb2ec	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	16b1c750-627e-4f2b-a651-a59d01f50b55	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c924b942-5c6b-4200-919e-217c69da822e	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	5025c28f-b0d5-419c-bc1f-46a2c6569ea0	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
9bbd72c1-74a5-4332-be17-f204453d3bdc	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	75975af8-029a-4c80-a11e-64b527c3da7d	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
17836ba7-56c5-44dc-aa76-63d92637d3e4	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	57c6db75-c04b-4397-8f24-3269525e922a	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
f1b5548d-1fed-40ce-972d-7014b8ed5346	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	91707f3e-3f20-419c-a423-677a500afa71	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
c21da25c-e438-451b-8057-777958ed99b5	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	192e8b09-2272-4329-92ea-b754008b2aa7	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
4f5b6947-7b14-433b-b59e-6c0e418e9390	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	07fd42e8-84c8-4d55-beda-d9e395435c03	0	gpt-5-nano	reserved	\N	2026-10-16 07:50:03.040977+00
\.


--
-- Data for Name: agent_threads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_threads (id, user_id) FROM stdin;
00000000-0000-4000-8000-0000000000b1	00000000-0000-4000-8000-0000000000a1
00000000-0000-4000-8000-0000000000b2	00000000-0000-4000-8000-0000000000a2
\.


--
-- Data for Name: agent_usage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_usage (id, user_id, thread_id, model, input_tokens, output_tokens, cache_read_tokens, cache_write_tokens, created_at, call_id) FROM stdin;
\.


--
-- Data for Name: career_model_campaign_v1; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.career_model_campaign_v1 (campaign, provider, model, price_key, limit_micros, opening_micros, current_micros, reconciled, expires_at) FROM stdin;
owner-shared-5usd	openai	gpt-5-nano	92b480924a973e4d7e3c911bebb88916fc10a152e087644fdc0abb462e27e56b	5000000	0	0	t	2026-10-16 08:50:02.840087+00
\.


--
-- Data for Name: career_model_reservations_v1; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.career_model_reservations_v1 (id, user_id, thread_id, turn_key, request_hash, payload_hash, provider, model, price_key, revision, account_version, epoch, bound_micros, state, cost_micros, usage, expires_at) FROM stdin;
a8670c8a-7857-45fa-8be1-1d1f6a835eba	00000000-0000-4000-8000-0000000000a1	00000000-0000-4000-8000-0000000000b1	flex-turn	a73cc1137ced945fc15880fef7441da22d4b8edbbb3bc6312b7ddf15d3cd9642	8fde4410aee464495cf955a22c53feacf13c19f02755995cd25a0ebbd3e5cde6	openai	gpt-5-nano	92b480924a973e4d7e3c911bebb88916fc10a152e087644fdc0abb462e27e56b	0	0	0	1302	not_sent	0	{}	2026-10-16 07:50:35.173615+00
\.


--
-- Data for Name: career_reminder_outbox; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.career_reminder_outbox (user_id, reminder_id, payload, record, status, lease_token, lease_until, attempts, created_at, updated_at, delivered_at, seen_at) FROM stdin;
\.


--
-- Data for Name: career_task_effects_v1; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.career_task_effects_v1 (user_id, intent_id, effect_key, task_id, operation, token, state, before_sha256, after_sha256, created_at) FROM stdin;
\.


--
-- Data for Name: career_task_intents_v1; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.career_task_intents_v1 (user_id, intent_id, thread_id, turn_key, request_hash, event_hash, binding, private_input, result, authority_account_version, privacy_epoch, state, task_id, lease_token, expires_at, spent, reserved, budget_limit, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: career_watch_kv; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.career_watch_kv (user_id, key, value, updated_at) FROM stdin;
00000000-0000-4000-8000-0000000000a1	career:account	{"epoch": 0, "version": 1}	2026-10-16 07:50:06.107553+00
00000000-0000-4000-8000-0000000000a1	career:turn:00000000-0000-4000-8000-0000000000b1:flex-turn	{"hash": "a73cc1137ced945fc15880fef7441da22d4b8edbbb3bc6312b7ddf15d3cd9642", "epoch": 0, "response": {"meta": {"career": true, "intent": "conversation_interview", "contained": false, "career_model": {"status": "budget_denied", "provider_calls": 0}, "result_status": "prepared", "career_dialogue": {"epoch": 0, "barrier": false, "version": "career_dialogue/v2", "revision": 1, "user_text": "Help me practice an interview answer.", "account_version": 1}}, "reply": "AI coaching is unavailable for this turn. Let's practice one answer at a time. Tell me about a class or work project where something went wrong: what did you do, and what happened?", "action": null, "turn_key": "flex-turn", "reminders": [], "thread_id": "00000000-0000-4000-8000-0000000000b1", "capabilities": {"portal_browser": {"reason": "The Node browser worker is not connected to this Edge handler.", "status": "NOT_WIRED"}, "job_alert_delivery": {"reason": "No alert scheduler or delivery worker is connected to this Edge handler. Saving a watch does not start polling or deliver reminders.", "status": "NOT_WIRED"}}}}	2026-10-16 07:50:06.107553+00
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.profiles (id) FROM stdin;
00000000-0000-4000-8000-0000000000a1
\.


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: agent_flow_state agent_flow_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_flow_state
    ADD CONSTRAINT agent_flow_state_pkey PRIMARY KEY (thread_id);


--
-- Name: agent_messages agent_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_messages
    ADD CONSTRAINT agent_messages_pkey PRIMARY KEY (id);


--
-- Name: agent_model_calls agent_model_calls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_model_calls
    ADD CONSTRAINT agent_model_calls_pkey PRIMARY KEY (id);


--
-- Name: agent_model_calls agent_model_calls_user_id_request_id_step_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_model_calls
    ADD CONSTRAINT agent_model_calls_user_id_request_id_step_key UNIQUE (user_id, request_id, step);


--
-- Name: agent_threads agent_threads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_threads
    ADD CONSTRAINT agent_threads_pkey PRIMARY KEY (id);


--
-- Name: agent_usage agent_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_usage
    ADD CONSTRAINT agent_usage_pkey PRIMARY KEY (id);


--
-- Name: career_model_campaign_v1 career_model_campaign_v1_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_model_campaign_v1
    ADD CONSTRAINT career_model_campaign_v1_pkey PRIMARY KEY (campaign);


--
-- Name: career_model_reservations_v1 career_model_reservations_v1_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_model_reservations_v1
    ADD CONSTRAINT career_model_reservations_v1_pkey PRIMARY KEY (id);


--
-- Name: career_model_reservations_v1 career_model_reservations_v1_user_id_thread_id_turn_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_model_reservations_v1
    ADD CONSTRAINT career_model_reservations_v1_user_id_thread_id_turn_key_key UNIQUE (user_id, thread_id, turn_key);


--
-- Name: career_reminder_outbox career_reminder_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_reminder_outbox
    ADD CONSTRAINT career_reminder_outbox_pkey PRIMARY KEY (user_id, reminder_id);


--
-- Name: career_task_effects_v1 career_task_effects_v1_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_task_effects_v1
    ADD CONSTRAINT career_task_effects_v1_pkey PRIMARY KEY (user_id, intent_id, effect_key);


--
-- Name: career_task_effects_v1 career_task_effects_v1_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_task_effects_v1
    ADD CONSTRAINT career_task_effects_v1_token_key UNIQUE (token);


--
-- Name: career_task_intents_v1 career_task_intents_v1_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_task_intents_v1
    ADD CONSTRAINT career_task_intents_v1_pkey PRIMARY KEY (user_id, intent_id);


--
-- Name: career_task_intents_v1 career_task_intents_v1_user_id_event_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_task_intents_v1
    ADD CONSTRAINT career_task_intents_v1_user_id_event_hash_key UNIQUE (user_id, event_hash);


--
-- Name: career_task_intents_v1 career_task_intents_v1_user_id_thread_id_turn_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_task_intents_v1
    ADD CONSTRAINT career_task_intents_v1_user_id_thread_id_turn_key_key UNIQUE (user_id, thread_id, turn_key);


--
-- Name: career_watch_kv career_watch_kv_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_watch_kv
    ADD CONSTRAINT career_watch_kv_pkey PRIMARY KEY (user_id, key);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: agent_model_calls_user_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_model_calls_user_month ON public.agent_model_calls USING btree (user_id, created_at);


--
-- Name: agent_usage_call_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX agent_usage_call_id ON public.agent_usage USING btree (call_id) WHERE (call_id IS NOT NULL);


--
-- Name: career_model_started_deadline_v1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX career_model_started_deadline_v1 ON public.career_model_reservations_v1 USING btree (expires_at) WHERE (state = 'started'::text);


--
-- Name: career_model_unknown_v1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX career_model_unknown_v1 ON public.career_model_reservations_v1 USING btree (state) WHERE (state = 'unknown'::text);


--
-- Name: career_reminder_unseen; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX career_reminder_unseen ON public.career_reminder_outbox USING btree (user_id, delivered_at) WHERE ((status = 'delivered'::text) AND (seen_at IS NULL));


--
-- Name: career_task_one_submit_v1; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX career_task_one_submit_v1 ON public.career_task_effects_v1 USING btree (user_id, task_id) WHERE (operation = 'submit'::text);


--
-- Name: career_watch_kv career_task_account_control_v1; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER career_task_account_control_v1 AFTER INSERT OR DELETE OR UPDATE ON public.career_watch_kv FOR EACH ROW EXECUTE FUNCTION public.career_task_control_hook_v1();


--
-- Name: agent_flow_state agent_flow_state_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_flow_state
    ADD CONSTRAINT agent_flow_state_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.agent_threads(id) ON DELETE CASCADE;


--
-- Name: agent_flow_state agent_flow_state_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_flow_state
    ADD CONSTRAINT agent_flow_state_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: agent_messages agent_messages_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_messages
    ADD CONSTRAINT agent_messages_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.agent_threads(id);


--
-- Name: agent_model_calls agent_model_calls_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_model_calls
    ADD CONSTRAINT agent_model_calls_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.agent_threads(id) ON DELETE CASCADE;


--
-- Name: agent_model_calls agent_model_calls_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_model_calls
    ADD CONSTRAINT agent_model_calls_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: agent_threads agent_threads_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_threads
    ADD CONSTRAINT agent_threads_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id);


--
-- Name: agent_usage agent_usage_call_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_usage
    ADD CONSTRAINT agent_usage_call_id_fkey FOREIGN KEY (call_id) REFERENCES public.agent_model_calls(id) ON DELETE CASCADE;


--
-- Name: agent_usage agent_usage_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_usage
    ADD CONSTRAINT agent_usage_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.agent_threads(id) ON DELETE CASCADE;


--
-- Name: agent_usage agent_usage_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_usage
    ADD CONSTRAINT agent_usage_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: career_model_reservations_v1 career_model_reservations_v1_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_model_reservations_v1
    ADD CONSTRAINT career_model_reservations_v1_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.agent_threads(id);


--
-- Name: career_model_reservations_v1 career_model_reservations_v1_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_model_reservations_v1
    ADD CONSTRAINT career_model_reservations_v1_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: career_reminder_outbox career_reminder_outbox_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_reminder_outbox
    ADD CONSTRAINT career_reminder_outbox_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: career_task_effects_v1 career_task_effects_v1_user_id_intent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_task_effects_v1
    ADD CONSTRAINT career_task_effects_v1_user_id_intent_id_fkey FOREIGN KEY (user_id, intent_id) REFERENCES public.career_task_intents_v1(user_id, intent_id);


--
-- Name: career_task_intents_v1 career_task_intents_v1_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_task_intents_v1
    ADD CONSTRAINT career_task_intents_v1_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.agent_threads(id);


--
-- Name: career_task_intents_v1 career_task_intents_v1_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_task_intents_v1
    ADD CONSTRAINT career_task_intents_v1_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: career_watch_kv career_watch_kv_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_watch_kv
    ADD CONSTRAINT career_watch_kv_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: profiles profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id);


--
-- Name: agent_model_calls agent_model_call_owner; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY agent_model_call_owner ON public.agent_model_calls FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: agent_model_calls; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_model_calls ENABLE ROW LEVEL SECURITY;

--
-- Name: career_task_effects_v1 career_effect_backend_v1; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY career_effect_backend_v1 ON public.career_task_effects_v1 TO service_role USING (true) WITH CHECK (true);


--
-- Name: career_model_campaign_v1 career_model_campaign_backend; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY career_model_campaign_backend ON public.career_model_campaign_v1 TO service_role USING (true) WITH CHECK (true);


--
-- Name: career_model_campaign_v1; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.career_model_campaign_v1 ENABLE ROW LEVEL SECURITY;

--
-- Name: career_model_reservations_v1 career_model_reservation_backend; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY career_model_reservation_backend ON public.career_model_reservations_v1 TO service_role USING (true) WITH CHECK (true);


--
-- Name: career_model_reservations_v1; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.career_model_reservations_v1 ENABLE ROW LEVEL SECURITY;

--
-- Name: career_reminder_outbox career_reminder_backend; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY career_reminder_backend ON public.career_reminder_outbox TO service_role USING (true) WITH CHECK (true);


--
-- Name: career_reminder_outbox; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.career_reminder_outbox ENABLE ROW LEVEL SECURITY;

--
-- Name: career_task_intents_v1 career_task_backend_v1; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY career_task_backend_v1 ON public.career_task_intents_v1 TO service_role USING (true) WITH CHECK (true);


--
-- Name: career_task_effects_v1; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.career_task_effects_v1 ENABLE ROW LEVEL SECURITY;

--
-- Name: career_task_intents_v1; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.career_task_intents_v1 ENABLE ROW LEVEL SECURITY;

--
-- Name: career_watch_kv career_watch_backend; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY career_watch_backend ON public.career_watch_kv TO service_role USING (true) WITH CHECK (true);


--
-- Name: career_watch_kv; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.career_watch_kv ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict ydjx2u6jDCfrSr2XD0DJvKHpo9EIjkxesKV3FT5uGfmNEOCpNYFbRd4ednRHJdM

