import pathlib,subprocess,os,json,datetime,concurrent.futures,time,hashlib
node='/tmp/upmore-spec-b-ci-tools/node_modules/.bin/node';deno='/tmp/upmore-spec-b-ci-tools/node_modules/.bin/deno'
toolsdir=str(pathlib.Path(node).parent)
env={k:v for k,v in os.environ.items() if k in ['PATH','HOME','LANG','LC_ALL','TMPDIR']};env['PATH']=toolsdir+':'+env['PATH'];env['DENO_DIR']='/tmp/upmore-spec-b-deno-cache';env['NO_COLOR']='1'
commands=[('node-domain',[node,'--test','tests/*.cjs'],'.'),('router-fresh',['python3','scripts/build-router-core.py','--check'],'.'),('financial-fresh',['python3','scripts/build-financial-core.py','--check'],'.'),('cards-fresh',[node,'scripts/build-connect-cards.cjs','--check'],'.'),('connector-matrix-fresh',[node,'scripts/build-connector-matrix.cjs','--check'],'.'),('teardowns-fresh',[node,'scripts/build-teardowns.cjs','--check'],'.'),('methods-fresh',[node,'scripts/build-methods.cjs','--check'],'.'),('mutation-report-fresh',[node,'scripts/build-mutation-report.cjs','--check'],'.'),('standalone-fresh',['python3','scripts/build-standalone-gauntlet.py','--check'],'.'),('parity-fresh',[node,'evals/parity/build-matrix.cjs','--check'],'.'),('realworld-fresh',[node,'scripts/realworld-audit.cjs','--check'],'.'),('datasets',[node,'evals/data/validate.cjs'],'.'),('eval-harness',[node,'evals/runner.cjs'],'.'),('eval-mutations',[node,'evals/runner.cjs','--mutations'],'.'),('agent100',[node,'harness/runner.js','--mode','dry','--all'],'tests/agent100'),('deno-edge',[deno,'test','tests/edge/'],'.'),('testing-agent',[deno,'run','-A','evals/agent/run.ts','--check'],'.'),('testing-agent-mutations',[deno,'run','-A','evals/agent/mutations.ts'],'.'),('deno-check',[deno,'check','supabase/functions/agent-chat/index.ts','supabase/functions/model-health/index.ts','supabase/functions/agent-proactive/index.ts','supabase/functions/broker-oauth-start/index.ts','supabase/functions/broker-oauth-callback/index.ts','supabase/functions/manual-connect/index.ts','supabase/functions/gmail-oauth/career.ts'],'.')]
def snapshot(label,root):
 out=pathlib.Path('/tmp/upmore-spec-b-ci-results')/label;out.mkdir(parents=True,exist_ok=False);records=[]
 for name,cmd,sub in commands:
  actual=cmd[:]
  if name=='node-domain':actual=[node,'--test',*map(str,sorted(pathlib.Path(root,'tests').glob('*.cjs'))) ]
  start=time.monotonic()
  try:
   p=subprocess.run(actual,cwd=pathlib.Path(root,sub),env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=600);code=p.returncode;data=p.stdout
  except subprocess.TimeoutExpired as e:code=124;data=(e.stdout or b'')+b'\nCI RUNNER: TIMEOUT 600s\n'
  (out/(name+'.log')).write_bytes(data);rec={'id':name,'command':actual,'cwd':sub,'exit_code':code,'duration_seconds':round(time.monotonic()-start,2),'log':name+'.log','log_sha256':hashlib.sha256(data).hexdigest()};records.append(rec)
  (out/'results.json').write_text(json.dumps({'label':label,'root':root,'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'commands':records,'completed':len(records)==len(commands),'node':subprocess.check_output([node,'--version'],text=True).strip(),'deno':subprocess.check_output([deno,'--version'],text=True).splitlines()[0]},indent=2)+'\n');print(label,name,code,flush=True)
 return records
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  futures=[pool.submit(snapshot,'base','/tmp/upmore-spec-b-ci-base'),pool.submit(snapshot,'published-before','/tmp/upmore-spec-b-ci-before')]
  for f in futures:f.result()
