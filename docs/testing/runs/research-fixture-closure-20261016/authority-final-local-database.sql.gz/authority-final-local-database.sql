--
-- PostgreSQL database dump
--

\restrict mXqTIC0Rh5mqMVMeNjKuPnH7hv8GT8xqKcCFMmylHZ9aOOvVxILGwGGOsd87y7U

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg13+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- Name: career_host_commit(uuid, uuid, text, text, bigint, bigint, jsonb, jsonb, text, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_host_commit(p_user uuid, p_thread uuid, p_key text, p_hash text, p_revision bigint, p_account_version bigint, p_snapshot jsonb, p_patch jsonb, p_input text, p_response jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $_$
declare a jsonb; old_snapshot jsonb; receipt jsonb; wp jsonb; epoch bigint; next_snapshot jsonb; patch_key text;
begin
 if p_user is null or p_thread is null or p_key is null or p_hash is null or p_key !~ '^[A-Za-z0-9_-]{1,128}$' or p_hash !~ '^[a-f0-9]{64}$' or p_snapshot is null or jsonb_typeof(p_snapshot)<>'object' or octet_length(p_snapshot::text)>1048576
  or p_input is null or length(p_input)>20000 or p_response is null or jsonb_typeof(p_response->'reply') is distinct from 'string' or octet_length(p_response::text)>1048576 or jsonb_typeof(coalesce(p_patch,'{}'::jsonb))<>'object' or p_snapshot#>>'{scope,userId}' is distinct from p_user::text or jsonb_typeof(p_response)<>'object' or p_response->>'thread_id' is distinct from p_thread::text then raise exception 'invalid host commit';end if;
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 perform 1 from agent_threads where id=p_thread and user_id=p_user for update;
 if not found or exists(select 1 from agent_flow_state where thread_id=p_thread and user_id is distinct from p_user) then return jsonb_build_object('error','owned_thread_missing');end if;
 select value into a from career_watch_kv where user_id=p_user and key='career:account';a:=coalesce(a,'{"version":0,"epoch":0}'::jsonb);epoch:=coalesce((a->>'epoch')::bigint,0);
 select value into receipt from career_watch_kv where user_id=p_user and key='career:turn:'||p_thread||':'||p_key;
 if receipt is not null then
  if receipt->>'hash'<>p_hash then return jsonb_build_object('error','turn_key_conflict');end if;
  if coalesce((receipt->>'epoch')::bigint,0)<>epoch or (receipt->'response' is null or receipt->'response'='null'::jsonb) then return jsonb_build_object('error','privacy_epoch_changed');end if;
  return jsonb_build_object('response',receipt->'response','replay',true);
 end if;
 if coalesce((a->>'version')::bigint,0)<>p_account_version then return jsonb_build_object('error','revision_conflict');end if;
 select state->'career' into old_snapshot from agent_flow_state where thread_id=p_thread and user_id=p_user for update;
 if coalesce((old_snapshot->>'revision')::bigint,0)<>p_revision then return jsonb_build_object('error','revision_conflict');end if;
 for patch_key in select jsonb_object_keys(coalesce(p_patch,'{}'::jsonb)) loop
  if patch_key not in ('paused','preferred_locations','erase') then raise exception 'invalid account patch';end if;
 end loop;
 if p_patch ? 'preferred_locations' and (jsonb_typeof(p_patch->'preferred_locations')<>'array' or jsonb_array_length(p_patch->'preferred_locations')<>1 or length(p_patch#>>'{preferred_locations,0}') not between 1 and 100) then raise exception 'invalid location';end if;
 if p_patch ? 'paused' and jsonb_typeof(p_patch->'paused')<>'boolean' then raise exception 'invalid pause';end if;
 if p_patch ? 'erase' and p_patch->'erase'<>'true'::jsonb then raise exception 'invalid erasure';end if;
 if p_patch->'erase'='true'::jsonb then
  epoch:=epoch+1;
  update agent_flow_state set state=jsonb_set(coalesce(state,'{}'::jsonb),'{career}',jsonb_build_object('v',1,'scope',jsonb_build_object('userId',p_user),'revision',coalesce((state#>>'{career,revision}')::bigint,0)+1,'stores',jsonb_build_object('globalPause',jsonb_build_object('set',true,'source','account_control')))),updated_at=now() where user_id=p_user;
  delete from career_watch_kv where user_id=p_user and key not like 'career:turn:%';
  update career_watch_kv set value=jsonb_set(value,'{response}','null'::jsonb),updated_at=now() where user_id=p_user and key like 'career:turn:%';
  update career_reminder_outbox set payload=null,record=null,status='cancelled',updated_at=now() where user_id=p_user;
  a:=jsonb_build_object('epoch',epoch,'paused',true,'version',p_account_version);
 end if;
 a:=a||coalesce(p_patch-'erase','{}'::jsonb)||jsonb_build_object('version',p_account_version+1,'epoch',epoch);
 insert into career_watch_kv(user_id,key,value)values(p_user,'career:account',a)on conflict(user_id,key)do update set value=excluded.value,updated_at=now();
 if a->'paused'='true'::jsonb then update career_reminder_outbox set status='cancelled',updated_at=now() where user_id=p_user and status in ('pending','claimed','uncertain');end if;
 next_snapshot:=(case when p_patch->'erase'='true'::jsonb then jsonb_build_object('v',1,'scope',jsonb_build_object('userId',p_user),'stores',jsonb_build_object('globalPause',jsonb_build_object('set',true,'source','account_control'))) else p_snapshot end)||jsonb_build_object('revision',p_revision+1,'privacy_epoch',epoch);
 wp:=next_snapshot#>array['stores','alertWatchState','career:watch-profile:'||p_user];
 if wp is not null then
  if wp->>'user_id' is distinct from p_user::text then raise exception 'watch owner mismatch';end if;
  insert into career_watch_kv(user_id,key,value)values(p_user,'career:watch-profile:'||p_user,wp)on conflict(user_id,key)do update set value=excluded.value,updated_at=now();
 end if;
 insert into agent_flow_state(thread_id,user_id,state,updated_at)values(p_thread,p_user,jsonb_build_object('career',next_snapshot),now())
 on conflict(thread_id)do update set state=jsonb_set(coalesce(agent_flow_state.state,'{}'::jsonb),'{career}',next_snapshot),updated_at=now() where agent_flow_state.user_id=p_user;
 insert into agent_messages(thread_id,role,content)values(p_thread,'user',p_input);
 insert into agent_messages(thread_id,role,content,meta)values(p_thread,'assistant',p_response->>'reply',coalesce(p_response->'meta','{}'::jsonb)||jsonb_build_object('career',true,'career_turn_key',p_key));
 update career_reminder_outbox set seen_at=now() where user_id=p_user and status='delivered' and reminder_id in(select x->>'reminder_id' from jsonb_array_elements(coalesce(p_response->'reminders','[]'::jsonb))x);
 insert into career_watch_kv(user_id,key,value)values(p_user,'career:turn:'||p_thread||':'||p_key,jsonb_build_object('hash',p_hash,'epoch',epoch,'response',p_response));
 return jsonb_build_object('response',p_response);
end $_$;


--
-- Name: career_host_load(uuid, uuid, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_host_load(p_user uuid, p_thread uuid, p_key text, p_hash text) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $_$
declare f jsonb; a jsonb; r jsonb; w jsonb; legacy_count integer; reminders jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 if p_user is null or p_thread is null or p_key is null or p_hash is null or p_key !~ '^[A-Za-z0-9_-]{1,128}$' or p_hash !~ '^[a-f0-9]{64}$' then return jsonb_build_object('error','invalid_turn_key');end if;
 if exists(select 1 from agent_flow_state where thread_id=p_thread and user_id is distinct from p_user) or not exists(select 1 from agent_threads where id=p_thread and user_id=p_user) then return jsonb_build_object('error','owned_thread_missing');end if;
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 a:=coalesce(a,'{"version":0,"epoch":0}'::jsonb);
 select value into r from career_watch_kv where user_id=p_user and key='career:turn:'||p_thread||':'||p_key;
 if r is not null then
  if r->>'hash'<>p_hash then return jsonb_build_object('error','turn_key_conflict');end if;
  if coalesce((r->>'epoch')::bigint,0)<>coalesce((a->>'epoch')::bigint,0) or r->'response' is null or r->'response'='null'::jsonb then return jsonb_build_object('error','privacy_epoch_changed');end if;
  return jsonb_build_object('replay',r->'response');
 end if;
 select state->'career' into f from agent_flow_state where thread_id=p_thread and user_id=p_user;
 select value into w from career_watch_kv where user_id=p_user and key='career:watch-profile:'||p_user;
 if w is null and coalesce((a->>'epoch')::bigint,0)=0 then
  select count(distinct state#>array['career','stores','alertWatchState','career:watch-profile:'||p_user]) into legacy_count
   from agent_flow_state where user_id=p_user and state#>>array['career','stores','alertWatchState','career:watch-profile:'||p_user,'user_id']=p_user::text;
  if legacy_count>1 then return jsonb_build_object('error','watch_profile_conflict');end if;
  select state#>array['career','stores','alertWatchState','career:watch-profile:'||p_user] into w from agent_flow_state
   where user_id=p_user and state#>>array['career','stores','alertWatchState','career:watch-profile:'||p_user,'user_id']=p_user::text limit 1;
 end if;
 if w is not null and w->>'user_id' is distinct from p_user::text then return jsonb_build_object('error','watch_profile_conflict');end if;
 select coalesce(jsonb_agg(record),'[]'::jsonb) into reminders from (select record from career_reminder_outbox where user_id=p_user and status='delivered' and seen_at is null order by delivered_at,reminder_id limit 5) q;
 return jsonb_build_object('snapshot',f,'revision',coalesce((f->>'revision')::bigint,0),'accountVersion',coalesce((a->>'version')::bigint,0),'account',a,
  'watchState',case when w is null then '{}'::jsonb else jsonb_build_object('career:watch-profile:'||p_user,w) end,'reminders',reminders);
end $_$;


--
-- Name: career_reminder_ack(uuid, text, uuid, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_reminder_ack(p_user uuid, p_id text, p_lease uuid, p_record jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare r career_reminder_outbox; a jsonb; ledger jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 select * into r from career_reminder_outbox where user_id=p_user and reminder_id=p_id for update;
 if not found then raise exception 'missing reminder';end if;
 if r.status='delivered' and r.lease_token=p_lease then return jsonb_build_object('status','delivered','record',r.record);end if;
 if r.lease_token is distinct from p_lease or r.status not in ('claimed','uncertain') or a->'paused'='true'::jsonb or not career_reminder_allowed(p_user,r.payload) then raise exception 'reminder acknowledgement unavailable';end if;
 if p_record->>'user_id' is distinct from p_user::text or p_record->>'reminder_id' is distinct from p_id or p_record->>'channel' is distinct from 'product_inbox' or p_record->'deadline' is distinct from r.payload->'deadline' or p_record->>'url' is distinct from r.payload->>'url' or p_record->>'job_id' is distinct from r.payload->>'job_id' or p_record->>'title' is distinct from r.payload->>'title' or p_record->>'company' is distinct from r.payload->>'company' or p_record->'fit_lines' is distinct from coalesce(r.payload#>'{fit,lines}','[]'::jsonb) or p_record->'matched_fact_ids' is distinct from coalesce(r.payload#>'{fit,matched_fact_ids}','[]'::jsonb) then raise exception 'reminder evidence mismatch';end if;
 p_record:=p_record||jsonb_build_object('provenance',jsonb_build_object('kind','career_reminder_outbox','version',1,'payload_sha256',encode(sha256(convert_to(r.payload::text,'UTF8')),'hex')));
 update career_reminder_outbox set status='delivered',record=p_record,delivered_at=now(),updated_at=now() where user_id=p_user and reminder_id=p_id;
 select value into ledger from career_watch_kv where user_id=p_user and key='career:delivery-ledger:'||p_user;
 ledger:=coalesce(ledger,jsonb_build_object('user_id',p_user,'delivered_ids','[]'::jsonb,'records','[]'::jsonb));
 ledger:=ledger||jsonb_build_object('delivered_ids',coalesce(ledger->'delivered_ids','[]'::jsonb)||jsonb_build_array(p_id),'records',coalesce(ledger->'records','[]'::jsonb)||jsonb_build_array(p_record));
 insert into career_watch_kv(user_id,key,value)values(p_user,'career:delivery-ledger:'||p_user,ledger)on conflict(user_id,key)do update set value=excluded.value,updated_at=now();
 return jsonb_build_object('status','delivered','record',p_record);
end $$;


--
-- Name: career_reminder_allowed(uuid, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_reminder_allowed(p_user uuid, p_reminder jsonb) RETURNS boolean
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select exists(select 1 from career_watch_kv w where user_id=p_user and key='career:watch-profile:'||p_user
 and w.value->>'user_id'=p_user::text and coalesce(w.value#>'{opt_out,global}','false'::jsonb)<>'true'::jsonb
 and exists(select 1 from jsonb_array_elements(coalesce(w.value->'interests','[]'::jsonb)) i where i->>'interest_id'=p_reminder->>'interest_id')
 and not exists(select 1 from jsonb_array_elements_text(coalesce(w.value#>'{opt_out,companies}','[]'::jsonb)) c where lower(c)=lower(p_reminder->>'company')));
$$;


--
-- Name: career_reminder_claim(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_reminder_claim(p_user uuid, p_id text) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare r career_reminder_outbox; a jsonb; token uuid;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 select * into r from career_reminder_outbox where user_id=p_user and reminder_id=p_id for update;
 if not found then return jsonb_build_object('status','missing','claimed',false);end if;
 if (a->'paused'='true'::jsonb or not career_reminder_allowed(p_user,r.payload)) and r.status in ('pending','claimed','uncertain') then update career_reminder_outbox set status='cancelled',updated_at=now() where user_id=p_user and reminder_id=p_id;return jsonb_build_object('status','cancelled','claimed',false);end if;
 if r.status='claimed' and r.lease_until<now() then update career_reminder_outbox set status='uncertain',updated_at=now() where user_id=p_user and reminder_id=p_id;return jsonb_build_object('status','uncertain','claimed',false);end if;
 if r.status<>'pending' then return jsonb_build_object('status',r.status,'claimed',false,'record',r.record);end if;
 token:=gen_random_uuid();update career_reminder_outbox set status='claimed',lease_token=token,lease_until=now()+interval '1 minute',attempts=attempts+1,updated_at=now() where user_id=p_user and reminder_id=p_id;
 return jsonb_build_object('status','claimed','claimed',true,'leaseToken',token,'reminder',r.payload);
end $$;


--
-- Name: career_reminder_enqueue(uuid, jsonb, bigint, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_reminder_enqueue(p_user uuid, p_reminder jsonb, p_version bigint, p_epoch bigint) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare a jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 if coalesce((a->>'version')::bigint,0) is distinct from p_version or coalesce((a->>'epoch')::bigint,0) is distinct from p_epoch or a->'paused'='true'::jsonb then raise exception 'stale or paused career worker';end if;
 if p_user is null or p_reminder is null or jsonb_typeof(p_reminder)<>'object' or p_reminder->>'user_id' is distinct from p_user::text or coalesce(length(p_reminder->>'reminder_id'),0) not between 1 and 200 or octet_length(p_reminder::text)>100000 then raise exception 'invalid reminder owner';end if;
 if exists(select 1 from career_reminder_outbox where user_id=p_user and reminder_id=p_reminder->>'reminder_id') then return jsonb_build_object('stored',true);end if;
 if not career_reminder_allowed(p_user,p_reminder) then raise exception 'inactive reminder interest';end if;
 insert into career_reminder_outbox(user_id,reminder_id,payload)values(p_user,p_reminder->>'reminder_id',p_reminder)on conflict(user_id,reminder_id)do nothing;
 return jsonb_build_object('stored',true);
end $$;


--
-- Name: career_reminder_list(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_reminder_list(p_user uuid) RETURNS jsonb
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select jsonb_build_object('reminders',coalesce(jsonb_agg(payload),'[]'::jsonb)) from (select payload from career_reminder_outbox where user_id=p_user and status in ('pending','claimed','uncertain') and payload is not null order by created_at,reminder_id limit 100) q;
$$;


--
-- Name: career_reminder_status(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_reminder_status(p_user uuid, p_id text) RETURNS jsonb
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select jsonb_build_object('status',status,'record',record,'leaseToken',lease_token,'reminder',payload) from career_reminder_outbox where user_id=p_user and reminder_id=p_id;
$$;


--
-- Name: career_task_account_v1(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_account_v1(p_user uuid) RETURNS jsonb
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select jsonb_build_object('exists',exists(select 1 from career_watch_kv where user_id=p_user and key='career:account'),'account',(select value from career_watch_kv where user_id=p_user and key='career:account'));
$$;


--
-- Name: career_task_begin_effect_v1(uuid, text, uuid, text, text, text, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_begin_effect_v1(p_user uuid, p_intent text, p_lease uuid, p_task text, p_operation text, p_effect_key text, p_bindings jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $_$
declare i career_task_intents_v1;a jsonb;e career_task_effects_v1;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select * into i from career_task_intents_v1 where user_id=p_user and intent_id=p_intent for update;
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 if a is null or i.intent_id is null or i.state<>'claimed' or p_lease is distinct from i.lease_token or p_task is distinct from i.task_id or i.expires_at<=now() or i.privacy_epoch is distinct from coalesce((a->>'epoch')::bigint,0) or i.authority_account_version is distinct from (a->>'version')::bigint or (p_operation<>'destination_readback' and a->'paused'='true'::jsonb) then raise exception 'task authority revoked';end if;
 if coalesce(p_operation,'') not in ('open','form','fill','answers','atReview','armForSubmit','submit','submissionState','destination_readback','read_public_page') or (i.binding->>'action'='research' and p_operation<>'read_public_page') or (i.binding->>'action'<>'research' and p_operation='read_public_page') or (i.binding->>'action'='prepare' and p_operation in ('armForSubmit','submit')) or (i.binding->>'action'='reconcile' and p_operation<>'destination_readback') then raise exception 'task operation not authorized';end if;
 if coalesce(p_effect_key,'') !~ '^[a-f0-9]{64}$' or p_bindings is distinct from i.binding then raise exception 'task effect binding mismatch';end if;
 if p_operation<>'destination_readback' and exists(select 1 from career_task_effects_v1 where user_id=p_user and task_id=p_task and state in ('started','uncertain')) then raise exception 'task effect outcome uncertain';end if;
 if i.spent+i.reserved>=i.budget_limit then raise exception 'task budget exhausted';end if;
 insert into career_task_effects_v1(user_id,intent_id,effect_key,task_id,operation,state) values(p_user,p_intent,p_effect_key,p_task,p_operation,'reserved') returning * into e;
 update career_task_intents_v1 set reserved=reserved+1 where user_id=p_user and intent_id=p_intent;
 return jsonb_build_object('token',e.token,'effectKey',e.effect_key,'state',e.state);
end $_$;


--
-- Name: career_task_claim_v1(uuid, text, text, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_claim_v1(p_user uuid, p_intent text, p_task text, p_lease uuid DEFAULT NULL::uuid) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $_$
declare i career_task_intents_v1;a jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select * into i from career_task_intents_v1 where user_id=p_user and intent_id=p_intent for update;
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 if i.intent_id is null then raise exception 'task intent missing';end if;
 if a is null or i.privacy_epoch is distinct from coalesce((a->>'epoch')::bigint,0) or i.authority_account_version is distinct from (a->>'version')::bigint or (i.binding->>'action'<>'reconcile' and a->'paused'='true'::jsonb) or i.expires_at<=now() or i.state not in ('queued','claimed') then raise exception 'task authority revoked';end if;
 if coalesce(p_task,'') !~ '^[a-f0-9]{32}$' or (i.task_id is not null and i.task_id<>p_task) then raise exception 'task binding mismatch';end if;
 if i.state='claimed' and (p_lease is null or p_lease is distinct from i.lease_token) then raise exception 'task claim busy';end if;
 update career_task_intents_v1 set task_id=p_task,state='claimed',lease_token=coalesce(lease_token,gen_random_uuid()),updated_at=now() where user_id=p_user and intent_id=p_intent returning * into i;
 return jsonb_build_object('version','career_task_intent/v1','intentId',p_intent,'userId',p_user,'taskId',i.task_id,'accountVersion',i.authority_account_version,'privacyEpoch',i.privacy_epoch,'leaseToken',i.lease_token,'binding',i.binding,'request',i.private_input);
end $_$;


--
-- Name: career_task_consume_effect_v1(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_consume_effect_v1(p_user uuid, p_token uuid) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare e career_task_effects_v1;i career_task_intents_v1;a jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select * into e from career_task_effects_v1 where user_id=p_user and token=p_token for update;
 select * into i from career_task_intents_v1 where user_id=p_user and intent_id=e.intent_id;
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 if e.token is null or e.state<>'reserved' or i.state<>'claimed' or i.expires_at<=now() or a is null or i.authority_account_version is distinct from (a->>'version')::bigint or i.privacy_epoch is distinct from coalesce((a->>'epoch')::bigint,0) or (e.operation<>'destination_readback' and a->'paused'='true'::jsonb) then raise exception 'task effect revoked or already consumed';end if;
 update career_task_effects_v1 set state='started' where user_id=p_user and token=p_token;
 return jsonb_build_object('consumed',true,'token',p_token);
end $$;


--
-- Name: career_task_control_hook_v1(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_control_hook_v1() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare u uuid; epoch_changed boolean;
begin
 if coalesce(new.key,old.key)<>'career:account' then return null;end if;
 u:=coalesce(new.user_id,old.user_id);
 perform pg_advisory_xact_lock(hashtextextended(u::text,0));
 epoch_changed:=tg_op='DELETE' or (tg_op='UPDATE' and coalesce((new.value->>'epoch')::bigint,0)<>coalesce((old.value->>'epoch')::bigint,0));
 update career_task_intents_v1 i set state=case when exists(select 1 from career_task_effects_v1 e where e.user_id=i.user_id and e.intent_id=i.intent_id and e.state in ('started','uncertain')) then 'uncertain' else 'cancelled' end,updated_at=now()
  where i.user_id=u and i.state in ('queued','claimed','uncertain') and (tg_op='DELETE' or new.value->'paused'='true'::jsonb or i.authority_account_version is distinct from (new.value->>'version')::bigint or i.privacy_epoch is distinct from coalesce((new.value->>'epoch')::bigint,0));
 if epoch_changed then
  update career_task_intents_v1 set private_input=null,result=null,
   binding=jsonb_build_object('version','career_task_intent/v1','intent_id',intent_id,'user_id',user_id,'action',binding->>'action','task_id',task_id,'request_hash',request_hash),updated_at=now() where user_id=u;
 end if;
 return null;
end $$;


--
-- Name: career_task_effect_status_v1(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_effect_status_v1(p_user uuid, p_token uuid) RETURNS jsonb
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select coalesce((select jsonb_build_object('state',state,'token',token,'beforeSha256',before_sha256,'afterSha256',after_sha256) from career_task_effects_v1 where user_id=p_user and token=p_token),'{}'::jsonb);
$$;


--
-- Name: career_task_finish_v1(uuid, text, uuid, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_finish_v1(p_user uuid, p_intent text, p_lease uuid, p_result jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare i career_task_intents_v1;a jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select * into i from career_task_intents_v1 where user_id=p_user and intent_id=p_intent for update;
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 if i.intent_id is null or p_lease is distinct from i.lease_token then raise exception 'task result owner mismatch';end if;
 if a is null or i.privacy_epoch is distinct from coalesce((a->>'epoch')::bigint,0) or i.authority_account_version is distinct from (a->>'version')::bigint or i.state not in ('claimed','completed') then return jsonb_build_object('state','revoked');end if;
 if p_result->>'userId' is distinct from p_user::text or p_result->>'id' is distinct from i.task_id or p_result->>'version' is distinct from 'career_task/v1' or octet_length(p_result::text)>1048576 then raise exception 'invalid owned task result';end if;
 if i.state='completed' and i.result is distinct from p_result then raise exception 'task result receipt conflict';end if;
 update career_task_intents_v1 set state='completed',result=p_result,updated_at=now() where user_id=p_user and intent_id=p_intent;
 return jsonb_build_object('state','completed');
end $$;


--
-- Name: career_task_pending_v1(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_pending_v1() RETURNS jsonb
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select jsonb_build_object('intents',coalesce(jsonb_agg(jsonb_build_object('userId',i.user_id,'intentId',i.intent_id,'binding',i.binding,'request',i.private_input)),'[]'::jsonb)) from (select i.* from career_task_intents_v1 i join career_watch_kv a on a.user_id=i.user_id and a.key='career:account' where i.state='queued' and i.expires_at>now() and i.authority_account_version=(a.value->>'version')::bigint and i.privacy_epoch=coalesce((a.value->>'epoch')::bigint,0) and (i.binding->>'action'='reconcile' or a.value->'paused' is distinct from 'true'::jsonb) order by i.created_at limit 50)i;
$$;


--
-- Name: career_task_result_v1(uuid, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_result_v1(p_user uuid, p_task text DEFAULT NULL::text, p_intent text DEFAULT NULL::text) RETURNS jsonb
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select coalesce((select jsonb_build_object('task',i.result,'researchProof',case when i.binding->>'action'='research' and i.result is not null then jsonb_build_object(
  'userId',i.user_id,'taskId',i.task_id,'intentId',i.intent_id,'binding',i.binding,
  'read',(select jsonb_build_object('state',e.state,'afterSha256',e.after_sha256,'admittedAt',e.created_at) from career_task_effects_v1 e where e.user_id=i.user_id and e.intent_id=i.intent_id and e.task_id=i.task_id and e.operation='read_public_page' order by e.created_at desc limit 1)) else null end)
  from career_task_intents_v1 i join career_watch_kv a on a.user_id=i.user_id and a.key='career:account' where i.user_id=p_user and (i.task_id=p_task or i.intent_id=p_intent) and i.privacy_epoch=coalesce((a.value->>'epoch')::bigint,0) order by i.updated_at desc limit 1),' {"task":null}'::jsonb);
$$;


--
-- Name: career_task_settle_effect_v1(uuid, uuid, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_settle_effect_v1(p_user uuid, p_token uuid, p_outcome text, p_before text, p_after text) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $_$
declare e career_task_effects_v1;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select * into e from career_task_effects_v1 where user_id=p_user and token=p_token for update;
 if e.token is null or coalesce(p_outcome,'') not in ('completed','definitely_failed','uncertain') or (p_before is not null and p_before !~ '^[a-f0-9]{64}$') or (p_after is not null and p_after !~ '^[a-f0-9]{64}$') then raise exception 'invalid effect settlement';end if;
 if e.state in ('completed','definitely_failed','uncertain') then
  if e.state is distinct from p_outcome or e.before_sha256 is distinct from p_before or e.after_sha256 is distinct from p_after then raise exception 'effect receipt conflict';end if;
 elsif e.state='started' or (e.state='reserved' and p_outcome='definitely_failed') then
  update career_task_effects_v1 set state=p_outcome,before_sha256=p_before,after_sha256=p_after where user_id=p_user and token=p_token;
  update career_task_intents_v1 set reserved=greatest(reserved-1,0),spent=spent+1 where user_id=p_user and intent_id=e.intent_id;
 else raise exception 'effect was not consumed';end if;
 return jsonb_build_object('state',p_outcome,'token',p_token,'beforeSha256',p_before,'afterSha256',p_after);
end $_$;


--
-- Name: career_task_turn_commit_v1(jsonb, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_task_turn_commit_v1(p_base jsonb, p_intent jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $_$
declare u uuid; a jsonb; saved jsonb; row_intent career_task_intents_v1; k text; action text; payload jsonb;
begin
 u:=(p_base->>'p_user')::uuid;action:=p_intent->>'action';
 if p_intent is null or jsonb_typeof(p_intent)<>'object' or p_intent->>'version' is distinct from 'career_task_intent/v1' then raise exception 'invalid task intent version';end if;
 for k in select jsonb_object_keys(p_intent) loop
  if k not in ('version','intent_id','user_id','thread_id','turn_key','request_hash','action','task_id','event_id','artifact_id','resume_sha256','payload_sha256','profile_sha256','destination','authority_account_version','privacy_epoch','research') then raise exception 'unknown task intent field';end if;
 end loop;
 if coalesce(p_intent->>'intent_id','') !~ '^[a-f0-9]{64}$' or p_intent->>'user_id' is distinct from u::text or p_intent->>'thread_id' is distinct from p_base->>'p_thread' or p_intent->>'turn_key' is distinct from p_base->>'p_key' or p_intent->>'request_hash' is distinct from p_base->>'p_hash' or coalesce(action,'') not in ('prepare','approve','reconcile','research') or coalesce(p_intent->>'event_id','') !~ '^[A-Za-z0-9_-]{1,128}$' then raise exception 'invalid task intent binding';end if;
 if action<>'research' and p_intent ? 'research' then raise exception 'research binding on another task kind';end if;
 if action='research' and (jsonb_typeof(p_intent->'research') is distinct from 'object' or (select count(*) from jsonb_object_keys(p_intent->'research'))<>2 or p_intent#>>'{research,url}' is distinct from p_intent->>'destination' or coalesce(p_intent->>'destination','') !~ '^https://[a-z0-9.-]+/' or coalesce(length(p_intent#>>'{research,question}'),0) not between 1 and 500 or p_intent->>'task_id' is not null or p_intent->>'artifact_id' is not null or p_intent->>'resume_sha256' is not null or p_intent->>'payload_sha256' is not null or p_intent->>'profile_sha256' is not null) then raise exception 'invalid research intent';end if;
 if action='prepare' and (coalesce(p_intent->>'artifact_id','') !~ '^[A-Za-z0-9_-]{1,160}$' or coalesce(p_intent->>'resume_sha256','') !~ '^[a-f0-9]{64}$' or p_intent->>'destination' is distinct from p_base#>>'{p_snapshot,stores,posting,url}' or p_base#>>'{p_snapshot,stores,posting,canonicalKey}' is null) then raise exception 'invalid preparation intent';end if;
 if action in ('approve','reconcile') and coalesce(p_intent->>'task_id','') !~ '^[a-f0-9]{32}$' then raise exception 'invalid task identity';end if;
 if action='approve' and (coalesce(p_intent->>'resume_sha256','') !~ '^[a-f0-9]{64}$' or coalesce(p_intent->>'payload_sha256','') !~ '^[a-f0-9]{64}$' or coalesce(p_intent->>'destination','') !~ '^https?://' or p_base->>'p_input' is distinct from 'Approve browser task '||(p_intent->>'task_id')) then raise exception 'invalid task approval';end if;
 if p_intent ? 'profile_sha256' and p_intent->>'profile_sha256' is not null and p_intent->>'profile_sha256' !~ '^[a-f0-9]{64}$' then raise exception 'invalid profile binding';end if;
 perform pg_advisory_xact_lock(hashtextextended(u::text,0));
 if exists(select 1 from career_task_intents_v1 where user_id=u and event_hash=encode(sha256(convert_to(u::text||':'||(p_intent->>'event_id'),'UTF8')),'hex') and intent_id<>p_intent->>'intent_id') then return jsonb_build_object('error','task_event_conflict');end if;
 select value into a from career_watch_kv where user_id=u and key='career:account';
 select * into row_intent from career_task_intents_v1 where user_id=u and intent_id=p_intent->>'intent_id';
 if row_intent.intent_id is not null then
  if row_intent.binding is distinct from p_intent then raise exception 'immutable task intent conflict';end if;
 end if;
 -- Call the existing commit, never a fork of its transaction/control logic.
 saved:=career_host_commit(u,(p_base->>'p_thread')::uuid,p_base->>'p_key',p_base->>'p_hash',(p_base->>'p_revision')::bigint,(p_base->>'p_account_version')::bigint,p_base->'p_snapshot',p_base->'p_patch',p_base->>'p_input',p_base->'p_response');
 if saved ? 'error' then return saved;end if;
 if saved->'replay'='true'::jsonb then
  if row_intent.intent_id is null then raise exception 'replayed task receipt missing intent';end if;
  return saved;
 end if;
 select value into a from career_watch_kv where user_id=u and key='career:account';
 if a is null or (a->>'version')::bigint is distinct from (p_intent->>'authority_account_version')::bigint or coalesce((a->>'epoch')::bigint,0) is distinct from (p_intent->>'privacy_epoch')::bigint or (action<>'reconcile' and a->'paused'='true'::jsonb) then raise exception 'task authority changed';end if;
 if p_base#>>'{p_response,task,intent_id}' is distinct from p_intent->>'intent_id' or p_base#>>'{p_response,task,userId}' is distinct from u::text or p_base#>'{p_response,task,bindings}' is distinct from p_intent then raise exception 'task response binding mismatch';end if;
 payload:=case when action='research' then jsonb_build_object('eventId',p_intent->>'event_id','research',p_intent->'research') when action='prepare' then jsonb_build_object('eventId',p_intent->>'event_id','posting',p_base#>'{p_snapshot,stores,posting}','artifactId',p_intent->>'artifact_id','resumeSha256',p_intent->>'resume_sha256') else null end;
 insert into career_task_intents_v1(user_id,intent_id,thread_id,turn_key,request_hash,event_hash,binding,private_input,authority_account_version,privacy_epoch,task_id)
 values(u,p_intent->>'intent_id',(p_base->>'p_thread')::uuid,p_base->>'p_key',p_base->>'p_hash',encode(sha256(convert_to(u::text||':'||(p_intent->>'event_id'),'UTF8')),'hex'),p_intent,payload,(p_intent->>'authority_account_version')::bigint,(p_intent->>'privacy_epoch')::bigint,p_intent->>'task_id');
 return saved;
end $_$;


--
-- Name: career_watch_cycle_commit(uuid, bigint, bigint, jsonb, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_watch_cycle_commit(p_user uuid, p_version bigint, p_epoch bigint, p_writes jsonb, p_reminders jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare a jsonb; entry record; reminder jsonb; saved jsonb; version bigint:=p_version;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 if coalesce((a->>'version')::bigint,0) is distinct from p_version or coalesce((a->>'epoch')::bigint,0) is distinct from p_epoch or a->'paused'='true'::jsonb then raise exception 'stale or paused career worker';end if;
 if p_writes is null or jsonb_typeof(p_writes)<>'object' or p_reminders is null or jsonb_typeof(p_reminders)<>'array' or octet_length(p_writes::text)>4194304 or jsonb_array_length(p_reminders)>1000 then raise exception 'invalid career cycle';end if;
 for entry in select key,value from jsonb_each(p_writes) loop
  saved:=career_watch_write(p_user,entry.key,entry.value,version,p_epoch);version:=(saved->>'version')::bigint;
 end loop;
 for reminder in select value from jsonb_array_elements(p_reminders) loop perform career_reminder_enqueue(p_user,reminder,version,p_epoch);end loop;
 return jsonb_build_object('version',version,'epoch',p_epoch);
end $$;


--
-- Name: career_watch_read(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_watch_read(p_user uuid, p_key text) RETURNS jsonb
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select jsonb_build_object('value',(select value from career_watch_kv where user_id=p_user and key=p_key),'version',coalesce((a.value->>'version')::bigint,0),'epoch',coalesce((a.value->>'epoch')::bigint,0),'paused',coalesce((a.value->>'paused')::boolean,false))
 from (select (select value from career_watch_kv where user_id=p_user and key='career:account') value) a;
$$;


--
-- Name: career_watch_write(uuid, text, jsonb, bigint, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_watch_write(p_user uuid, p_key text, p_value jsonb, p_version bigint, p_epoch bigint) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare a jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select value into a from career_watch_kv where user_id=p_user and key='career:account';a:=coalesce(a,'{"version":0,"epoch":0}'::jsonb);
 if (a->>'version')::bigint is distinct from p_version or (a->>'epoch')::bigint is distinct from p_epoch or a->'paused'='true'::jsonb then raise exception 'stale or paused career worker';end if;
 if p_user is null or p_key is null or not (p_key in ('career:watch-profile:'||p_user,'career:reminder-queue:'||p_user,'career:reminder-history:'||p_user) or (p_key like 'career:jobs:snapshot:board:%' and right(p_key,37)=':'||p_user)) or p_value is null or octet_length(p_value::text)>1048576 then raise exception 'invalid watch state';end if;
 if p_key='career:watch-profile:'||p_user and p_value->>'user_id' is distinct from p_user::text then raise exception 'watch owner mismatch';end if;
 insert into career_watch_kv(user_id,key,value) values(p_user,p_key,p_value) on conflict(user_id,key) do update set value=excluded.value,updated_at=now();
 a:=a||jsonb_build_object('version',p_version+1);
 insert into career_watch_kv(user_id,key,value) values(p_user,'career:account',a) on conflict(user_id,key) do update set value=excluded.value,updated_at=now();
 return jsonb_build_object('version',p_version+1,'epoch',p_epoch);
end $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    id uuid NOT NULL
);


--
-- Name: agent_flow_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_flow_state (
    thread_id uuid NOT NULL,
    user_id uuid NOT NULL,
    state jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_flow_state_state_check CHECK ((jsonb_typeof(state) = 'object'::text)),
    CONSTRAINT agent_flow_state_state_check1 CHECK ((pg_column_size(state) < 524288)),
    CONSTRAINT agent_flow_state_state_check2 CHECK ((NOT ((state)::text ~* '"(otp|one_time_code|password|passcode|card_number|pan|cvv|ssn)"\s*:'::text)))
);


--
-- Name: agent_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    thread_id uuid NOT NULL,
    role text,
    content text,
    meta jsonb,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT agent_messages_role_check CHECK ((role = ANY (ARRAY['user'::text, 'assistant'::text, 'system'::text])))
);


--
-- Name: agent_threads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_threads (
    id uuid NOT NULL,
    user_id uuid NOT NULL
);


--
-- Name: career_reminder_outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.career_reminder_outbox (
    user_id uuid NOT NULL,
    reminder_id text NOT NULL,
    payload jsonb,
    record jsonb,
    status text DEFAULT 'pending'::text NOT NULL,
    lease_token uuid,
    lease_until timestamp with time zone,
    attempts integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    delivered_at timestamp with time zone,
    seen_at timestamp with time zone,
    CONSTRAINT career_reminder_outbox_reminder_id_check CHECK (((length(reminder_id) >= 1) AND (length(reminder_id) <= 200))),
    CONSTRAINT career_reminder_outbox_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'claimed'::text, 'uncertain'::text, 'delivered'::text, 'cancelled'::text])))
);


--
-- Name: career_task_effects_v1; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.career_task_effects_v1 (
    user_id uuid NOT NULL,
    intent_id text NOT NULL,
    effect_key text NOT NULL,
    task_id text NOT NULL,
    operation text NOT NULL,
    token uuid DEFAULT gen_random_uuid() NOT NULL,
    state text NOT NULL,
    before_sha256 text,
    after_sha256 text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT career_task_effects_v1_state_check CHECK ((state = ANY (ARRAY['reserved'::text, 'started'::text, 'completed'::text, 'definitely_failed'::text, 'uncertain'::text])))
);


--
-- Name: career_task_intents_v1; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.career_task_intents_v1 (
    user_id uuid NOT NULL,
    intent_id text NOT NULL,
    thread_id uuid NOT NULL,
    turn_key text NOT NULL,
    request_hash text NOT NULL,
    event_hash text NOT NULL,
    binding jsonb NOT NULL,
    private_input jsonb,
    result jsonb,
    authority_account_version bigint NOT NULL,
    privacy_epoch bigint NOT NULL,
    state text DEFAULT 'queued'::text NOT NULL,
    task_id text,
    lease_token uuid,
    expires_at timestamp with time zone DEFAULT (now() + '00:10:00'::interval) NOT NULL,
    spent integer DEFAULT 0 NOT NULL,
    reserved integer DEFAULT 0 NOT NULL,
    budget_limit integer DEFAULT 120 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT career_task_intents_v1_intent_id_check CHECK ((intent_id ~ '^[a-f0-9]{64}$'::text)),
    CONSTRAINT career_task_intents_v1_state_check CHECK ((state = ANY (ARRAY['queued'::text, 'claimed'::text, 'completed'::text, 'cancelled'::text, 'uncertain'::text])))
);


--
-- Name: career_watch_kv; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.career_watch_kv (
    user_id uuid NOT NULL,
    key text NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE career_watch_kv; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.career_watch_kv IS 'MI-032 alerts host wiring: generic per-user KV for the career watch/assign state (152 watch profiles, reminder queues, seat history; 151 per-board snapshots; host delivery ledger). Written/read by scripts/career/alerts-host.mjs createSupabaseStore via the service role. Design: docs/career/alerts-host-wiring.md.';


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profiles (
    id uuid NOT NULL
);


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (id) FROM stdin;
00000000-0000-4000-8000-000000000001
00000000-0000-4000-8000-000000000002
\.


--
-- Data for Name: agent_flow_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_flow_state (thread_id, user_id, state, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000003	00000000-0000-4000-8000-000000000001	{"career": {"v": 1, "scope": {"userId": "00000000-0000-4000-8000-000000000001"}, "stores": {"posting": {"url": "http://localhost:8123/form", "role": "Test role", "status": "open", "company": "TEST ONLY", "canonicalKey": "local:test-role"}, "trackStore": {"rows": [], "_careerThread": {"lastWork": {"at": "2026-10-16T02:50:35.591Z", "ask": "Prepare the chosen application in the browser", "kind": "tailor", "intent": "career_tailor", "company": null}}}}, "revision": 5, "privacy_epoch": 0}}	2026-10-16 02:50:48.821219+00
\.


--
-- Data for Name: agent_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_messages (id, thread_id, role, content, meta, created_at) FROM stdin;
5c9a987f-fb02-42e2-86c9-6fd28dd21f84	00000000-0000-4000-8000-000000000003	user	Prepare the chosen application in the browser	\N	2026-10-16 02:50:35.77955+00
95beba2b-9404-4486-9f7b-d7b0fd394981	00000000-0000-4000-8000-000000000003	assistant	The browser task intent is queued for a separate worker. No browser action is claimed by this chat reply; its immutable intent reference is attached.	{"career": true, "intent": "career_browser_task", "contained": false, "result_status": "queued", "career_turn_key": "staged-prepare"}	2026-10-16 02:50:35.77955+00
d10129eb-f5c5-42fe-9ef1-6a5adc8b1ec1	00000000-0000-4000-8000-000000000003	user	Show my browser task	\N	2026-10-16 02:50:40.838319+00
a5093877-744c-4f56-80e2-3a0e4daf85df	00000000-0000-4000-8000-000000000003	assistant	The owned browser task's saved evidence is attached. No new browser action was started.	{"career": true, "intent": "career_browser_task", "contained": false, "result_status": "review_ready", "career_turn_key": "staged-status"}	2026-10-16 02:50:40.838319+00
3c275154-154a-4746-ac47-f2606ef9d528	00000000-0000-4000-8000-000000000003	user	yes	\N	2026-10-16 02:50:41.062535+00
87e23cc1-d85d-4d28-8f4a-3dd708421d5c	00000000-0000-4000-8000-000000000003	assistant	Approve the specific browser task explicitly from its exact review; a bare yes authorizes nothing.	{"career": true, "intent": "career_browser_task", "contained": false, "result_status": "awaiting_user", "career_turn_key": "bare-yes"}	2026-10-16 02:50:41.062535+00
de6b4e55-eea9-42da-8255-208c1e7bbb20	00000000-0000-4000-8000-000000000003	user	Approve browser task 481686e63ae3f11750f3db7ef3475f8b	\N	2026-10-16 02:50:41.280067+00
ac0be7b7-70de-4888-b2a7-013cc362f899	00000000-0000-4000-8000-000000000003	assistant	The browser task intent is queued for a separate worker. No browser action is claimed by this chat reply; its immutable intent reference is attached.	{"career": true, "intent": "career_browser_task", "contained": false, "result_status": "queued", "career_turn_key": "staged-approval"}	2026-10-16 02:50:41.280067+00
83bb7541-8b05-4a43-8ad6-5ab90df7f5e2	00000000-0000-4000-8000-000000000003	user	Show my browser task	\N	2026-10-16 02:50:48.821219+00
70d6f075-ca7a-4ee5-8a92-cb33e938de11	00000000-0000-4000-8000-000000000003	assistant	The owned browser task's saved evidence is attached. No new browser action was started.	{"career": true, "intent": "career_browser_task", "contained": false, "result_status": "completed", "career_turn_key": "staged-done"}	2026-10-16 02:50:48.821219+00
\.


--
-- Data for Name: agent_threads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_threads (id, user_id) FROM stdin;
00000000-0000-4000-8000-000000000003	00000000-0000-4000-8000-000000000001
\.


--
-- Data for Name: career_reminder_outbox; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.career_reminder_outbox (user_id, reminder_id, payload, record, status, lease_token, lease_until, attempts, created_at, updated_at, delivered_at, seen_at) FROM stdin;
\.


--
-- Data for Name: career_task_effects_v1; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.career_task_effects_v1 (user_id, intent_id, effect_key, task_id, operation, token, state, before_sha256, after_sha256, created_at) FROM stdin;
00000000-0000-4000-8000-000000000001	040fecd9227346a984ee2671027247b097f52a3051f54bb8889bc5eb4bbb70e6	87901f67f362ea3cd79e21bd2e8b5176591049f0617323f5ace4a82385871ddc	481686e63ae3f11750f3db7ef3475f8b	open	db606514-4515-439e-8de6-f0baf5551297	completed	87901f67f362ea3cd79e21bd2e8b5176591049f0617323f5ace4a82385871ddc	4062edaf750fb8074e7e83e0c9028c94e32468a8b6f1614774328ef045150f93	2026-10-16 02:50:36.93645+00
00000000-0000-4000-8000-000000000001	51b1571fdd02bd281562231a9d9696179f38f2a74739789e23f86e9e6784ab2c	45327feb942ba97134d48ae4901f847809eb2ca3ae0a8a3d3e4e548b7a077182	481686e63ae3f11750f3db7ef3475f8b	open	17b05919-8fd5-4ab6-86ad-14c348a83edb	completed	45327feb942ba97134d48ae4901f847809eb2ca3ae0a8a3d3e4e548b7a077182	4062edaf750fb8074e7e83e0c9028c94e32468a8b6f1614774328ef045150f93	2026-10-16 02:50:42.181965+00
00000000-0000-4000-8000-000000000001	040fecd9227346a984ee2671027247b097f52a3051f54bb8889bc5eb4bbb70e6	f676b29c4c138ef1a95b3a5592cfe3a9d78fd60d99b0d3f21ddc5fc09ad18f15	481686e63ae3f11750f3db7ef3475f8b	form	be3b316e-28f2-499f-8087-85932dd16198	completed	f676b29c4c138ef1a95b3a5592cfe3a9d78fd60d99b0d3f21ddc5fc09ad18f15	82bb70610eb192838989852be8707b6c9f31cd4364022464ffc85b62c9d66cf4	2026-10-16 02:50:37.436747+00
00000000-0000-4000-8000-000000000001	040fecd9227346a984ee2671027247b097f52a3051f54bb8889bc5eb4bbb70e6	8edac51ceb306d38cf23c273a3147311baa0428e0def55a922903fb997afef61	481686e63ae3f11750f3db7ef3475f8b	fill	260e7f62-187e-467d-9a46-04f0168a2050	completed	8edac51ceb306d38cf23c273a3147311baa0428e0def55a922903fb997afef61	74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b	2026-10-16 02:50:37.871755+00
00000000-0000-4000-8000-000000000001	040fecd9227346a984ee2671027247b097f52a3051f54bb8889bc5eb4bbb70e6	53c0e205bb61b82252732e70cfd54fc4345005160f5709f2007e4c79b4a4231c	481686e63ae3f11750f3db7ef3475f8b	fill	113f7e3f-5d72-47c6-b9a6-00723bcb4594	completed	53c0e205bb61b82252732e70cfd54fc4345005160f5709f2007e4c79b4a4231c	74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b	2026-10-16 02:50:38.282833+00
00000000-0000-4000-8000-000000000001	51b1571fdd02bd281562231a9d9696179f38f2a74739789e23f86e9e6784ab2c	c424e166ba160b1c044d5f34fcc068cc1de5cc1427ed9cbd4935916e81ed2d62	481686e63ae3f11750f3db7ef3475f8b	form	af9dd856-d995-445c-9987-78e267088856	completed	c424e166ba160b1c044d5f34fcc068cc1de5cc1427ed9cbd4935916e81ed2d62	82bb70610eb192838989852be8707b6c9f31cd4364022464ffc85b62c9d66cf4	2026-10-16 02:50:42.670068+00
00000000-0000-4000-8000-000000000001	040fecd9227346a984ee2671027247b097f52a3051f54bb8889bc5eb4bbb70e6	2d1c486d7c14a824dfe27805683ed440b46233b1037b29f809ea6045e70bc4c3	481686e63ae3f11750f3db7ef3475f8b	answers	e627fe0d-3fe6-4fdd-82b5-0ee314ac7089	completed	2d1c486d7c14a824dfe27805683ed440b46233b1037b29f809ea6045e70bc4c3	0dc23eb8acb225255d0a8916d83381cc917423848d4ff0f9967b7cf329d1bc09	2026-10-16 02:50:38.73633+00
00000000-0000-4000-8000-000000000001	040fecd9227346a984ee2671027247b097f52a3051f54bb8889bc5eb4bbb70e6	da2df72bc8547ac1589609952ed5cc92c9a7e082847bc7970df35cba0b938535	481686e63ae3f11750f3db7ef3475f8b	atReview	4b7534c9-1bea-4b3b-8b61-77cab03b2ead	completed	da2df72bc8547ac1589609952ed5cc92c9a7e082847bc7970df35cba0b938535	73e7b3e1606b413bf890f0d4210ccca3ef82d3367cc5e73045b699ceb4ee3090	2026-10-16 02:50:39.20743+00
00000000-0000-4000-8000-000000000001	51b1571fdd02bd281562231a9d9696179f38f2a74739789e23f86e9e6784ab2c	9497e718db0c38d03146f8aec8d0a392edee2c20670e26ba210920771d521c0c	481686e63ae3f11750f3db7ef3475f8b	atReview	4392f3ef-13fa-41dd-8e28-178199848572	completed	9497e718db0c38d03146f8aec8d0a392edee2c20670e26ba210920771d521c0c	73e7b3e1606b413bf890f0d4210ccca3ef82d3367cc5e73045b699ceb4ee3090	2026-10-16 02:50:44.544116+00
00000000-0000-4000-8000-000000000001	040fecd9227346a984ee2671027247b097f52a3051f54bb8889bc5eb4bbb70e6	c9bec3de2eaab89c1f8a01ab5691559edd427d09d513eb807361d4c9df071374	481686e63ae3f11750f3db7ef3475f8b	form	810aea1c-24ef-4505-8e3b-08ccbaa203ec	completed	c9bec3de2eaab89c1f8a01ab5691559edd427d09d513eb807361d4c9df071374	82bb70610eb192838989852be8707b6c9f31cd4364022464ffc85b62c9d66cf4	2026-10-16 02:50:39.646907+00
00000000-0000-4000-8000-000000000001	51b1571fdd02bd281562231a9d9696179f38f2a74739789e23f86e9e6784ab2c	4d0424356e7becaf6be59243b56b25b7dc3c38203ba653c1031fbc6df0bca7cb	481686e63ae3f11750f3db7ef3475f8b	fill	03f7db40-7123-453a-9bbe-d6b04b4ecd26	completed	4d0424356e7becaf6be59243b56b25b7dc3c38203ba653c1031fbc6df0bca7cb	74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b	2026-10-16 02:50:43.131592+00
00000000-0000-4000-8000-000000000001	040fecd9227346a984ee2671027247b097f52a3051f54bb8889bc5eb4bbb70e6	70f4b24b6459c3fe85091c3d528649d49773194a6ee8837ff952170be048346c	481686e63ae3f11750f3db7ef3475f8b	answers	9d9d9987-1351-4cd2-bd00-48708b2c3ae2	completed	70f4b24b6459c3fe85091c3d528649d49773194a6ee8837ff952170be048346c	0dc23eb8acb225255d0a8916d83381cc917423848d4ff0f9967b7cf329d1bc09	2026-10-16 02:50:40.11762+00
00000000-0000-4000-8000-000000000001	51b1571fdd02bd281562231a9d9696179f38f2a74739789e23f86e9e6784ab2c	e005343f144fe410b2b734804d8f917c2d3006f0e6d7732a345779bf9c02419f	481686e63ae3f11750f3db7ef3475f8b	fill	60844073-75eb-4d25-ba5d-4644334b7a48	completed	e005343f144fe410b2b734804d8f917c2d3006f0e6d7732a345779bf9c02419f	74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b	2026-10-16 02:50:43.599476+00
00000000-0000-4000-8000-000000000001	51b1571fdd02bd281562231a9d9696179f38f2a74739789e23f86e9e6784ab2c	11a2c1e1364b111ce581052de43f9f690b13396404c94df700489bbba1a73c2e	481686e63ae3f11750f3db7ef3475f8b	answers	cdeb3586-28bd-4755-9de6-e35c8b8e1444	completed	11a2c1e1364b111ce581052de43f9f690b13396404c94df700489bbba1a73c2e	0dc23eb8acb225255d0a8916d83381cc917423848d4ff0f9967b7cf329d1bc09	2026-10-16 02:50:46.363269+00
00000000-0000-4000-8000-000000000001	51b1571fdd02bd281562231a9d9696179f38f2a74739789e23f86e9e6784ab2c	f43acf225c134de9868a4c16b066b3c724c79faec4a19514c3e4fc9fb06ae7f8	481686e63ae3f11750f3db7ef3475f8b	answers	3d482144-b54e-42e2-b5db-8eb1478bdfe3	completed	f43acf225c134de9868a4c16b066b3c724c79faec4a19514c3e4fc9fb06ae7f8	0dc23eb8acb225255d0a8916d83381cc917423848d4ff0f9967b7cf329d1bc09	2026-10-16 02:50:44.064853+00
00000000-0000-4000-8000-000000000001	51b1571fdd02bd281562231a9d9696179f38f2a74739789e23f86e9e6784ab2c	6e6f127d6219f5f226c5da6a8a746853bcf34dedcf0fb78c1756a94d333bca2c	481686e63ae3f11750f3db7ef3475f8b	form	a929acac-cb2f-4a57-ba2a-e08349b78f81	completed	6e6f127d6219f5f226c5da6a8a746853bcf34dedcf0fb78c1756a94d333bca2c	82bb70610eb192838989852be8707b6c9f31cd4364022464ffc85b62c9d66cf4	2026-10-16 02:50:45.008344+00
00000000-0000-4000-8000-000000000001	51b1571fdd02bd281562231a9d9696179f38f2a74739789e23f86e9e6784ab2c	62cb2a13e684c9e87bb3c7d442dea03f45ae47a38a282b1d7c66fb53462a3455	481686e63ae3f11750f3db7ef3475f8b	form	c3d8f54f-f993-46e6-b68d-7a8a2295c6e4	completed	62cb2a13e684c9e87bb3c7d442dea03f45ae47a38a282b1d7c66fb53462a3455	82bb70610eb192838989852be8707b6c9f31cd4364022464ffc85b62c9d66cf4	2026-10-16 02:50:45.94907+00
00000000-0000-4000-8000-000000000001	51b1571fdd02bd281562231a9d9696179f38f2a74739789e23f86e9e6784ab2c	8dc76d3725b656596c641efef7b8d5af681872aed79397393d6b4605297537c4	481686e63ae3f11750f3db7ef3475f8b	answers	9b842c61-4d0c-4486-a517-9d0dea295bc6	completed	8dc76d3725b656596c641efef7b8d5af681872aed79397393d6b4605297537c4	0dc23eb8acb225255d0a8916d83381cc917423848d4ff0f9967b7cf329d1bc09	2026-10-16 02:50:45.470285+00
00000000-0000-4000-8000-000000000001	51b1571fdd02bd281562231a9d9696179f38f2a74739789e23f86e9e6784ab2c	e1c480cfc0668f8da3df6a53be1b0050c9b166e0fdad4eead7151f5bf562fcec	481686e63ae3f11750f3db7ef3475f8b	armForSubmit	cbfa5f0d-0636-471b-8b2b-f89db69d5e05	completed	e1c480cfc0668f8da3df6a53be1b0050c9b166e0fdad4eead7151f5bf562fcec	74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b	2026-10-16 02:50:46.861162+00
00000000-0000-4000-8000-000000000001	51b1571fdd02bd281562231a9d9696179f38f2a74739789e23f86e9e6784ab2c	cb301ef70d257392404ed142ac4b5fe6c249322bd34483db13de3d586fc230ed	481686e63ae3f11750f3db7ef3475f8b	submit	5d299649-d642-457e-8246-916cc1ce78d9	completed	cb301ef70d257392404ed142ac4b5fe6c249322bd34483db13de3d586fc230ed	5efbc709172617fe62aa352235a032d3e346ef4abe01a4f451f582e268f4f154	2026-10-16 02:50:47.320259+00
00000000-0000-4000-8000-000000000001	51b1571fdd02bd281562231a9d9696179f38f2a74739789e23f86e9e6784ab2c	1a526a13118712ecddc01d8d3fa3fc890eac906af469fc455a904069f676d371	481686e63ae3f11750f3db7ef3475f8b	destination_readback	88fa4d50-bf82-41d6-a8a4-403eb8a6a035	completed	1a526a13118712ecddc01d8d3fa3fc890eac906af469fc455a904069f676d371	c1100332fad928836bca8476cebdf601060ef8eb7a2096cab66fa621198307a9	2026-10-16 02:50:47.803778+00
\.


--
-- Data for Name: career_task_intents_v1; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.career_task_intents_v1 (user_id, intent_id, thread_id, turn_key, request_hash, event_hash, binding, private_input, result, authority_account_version, privacy_epoch, state, task_id, lease_token, expires_at, spent, reserved, budget_limit, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000001	040fecd9227346a984ee2671027247b097f52a3051f54bb8889bc5eb4bbb70e6	00000000-0000-4000-8000-000000000003	staged-prepare	6b163551fc486e88496e6bde6cc8bce22630ca0cec59a0bcb4f00ec0fddca7dc	8075c82c526900ea0553757120ce1cdbef252882a1280d95188984d54c3ac724	{"action": "prepare", "task_id": null, "user_id": "00000000-0000-4000-8000-000000000001", "version": "career_task_intent/v1", "event_id": "staged-prepare", "turn_key": "staged-prepare", "intent_id": "040fecd9227346a984ee2671027247b097f52a3051f54bb8889bc5eb4bbb70e6", "thread_id": "00000000-0000-4000-8000-000000000003", "artifact_id": "owned-resume-1", "destination": "http://localhost:8123/form", "request_hash": "6b163551fc486e88496e6bde6cc8bce22630ca0cec59a0bcb4f00ec0fddca7dc", "privacy_epoch": 0, "resume_sha256": "9c34a12fba5f2d2b0b7e7d7ac62b91ff30d227f853fb70a518ec19208e8fa511", "payload_sha256": null, "profile_sha256": null, "authority_account_version": 1}	{"eventId": "staged-prepare", "posting": {"url": "http://localhost:8123/form", "role": "Test role", "status": "open", "company": "TEST ONLY", "canonicalKey": "local:test-role"}, "artifactId": "owned-resume-1", "resumeSha256": "9c34a12fba5f2d2b0b7e7d7ac62b91ff30d227f853fb70a518ec19208e8fa511"}	{"id": "481686e63ae3f11750f3db7ef3475f8b", "asks": [], "kind": "career_application", "phase": "check", "budget": {"spendCents": 0, "limitActions": 120, "spentActions": 8, "reservedActions": 0}, "result": null, "review": {"kind": "career_browser_review", "taskId": "481686e63ae3f11750f3db7ef3475f8b", "userId": "00000000-0000-4000-8000-000000000001", "payload": {"email": "synthetic@example.test", "resume": {"sha256": "9c34a12fba5f2d2b0b7e7d7ac62b91ff30d227f853fb70a518ec19208e8fa511", "filename": "resume.txt"}, "resume_sha256": "9c34a12fba5f2d2b0b7e7d7ac62b91ff30d227f853fb70a518ec19208e8fa511"}, "bindings": [{"source": "profile", "fieldId": "email", "profileKey": "email", "profileHash": "2cdc505399f121714e519cb5282e186ae6b949473627ba5cc6eeeb8f37ec22be", "questionKey": null}, {"source": "profile", "fieldId": "resume", "profileKey": "resume", "profileHash": "2cdc505399f121714e519cb5282e186ae6b949473627ba5cc6eeeb8f37ec22be", "questionKey": null}], "authority": {"intentId": "040fecd9227346a984ee2671027247b097f52a3051f54bb8889bc5eb4bbb70e6", "privacyEpoch": 0, "accountVersion": 1}, "expiresAt": "2026-10-15T12:10:00.000Z", "observedAt": "2026-10-15T12:00:00.000Z", "postingKey": "local:test-role", "destination": "http://localhost:8123/submit", "observation": null, "profileHash": "2cdc505399f121714e519cb5282e186ae6b949473627ba5cc6eeeb8f37ec22be", "resumeSha256": "9c34a12fba5f2d2b0b7e7d7ac62b91ff30d227f853fb70a518ec19208e8fa511", "payloadSha256": "325adca131c665ed18b50fe6f437872c2ead6eaa6af591966fdae78259e8f722"}, "status": "review_ready", "userId": "00000000-0000-4000-8000-000000000001", "blocker": null, "version": "career_task/v1", "revision": 36, "authority": {"intentId": "040fecd9227346a984ee2671027247b097f52a3051f54bb8889bc5eb4bbb70e6", "privacyEpoch": 0, "accountVersion": 1}, "capabilities": {"browser": "CONTROLLED_LOCAL_ONLY", "employer_submission": "NOT_WIRED"}}	1	0	completed	481686e63ae3f11750f3db7ef3475f8b	ad3726c7-ea31-4b3c-a61d-157d2067c5ba	2026-10-16 03:00:35.77955+00	8	0	120	2026-10-16 02:50:35.77955+00	2026-10-16 02:50:40.479876+00
00000000-0000-4000-8000-000000000001	51b1571fdd02bd281562231a9d9696179f38f2a74739789e23f86e9e6784ab2c	00000000-0000-4000-8000-000000000003	staged-approval	823803f52bf5857ccbcfd7440d11b3c03745c1921a94574ba186401c24677aa2	3640b0040b6bda06457e890fecb21940e58445f54f02cf6723e1513e0494a234	{"action": "approve", "task_id": "481686e63ae3f11750f3db7ef3475f8b", "user_id": "00000000-0000-4000-8000-000000000001", "version": "career_task_intent/v1", "event_id": "staged-approval", "turn_key": "staged-approval", "intent_id": "51b1571fdd02bd281562231a9d9696179f38f2a74739789e23f86e9e6784ab2c", "thread_id": "00000000-0000-4000-8000-000000000003", "artifact_id": null, "destination": "http://localhost:8123/submit", "request_hash": "823803f52bf5857ccbcfd7440d11b3c03745c1921a94574ba186401c24677aa2", "privacy_epoch": 0, "resume_sha256": "9c34a12fba5f2d2b0b7e7d7ac62b91ff30d227f853fb70a518ec19208e8fa511", "payload_sha256": "325adca131c665ed18b50fe6f437872c2ead6eaa6af591966fdae78259e8f722", "profile_sha256": null, "authority_account_version": 4}	\N	{"id": "481686e63ae3f11750f3db7ef3475f8b", "asks": [], "kind": "career_application", "phase": "check", "budget": {"spendCents": 0, "limitActions": 120, "spentActions": 21, "reservedActions": 0}, "result": {"kind": "career_browser_result", "status": "completed", "taskId": "481686e63ae3f11750f3db7ef3475f8b", "capture": {"confirmationId": "TEST-RECEIPT-1", "confirmationUrl": "http://localhost:8123/submit"}, "receipt": {"source": "controlled_portal_readback", "taskId": "481686e63ae3f11750f3db7ef3475f8b", "userId": "00000000-0000-4000-8000-000000000001", "destination": "http://localhost:8123/submit", "resumeSha256": "9c34a12fba5f2d2b0b7e7d7ac62b91ff30d227f853fb70a518ec19208e8fa511", "payloadSha256": "325adca131c665ed18b50fe6f437872c2ead6eaa6af591966fdae78259e8f722", "confirmationId": "TEST-RECEIPT-1"}, "checkedAt": "2026-10-15T12:00:00.000Z", "approvalRef": "staged-approval", "destination": "http://localhost:8123/submit", "resumeSha256": "9c34a12fba5f2d2b0b7e7d7ac62b91ff30d227f853fb70a518ec19208e8fa511", "payloadSha256": "325adca131c665ed18b50fe6f437872c2ead6eaa6af591966fdae78259e8f722"}, "review": {"kind": "career_browser_review", "taskId": "481686e63ae3f11750f3db7ef3475f8b", "userId": "00000000-0000-4000-8000-000000000001", "payload": {"email": "synthetic@example.test", "resume": {"sha256": "9c34a12fba5f2d2b0b7e7d7ac62b91ff30d227f853fb70a518ec19208e8fa511", "filename": "resume.txt"}, "resume_sha256": "9c34a12fba5f2d2b0b7e7d7ac62b91ff30d227f853fb70a518ec19208e8fa511"}, "bindings": [{"source": "profile", "fieldId": "email", "profileKey": "email", "profileHash": "2cdc505399f121714e519cb5282e186ae6b949473627ba5cc6eeeb8f37ec22be", "questionKey": null}, {"source": "profile", "fieldId": "resume", "profileKey": "resume", "profileHash": "2cdc505399f121714e519cb5282e186ae6b949473627ba5cc6eeeb8f37ec22be", "questionKey": null}], "authority": {"intentId": "51b1571fdd02bd281562231a9d9696179f38f2a74739789e23f86e9e6784ab2c", "privacyEpoch": 0, "accountVersion": 4}, "expiresAt": "2026-10-15T12:10:00.000Z", "observedAt": "2026-10-15T12:00:00.000Z", "postingKey": "local:test-role", "destination": "http://localhost:8123/submit", "observation": null, "profileHash": "2cdc505399f121714e519cb5282e186ae6b949473627ba5cc6eeeb8f37ec22be", "resumeSha256": "9c34a12fba5f2d2b0b7e7d7ac62b91ff30d227f853fb70a518ec19208e8fa511", "payloadSha256": "325adca131c665ed18b50fe6f437872c2ead6eaa6af591966fdae78259e8f722"}, "status": "completed", "userId": "00000000-0000-4000-8000-000000000001", "blocker": null, "version": "career_task/v1", "revision": 92, "authority": {"intentId": "51b1571fdd02bd281562231a9d9696179f38f2a74739789e23f86e9e6784ab2c", "privacyEpoch": 0, "accountVersion": 4}, "capabilities": {"browser": "CONTROLLED_LOCAL_ONLY", "employer_submission": "NOT_WIRED"}}	4	0	completed	481686e63ae3f11750f3db7ef3475f8b	cb234abc-0212-41c8-9baf-425cb22c9ab9	2026-10-16 03:00:41.280067+00	13	0	120	2026-10-16 02:50:41.280067+00	2026-10-16 02:50:48.347312+00
\.


--
-- Data for Name: career_watch_kv; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.career_watch_kv (user_id, key, value, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000001	career:turn:00000000-0000-4000-8000-000000000003:staged-prepare	{"hash": "6b163551fc486e88496e6bde6cc8bce22630ca0cec59a0bcb4f00ec0fddca7dc", "epoch": 0, "response": {"meta": {"career": true, "intent": "career_browser_task", "contained": false, "result_status": "queued"}, "task": {"id": null, "kind": "pending_task_intent", "status": "queued", "userId": "00000000-0000-4000-8000-000000000001", "version": "career_task_intent/v1", "bindings": {"action": "prepare", "task_id": null, "user_id": "00000000-0000-4000-8000-000000000001", "version": "career_task_intent/v1", "event_id": "staged-prepare", "turn_key": "staged-prepare", "intent_id": "040fecd9227346a984ee2671027247b097f52a3051f54bb8889bc5eb4bbb70e6", "thread_id": "00000000-0000-4000-8000-000000000003", "artifact_id": "owned-resume-1", "destination": "http://localhost:8123/form", "request_hash": "6b163551fc486e88496e6bde6cc8bce22630ca0cec59a0bcb4f00ec0fddca7dc", "privacy_epoch": 0, "resume_sha256": "9c34a12fba5f2d2b0b7e7d7ac62b91ff30d227f853fb70a518ec19208e8fa511", "payload_sha256": null, "profile_sha256": null, "authority_account_version": 1}, "intent_id": "040fecd9227346a984ee2671027247b097f52a3051f54bb8889bc5eb4bbb70e6", "provenance": {"source": "atomic_career_task_intent", "turnKey": "staged-prepare", "threadId": "00000000-0000-4000-8000-000000000003"}}, "reply": "The browser task intent is queued for a separate worker. No browser action is claimed by this chat reply; its immutable intent reference is attached.", "action": null, "turn_key": "staged-prepare", "reminders": [], "thread_id": "00000000-0000-4000-8000-000000000003", "capabilities": {"portal_browser": {"reason": "The Node browser worker is not connected to this Edge handler.", "status": "NOT_WIRED"}, "job_alert_delivery": {"reason": "No alert scheduler or delivery worker is connected to this Edge handler. Saving a watch does not start polling or deliver reminders.", "status": "NOT_WIRED"}}}}	2026-10-16 02:50:35.77955+00
00000000-0000-4000-8000-000000000001	career:turn:00000000-0000-4000-8000-000000000003:staged-status	{"hash": "a31433172fd1c2afc7a864f4c974a8bd3558d1677500ff82965e731e316ef695", "epoch": 0, "response": {"meta": {"career": true, "intent": "career_browser_task", "contained": false, "result_status": "review_ready"}, "task": {"id": "481686e63ae3f11750f3db7ef3475f8b", "asks": [], "kind": "career_application", "phase": "check", "budget": {"spendCents": 0, "limitActions": 120, "spentActions": 8, "reservedActions": 0}, "result": null, "review": {"kind": "career_browser_review", "taskId": "481686e63ae3f11750f3db7ef3475f8b", "userId": "00000000-0000-4000-8000-000000000001", "payload": {"email": "synthetic@example.test", "resume": {"sha256": "9c34a12fba5f2d2b0b7e7d7ac62b91ff30d227f853fb70a518ec19208e8fa511", "filename": "resume.txt"}, "resume_sha256": "9c34a12fba5f2d2b0b7e7d7ac62b91ff30d227f853fb70a518ec19208e8fa511"}, "bindings": [{"source": "profile", "fieldId": "email", "profileKey": "email", "profileHash": "2cdc505399f121714e519cb5282e186ae6b949473627ba5cc6eeeb8f37ec22be", "questionKey": null}, {"source": "profile", "fieldId": "resume", "profileKey": "resume", "profileHash": "2cdc505399f121714e519cb5282e186ae6b949473627ba5cc6eeeb8f37ec22be", "questionKey": null}], "authority": {"intentId": "040fecd9227346a984ee2671027247b097f52a3051f54bb8889bc5eb4bbb70e6", "privacyEpoch": 0, "accountVersion": 1}, "expiresAt": "2026-10-15T12:10:00.000Z", "observedAt": "2026-10-15T12:00:00.000Z", "postingKey": "local:test-role", "destination": "http://localhost:8123/submit", "observation": null, "profileHash": "2cdc505399f121714e519cb5282e186ae6b949473627ba5cc6eeeb8f37ec22be", "resumeSha256": "9c34a12fba5f2d2b0b7e7d7ac62b91ff30d227f853fb70a518ec19208e8fa511", "payloadSha256": "325adca131c665ed18b50fe6f437872c2ead6eaa6af591966fdae78259e8f722"}, "status": "review_ready", "userId": "00000000-0000-4000-8000-000000000001", "blocker": null, "version": "career_task/v1", "revision": 36, "authority": {"intentId": "040fecd9227346a984ee2671027247b097f52a3051f54bb8889bc5eb4bbb70e6", "privacyEpoch": 0, "accountVersion": 1}, "capabilities": {"browser": "CONTROLLED_LOCAL_ONLY", "employer_submission": "NOT_WIRED"}}, "reply": "The owned browser task's saved evidence is attached. No new browser action was started.", "action": null, "turn_key": "staged-status", "reminders": [], "thread_id": "00000000-0000-4000-8000-000000000003", "capabilities": {"portal_browser": {"reason": "The Node browser worker is not connected to this Edge handler.", "status": "NOT_WIRED"}, "job_alert_delivery": {"reason": "No alert scheduler or delivery worker is connected to this Edge handler. Saving a watch does not start polling or deliver reminders.", "status": "NOT_WIRED"}}}}	2026-10-16 02:50:40.838319+00
00000000-0000-4000-8000-000000000001	career:turn:00000000-0000-4000-8000-000000000003:bare-yes	{"hash": "f8932cde1eda71af1afa567c6f745d349d2254551ce1cba2973e5970d3038249", "epoch": 0, "response": {"meta": {"career": true, "intent": "career_browser_task", "contained": false, "result_status": "awaiting_user"}, "reply": "Approve the specific browser task explicitly from its exact review; a bare yes authorizes nothing.", "action": null, "turn_key": "bare-yes", "reminders": [], "thread_id": "00000000-0000-4000-8000-000000000003", "capabilities": {"portal_browser": {"reason": "The Node browser worker is not connected to this Edge handler.", "status": "NOT_WIRED"}, "job_alert_delivery": {"reason": "No alert scheduler or delivery worker is connected to this Edge handler. Saving a watch does not start polling or deliver reminders.", "status": "NOT_WIRED"}}}}	2026-10-16 02:50:41.062535+00
00000000-0000-4000-8000-000000000001	career:turn:00000000-0000-4000-8000-000000000003:staged-approval	{"hash": "823803f52bf5857ccbcfd7440d11b3c03745c1921a94574ba186401c24677aa2", "epoch": 0, "response": {"meta": {"career": true, "intent": "career_browser_task", "contained": false, "result_status": "queued"}, "task": {"id": "481686e63ae3f11750f3db7ef3475f8b", "kind": "pending_task_intent", "status": "queued", "userId": "00000000-0000-4000-8000-000000000001", "version": "career_task_intent/v1", "bindings": {"action": "approve", "task_id": "481686e63ae3f11750f3db7ef3475f8b", "user_id": "00000000-0000-4000-8000-000000000001", "version": "career_task_intent/v1", "event_id": "staged-approval", "turn_key": "staged-approval", "intent_id": "51b1571fdd02bd281562231a9d9696179f38f2a74739789e23f86e9e6784ab2c", "thread_id": "00000000-0000-4000-8000-000000000003", "artifact_id": null, "destination": "http://localhost:8123/submit", "request_hash": "823803f52bf5857ccbcfd7440d11b3c03745c1921a94574ba186401c24677aa2", "privacy_epoch": 0, "resume_sha256": "9c34a12fba5f2d2b0b7e7d7ac62b91ff30d227f853fb70a518ec19208e8fa511", "payload_sha256": "325adca131c665ed18b50fe6f437872c2ead6eaa6af591966fdae78259e8f722", "profile_sha256": null, "authority_account_version": 4}, "intent_id": "51b1571fdd02bd281562231a9d9696179f38f2a74739789e23f86e9e6784ab2c", "provenance": {"source": "atomic_career_task_intent", "turnKey": "staged-approval", "threadId": "00000000-0000-4000-8000-000000000003"}}, "reply": "The browser task intent is queued for a separate worker. No browser action is claimed by this chat reply; its immutable intent reference is attached.", "action": null, "turn_key": "staged-approval", "reminders": [], "thread_id": "00000000-0000-4000-8000-000000000003", "capabilities": {"portal_browser": {"reason": "The Node browser worker is not connected to this Edge handler.", "status": "NOT_WIRED"}, "job_alert_delivery": {"reason": "No alert scheduler or delivery worker is connected to this Edge handler. Saving a watch does not start polling or deliver reminders.", "status": "NOT_WIRED"}}}}	2026-10-16 02:50:41.280067+00
00000000-0000-4000-8000-000000000001	career:account	{"epoch": 0, "version": 5}	2026-10-16 02:50:48.821219+00
00000000-0000-4000-8000-000000000001	career:turn:00000000-0000-4000-8000-000000000003:staged-done	{"hash": "94639bef833d83d5a7673a4183bf7da53815e3deb9a3dc32aea16f43bab6572f", "epoch": 0, "response": {"meta": {"career": true, "intent": "career_browser_task", "contained": false, "result_status": "completed"}, "task": {"id": "481686e63ae3f11750f3db7ef3475f8b", "asks": [], "kind": "career_application", "phase": "check", "budget": {"spendCents": 0, "limitActions": 120, "spentActions": 21, "reservedActions": 0}, "result": {"kind": "career_browser_result", "status": "completed", "taskId": "481686e63ae3f11750f3db7ef3475f8b", "capture": {"confirmationId": "TEST-RECEIPT-1", "confirmationUrl": "http://localhost:8123/submit"}, "receipt": {"source": "controlled_portal_readback", "taskId": "481686e63ae3f11750f3db7ef3475f8b", "userId": "00000000-0000-4000-8000-000000000001", "destination": "http://localhost:8123/submit", "resumeSha256": "9c34a12fba5f2d2b0b7e7d7ac62b91ff30d227f853fb70a518ec19208e8fa511", "payloadSha256": "325adca131c665ed18b50fe6f437872c2ead6eaa6af591966fdae78259e8f722", "confirmationId": "TEST-RECEIPT-1"}, "checkedAt": "2026-10-15T12:00:00.000Z", "approvalRef": "staged-approval", "destination": "http://localhost:8123/submit", "resumeSha256": "9c34a12fba5f2d2b0b7e7d7ac62b91ff30d227f853fb70a518ec19208e8fa511", "payloadSha256": "325adca131c665ed18b50fe6f437872c2ead6eaa6af591966fdae78259e8f722"}, "review": {"kind": "career_browser_review", "taskId": "481686e63ae3f11750f3db7ef3475f8b", "userId": "00000000-0000-4000-8000-000000000001", "payload": {"email": "synthetic@example.test", "resume": {"sha256": "9c34a12fba5f2d2b0b7e7d7ac62b91ff30d227f853fb70a518ec19208e8fa511", "filename": "resume.txt"}, "resume_sha256": "9c34a12fba5f2d2b0b7e7d7ac62b91ff30d227f853fb70a518ec19208e8fa511"}, "bindings": [{"source": "profile", "fieldId": "email", "profileKey": "email", "profileHash": "2cdc505399f121714e519cb5282e186ae6b949473627ba5cc6eeeb8f37ec22be", "questionKey": null}, {"source": "profile", "fieldId": "resume", "profileKey": "resume", "profileHash": "2cdc505399f121714e519cb5282e186ae6b949473627ba5cc6eeeb8f37ec22be", "questionKey": null}], "authority": {"intentId": "51b1571fdd02bd281562231a9d9696179f38f2a74739789e23f86e9e6784ab2c", "privacyEpoch": 0, "accountVersion": 4}, "expiresAt": "2026-10-15T12:10:00.000Z", "observedAt": "2026-10-15T12:00:00.000Z", "postingKey": "local:test-role", "destination": "http://localhost:8123/submit", "observation": null, "profileHash": "2cdc505399f121714e519cb5282e186ae6b949473627ba5cc6eeeb8f37ec22be", "resumeSha256": "9c34a12fba5f2d2b0b7e7d7ac62b91ff30d227f853fb70a518ec19208e8fa511", "payloadSha256": "325adca131c665ed18b50fe6f437872c2ead6eaa6af591966fdae78259e8f722"}, "status": "completed", "userId": "00000000-0000-4000-8000-000000000001", "blocker": null, "version": "career_task/v1", "revision": 92, "authority": {"intentId": "51b1571fdd02bd281562231a9d9696179f38f2a74739789e23f86e9e6784ab2c", "privacyEpoch": 0, "accountVersion": 4}, "capabilities": {"browser": "CONTROLLED_LOCAL_ONLY", "employer_submission": "NOT_WIRED"}}, "reply": "The owned browser task's saved evidence is attached. No new browser action was started.", "action": null, "turn_key": "staged-done", "reminders": [], "thread_id": "00000000-0000-4000-8000-000000000003", "capabilities": {"portal_browser": {"reason": "The Node browser worker is not connected to this Edge handler.", "status": "NOT_WIRED"}, "job_alert_delivery": {"reason": "No alert scheduler or delivery worker is connected to this Edge handler. Saving a watch does not start polling or deliver reminders.", "status": "NOT_WIRED"}}}}	2026-10-16 02:50:48.821219+00
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.profiles (id) FROM stdin;
\.


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: agent_flow_state agent_flow_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_flow_state
    ADD CONSTRAINT agent_flow_state_pkey PRIMARY KEY (thread_id);


--
-- Name: agent_messages agent_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_messages
    ADD CONSTRAINT agent_messages_pkey PRIMARY KEY (id);


--
-- Name: agent_threads agent_threads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_threads
    ADD CONSTRAINT agent_threads_pkey PRIMARY KEY (id);


--
-- Name: career_reminder_outbox career_reminder_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_reminder_outbox
    ADD CONSTRAINT career_reminder_outbox_pkey PRIMARY KEY (user_id, reminder_id);


--
-- Name: career_task_effects_v1 career_task_effects_v1_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_task_effects_v1
    ADD CONSTRAINT career_task_effects_v1_pkey PRIMARY KEY (user_id, intent_id, effect_key);


--
-- Name: career_task_effects_v1 career_task_effects_v1_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_task_effects_v1
    ADD CONSTRAINT career_task_effects_v1_token_key UNIQUE (token);


--
-- Name: career_task_intents_v1 career_task_intents_v1_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_task_intents_v1
    ADD CONSTRAINT career_task_intents_v1_pkey PRIMARY KEY (user_id, intent_id);


--
-- Name: career_task_intents_v1 career_task_intents_v1_user_id_event_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_task_intents_v1
    ADD CONSTRAINT career_task_intents_v1_user_id_event_hash_key UNIQUE (user_id, event_hash);


--
-- Name: career_task_intents_v1 career_task_intents_v1_user_id_thread_id_turn_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_task_intents_v1
    ADD CONSTRAINT career_task_intents_v1_user_id_thread_id_turn_key_key UNIQUE (user_id, thread_id, turn_key);


--
-- Name: career_watch_kv career_watch_kv_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_watch_kv
    ADD CONSTRAINT career_watch_kv_pkey PRIMARY KEY (user_id, key);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: career_reminder_unseen; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX career_reminder_unseen ON public.career_reminder_outbox USING btree (user_id, delivered_at) WHERE ((status = 'delivered'::text) AND (seen_at IS NULL));


--
-- Name: career_task_one_submit_v1; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX career_task_one_submit_v1 ON public.career_task_effects_v1 USING btree (user_id, task_id) WHERE (operation = 'submit'::text);


--
-- Name: career_watch_kv career_task_account_control_v1; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER career_task_account_control_v1 AFTER INSERT OR DELETE OR UPDATE ON public.career_watch_kv FOR EACH ROW EXECUTE FUNCTION public.career_task_control_hook_v1();


--
-- Name: agent_flow_state agent_flow_state_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_flow_state
    ADD CONSTRAINT agent_flow_state_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.agent_threads(id) ON DELETE CASCADE;


--
-- Name: agent_flow_state agent_flow_state_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_flow_state
    ADD CONSTRAINT agent_flow_state_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: agent_messages agent_messages_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_messages
    ADD CONSTRAINT agent_messages_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.agent_threads(id);


--
-- Name: agent_threads agent_threads_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_threads
    ADD CONSTRAINT agent_threads_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id);


--
-- Name: career_reminder_outbox career_reminder_outbox_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_reminder_outbox
    ADD CONSTRAINT career_reminder_outbox_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: career_task_effects_v1 career_task_effects_v1_user_id_intent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_task_effects_v1
    ADD CONSTRAINT career_task_effects_v1_user_id_intent_id_fkey FOREIGN KEY (user_id, intent_id) REFERENCES public.career_task_intents_v1(user_id, intent_id);


--
-- Name: career_task_intents_v1 career_task_intents_v1_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_task_intents_v1
    ADD CONSTRAINT career_task_intents_v1_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.agent_threads(id);


--
-- Name: career_task_intents_v1 career_task_intents_v1_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_task_intents_v1
    ADD CONSTRAINT career_task_intents_v1_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: career_watch_kv career_watch_kv_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_watch_kv
    ADD CONSTRAINT career_watch_kv_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: profiles profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id);


--
-- Name: career_task_effects_v1 career_effect_backend_v1; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY career_effect_backend_v1 ON public.career_task_effects_v1 TO service_role USING (true) WITH CHECK (true);


--
-- Name: career_reminder_outbox career_reminder_backend; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY career_reminder_backend ON public.career_reminder_outbox TO service_role USING (true) WITH CHECK (true);


--
-- Name: career_reminder_outbox; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.career_reminder_outbox ENABLE ROW LEVEL SECURITY;

--
-- Name: career_task_intents_v1 career_task_backend_v1; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY career_task_backend_v1 ON public.career_task_intents_v1 TO service_role USING (true) WITH CHECK (true);


--
-- Name: career_task_effects_v1; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.career_task_effects_v1 ENABLE ROW LEVEL SECURITY;

--
-- Name: career_task_intents_v1; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.career_task_intents_v1 ENABLE ROW LEVEL SECURITY;

--
-- Name: career_watch_kv career_watch_backend; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY career_watch_backend ON public.career_watch_kv TO service_role USING (true) WITH CHECK (true);


--
-- Name: career_watch_kv; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.career_watch_kv ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict mXqTIC0Rh5mqMVMeNjKuPnH7hv8GT8xqKcCFMmylHZ9aOOvVxILGwGGOsd87y7U

