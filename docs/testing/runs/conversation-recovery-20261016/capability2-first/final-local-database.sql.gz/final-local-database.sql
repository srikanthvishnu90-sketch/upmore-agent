--
-- PostgreSQL database dump
--

\restrict rbVcidEUuxM9M9ZSNykaAfSmIO2iOQ148FB4mdpyoAR3mV11dSzlsjUaqcbCpoE

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg13+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- Name: recovery_reject_save(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.recovery_reject_save() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ begin if current_setting('recovery.fail_save',true)='1' then raise exception 'FROZEN RECOVERY SAVE FAULT';end if;return NEW;end $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    id uuid NOT NULL
);


--
-- Name: agent_flow_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_flow_state (
    thread_id uuid NOT NULL,
    user_id uuid NOT NULL,
    state jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_flow_state_state_check CHECK ((jsonb_typeof(state) = 'object'::text)),
    CONSTRAINT agent_flow_state_state_check1 CHECK ((pg_column_size(state) < 524288)),
    CONSTRAINT agent_flow_state_state_check2 CHECK ((NOT ((state)::text ~* '"(otp|one_time_code|password|passcode|card_number|pan|cvv|ssn)"\s*:'::text)))
);


--
-- Name: agent_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    thread_id uuid NOT NULL,
    role text,
    content text,
    meta jsonb,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT agent_messages_role_check CHECK ((role = ANY (ARRAY['user'::text, 'assistant'::text, 'system'::text])))
);


--
-- Name: agent_threads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_threads (
    id uuid NOT NULL,
    user_id uuid NOT NULL
);


--
-- Name: career_watch_kv; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.career_watch_kv (
    user_id uuid NOT NULL,
    key text NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE career_watch_kv; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.career_watch_kv IS 'MI-032 alerts host wiring: generic per-user KV for the career watch/assign state (152 watch profiles, reminder queues, seat history; 151 per-board snapshots; host delivery ledger). Written/read by scripts/career/alerts-host.mjs createSupabaseStore via the service role. Design: docs/career/alerts-host-wiring.md.';


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profiles (
    id uuid NOT NULL
);


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (id) FROM stdin;
00000000-0000-4000-8000-000000000001
\.


--
-- Data for Name: agent_flow_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_flow_state (thread_id, user_id, state, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000113	00000000-0000-4000-8000-000000000001	{"career": {"v": 1, "stores": {"plan": {"at": "2026-10-16T00:48:52.860Z", "days": 0, "kind": "campaign_plan", "count": 40, "firms": ["Quartz Studio"], "target": {"count": 40, "firms": ["Quartz Studio"], "vague": false, "firm_set": null, "industry": "investment_banking", "geography": "Austin", "exclusions": ["geo:EU_UK"], "firms_named": true, "role_family": "investment_banking", "role_phrase": null, "count_source": "default", "firms_source": "named", "school_filter": null, "seniority_band": null, "proposed_default": null, "background_filters": {}}, "lastAsk": "I want to network into Quartz Studio in Austin.", "purpose": null, "deferred": [], "firm_set": null, "scheduled": 0, "firms_named": true, "role_family": "investment_banking", "firms_source": "named"}, "profile": {"facts": [{"end": "2028-05", "org": "Synthetic University", "kind": "education", "text": "Junior B.A. Economics at Synthetic University, graduating May 2028", "title": "B.A. Economics", "fact_id": "REC-E1", "evidence": ["synthetic fixture supplied education"], "unproven": false}, {"kind": "skill", "name": "Python", "text": "Class Python CSV parser", "fact_id": "REC-S1", "evidence": ["synthetic class project"], "unproven": false}], "basics": {"name": "Synthetic Recovery Learner", "location": "Chicago, IL"}, "constraints": {}, "preferences": {"locations": ["Chicago"], "starredCompanies": []}, "_careerTrackStore": {"rows": [], "_careerThread": {"plan": {"at": "2026-10-16T00:48:52.860Z", "days": 0, "kind": "campaign_plan", "count": 40, "firms": ["Quartz Studio"], "target": {"count": 40, "firms": ["Quartz Studio"], "vague": false, "firm_set": null, "industry": "investment_banking", "geography": "Austin", "exclusions": ["geo:EU_UK"], "firms_named": true, "role_family": "investment_banking", "role_phrase": null, "count_source": "default", "firms_source": "named", "school_filter": null, "seniority_band": null, "proposed_default": null, "background_filters": {}}, "lastAsk": "I want to network into Quartz Studio in Austin.", "purpose": null, "deferred": [], "firm_set": null, "scheduled": 0, "firms_named": true, "role_family": "investment_banking", "firms_source": "named"}, "facts": {"facts": [{"at": "2026-10-16T00:48:52.860Z", "kind": "geography", "value": "Austin", "evidence": "in Austin"}, {"at": "2026-10-16T00:48:52.860Z", "kind": "target_firm", "value": "Quartz Studio", "evidence": "network into Quartz Studio"}], "updatedAt": "2026-10-16T00:48:52.860Z"}}}}, "trackStore": {"rows": [], "_careerThread": {"plan": {"at": "2026-10-16T00:48:52.860Z", "days": 0, "kind": "campaign_plan", "count": 40, "firms": ["Quartz Studio"], "target": {"count": 40, "firms": ["Quartz Studio"], "vague": false, "firm_set": null, "industry": "investment_banking", "geography": "Austin", "exclusions": ["geo:EU_UK"], "firms_named": true, "role_family": "investment_banking", "role_phrase": null, "count_source": "default", "firms_source": "named", "school_filter": null, "seniority_band": null, "proposed_default": null, "background_filters": {}}, "lastAsk": "I want to network into Quartz Studio in Austin.", "purpose": null, "deferred": [], "firm_set": null, "scheduled": 0, "firms_named": true, "role_family": "investment_banking", "firms_source": "named"}, "facts": {"facts": [{"at": "2026-10-16T00:48:52.860Z", "kind": "geography", "value": "Austin", "evidence": "in Austin"}, {"at": "2026-10-16T00:48:52.860Z", "kind": "target_firm", "value": "Quartz Studio", "evidence": "network into Quartz Studio"}], "updatedAt": "2026-10-16T00:48:52.860Z"}}}, "statedFacts": {"facts": [{"at": "2026-10-16T00:48:52.860Z", "kind": "geography", "value": "Austin", "evidence": "in Austin"}, {"at": "2026-10-16T00:48:52.860Z", "kind": "target_firm", "value": "Quartz Studio", "evidence": "network into Quartz Studio"}], "updatedAt": "2026-10-16T00:48:52.860Z"}}}}	2026-10-16 00:48:52.149546+00
\.


--
-- Data for Name: agent_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_messages (id, thread_id, role, content, meta, created_at) FROM stdin;
cd6a36bb-bcf8-4e71-8ac6-c55861ee0a64	00000000-0000-4000-8000-000000000113	user	I want to network into Quartz Studio in Austin.	{}	2026-10-16 00:48:52.736091+00
104d79fb-986f-46c7-b808-3f6550d30c18	00000000-0000-4000-8000-000000000113	assistant	Building the list now: investment bankers at Quartz Studio in Austin — sized by what the sources yield, not by a number invented here.\nOne firm, so the per-firm cap shapes the waves: at most 15 first emails to Quartz Studio in any 30 days — the rest run in later monthly waves, planned that way from the start. Sources, in order: your own LinkedIn export, names you paste, your school's alumni directory, and firm team pages — every name carries its source, and nobody is emailed on a guessed address. The found, trustworthy, and sendable counts come back here before a single draft exists, and drafting starts only when you approve the whole plan.	{"career": true, "intent": "outreach_clarification", "contained": false, "result_status": "awaiting_user"}	2026-10-16 00:48:53.072532+00
b489c599-c2d5-4e0d-83f4-5e820aba5261	00000000-0000-4000-8000-000000000113	user	Actually, my preferred location is Denver.	{}	2026-10-16 00:48:53.738867+00
ab2ab67d-3bc9-4e1b-a3af-d53e089f6df2	00000000-0000-4000-8000-000000000113	assistant	I didn't catch that. Try naming the job, company, or person — or say 'find jobs' and I'll start there.	{"career": true, "intent": null, "contained": true, "result_status": null}	2026-10-16 00:48:54.106009+00
10a0bf02-54ac-411f-8e83-e1ec6d97eb33	00000000-0000-4000-8000-000000000113	user	Actually, my preferred location is Denver.	{}	2026-10-16 00:48:54.889463+00
994b633c-8186-4084-a881-b1fc6c2d8def	00000000-0000-4000-8000-000000000113	assistant	I didn't catch that. Try naming the job, company, or person — or say 'find jobs' and I'll start there.	{"career": true, "intent": null, "contained": true, "result_status": null}	2026-10-16 00:48:55.290396+00
4e5b6449-b1f5-415e-a0a7-ecd4b8853570	00000000-0000-4000-8000-000000000113	user	Actually, my preferred location is Denver.	{}	2026-10-16 00:48:55.858486+00
bae1d58f-a527-4706-8503-09c99d685d0e	00000000-0000-4000-8000-000000000113	assistant	I didn't catch that. Try naming the job, company, or person — or say 'find jobs' and I'll start there.	{"career": true, "intent": null, "contained": true, "result_status": null}	2026-10-16 00:48:56.227642+00
4a0cecfa-092b-48d8-a599-5984859ead9b	00000000-0000-4000-8000-000000000113	user	Actually, my preferred location is Seattle.	{}	2026-10-16 00:48:56.80094+00
82b4e5da-33f7-4784-b76e-39d9fc212856	00000000-0000-4000-8000-000000000113	assistant	I didn't catch that. Try naming the job, company, or person — or say 'find jobs' and I'll start there.	{"career": true, "intent": null, "contained": true, "result_status": null}	2026-10-16 00:48:57.148538+00
5ff69882-02f1-4663-88aa-141224d2f011	00000000-0000-4000-8000-000000000113	user	Recap my target city after the failed save and the successful retry.	{}	2026-10-16 00:48:57.735749+00
32e2e8ea-09df-4903-9f3e-901049007efe	00000000-0000-4000-8000-000000000113	assistant	Where we landed, from this thread's own record.\nThe outreach plan stands targeting Quartz Studio in Austin — no list built yet, no sends, everything waits on your approval of the whole plan. Your facts on record: you're targeting Austin; your target firm is Quartz Studio. Name the piece to move next and it runs from exactly this state.	{"career": true, "intent": "career_guidance", "contained": false, "result_status": "awaiting_user"}	2026-10-16 00:48:58.063232+00
\.


--
-- Data for Name: agent_threads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_threads (id, user_id) FROM stdin;
00000000-0000-4000-8000-000000000113	00000000-0000-4000-8000-000000000001
\.


--
-- Data for Name: career_watch_kv; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.career_watch_kv (user_id, key, value, updated_at) FROM stdin;
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.profiles (id) FROM stdin;
00000000-0000-4000-8000-000000000001
\.


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: agent_flow_state agent_flow_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_flow_state
    ADD CONSTRAINT agent_flow_state_pkey PRIMARY KEY (thread_id);


--
-- Name: agent_messages agent_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_messages
    ADD CONSTRAINT agent_messages_pkey PRIMARY KEY (id);


--
-- Name: agent_threads agent_threads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_threads
    ADD CONSTRAINT agent_threads_pkey PRIMARY KEY (id);


--
-- Name: career_watch_kv career_watch_kv_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_watch_kv
    ADD CONSTRAINT career_watch_kv_pkey PRIMARY KEY (user_id, key);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: agent_flow_state recovery_save_fault; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER recovery_save_fault BEFORE INSERT OR UPDATE ON public.agent_flow_state FOR EACH ROW EXECUTE FUNCTION public.recovery_reject_save();


--
-- Name: agent_flow_state agent_flow_state_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_flow_state
    ADD CONSTRAINT agent_flow_state_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.agent_threads(id) ON DELETE CASCADE;


--
-- Name: agent_flow_state agent_flow_state_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_flow_state
    ADD CONSTRAINT agent_flow_state_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: agent_messages agent_messages_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_messages
    ADD CONSTRAINT agent_messages_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.agent_threads(id);


--
-- Name: agent_threads agent_threads_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_threads
    ADD CONSTRAINT agent_threads_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id);


--
-- Name: career_watch_kv career_watch_kv_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_watch_kv
    ADD CONSTRAINT career_watch_kv_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: profiles profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id);


--
-- Name: career_watch_kv; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.career_watch_kv ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict rbVcidEUuxM9M9ZSNykaAfSmIO2iOQ148FB4mdpyoAR3mV11dSzlsjUaqcbCpoE

