--
-- PostgreSQL database dump
--

\restrict 76SnSH8jw7yPsu7EUDW0E8EzKm91pz65y77lr2YS21vVNC6YWUPk0pbhEKK7UCS

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg13+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- Name: recovery_reject_save(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.recovery_reject_save() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ begin if current_setting('recovery.fail_save',true)='1' then raise exception 'FROZEN RECOVERY SAVE FAULT';end if;return NEW;end $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    id uuid NOT NULL
);


--
-- Name: agent_flow_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_flow_state (
    thread_id uuid NOT NULL,
    user_id uuid NOT NULL,
    state jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_flow_state_state_check CHECK ((jsonb_typeof(state) = 'object'::text)),
    CONSTRAINT agent_flow_state_state_check1 CHECK ((pg_column_size(state) < 524288)),
    CONSTRAINT agent_flow_state_state_check2 CHECK ((NOT ((state)::text ~* '"(otp|one_time_code|password|passcode|card_number|pan|cvv|ssn)"\s*:'::text)))
);


--
-- Name: agent_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    thread_id uuid NOT NULL,
    role text,
    content text,
    meta jsonb,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT agent_messages_role_check CHECK ((role = ANY (ARRAY['user'::text, 'assistant'::text, 'system'::text])))
);


--
-- Name: agent_threads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_threads (
    id uuid NOT NULL,
    user_id uuid NOT NULL
);


--
-- Name: career_watch_kv; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.career_watch_kv (
    user_id uuid NOT NULL,
    key text NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE career_watch_kv; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.career_watch_kv IS 'MI-032 alerts host wiring: generic per-user KV for the career watch/assign state (152 watch profiles, reminder queues, seat history; 151 per-board snapshots; host delivery ledger). Written/read by scripts/career/alerts-host.mjs createSupabaseStore via the service role. Design: docs/career/alerts-host-wiring.md.';


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profiles (
    id uuid NOT NULL
);


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (id) FROM stdin;
00000000-0000-4000-8000-000000000001
\.


--
-- Data for Name: agent_flow_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_flow_state (thread_id, user_id, state, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000113	00000000-0000-4000-8000-000000000001	{"career": {"v": 1, "stores": {"plan": {"at": "2026-10-16T00:48:54.807Z", "days": 0, "kind": "campaign_plan", "count": 40, "firms": ["Quartz Studio"], "target": {"count": 40, "firms": ["Quartz Studio"], "vague": false, "firm_set": null, "industry": "investment_banking", "geography": "Austin", "exclusions": ["geo:EU_UK"], "firms_named": true, "role_family": "investment_banking", "role_phrase": null, "count_source": "default", "firms_source": "named", "school_filter": null, "seniority_band": null, "proposed_default": null, "background_filters": {}}, "lastAsk": "I want to network into Quartz Studio in Austin.", "purpose": null, "deferred": [], "firm_set": null, "scheduled": 0, "firms_named": true, "role_family": "investment_banking", "firms_source": "named"}, "profile": {"facts": [{"end": "2028-05", "org": "Synthetic University", "kind": "education", "text": "Junior B.A. Economics at Synthetic University, graduating May 2028", "title": "B.A. Economics", "fact_id": "REC-E1", "evidence": ["synthetic fixture supplied education"], "unproven": false}, {"kind": "skill", "name": "Python", "text": "Class Python CSV parser", "fact_id": "REC-S1", "evidence": ["synthetic class project"], "unproven": false}], "basics": {"name": "Synthetic Recovery Learner", "location": "Chicago, IL"}, "constraints": {}, "preferences": {"locations": ["Chicago"], "starredCompanies": []}, "_careerTrackStore": {"rows": [], "_careerThread": {"plan": {"at": "2026-10-16T00:48:54.807Z", "days": 0, "kind": "campaign_plan", "count": 40, "firms": ["Quartz Studio"], "target": {"count": 40, "firms": ["Quartz Studio"], "vague": false, "firm_set": null, "industry": "investment_banking", "geography": "Austin", "exclusions": ["geo:EU_UK"], "firms_named": true, "role_family": "investment_banking", "role_phrase": null, "count_source": "default", "firms_source": "named", "school_filter": null, "seniority_band": null, "proposed_default": null, "background_filters": {}}, "lastAsk": "I want to network into Quartz Studio in Austin.", "purpose": null, "deferred": [], "firm_set": null, "scheduled": 0, "firms_named": true, "role_family": "investment_banking", "firms_source": "named"}, "facts": {"facts": [{"at": "2026-10-16T00:48:54.807Z", "kind": "geography", "value": "Austin", "evidence": "in Austin"}, {"at": "2026-10-16T00:48:54.807Z", "kind": "target_firm", "value": "Quartz Studio", "evidence": "network into Quartz Studio"}], "updatedAt": "2026-10-16T00:48:54.807Z"}}}}, "trackStore": {"rows": [], "_careerThread": {"plan": {"at": "2026-10-16T00:48:54.807Z", "days": 0, "kind": "campaign_plan", "count": 40, "firms": ["Quartz Studio"], "target": {"count": 40, "firms": ["Quartz Studio"], "vague": false, "firm_set": null, "industry": "investment_banking", "geography": "Austin", "exclusions": ["geo:EU_UK"], "firms_named": true, "role_family": "investment_banking", "role_phrase": null, "count_source": "default", "firms_source": "named", "school_filter": null, "seniority_band": null, "proposed_default": null, "background_filters": {}}, "lastAsk": "I want to network into Quartz Studio in Austin.", "purpose": null, "deferred": [], "firm_set": null, "scheduled": 0, "firms_named": true, "role_family": "investment_banking", "firms_source": "named"}, "facts": {"facts": [{"at": "2026-10-16T00:48:54.807Z", "kind": "geography", "value": "Austin", "evidence": "in Austin"}, {"at": "2026-10-16T00:48:54.807Z", "kind": "target_firm", "value": "Quartz Studio", "evidence": "network into Quartz Studio"}], "updatedAt": "2026-10-16T00:48:54.807Z"}}}, "statedFacts": {"facts": [{"at": "2026-10-16T00:48:54.807Z", "kind": "geography", "value": "Austin", "evidence": "in Austin"}, {"at": "2026-10-16T00:48:54.807Z", "kind": "target_firm", "value": "Quartz Studio", "evidence": "network into Quartz Studio"}], "updatedAt": "2026-10-16T00:48:54.807Z"}}}}	2026-10-16 00:48:54.032382+00
\.


--
-- Data for Name: agent_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_messages (id, thread_id, role, content, meta, created_at) FROM stdin;
b584661e-408e-4973-a798-d1a090f81fa6	00000000-0000-4000-8000-000000000113	user	I want to network into Quartz Studio in Austin.	{}	2026-10-16 00:48:54.657032+00
53af8e1b-8898-4ae4-8442-d54641f1f177	00000000-0000-4000-8000-000000000113	assistant	Building the list now: investment bankers at Quartz Studio in Austin — sized by what the sources yield, not by a number invented here.\nOne firm, so the per-firm cap shapes the waves: at most 15 first emails to Quartz Studio in any 30 days — the rest run in later monthly waves, planned that way from the start. Sources, in order: your own LinkedIn export, names you paste, your school's alumni directory, and firm team pages — every name carries its source, and nobody is emailed on a guessed address. The found, trustworthy, and sendable counts come back here before a single draft exists, and drafting starts only when you approve the whole plan.	{"career": true, "intent": "outreach_clarification", "contained": false, "result_status": "awaiting_user"}	2026-10-16 00:48:55.045183+00
adff960b-9c18-48d5-b2d6-0fc043d52db8	00000000-0000-4000-8000-000000000113	user	Actually, my preferred location is Denver.	{}	2026-10-16 00:48:55.588679+00
756ed78d-3f04-4d2b-83f6-21e5281a7379	00000000-0000-4000-8000-000000000113	assistant	I didn't catch that. Try naming the job, company, or person — or say 'find jobs' and I'll start there.	{"career": true, "intent": null, "contained": true, "result_status": null}	2026-10-16 00:48:55.923914+00
528c5bff-1cd5-4519-b380-1c43605b3876	00000000-0000-4000-8000-000000000113	user	Actually, my preferred location is Denver.	{}	2026-10-16 00:48:56.473957+00
d3a9814d-48cb-4a0c-8eaf-9a32043fef15	00000000-0000-4000-8000-000000000113	assistant	I didn't catch that. Try naming the job, company, or person — or say 'find jobs' and I'll start there.	{"career": true, "intent": null, "contained": true, "result_status": null}	2026-10-16 00:48:56.792391+00
e9a24ccc-be65-477b-9177-c03cefbdc9f0	00000000-0000-4000-8000-000000000113	user	Actually, my preferred location is Denver.	{}	2026-10-16 00:48:57.397715+00
6349738c-7d1f-45e4-91aa-4a30f78ec5e0	00000000-0000-4000-8000-000000000113	assistant	I didn't catch that. Try naming the job, company, or person — or say 'find jobs' and I'll start there.	{"career": true, "intent": null, "contained": true, "result_status": null}	2026-10-16 00:48:57.742342+00
088865c8-771f-4922-bd19-f984fd3d1223	00000000-0000-4000-8000-000000000113	user	Actually, my preferred location is Seattle.	{}	2026-10-16 00:48:58.285535+00
f0debc12-6ba9-4999-b9a4-33e1c0d4345d	00000000-0000-4000-8000-000000000113	assistant	I didn't catch that. Try naming the job, company, or person — or say 'find jobs' and I'll start there.	{"career": true, "intent": null, "contained": true, "result_status": null}	2026-10-16 00:48:58.665408+00
860ccd48-3330-4455-b124-c4b34c05458d	00000000-0000-4000-8000-000000000113	user	Recap my target city after the failed save and the successful retry.	{}	2026-10-16 00:48:59.267333+00
59381023-6cc0-434b-b8ec-f99038eb587f	00000000-0000-4000-8000-000000000113	assistant	Where we landed, from this thread's own record.\nThe outreach plan stands targeting Quartz Studio in Austin — no list built yet, no sends, everything waits on your approval of the whole plan. Your facts on record: you're targeting Austin; your target firm is Quartz Studio. Name the piece to move next and it runs from exactly this state.	{"career": true, "intent": "career_guidance", "contained": false, "result_status": "awaiting_user"}	2026-10-16 00:48:59.569776+00
\.


--
-- Data for Name: agent_threads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_threads (id, user_id) FROM stdin;
00000000-0000-4000-8000-000000000113	00000000-0000-4000-8000-000000000001
\.


--
-- Data for Name: career_watch_kv; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.career_watch_kv (user_id, key, value, updated_at) FROM stdin;
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.profiles (id) FROM stdin;
00000000-0000-4000-8000-000000000001
\.


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: agent_flow_state agent_flow_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_flow_state
    ADD CONSTRAINT agent_flow_state_pkey PRIMARY KEY (thread_id);


--
-- Name: agent_messages agent_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_messages
    ADD CONSTRAINT agent_messages_pkey PRIMARY KEY (id);


--
-- Name: agent_threads agent_threads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_threads
    ADD CONSTRAINT agent_threads_pkey PRIMARY KEY (id);


--
-- Name: career_watch_kv career_watch_kv_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_watch_kv
    ADD CONSTRAINT career_watch_kv_pkey PRIMARY KEY (user_id, key);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: agent_flow_state recovery_save_fault; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER recovery_save_fault BEFORE INSERT OR UPDATE ON public.agent_flow_state FOR EACH ROW EXECUTE FUNCTION public.recovery_reject_save();


--
-- Name: agent_flow_state agent_flow_state_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_flow_state
    ADD CONSTRAINT agent_flow_state_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.agent_threads(id) ON DELETE CASCADE;


--
-- Name: agent_flow_state agent_flow_state_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_flow_state
    ADD CONSTRAINT agent_flow_state_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: agent_messages agent_messages_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_messages
    ADD CONSTRAINT agent_messages_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.agent_threads(id);


--
-- Name: agent_threads agent_threads_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_threads
    ADD CONSTRAINT agent_threads_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id);


--
-- Name: career_watch_kv career_watch_kv_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_watch_kv
    ADD CONSTRAINT career_watch_kv_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: profiles profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id);


--
-- Name: career_watch_kv; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.career_watch_kv ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict 76SnSH8jw7yPsu7EUDW0E8EzKm91pz65y77lr2YS21vVNC6YWUPk0pbhEKK7UCS

