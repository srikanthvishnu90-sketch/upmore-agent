# conversations-033

All conversations are synthetic. Full production handler, mock authentication/PostgREST and disabled model; no real outbound messages or provider actions.

## C01601 · M01 · Confirmed nickname recalls the right person · PASS

Expected: [{"say":"save greta as brother"},{"say":"yes"},{"say":"send brother 60","match":"Greta Kim.*@gretak","outcome":"confirm"}]

### Trial 1

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Greta Kim (brother, @gretak).

User: send brother 60

Upmore: Set up $60.00 to Greta Kim (brother, @gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Greta Kim (brother, @gretak).

User: send brother 60

Upmore: Set up $60.00 to Greta Kim (brother, @gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Greta Kim (brother, @gretak).

User: send brother 60

Upmore: Set up $60.00 to Greta Kim (brother, @gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01602 · M02 · Explicit remember phrasing persists an alias · PASS

Expected: [{"say":"remember Bill Rao as my sister"},{"say":"yes"},{"say":"send sister 75","match":"Bill Rao.*@billr","outcome":"confirm"}]

### Trial 1

User: remember Bill Rao as my sister

Upmore: Save "sister" as your name for Bill Rao (@billr)? Then "send sister 20" goes to Bill Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Bill Rao (sister, @billr).

User: send sister 75

Upmore: Set up $75.00 to Bill Rao (sister, @billr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: remember Bill Rao as my sister

Upmore: Save "sister" as your name for Bill Rao (@billr)? Then "send sister 20" goes to Bill Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Bill Rao (sister, @billr).

User: send sister 75

Upmore: Set up $75.00 to Bill Rao (sister, @billr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: remember Bill Rao as my sister

Upmore: Save "sister" as your name for Bill Rao (@billr)? Then "send sister 20" goes to Bill Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Bill Rao (sister, @billr).

User: send sister 75

Upmore: Set up $75.00 to Bill Rao (sister, @billr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01603 · M03 · Natural relationship statement needs confirmation and persists · PASS

Expected: [{"say":"my dad is Greta Kim","match":"Save"},{"say":"yes"},{"say":"send dad 90","match":"Greta Kim","outcome":"confirm"}]

### Trial 1

User: my dad is Greta Kim

Upmore: Save "dad" as your name for Greta Kim (@gretak)? Then "send dad 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Greta Kim (dad, @gretak).

User: send dad 90

Upmore: Set up $90.00 to Greta Kim (dad, @gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: my dad is Greta Kim

Upmore: Save "dad" as your name for Greta Kim (@gretak)? Then "send dad 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Greta Kim (dad, @gretak).

User: send dad 90

Upmore: Set up $90.00 to Greta Kim (dad, @gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: my dad is Greta Kim

Upmore: Save "dad" as your name for Greta Kim (@gretak)? Then "send dad 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Greta Kim (dad, @gretak).

User: send dad 90

Upmore: Set up $90.00 to Greta Kim (dad, @gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01604 · M04 · An alias is moved only to the newly confirmed person · PASS

Expected: [{"say":"save greta as brother"},{"say":"yes"},{"say":"brother is Bill Rao"},{"say":"yes"},{"say":"send brother 60","match":"Bill Rao","outcome":"confirm"}]

### Trial 1

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Greta Kim (brother, @gretak).

User: brother is Bill Rao

Upmore: Save "brother" as your name for Bill Rao (@billr)? Then "send brother 20" goes to Bill Rao. "brother" means Greta Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bill Rao (brother, @billr).

User: send brother 60

Upmore: Set up $60.00 to Bill Rao (brother, @billr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Greta Kim (brother, @gretak).

User: brother is Bill Rao

Upmore: Save "brother" as your name for Bill Rao (@billr)? Then "send brother 20" goes to Bill Rao. "brother" means Greta Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bill Rao (brother, @billr).

User: send brother 60

Upmore: Set up $60.00 to Bill Rao (brother, @billr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Greta Kim (brother, @gretak).

User: brother is Bill Rao

Upmore: Save "brother" as your name for Bill Rao (@billr)? Then "send brother 20" goes to Bill Rao. "brother" means Greta Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bill Rao (brother, @billr).

User: send brother 60

Upmore: Set up $60.00 to Bill Rao (brother, @billr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01605 · M05 · Rejected alias preserves the previous confirmed fact · PASS

Expected: [{"say":"save greta as brother"},{"say":"yes"},{"say":"brother is Bill Rao"},{"say":"no"},{"say":"send brother 60","match":"Greta Kim","outcome":"confirm"}]

### Trial 1

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Greta Kim (brother, @gretak).

User: brother is Bill Rao

Upmore: Save "brother" as your name for Bill Rao (@billr)? Then "send brother 20" goes to Bill Rao. "brother" means Greta Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 60

Upmore: Set up $60.00 to Greta Kim (brother, @gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Greta Kim (brother, @gretak).

User: brother is Bill Rao

Upmore: Save "brother" as your name for Bill Rao (@billr)? Then "send brother 20" goes to Bill Rao. "brother" means Greta Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 60

Upmore: Set up $60.00 to Greta Kim (brother, @gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Greta Kim (brother, @gretak).

User: brother is Bill Rao

Upmore: Save "brother" as your name for Bill Rao (@billr)? Then "send brother 20" goes to Bill Rao. "brother" means Greta Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 60

Upmore: Set up $60.00 to Greta Kim (brother, @gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01606 · M06 · Amount correction preserves payee and replaces the old card · PASS

Expected: [{"say":"send greta 60"},{"say":"make it 105","match":"105.00.*Greta Kim","outcome":"confirm"},{"say":"yes","match":"105.00","outcome":"staged"},{"state":"state.send.sends.0.amount_cents","equals":10500}]

### Trial 1

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 105

Upmore: Got it. Set up $105.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $105.00; 4. Keep it private, then Pay. I'll confirm when $105.00 to Greta Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 105

Upmore: Got it. Set up $105.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $105.00; 4. Keep it private, then Pay. I'll confirm when $105.00 to Greta Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 105

Upmore: Got it. Set up $105.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $105.00; 4. Keep it private, then Pay. I'll confirm when $105.00 to Greta Kim posts; if it hasn't by tonight, I'll ask.

## C01607 · M07 · Actually correction handles a different amount · PASS

Expected: [{"say":"send greta 60"},{"say":"actually make it 150","match":"150.00.*Greta Kim","outcome":"confirm"},{"say":"yes","match":"150.00","outcome":"staged"}]

### Trial 1

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 150

Upmore: Got it. Set up $150.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $150.00; 4. Keep it private, then Pay. I'll confirm when $150.00 to Greta Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 150

Upmore: Got it. Set up $150.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $150.00; 4. Keep it private, then Pay. I'll confirm when $150.00 to Greta Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 150

Upmore: Got it. Set up $150.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $150.00; 4. Keep it private, then Pay. I'll confirm when $150.00 to Greta Kim posts; if it hasn't by tonight, I'll ask.

## C01608 · M08 · Bare currency correction retains payment context · PASS

Expected: [{"say":"send greta 60"},{"say":"$37.50 instead","match":"37.50.*Greta Kim","outcome":"confirm"},{"say":"yes","match":"37.50","outcome":"staged"}]

### Trial 1

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $37.50 instead

Upmore: Got it. Set up $37.50 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $37.50; 4. Keep it private, then Pay. I'll confirm when $37.50 to Greta Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $37.50 instead

Upmore: Got it. Set up $37.50 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $37.50; 4. Keep it private, then Pay. I'll confirm when $37.50 to Greta Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $37.50 instead

Upmore: Got it. Set up $37.50 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $37.50; 4. Keep it private, then Pay. I'll confirm when $37.50 to Greta Kim posts; if it hasn't by tonight, I'll ask.

## C01609 · M09 · Split total correction recomputes every share before approval · PASS

Expected: [{"say":"split 180 with greta and bill"},{"say":"make it 270","match":"90.00 each.*270.00","outcome":"confirm"},{"say":"yes","match":"90.00","outcome":"staged"}]

### Trial 1

User: split 180 with greta and bill

Upmore: Request $60.00 each from Greta Kim (@gretak) and Bill Rao (@billr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 270

Upmore: Got it. Request $90.00 each from Greta Kim (@gretak) and Bill Rao (@billr) in Venmo: $270.00 split 3 ways, yours $90.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Greta Kim (@gretak) $90.00 in Venmo, Bill Rao (@billr) $90.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 180 with greta and bill

Upmore: Request $60.00 each from Greta Kim (@gretak) and Bill Rao (@billr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 270

Upmore: Got it. Request $90.00 each from Greta Kim (@gretak) and Bill Rao (@billr) in Venmo: $270.00 split 3 ways, yours $90.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Greta Kim (@gretak) $90.00 in Venmo, Bill Rao (@billr) $90.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 180 with greta and bill

Upmore: Request $60.00 each from Greta Kim (@gretak) and Bill Rao (@billr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 270

Upmore: Got it. Request $90.00 each from Greta Kim (@gretak) and Bill Rao (@billr) in Venmo: $270.00 split 3 ways, yours $90.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Greta Kim (@gretak) $90.00 in Venmo, Bill Rao (@billr) $90.00 in Venmo. I'll mark each one paid when the money lands.

## C01610 · M10 · Rent setup correction retains recipient and due day · FAIL

Expected: [{"say":"pay my rent"},{"say":"greta $2700 on the 1st via Venmo"},{"say":"make it 2850","match":"2850.00.*Greta Kim.*1st","outcome":"confirm"},{"say":"yes"},{"state":"standing.0.amount_cents","equals":285000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 2850

Upmore: Got it. Set up rent: $2,850.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,850.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"2850.00.*Greta Kim.*1st","actual":{"thread_id":"0a9dfc7d-f8b0-4941-a8fd-6fab4aafb1f0","reply":"Got it. Set up rent: $2,850.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 2850

Upmore: Got it. Set up rent: $2,850.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,850.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"2850.00.*Greta Kim.*1st","actual":{"thread_id":"b0e98fcc-6188-4d42-8f72-202dcfab0c69","reply":"Got it. Set up rent: $2,850.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 2850

Upmore: Got it. Set up rent: $2,850.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,850.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"2850.00.*Greta Kim.*1st","actual":{"thread_id":"1d21b236-6149-42ca-a934-1b055b3e0b4d","reply":"Got it. Set up rent: $2,850.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

## C01611 · M11 · Details refers to the pending payment · PASS

Expected: [{"say":"send greta 60"},{"say":"details","match":"60.00.*Greta Kim","outcome":"details"}]

### Trial 1

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $60.00 to Greta Kim on Venmo $60.00 to Greta Kim (@gretak) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

### Trial 2

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $60.00 to Greta Kim on Venmo $60.00 to Greta Kim (@gretak) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

### Trial 3

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $60.00 to Greta Kim on Venmo $60.00 to Greta Kim (@gretak) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

## C01612 · M12 · A short yes resumes a serialized split · PASS

Expected: [{"say":"split 180 with greta and bill"},{"say":"yes","match":"Greta Kim.*60.00.*Bill Rao.*60.00","outcome":"staged"}]

### Trial 1

User: split 180 with greta and bill

Upmore: Request $60.00 each from Greta Kim (@gretak) and Bill Rao (@billr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Greta Kim (@gretak) $60.00 in Venmo, Bill Rao (@billr) $60.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 180 with greta and bill

Upmore: Request $60.00 each from Greta Kim (@gretak) and Bill Rao (@billr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Greta Kim (@gretak) $60.00 in Venmo, Bill Rao (@billr) $60.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 180 with greta and bill

Upmore: Request $60.00 each from Greta Kim (@gretak) and Bill Rao (@billr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Greta Kim (@gretak) $60.00 in Venmo, Bill Rao (@billr) $60.00 in Venmo. I'll mark each one paid when the money lands.

## C01613 · M13 · Cancellation that resolves the last discussed subscription · PASS

Expected: [{"say":"cancel netflix","match":"Netflix"},{"say":"cancel that","match":"Netflix"}]

### Trial 1

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 2

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 3

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

## C01614 · M14 · Stop rent refers to the confirmed standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"greta $2700 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent","match":"Rent is off","outcome":"rent_stopped"},{"state":"standing.0.status","equals":"stopped"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Greta Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Greta Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Greta Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

## C01615 · M15 · A contextual fee question retains payment identity and asks before acting · PASS

Expected: [{"say":"send greta 60"},{"say":"what's the fee on that","match":"60.00.*Greta Kim"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $60.00 to Greta Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $60.00 to Greta Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $60.00 to Greta Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C01616 · M16 · Rent setup answers retain the original goal · FAIL

Expected: [{"say":"pay my rent","match":"Who"},{"say":"greta $2700 on the 1st via Venmo","match":"2700.00.*Greta Kim","outcome":"confirm"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"standing.0.payee_handle","equals":"@gretak"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"2700.00.*Greta Kim","actual":{"thread_id":"415df980-0083-4ba5-bc33-43365e9c5b7f","reply":"Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"2700.00.*Greta Kim","actual":{"thread_id":"f5e84dff-89db-4150-bac3-fcd7801047bf","reply":"Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"2700.00.*Greta Kim","actual":{"thread_id":"9df44c76-0420-4905-837e-77e122de9baa","reply":"Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

## C01617 · M17 · New recipient handle and rail answers retain amount · PASS

Expected: [{"say":"send Dana 75"},{"say":"@danak"},{"say":"@danak"},{"say":"Venmo"},{"say":"@danak","match":"75.00.*Dana","outcome":"confirm"}]

### Trial 1

User: send Dana 75

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $75.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: send Dana 75

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $75.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: send Dana 75

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $75.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01618 · M18 · Split remembers total while asking who participated · PASS

Expected: [{"say":"split 180 with 2 friends"},{"say":"greta and bill","match":"60.00 each.*180.00","outcome":"confirm"}]

### Trial 1

User: split 180 with 2 friends

Upmore: That's $60.00 each across 3 people. Who are the 2? I'll request $60.00 from each.

User: greta and bill

Upmore: Request $60.00 each from Greta Kim (@gretak) and Bill Rao (@billr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: split 180 with 2 friends

Upmore: That's $60.00 each across 3 people. Who are the 2? I'll request $60.00 from each.

User: greta and bill

Upmore: Request $60.00 each from Greta Kim (@gretak) and Bill Rao (@billr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: split 180 with 2 friends

Upmore: That's $60.00 each across 3 people. Who are the 2? I'll request $60.00 from each.

User: greta and bill

Upmore: Request $60.00 each from Greta Kim (@gretak) and Bill Rao (@billr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

## C01619 · M19 · Rent is remembered on the next independent invocation · FAIL

Expected: [{"say":"pay my rent"},{"say":"greta $2700 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent","match":"2700.00.*Greta Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Greta Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"2700.00.*Greta Kim","actual":{"thread_id":"4b250b5e-a92c-4d53-a568-d1f186bd8f36","reply":"Rent for November: $2,700.00 to Greta Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Greta Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"2700.00.*Greta Kim","actual":{"thread_id":"4563c4ad-08c5-413f-82af-6c22592ba44f","reply":"Rent for November: $2,700.00 to Greta Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Greta Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"2700.00.*Greta Kim","actual":{"thread_id":"dd71dbc3-b579-4ef2-8d3c-f41503cf52d3","reply":"Rent for November: $2,700.00 to Greta Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

## C01620 · M20 · An interrupted alias goal remains unconfirmed · PASS

Expected: [{"say":"save greta as brother"},{"say":"no"},{"state":"recipients.0.nickname","equals":null},{"say":"send brother 60","match":"handle","outcome":"ask"}]

### Trial 1

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 60

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 2

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 60

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 3

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 60

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

## C01621 · M21 · A staged payment is remembered without claiming completion · PASS

Expected: [{"say":"send greta 60"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Greta Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $60.00 to Greta Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 2

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Greta Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $60.00 to Greta Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 3

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Greta Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $60.00 to Greta Kim for you to send in Venmo. A second yes doesn't stage it again.

## C01622 · M22 · A staged split is remembered without duplicating it · PASS

Expected: [{"say":"split 180 with greta and bill"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 180 with greta and bill

Upmore: Request $60.00 each from Greta Kim (@gretak) and Bill Rao (@billr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Greta Kim (@gretak) $60.00 in Venmo, Bill Rao (@billr) $60.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 180 with greta and bill

Upmore: Request $60.00 each from Greta Kim (@gretak) and Bill Rao (@billr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Greta Kim (@gretak) $60.00 in Venmo, Bill Rao (@billr) $60.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 180 with greta and bill

Upmore: Request $60.00 each from Greta Kim (@gretak) and Bill Rao (@billr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Greta Kim (@gretak) $60.00 in Venmo, Bill Rao (@billr) $60.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C01623 · M23 · A declined payment cannot be resurrected by yes · PASS

Expected: [{"say":"send greta 60"},{"say":"no","match":"Nothing","outcome":"declined"},{"say":"yes","not":"^Staged, not sent"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 2

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 3

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

## C01624 · M24 · Stopping rent prevents the next turn from claiming an active rule · PASS

Expected: [{"say":"pay my rent"},{"say":"greta $2700 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Greta Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Greta Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Greta Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C01625 · M25 · Status follow-up recalls staged versus sent · PASS

Expected: [{"say":"send greta 60"},{"say":"yes"},{"say":"did it go through","match":"(?:not (?:yet )?(?:sent|posted)|staged|have not seen|waiting for.*post)"}]

### Trial 1

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Greta Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $60.00 to Greta Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

### Trial 2

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Greta Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $60.00 to Greta Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

### Trial 3

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Greta Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $60.00 to Greta Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

## C01626 · M26 · Unapproved nickname does not become a known fact · PASS

Expected: [{"say":"save greta as brother"},{"state":"recipients.0.nickname","equals":null},{"say":"no"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 2

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 3

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

## C01627 · M27 · Unapproved rent terms are not durable instructions · PASS

Expected: [{"say":"pay my rent"},{"say":"greta $2700 on the 1st via Venmo"},{"state":"standing.length","equals":0},{"say":"no"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

## C01628 · M28 · An expired payment card is restated and requires a fresh yes · PASS

Expected: [{"say":"send greta 60"},{"minutes":11},{"say":"yes","match":"expired.*fresh","outcome":"confirm"},{"state":"state.send.sends.length","equals":0},{"say":"yes","match":"Staged","outcome":"staged"}]

### Trial 1

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Greta Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Greta Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Greta Kim posts; if it hasn't by tonight, I'll ask.

## C01629 · M29 · An expired nickname card never writes a fact · PASS

Expected: [{"say":"save greta as brother"},{"minutes":11},{"say":"yes","match":"expired"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 2

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 3

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

## C01630 · M30 · A question containing yes does not approve a payment · PASS

Expected: [{"say":"send greta 60"},{"say":"yes but is there a fee"},{"state":"state.send.sends.length","equals":0},{"say":"no"}]

### Trial 1

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

### Trial 2

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

### Trial 3

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

## C01631 · M31 · Moving to small talk explicitly drops the old payment · PASS

Expected: [{"say":"send greta 60"},{"say":"what's a good movie","match":"dropped.*60.00"},{"say":"yes","not":"^Staged"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $60.00 to Greta Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $60.00 to Greta Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $60.00 to Greta Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C01632 · M32 · Switching recipients makes the latest request authoritative · FAIL

Expected: [{"say":"send greta 60"},{"say":"send bill 90","match":"90.00.*Bill Rao","outcome":"confirm"},{"say":"yes","match":"90.00.*Bill Rao","outcome":"staged"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send bill 90

Upmore: (I dropped the $60.00 to Greta Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"90.00.*Bill Rao","actual":{"thread_id":"9de58d62-924a-43ab-8408-92d267249870","reply":"(I dropped the $60.00 to Greta Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":2,"kind":"outcome","expected":"confirm","actual":{"thread_id":"9de58d62-924a-43ab-8408-92d267249870","reply":"(I dropped the $60.00 to Greta Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"reply","expected":"90.00.*Bill Rao","actual":{"thread_id":"9de58d62-924a-43ab-8408-92d267249870","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"staged","actual":{"thread_id":"9de58d62-924a-43ab-8408-92d267249870","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"state","expected":{"path":"state.send.sends.length","value":1},"actual":0}]

### Trial 2

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send bill 90

Upmore: (I dropped the $60.00 to Greta Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"90.00.*Bill Rao","actual":{"thread_id":"2762b6f0-ff0d-4ee7-beb5-13d96c021da6","reply":"(I dropped the $60.00 to Greta Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":2,"kind":"outcome","expected":"confirm","actual":{"thread_id":"2762b6f0-ff0d-4ee7-beb5-13d96c021da6","reply":"(I dropped the $60.00 to Greta Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"reply","expected":"90.00.*Bill Rao","actual":{"thread_id":"2762b6f0-ff0d-4ee7-beb5-13d96c021da6","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"staged","actual":{"thread_id":"2762b6f0-ff0d-4ee7-beb5-13d96c021da6","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"state","expected":{"path":"state.send.sends.length","value":1},"actual":0}]

### Trial 3

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send bill 90

Upmore: (I dropped the $60.00 to Greta Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

Failures: [{"step":2,"kind":"reply","expected":"90.00.*Bill Rao","actual":{"thread_id":"1229544b-ca48-433c-9c54-ee7e35d574e2","reply":"(I dropped the $60.00 to Greta Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":2,"kind":"outcome","expected":"confirm","actual":{"thread_id":"1229544b-ca48-433c-9c54-ee7e35d574e2","reply":"(I dropped the $60.00 to Greta Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"reply","expected":"90.00.*Bill Rao","actual":{"thread_id":"1229544b-ca48-433c-9c54-ee7e35d574e2","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":3,"kind":"outcome","expected":"staged","actual":{"thread_id":"1229544b-ca48-433c-9c54-ee7e35d574e2","reply":"I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.","action":null,"failure_code":"model_unavailable","http_status":200}},{"step":4,"kind":"state","expected":{"path":"state.send.sends.length","value":1},"actual":0}]

## C01633 · M33 · A payment supersedes a pending split rather than approving both · PASS

Expected: [{"say":"split 180 with greta and bill"},{"say":"send greta 60","match":"60.00.*Greta Kim","outcome":"confirm"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"state":"state.split.staged.length","equals":0}]

### Trial 1

User: split 180 with greta and bill

Upmore: Request $60.00 each from Greta Kim (@gretak) and Bill Rao (@billr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send greta 60

Upmore: I dropped the earlier card. Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Greta Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: split 180 with greta and bill

Upmore: Request $60.00 each from Greta Kim (@gretak) and Bill Rao (@billr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send greta 60

Upmore: I dropped the earlier card. Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Greta Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: split 180 with greta and bill

Upmore: Request $60.00 each from Greta Kim (@gretak) and Bill Rao (@billr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send greta 60

Upmore: I dropped the earlier card. Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Greta Kim posts; if it hasn't by tonight, I'll ask.

## C01634 · M34 · Switching from payment to rent keeps the new goal · PASS

Expected: [{"say":"send greta 60"},{"say":"pay my rent","match":"Who","outcome":"ask"},{"say":"greta $2700 on the 1st via Venmo"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 2

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 3

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

## C01635 · M35 · Never mind cancels an alias confirmation without saving · PASS

Expected: [{"say":"save greta as brother"},{"say":"never mind"},{"state":"recipients.0.nickname","equals":null},{"say":"yes","not":"^Saved:"}]

### Trial 1

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 2

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 3

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

## C01636 · M36 · Confirmed aliases survive a new conversation · PASS

Expected: [{"say":"save greta as brother"},{"say":"yes"},{"thread":"B"},{"say":"send brother 60","match":"Greta Kim","outcome":"confirm"}]

### Trial 1

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Greta Kim (brother, @gretak).

User: send brother 60

Upmore: Set up $60.00 to Greta Kim (brother, @gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Greta Kim (brother, @gretak).

User: send brother 60

Upmore: Set up $60.00 to Greta Kim (brother, @gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Greta Kim (brother, @gretak).

User: send brother 60

Upmore: Set up $60.00 to Greta Kim (brother, @gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01637 · M37 · Standing rent survives a new conversation · FAIL

Expected: [{"say":"pay my rent"},{"say":"greta $2700 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"pay my rent","match":"2700.00.*Greta Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Greta Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"2700.00.*Greta Kim","actual":{"thread_id":"14003f80-3f18-4614-aa28-5c6fdaaa14e0","reply":"Rent for November: $2,700.00 to Greta Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Greta Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"2700.00.*Greta Kim","actual":{"thread_id":"07b5cf33-8499-4a27-9ed7-bbd039630ee7","reply":"Rent for November: $2,700.00 to Greta Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Greta Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"2700.00.*Greta Kim","actual":{"thread_id":"8101dece-4f0f-4ad9-a990-0580b8634eec","reply":"Rent for November: $2,700.00 to Greta Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

## C01638 · M38 · Unapproved thread A card cannot be approved in thread B · PASS

Expected: [{"say":"send greta 60"},{"thread":"B"},{"say":"yes","not":"^Staged"},{"thread":"A"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C01639 · M39 · A nickname correction in another session supersedes the old meaning · PASS

Expected: [{"say":"save greta as brother"},{"say":"yes"},{"thread":"B"},{"say":"brother is Bill Rao"},{"say":"yes"},{"thread":"C"},{"say":"send brother 60","match":"Bill Rao","outcome":"confirm"}]

### Trial 1

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Greta Kim (brother, @gretak).

User: brother is Bill Rao

Upmore: Save "brother" as your name for Bill Rao (@billr)? Then "send brother 20" goes to Bill Rao. "brother" means Greta Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bill Rao (brother, @billr).

User: send brother 60

Upmore: Set up $60.00 to Bill Rao (brother, @billr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Greta Kim (brother, @gretak).

User: brother is Bill Rao

Upmore: Save "brother" as your name for Bill Rao (@billr)? Then "send brother 20" goes to Bill Rao. "brother" means Greta Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bill Rao (brother, @billr).

User: send brother 60

Upmore: Set up $60.00 to Bill Rao (brother, @billr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Greta Kim (brother, @gretak).

User: brother is Bill Rao

Upmore: Save "brother" as your name for Bill Rao (@billr)? Then "send brother 20" goes to Bill Rao. "brother" means Greta Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Bill Rao (brother, @billr).

User: send brother 60

Upmore: Set up $60.00 to Bill Rao (brother, @billr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01640 · M40 · Stopping rent in another session prevents future offers · PASS

Expected: [{"say":"pay my rent"},{"say":"greta $2700 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"stop rent"},{"thread":"C"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Greta Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Greta Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Greta Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C01641 · M41 · Repeating a staged approval does not stage twice after restore · PASS

Expected: [{"say":"send greta 60"},{"say":"yes"},{"say":"yes","match":"already staged","outcome":"already_done"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Greta Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $60.00 to Greta Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $60.00 to Greta Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 2

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Greta Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $60.00 to Greta Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $60.00 to Greta Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 3

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Greta Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $60.00 to Greta Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $60.00 to Greta Kim for you to send in Venmo. A second yes doesn't stage it again.

## C01642 · M42 · Rent setup retry leaves exactly one standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"greta $2700 on the 1st via Venmo"},{"say":"yes"},{"say":"yes","not":"^Rent is set up"},{"state":"standing.length","equals":1}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C01643 · M43 · Confirmed alias repeated is recognized as already known · PASS

Expected: [{"say":"save greta as brother"},{"say":"yes"},{"say":"save greta as brother","match":"already|Already|already means","outcome":"already_done"},{"state":"ops.length","equals":1}]

### Trial 1

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Greta Kim (brother, @gretak).

User: save greta as brother

Upmore: "brother" already means Greta Kim (brother, @gretak). Nothing changed.

### Trial 2

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Greta Kim (brother, @gretak).

User: save greta as brother

Upmore: "brother" already means Greta Kim (brother, @gretak). Nothing changed.

### Trial 3

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Greta Kim (brother, @gretak).

User: save greta as brother

Upmore: "brother" already means Greta Kim (brother, @gretak). Nothing changed.

## C01644 · M44 · The same month rent is staged once across restored sessions · PASS

Expected: [{"say":"pay my rent"},{"say":"greta $2700 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"pay my rent","match":"already staged","outcome":"already_done"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Greta Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $2,700.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $2,700.00 to Greta Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $2,700.00 to Greta Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Greta Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $2,700.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $2,700.00 to Greta Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $2,700.00 to Greta Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Greta Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @gretak; 3. Enter $2,700.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $2,700.00 to Greta Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $2,700.00 to Greta Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

## C01645 · M45 · Retried split approval preserves one set of requests · PASS

Expected: [{"say":"split 180 with greta and bill"},{"say":"yes"},{"say":"yes"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 180 with greta and bill

Upmore: Request $60.00 each from Greta Kim (@gretak) and Bill Rao (@billr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Greta Kim (@gretak) $60.00 in Venmo, Bill Rao (@billr) $60.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 180 with greta and bill

Upmore: Request $60.00 each from Greta Kim (@gretak) and Bill Rao (@billr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Greta Kim (@gretak) $60.00 in Venmo, Bill Rao (@billr) $60.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 180 with greta and bill

Upmore: Request $60.00 each from Greta Kim (@gretak) and Bill Rao (@billr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Greta Kim (@gretak) $60.00 in Venmo, Bill Rao (@billr) $60.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C01646 · M46 · Nickname save failure is never reported as remembered · PASS

Expected: [{"say":"save greta as brother"},{"set":{"failRecipients":true}},{"say":"yes","match":"couldn't save"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 2

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 3

User: save greta as brother

Upmore: Save "brother" as your name for Greta Kim (@gretak)? Then "send brother 20" goes to Greta Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

## C01647 · M47 · Rent save failure is never reported as a stored rule · PASS

Expected: [{"say":"pay my rent"},{"say":"greta $2700 on the 1st via Venmo"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*set|nothing was set up"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

## C01648 · M48 · A failed state write yields no approval card and retry is recoverable · PASS

Expected: [{"set":{"failState":true}},{"say":"send greta 60","error":"state storage unavailable"},{"set":{"failState":false}},{"say":"send greta 60","match":"60.00.*Greta Kim","outcome":"confirm"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send greta 60

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: send greta 60

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: send greta 60

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01649 · M49 · Unavailable facts cause an honest blocker and preserve the old card · PASS

Expected: [{"say":"send greta 60"},{"set":{"unreadable":true}},{"say":"yes","match":"can't read.*Nothing was changed","outcome":"unavailable"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

### Trial 2

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

### Trial 3

User: send greta 60

Upmore: Set up $60.00 to Greta Kim (@gretak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

## C01650 · M50 · A failed rent correction retains the prior confirmed terms · PASS

Expected: [{"say":"pay my rent"},{"say":"greta $2700 on the 1st via Venmo"},{"say":"yes"},{"say":"rent is 2850 now"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*change|rent stays as it was"},{"state":"standing.0.amount_cents","equals":270000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 2850 now

Upmore: Change rent (amount $2,700.00 to $2,850.00): $2,850.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 2850 now

Upmore: Change rent (amount $2,700.00 to $2,850.00): $2,850.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: greta $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Greta Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 2850 now

Upmore: Change rent (amount $2,700.00 to $2,850.00): $2,850.00 to Greta Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

