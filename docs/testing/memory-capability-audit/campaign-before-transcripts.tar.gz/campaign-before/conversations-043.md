# conversations-043

All conversations are synthetic. Full production handler, mock authentication/PostgREST and disabled model; no real outbound messages or provider actions.

## C02101 · M01 · Confirmed nickname recalls the right person · PASS

Expected: [{"say":"save ravi as brother"},{"say":"yes"},{"say":"send brother 60","match":"Ravi Kim.*@ravik","outcome":"confirm"}]

### Trial 1

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Ravi Kim (brother, @ravik).

User: send brother 60

Upmore: Set up $60.00 to Ravi Kim (brother, @ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Ravi Kim (brother, @ravik).

User: send brother 60

Upmore: Set up $60.00 to Ravi Kim (brother, @ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Ravi Kim (brother, @ravik).

User: send brother 60

Upmore: Set up $60.00 to Ravi Kim (brother, @ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02102 · M02 · Explicit remember phrasing persists an alias · PASS

Expected: [{"say":"remember Jules Rao as my sister"},{"say":"yes"},{"say":"send sister 75","match":"Jules Rao.*@julesr","outcome":"confirm"}]

### Trial 1

User: remember Jules Rao as my sister

Upmore: Save "sister" as your name for Jules Rao (@julesr)? Then "send sister 20" goes to Jules Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Jules Rao (sister, @julesr).

User: send sister 75

Upmore: Set up $75.00 to Jules Rao (sister, @julesr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: remember Jules Rao as my sister

Upmore: Save "sister" as your name for Jules Rao (@julesr)? Then "send sister 20" goes to Jules Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Jules Rao (sister, @julesr).

User: send sister 75

Upmore: Set up $75.00 to Jules Rao (sister, @julesr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: remember Jules Rao as my sister

Upmore: Save "sister" as your name for Jules Rao (@julesr)? Then "send sister 20" goes to Jules Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Jules Rao (sister, @julesr).

User: send sister 75

Upmore: Set up $75.00 to Jules Rao (sister, @julesr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02103 · M03 · Natural relationship statement needs confirmation and persists · PASS

Expected: [{"say":"my dad is Ravi Kim","match":"Save"},{"say":"yes"},{"say":"send dad 90","match":"Ravi Kim","outcome":"confirm"}]

### Trial 1

User: my dad is Ravi Kim

Upmore: Save "dad" as your name for Ravi Kim (@ravik)? Then "send dad 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Ravi Kim (dad, @ravik).

User: send dad 90

Upmore: Set up $90.00 to Ravi Kim (dad, @ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: my dad is Ravi Kim

Upmore: Save "dad" as your name for Ravi Kim (@ravik)? Then "send dad 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Ravi Kim (dad, @ravik).

User: send dad 90

Upmore: Set up $90.00 to Ravi Kim (dad, @ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: my dad is Ravi Kim

Upmore: Save "dad" as your name for Ravi Kim (@ravik)? Then "send dad 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Ravi Kim (dad, @ravik).

User: send dad 90

Upmore: Set up $90.00 to Ravi Kim (dad, @ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02104 · M04 · An alias is moved only to the newly confirmed person · PASS

Expected: [{"say":"save ravi as brother"},{"say":"yes"},{"say":"brother is Jules Rao"},{"say":"yes"},{"say":"send brother 60","match":"Jules Rao","outcome":"confirm"}]

### Trial 1

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Ravi Kim (brother, @ravik).

User: brother is Jules Rao

Upmore: Save "brother" as your name for Jules Rao (@julesr)? Then "send brother 20" goes to Jules Rao. "brother" means Ravi Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Jules Rao (brother, @julesr).

User: send brother 60

Upmore: Set up $60.00 to Jules Rao (brother, @julesr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Ravi Kim (brother, @ravik).

User: brother is Jules Rao

Upmore: Save "brother" as your name for Jules Rao (@julesr)? Then "send brother 20" goes to Jules Rao. "brother" means Ravi Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Jules Rao (brother, @julesr).

User: send brother 60

Upmore: Set up $60.00 to Jules Rao (brother, @julesr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Ravi Kim (brother, @ravik).

User: brother is Jules Rao

Upmore: Save "brother" as your name for Jules Rao (@julesr)? Then "send brother 20" goes to Jules Rao. "brother" means Ravi Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Jules Rao (brother, @julesr).

User: send brother 60

Upmore: Set up $60.00 to Jules Rao (brother, @julesr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02105 · M05 · Rejected alias preserves the previous confirmed fact · PASS

Expected: [{"say":"save ravi as brother"},{"say":"yes"},{"say":"brother is Jules Rao"},{"say":"no"},{"say":"send brother 60","match":"Ravi Kim","outcome":"confirm"}]

### Trial 1

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Ravi Kim (brother, @ravik).

User: brother is Jules Rao

Upmore: Save "brother" as your name for Jules Rao (@julesr)? Then "send brother 20" goes to Jules Rao. "brother" means Ravi Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 60

Upmore: Set up $60.00 to Ravi Kim (brother, @ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Ravi Kim (brother, @ravik).

User: brother is Jules Rao

Upmore: Save "brother" as your name for Jules Rao (@julesr)? Then "send brother 20" goes to Jules Rao. "brother" means Ravi Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 60

Upmore: Set up $60.00 to Ravi Kim (brother, @ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Ravi Kim (brother, @ravik).

User: brother is Jules Rao

Upmore: Save "brother" as your name for Jules Rao (@julesr)? Then "send brother 20" goes to Jules Rao. "brother" means Ravi Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 60

Upmore: Set up $60.00 to Ravi Kim (brother, @ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02106 · M06 · Amount correction preserves payee and replaces the old card · PASS

Expected: [{"say":"send ravi 60"},{"say":"make it 105","match":"105.00.*Ravi Kim","outcome":"confirm"},{"say":"yes","match":"105.00","outcome":"staged"},{"state":"state.send.sends.0.amount_cents","equals":10500}]

### Trial 1

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 105

Upmore: Got it. Set up $105.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $105.00; 4. Keep it private, then Pay. I'll confirm when $105.00 to Ravi Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 105

Upmore: Got it. Set up $105.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $105.00; 4. Keep it private, then Pay. I'll confirm when $105.00 to Ravi Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 105

Upmore: Got it. Set up $105.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $105.00; 4. Keep it private, then Pay. I'll confirm when $105.00 to Ravi Kim posts; if it hasn't by tonight, I'll ask.

## C02107 · M07 · Actually correction handles a different amount · PASS

Expected: [{"say":"send ravi 60"},{"say":"actually make it 150","match":"150.00.*Ravi Kim","outcome":"confirm"},{"say":"yes","match":"150.00","outcome":"staged"}]

### Trial 1

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 150

Upmore: Got it. Set up $150.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $150.00; 4. Keep it private, then Pay. I'll confirm when $150.00 to Ravi Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 150

Upmore: Got it. Set up $150.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $150.00; 4. Keep it private, then Pay. I'll confirm when $150.00 to Ravi Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 150

Upmore: Got it. Set up $150.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $150.00; 4. Keep it private, then Pay. I'll confirm when $150.00 to Ravi Kim posts; if it hasn't by tonight, I'll ask.

## C02108 · M08 · Bare currency correction retains payment context · PASS

Expected: [{"say":"send ravi 60"},{"say":"$37.50 instead","match":"37.50.*Ravi Kim","outcome":"confirm"},{"say":"yes","match":"37.50","outcome":"staged"}]

### Trial 1

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $37.50 instead

Upmore: Got it. Set up $37.50 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $37.50; 4. Keep it private, then Pay. I'll confirm when $37.50 to Ravi Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $37.50 instead

Upmore: Got it. Set up $37.50 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $37.50; 4. Keep it private, then Pay. I'll confirm when $37.50 to Ravi Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $37.50 instead

Upmore: Got it. Set up $37.50 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $37.50; 4. Keep it private, then Pay. I'll confirm when $37.50 to Ravi Kim posts; if it hasn't by tonight, I'll ask.

## C02109 · M09 · Split total correction recomputes every share before approval · PASS

Expected: [{"say":"split 180 with ravi and jules"},{"say":"make it 270","match":"90.00 each.*270.00","outcome":"confirm"},{"say":"yes","match":"90.00","outcome":"staged"}]

### Trial 1

User: split 180 with ravi and jules

Upmore: Request $60.00 each from Ravi Kim (@ravik) and Jules Rao (@julesr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 270

Upmore: Got it. Request $90.00 each from Ravi Kim (@ravik) and Jules Rao (@julesr) in Venmo: $270.00 split 3 ways, yours $90.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Ravi Kim (@ravik) $90.00 in Venmo, Jules Rao (@julesr) $90.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 180 with ravi and jules

Upmore: Request $60.00 each from Ravi Kim (@ravik) and Jules Rao (@julesr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 270

Upmore: Got it. Request $90.00 each from Ravi Kim (@ravik) and Jules Rao (@julesr) in Venmo: $270.00 split 3 ways, yours $90.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Ravi Kim (@ravik) $90.00 in Venmo, Jules Rao (@julesr) $90.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 180 with ravi and jules

Upmore: Request $60.00 each from Ravi Kim (@ravik) and Jules Rao (@julesr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 270

Upmore: Got it. Request $90.00 each from Ravi Kim (@ravik) and Jules Rao (@julesr) in Venmo: $270.00 split 3 ways, yours $90.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Ravi Kim (@ravik) $90.00 in Venmo, Jules Rao (@julesr) $90.00 in Venmo. I'll mark each one paid when the money lands.

## C02110 · M10 · Rent setup correction retains recipient and due day · FAIL

Expected: [{"say":"pay my rent"},{"say":"ravi $2700 on the 1st via Venmo"},{"say":"make it 2850","match":"2850.00.*Ravi Kim.*1st","outcome":"confirm"},{"say":"yes"},{"state":"standing.0.amount_cents","equals":285000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 2850

Upmore: Got it. Set up rent: $2,850.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,850.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"2850.00.*Ravi Kim.*1st","actual":{"thread_id":"28ce07c1-6aaf-4e25-aa2e-88d790a7e84b","reply":"Got it. Set up rent: $2,850.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 2850

Upmore: Got it. Set up rent: $2,850.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,850.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"2850.00.*Ravi Kim.*1st","actual":{"thread_id":"f6b34a8c-4651-4a7a-b5ae-9e44aed6392d","reply":"Got it. Set up rent: $2,850.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 2850

Upmore: Got it. Set up rent: $2,850.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,850.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"2850.00.*Ravi Kim.*1st","actual":{"thread_id":"0451837c-85fd-414f-942e-65306c50ae81","reply":"Got it. Set up rent: $2,850.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

## C02111 · M11 · Details refers to the pending payment · PASS

Expected: [{"say":"send ravi 60"},{"say":"details","match":"60.00.*Ravi Kim","outcome":"details"}]

### Trial 1

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $60.00 to Ravi Kim on Venmo $60.00 to Ravi Kim (@ravik) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

### Trial 2

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $60.00 to Ravi Kim on Venmo $60.00 to Ravi Kim (@ravik) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

### Trial 3

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $60.00 to Ravi Kim on Venmo $60.00 to Ravi Kim (@ravik) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

## C02112 · M12 · A short yes resumes a serialized split · PASS

Expected: [{"say":"split 180 with ravi and jules"},{"say":"yes","match":"Ravi Kim.*60.00.*Jules Rao.*60.00","outcome":"staged"}]

### Trial 1

User: split 180 with ravi and jules

Upmore: Request $60.00 each from Ravi Kim (@ravik) and Jules Rao (@julesr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Ravi Kim (@ravik) $60.00 in Venmo, Jules Rao (@julesr) $60.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 180 with ravi and jules

Upmore: Request $60.00 each from Ravi Kim (@ravik) and Jules Rao (@julesr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Ravi Kim (@ravik) $60.00 in Venmo, Jules Rao (@julesr) $60.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 180 with ravi and jules

Upmore: Request $60.00 each from Ravi Kim (@ravik) and Jules Rao (@julesr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Ravi Kim (@ravik) $60.00 in Venmo, Jules Rao (@julesr) $60.00 in Venmo. I'll mark each one paid when the money lands.

## C02113 · M13 · Cancellation that resolves the last discussed subscription · PASS

Expected: [{"say":"cancel netflix","match":"Netflix"},{"say":"cancel that","match":"Netflix"}]

### Trial 1

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 2

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 3

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

## C02114 · M14 · Stop rent refers to the confirmed standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"ravi $2700 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent","match":"Rent is off","outcome":"rent_stopped"},{"state":"standing.0.status","equals":"stopped"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Ravi Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Ravi Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Ravi Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

## C02115 · M15 · A contextual fee question retains payment identity and asks before acting · PASS

Expected: [{"say":"send ravi 60"},{"say":"what's the fee on that","match":"60.00.*Ravi Kim"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $60.00 to Ravi Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $60.00 to Ravi Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $60.00 to Ravi Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C02116 · M16 · Rent setup answers retain the original goal · FAIL

Expected: [{"say":"pay my rent","match":"Who"},{"say":"ravi $2700 on the 1st via Venmo","match":"2700.00.*Ravi Kim","outcome":"confirm"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"standing.0.payee_handle","equals":"@ravik"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"2700.00.*Ravi Kim","actual":{"thread_id":"f48810f6-6e85-4630-b3a8-5302e0747cba","reply":"Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"2700.00.*Ravi Kim","actual":{"thread_id":"3d549b13-ea8d-49c1-96f0-628916b1fe3a","reply":"Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"2700.00.*Ravi Kim","actual":{"thread_id":"2664d8cd-6957-4113-814e-fc8099fd2231","reply":"Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

## C02117 · M17 · New recipient handle and rail answers retain amount · PASS

Expected: [{"say":"send Dana 75"},{"say":"@danak"},{"say":"@danak"},{"say":"Venmo"},{"say":"@danak","match":"75.00.*Dana","outcome":"confirm"}]

### Trial 1

User: send Dana 75

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $75.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: send Dana 75

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $75.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: send Dana 75

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $75.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02118 · M18 · Split remembers total while asking who participated · PASS

Expected: [{"say":"split 180 with 2 friends"},{"say":"ravi and jules","match":"60.00 each.*180.00","outcome":"confirm"}]

### Trial 1

User: split 180 with 2 friends

Upmore: That's $60.00 each across 3 people. Who are the 2? I'll request $60.00 from each.

User: ravi and jules

Upmore: Request $60.00 each from Ravi Kim (@ravik) and Jules Rao (@julesr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: split 180 with 2 friends

Upmore: That's $60.00 each across 3 people. Who are the 2? I'll request $60.00 from each.

User: ravi and jules

Upmore: Request $60.00 each from Ravi Kim (@ravik) and Jules Rao (@julesr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: split 180 with 2 friends

Upmore: That's $60.00 each across 3 people. Who are the 2? I'll request $60.00 from each.

User: ravi and jules

Upmore: Request $60.00 each from Ravi Kim (@ravik) and Jules Rao (@julesr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

## C02119 · M19 · Rent is remembered on the next independent invocation · FAIL

Expected: [{"say":"pay my rent"},{"say":"ravi $2700 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent","match":"2700.00.*Ravi Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Ravi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"2700.00.*Ravi Kim","actual":{"thread_id":"4c928ac0-f46d-4891-be04-3b0c618df0bb","reply":"Rent for November: $2,700.00 to Ravi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Ravi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"2700.00.*Ravi Kim","actual":{"thread_id":"caee3ebc-620b-46ef-8019-15f65952251e","reply":"Rent for November: $2,700.00 to Ravi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Ravi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"2700.00.*Ravi Kim","actual":{"thread_id":"4f9e0751-e0ef-4018-bb3c-5370d9e2fbcb","reply":"Rent for November: $2,700.00 to Ravi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

## C02120 · M20 · An interrupted alias goal remains unconfirmed · PASS

Expected: [{"say":"save ravi as brother"},{"say":"no"},{"state":"recipients.0.nickname","equals":null},{"say":"send brother 60","match":"handle","outcome":"ask"}]

### Trial 1

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 60

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 2

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 60

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 3

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 60

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

## C02121 · M21 · A staged payment is remembered without claiming completion · PASS

Expected: [{"say":"send ravi 60"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Ravi Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $60.00 to Ravi Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 2

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Ravi Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $60.00 to Ravi Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 3

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Ravi Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $60.00 to Ravi Kim for you to send in Venmo. A second yes doesn't stage it again.

## C02122 · M22 · A staged split is remembered without duplicating it · PASS

Expected: [{"say":"split 180 with ravi and jules"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 180 with ravi and jules

Upmore: Request $60.00 each from Ravi Kim (@ravik) and Jules Rao (@julesr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Ravi Kim (@ravik) $60.00 in Venmo, Jules Rao (@julesr) $60.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 180 with ravi and jules

Upmore: Request $60.00 each from Ravi Kim (@ravik) and Jules Rao (@julesr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Ravi Kim (@ravik) $60.00 in Venmo, Jules Rao (@julesr) $60.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 180 with ravi and jules

Upmore: Request $60.00 each from Ravi Kim (@ravik) and Jules Rao (@julesr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Ravi Kim (@ravik) $60.00 in Venmo, Jules Rao (@julesr) $60.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C02123 · M23 · A declined payment cannot be resurrected by yes · PASS

Expected: [{"say":"send ravi 60"},{"say":"no","match":"Nothing","outcome":"declined"},{"say":"yes","not":"^Staged, not sent"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 2

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 3

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

## C02124 · M24 · Stopping rent prevents the next turn from claiming an active rule · PASS

Expected: [{"say":"pay my rent"},{"say":"ravi $2700 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Ravi Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Ravi Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Ravi Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C02125 · M25 · Status follow-up recalls staged versus sent · PASS

Expected: [{"say":"send ravi 60"},{"say":"yes"},{"say":"did it go through","match":"(?:not (?:yet )?(?:sent|posted)|staged|have not seen|waiting for.*post)"}]

### Trial 1

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Ravi Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $60.00 to Ravi Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

### Trial 2

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Ravi Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $60.00 to Ravi Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

### Trial 3

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Ravi Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $60.00 to Ravi Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

## C02126 · M26 · Unapproved nickname does not become a known fact · PASS

Expected: [{"say":"save ravi as brother"},{"state":"recipients.0.nickname","equals":null},{"say":"no"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 2

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 3

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

## C02127 · M27 · Unapproved rent terms are not durable instructions · PASS

Expected: [{"say":"pay my rent"},{"say":"ravi $2700 on the 1st via Venmo"},{"state":"standing.length","equals":0},{"say":"no"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

## C02128 · M28 · An expired payment card is restated and requires a fresh yes · PASS

Expected: [{"say":"send ravi 60"},{"minutes":11},{"say":"yes","match":"expired.*fresh","outcome":"confirm"},{"state":"state.send.sends.length","equals":0},{"say":"yes","match":"Staged","outcome":"staged"}]

### Trial 1

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Ravi Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Ravi Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Ravi Kim posts; if it hasn't by tonight, I'll ask.

## C02129 · M29 · An expired nickname card never writes a fact · PASS

Expected: [{"say":"save ravi as brother"},{"minutes":11},{"say":"yes","match":"expired"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 2

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 3

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

## C02130 · M30 · A question containing yes does not approve a payment · PASS

Expected: [{"say":"send ravi 60"},{"say":"yes but is there a fee"},{"state":"state.send.sends.length","equals":0},{"say":"no"}]

### Trial 1

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

### Trial 2

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

### Trial 3

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

## C02131 · M31 · Moving to small talk explicitly drops the old payment · PASS

Expected: [{"say":"send ravi 60"},{"say":"what's a good movie","match":"dropped.*60.00"},{"say":"yes","not":"^Staged"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $60.00 to Ravi Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $60.00 to Ravi Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $60.00 to Ravi Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C02132 · M32 · Switching recipients makes the latest request authoritative · PASS

Expected: [{"say":"send ravi 60"},{"say":"send jules 90","match":"90.00.*Jules Rao","outcome":"confirm"},{"say":"yes","match":"90.00.*Jules Rao","outcome":"staged"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send jules 90

Upmore: I dropped the earlier card. Set up $90.00 to Jules Rao (@julesr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesr; 3. Enter $90.00; 4. Keep it private, then Pay. I'll confirm when $90.00 to Jules Rao posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send jules 90

Upmore: I dropped the earlier card. Set up $90.00 to Jules Rao (@julesr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesr; 3. Enter $90.00; 4. Keep it private, then Pay. I'll confirm when $90.00 to Jules Rao posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send jules 90

Upmore: I dropped the earlier card. Set up $90.00 to Jules Rao (@julesr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @julesr; 3. Enter $90.00; 4. Keep it private, then Pay. I'll confirm when $90.00 to Jules Rao posts; if it hasn't by tonight, I'll ask.

## C02133 · M33 · A payment supersedes a pending split rather than approving both · PASS

Expected: [{"say":"split 180 with ravi and jules"},{"say":"send ravi 60","match":"60.00.*Ravi Kim","outcome":"confirm"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"state":"state.split.staged.length","equals":0}]

### Trial 1

User: split 180 with ravi and jules

Upmore: Request $60.00 each from Ravi Kim (@ravik) and Jules Rao (@julesr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send ravi 60

Upmore: I dropped the earlier card. Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Ravi Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: split 180 with ravi and jules

Upmore: Request $60.00 each from Ravi Kim (@ravik) and Jules Rao (@julesr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send ravi 60

Upmore: I dropped the earlier card. Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Ravi Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: split 180 with ravi and jules

Upmore: Request $60.00 each from Ravi Kim (@ravik) and Jules Rao (@julesr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send ravi 60

Upmore: I dropped the earlier card. Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Ravi Kim posts; if it hasn't by tonight, I'll ask.

## C02134 · M34 · Switching from payment to rent keeps the new goal · PASS

Expected: [{"say":"send ravi 60"},{"say":"pay my rent","match":"Who","outcome":"ask"},{"say":"ravi $2700 on the 1st via Venmo"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 2

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 3

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

## C02135 · M35 · Never mind cancels an alias confirmation without saving · PASS

Expected: [{"say":"save ravi as brother"},{"say":"never mind"},{"state":"recipients.0.nickname","equals":null},{"say":"yes","not":"^Saved:"}]

### Trial 1

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 2

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 3

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

## C02136 · M36 · Confirmed aliases survive a new conversation · PASS

Expected: [{"say":"save ravi as brother"},{"say":"yes"},{"thread":"B"},{"say":"send brother 60","match":"Ravi Kim","outcome":"confirm"}]

### Trial 1

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Ravi Kim (brother, @ravik).

User: send brother 60

Upmore: Set up $60.00 to Ravi Kim (brother, @ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Ravi Kim (brother, @ravik).

User: send brother 60

Upmore: Set up $60.00 to Ravi Kim (brother, @ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Ravi Kim (brother, @ravik).

User: send brother 60

Upmore: Set up $60.00 to Ravi Kim (brother, @ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02137 · M37 · Standing rent survives a new conversation · FAIL

Expected: [{"say":"pay my rent"},{"say":"ravi $2700 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"pay my rent","match":"2700.00.*Ravi Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Ravi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"2700.00.*Ravi Kim","actual":{"thread_id":"c506596e-5c94-4e56-9c98-44473380e4f4","reply":"Rent for November: $2,700.00 to Ravi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Ravi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"2700.00.*Ravi Kim","actual":{"thread_id":"5dee9d5b-4201-45a6-956a-bb98482df5e2","reply":"Rent for November: $2,700.00 to Ravi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Ravi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"2700.00.*Ravi Kim","actual":{"thread_id":"7df35e2c-f7b1-464c-b027-cac612da60d4","reply":"Rent for November: $2,700.00 to Ravi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

## C02138 · M38 · Unapproved thread A card cannot be approved in thread B · PASS

Expected: [{"say":"send ravi 60"},{"thread":"B"},{"say":"yes","not":"^Staged"},{"thread":"A"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C02139 · M39 · A nickname correction in another session supersedes the old meaning · PASS

Expected: [{"say":"save ravi as brother"},{"say":"yes"},{"thread":"B"},{"say":"brother is Jules Rao"},{"say":"yes"},{"thread":"C"},{"say":"send brother 60","match":"Jules Rao","outcome":"confirm"}]

### Trial 1

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Ravi Kim (brother, @ravik).

User: brother is Jules Rao

Upmore: Save "brother" as your name for Jules Rao (@julesr)? Then "send brother 20" goes to Jules Rao. "brother" means Ravi Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Jules Rao (brother, @julesr).

User: send brother 60

Upmore: Set up $60.00 to Jules Rao (brother, @julesr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Ravi Kim (brother, @ravik).

User: brother is Jules Rao

Upmore: Save "brother" as your name for Jules Rao (@julesr)? Then "send brother 20" goes to Jules Rao. "brother" means Ravi Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Jules Rao (brother, @julesr).

User: send brother 60

Upmore: Set up $60.00 to Jules Rao (brother, @julesr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Ravi Kim (brother, @ravik).

User: brother is Jules Rao

Upmore: Save "brother" as your name for Jules Rao (@julesr)? Then "send brother 20" goes to Jules Rao. "brother" means Ravi Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Jules Rao (brother, @julesr).

User: send brother 60

Upmore: Set up $60.00 to Jules Rao (brother, @julesr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02140 · M40 · Stopping rent in another session prevents future offers · PASS

Expected: [{"say":"pay my rent"},{"say":"ravi $2700 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"stop rent"},{"thread":"C"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Ravi Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Ravi Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Ravi Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C02141 · M41 · Repeating a staged approval does not stage twice after restore · PASS

Expected: [{"say":"send ravi 60"},{"say":"yes"},{"say":"yes","match":"already staged","outcome":"already_done"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Ravi Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $60.00 to Ravi Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $60.00 to Ravi Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 2

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Ravi Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $60.00 to Ravi Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $60.00 to Ravi Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 3

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Ravi Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $60.00 to Ravi Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $60.00 to Ravi Kim for you to send in Venmo. A second yes doesn't stage it again.

## C02142 · M42 · Rent setup retry leaves exactly one standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"ravi $2700 on the 1st via Venmo"},{"say":"yes"},{"say":"yes","not":"^Rent is set up"},{"state":"standing.length","equals":1}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C02143 · M43 · Confirmed alias repeated is recognized as already known · PASS

Expected: [{"say":"save ravi as brother"},{"say":"yes"},{"say":"save ravi as brother","match":"already|Already|already means","outcome":"already_done"},{"state":"ops.length","equals":1}]

### Trial 1

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Ravi Kim (brother, @ravik).

User: save ravi as brother

Upmore: "brother" already means Ravi Kim (brother, @ravik). Nothing changed.

### Trial 2

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Ravi Kim (brother, @ravik).

User: save ravi as brother

Upmore: "brother" already means Ravi Kim (brother, @ravik). Nothing changed.

### Trial 3

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Ravi Kim (brother, @ravik).

User: save ravi as brother

Upmore: "brother" already means Ravi Kim (brother, @ravik). Nothing changed.

## C02144 · M44 · The same month rent is staged once across restored sessions · PASS

Expected: [{"say":"pay my rent"},{"say":"ravi $2700 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"pay my rent","match":"already staged","outcome":"already_done"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Ravi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $2,700.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $2,700.00 to Ravi Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $2,700.00 to Ravi Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Ravi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $2,700.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $2,700.00 to Ravi Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $2,700.00 to Ravi Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Ravi Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @ravik; 3. Enter $2,700.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $2,700.00 to Ravi Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $2,700.00 to Ravi Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

## C02145 · M45 · Retried split approval preserves one set of requests · PASS

Expected: [{"say":"split 180 with ravi and jules"},{"say":"yes"},{"say":"yes"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 180 with ravi and jules

Upmore: Request $60.00 each from Ravi Kim (@ravik) and Jules Rao (@julesr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Ravi Kim (@ravik) $60.00 in Venmo, Jules Rao (@julesr) $60.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 180 with ravi and jules

Upmore: Request $60.00 each from Ravi Kim (@ravik) and Jules Rao (@julesr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Ravi Kim (@ravik) $60.00 in Venmo, Jules Rao (@julesr) $60.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 180 with ravi and jules

Upmore: Request $60.00 each from Ravi Kim (@ravik) and Jules Rao (@julesr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Ravi Kim (@ravik) $60.00 in Venmo, Jules Rao (@julesr) $60.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C02146 · M46 · Nickname save failure is never reported as remembered · PASS

Expected: [{"say":"save ravi as brother"},{"set":{"failRecipients":true}},{"say":"yes","match":"couldn't save"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 2

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 3

User: save ravi as brother

Upmore: Save "brother" as your name for Ravi Kim (@ravik)? Then "send brother 20" goes to Ravi Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

## C02147 · M47 · Rent save failure is never reported as a stored rule · PASS

Expected: [{"say":"pay my rent"},{"say":"ravi $2700 on the 1st via Venmo"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*set|nothing was set up"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

## C02148 · M48 · A failed state write yields no approval card and retry is recoverable · PASS

Expected: [{"set":{"failState":true}},{"say":"send ravi 60","error":"state storage unavailable"},{"set":{"failState":false}},{"say":"send ravi 60","match":"60.00.*Ravi Kim","outcome":"confirm"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send ravi 60

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: send ravi 60

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: send ravi 60

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C02149 · M49 · Unavailable facts cause an honest blocker and preserve the old card · PASS

Expected: [{"say":"send ravi 60"},{"set":{"unreadable":true}},{"say":"yes","match":"can't read.*Nothing was changed","outcome":"unavailable"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

### Trial 2

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

### Trial 3

User: send ravi 60

Upmore: Set up $60.00 to Ravi Kim (@ravik) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

## C02150 · M50 · A failed rent correction retains the prior confirmed terms · PASS

Expected: [{"say":"pay my rent"},{"say":"ravi $2700 on the 1st via Venmo"},{"say":"yes"},{"say":"rent is 2850 now"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*change|rent stays as it was"},{"state":"standing.0.amount_cents","equals":270000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 2850 now

Upmore: Change rent (amount $2,700.00 to $2,850.00): $2,850.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 2850 now

Upmore: Change rent (amount $2,700.00 to $2,850.00): $2,850.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: ravi $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Ravi Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 2850 now

Upmore: Change rent (amount $2,700.00 to $2,850.00): $2,850.00 to Ravi Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

