# conversations-015

All conversations are synthetic. Full production handler, mock authentication/PostgREST and disabled model; no real outbound messages or provider actions.

## C00701 · M01 · Confirmed nickname recalls the right person · PASS

Expected: [{"say":"save omar as brother"},{"say":"yes"},{"say":"send brother 100","match":"Omar Kim.*@omark","outcome":"confirm"}]

### Trial 1

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Omar Kim (brother, @omark).

User: send brother 100

Upmore: Set up $100.00 to Omar Kim (brother, @omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Omar Kim (brother, @omark).

User: send brother 100

Upmore: Set up $100.00 to Omar Kim (brother, @omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Omar Kim (brother, @omark).

User: send brother 100

Upmore: Set up $100.00 to Omar Kim (brother, @omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00702 · M02 · Explicit remember phrasing persists an alias · PASS

Expected: [{"say":"remember Finn Rao as my sister"},{"say":"yes"},{"say":"send sister 125","match":"Finn Rao.*@finnr","outcome":"confirm"}]

### Trial 1

User: remember Finn Rao as my sister

Upmore: Save "sister" as your name for Finn Rao (@finnr)? Then "send sister 20" goes to Finn Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Finn Rao (sister, @finnr).

User: send sister 125

Upmore: Set up $125.00 to Finn Rao (sister, @finnr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: remember Finn Rao as my sister

Upmore: Save "sister" as your name for Finn Rao (@finnr)? Then "send sister 20" goes to Finn Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Finn Rao (sister, @finnr).

User: send sister 125

Upmore: Set up $125.00 to Finn Rao (sister, @finnr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: remember Finn Rao as my sister

Upmore: Save "sister" as your name for Finn Rao (@finnr)? Then "send sister 20" goes to Finn Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Finn Rao (sister, @finnr).

User: send sister 125

Upmore: Set up $125.00 to Finn Rao (sister, @finnr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00703 · M03 · Natural relationship statement needs confirmation and persists · PASS

Expected: [{"say":"my dad is Omar Kim","match":"Save"},{"say":"yes"},{"say":"send dad 150","match":"Omar Kim","outcome":"confirm"}]

### Trial 1

User: my dad is Omar Kim

Upmore: Save "dad" as your name for Omar Kim (@omark)? Then "send dad 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Omar Kim (dad, @omark).

User: send dad 150

Upmore: Set up $150.00 to Omar Kim (dad, @omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: my dad is Omar Kim

Upmore: Save "dad" as your name for Omar Kim (@omark)? Then "send dad 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Omar Kim (dad, @omark).

User: send dad 150

Upmore: Set up $150.00 to Omar Kim (dad, @omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: my dad is Omar Kim

Upmore: Save "dad" as your name for Omar Kim (@omark)? Then "send dad 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Omar Kim (dad, @omark).

User: send dad 150

Upmore: Set up $150.00 to Omar Kim (dad, @omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00704 · M04 · An alias is moved only to the newly confirmed person · PASS

Expected: [{"say":"save omar as brother"},{"say":"yes"},{"say":"brother is Finn Rao"},{"say":"yes"},{"say":"send brother 100","match":"Finn Rao","outcome":"confirm"}]

### Trial 1

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Omar Kim (brother, @omark).

User: brother is Finn Rao

Upmore: Save "brother" as your name for Finn Rao (@finnr)? Then "send brother 20" goes to Finn Rao. "brother" means Omar Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Finn Rao (brother, @finnr).

User: send brother 100

Upmore: Set up $100.00 to Finn Rao (brother, @finnr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Omar Kim (brother, @omark).

User: brother is Finn Rao

Upmore: Save "brother" as your name for Finn Rao (@finnr)? Then "send brother 20" goes to Finn Rao. "brother" means Omar Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Finn Rao (brother, @finnr).

User: send brother 100

Upmore: Set up $100.00 to Finn Rao (brother, @finnr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Omar Kim (brother, @omark).

User: brother is Finn Rao

Upmore: Save "brother" as your name for Finn Rao (@finnr)? Then "send brother 20" goes to Finn Rao. "brother" means Omar Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Finn Rao (brother, @finnr).

User: send brother 100

Upmore: Set up $100.00 to Finn Rao (brother, @finnr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00705 · M05 · Rejected alias preserves the previous confirmed fact · PASS

Expected: [{"say":"save omar as brother"},{"say":"yes"},{"say":"brother is Finn Rao"},{"say":"no"},{"say":"send brother 100","match":"Omar Kim","outcome":"confirm"}]

### Trial 1

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Omar Kim (brother, @omark).

User: brother is Finn Rao

Upmore: Save "brother" as your name for Finn Rao (@finnr)? Then "send brother 20" goes to Finn Rao. "brother" means Omar Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 100

Upmore: Set up $100.00 to Omar Kim (brother, @omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Omar Kim (brother, @omark).

User: brother is Finn Rao

Upmore: Save "brother" as your name for Finn Rao (@finnr)? Then "send brother 20" goes to Finn Rao. "brother" means Omar Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 100

Upmore: Set up $100.00 to Omar Kim (brother, @omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Omar Kim (brother, @omark).

User: brother is Finn Rao

Upmore: Save "brother" as your name for Finn Rao (@finnr)? Then "send brother 20" goes to Finn Rao. "brother" means Omar Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 100

Upmore: Set up $100.00 to Omar Kim (brother, @omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00706 · M06 · Amount correction preserves payee and replaces the old card · PASS

Expected: [{"say":"send omar 100"},{"say":"make it 175","match":"175.00.*Omar Kim","outcome":"confirm"},{"say":"yes","match":"175.00","outcome":"staged"},{"state":"state.send.sends.0.amount_cents","equals":17500}]

### Trial 1

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 175

Upmore: Got it. Set up $175.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $175.00; 4. Keep it private, then Pay. I'll confirm when $175.00 to Omar Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 175

Upmore: Got it. Set up $175.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $175.00; 4. Keep it private, then Pay. I'll confirm when $175.00 to Omar Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 175

Upmore: Got it. Set up $175.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $175.00; 4. Keep it private, then Pay. I'll confirm when $175.00 to Omar Kim posts; if it hasn't by tonight, I'll ask.

## C00707 · M07 · Actually correction handles a different amount · PASS

Expected: [{"say":"send omar 100"},{"say":"actually make it 250","match":"250.00.*Omar Kim","outcome":"confirm"},{"say":"yes","match":"250.00","outcome":"staged"}]

### Trial 1

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 250

Upmore: Got it. Set up $250.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $250.00; 4. Keep it private, then Pay. I'll confirm when $250.00 to Omar Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 250

Upmore: Got it. Set up $250.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $250.00; 4. Keep it private, then Pay. I'll confirm when $250.00 to Omar Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 250

Upmore: Got it. Set up $250.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $250.00; 4. Keep it private, then Pay. I'll confirm when $250.00 to Omar Kim posts; if it hasn't by tonight, I'll ask.

## C00708 · M08 · Bare currency correction retains payment context · PASS

Expected: [{"say":"send omar 100"},{"say":"$62.50 instead","match":"62.50.*Omar Kim","outcome":"confirm"},{"say":"yes","match":"62.50","outcome":"staged"}]

### Trial 1

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $62.50 instead

Upmore: Got it. Set up $62.50 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $62.50; 4. Keep it private, then Pay. I'll confirm when $62.50 to Omar Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $62.50 instead

Upmore: Got it. Set up $62.50 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $62.50; 4. Keep it private, then Pay. I'll confirm when $62.50 to Omar Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $62.50 instead

Upmore: Got it. Set up $62.50 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $62.50; 4. Keep it private, then Pay. I'll confirm when $62.50 to Omar Kim posts; if it hasn't by tonight, I'll ask.

## C00709 · M09 · Split total correction recomputes every share before approval · PASS

Expected: [{"say":"split 300 with omar and finn"},{"say":"make it 450","match":"150.00 each.*450.00","outcome":"confirm"},{"say":"yes","match":"150.00","outcome":"staged"}]

### Trial 1

User: split 300 with omar and finn

Upmore: Request $100.00 each from Omar Kim (@omark) and Finn Rao (@finnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 450

Upmore: Got it. Request $150.00 each from Omar Kim (@omark) and Finn Rao (@finnr) in Venmo: $450.00 split 3 ways, yours $150.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Omar Kim (@omark) $150.00 in Venmo, Finn Rao (@finnr) $150.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 300 with omar and finn

Upmore: Request $100.00 each from Omar Kim (@omark) and Finn Rao (@finnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 450

Upmore: Got it. Request $150.00 each from Omar Kim (@omark) and Finn Rao (@finnr) in Venmo: $450.00 split 3 ways, yours $150.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Omar Kim (@omark) $150.00 in Venmo, Finn Rao (@finnr) $150.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 300 with omar and finn

Upmore: Request $100.00 each from Omar Kim (@omark) and Finn Rao (@finnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 450

Upmore: Got it. Request $150.00 each from Omar Kim (@omark) and Finn Rao (@finnr) in Venmo: $450.00 split 3 ways, yours $150.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Omar Kim (@omark) $150.00 in Venmo, Finn Rao (@finnr) $150.00 in Venmo. I'll mark each one paid when the money lands.

## C00710 · M10 · Rent setup correction retains recipient and due day · FAIL

Expected: [{"say":"pay my rent"},{"say":"omar $4500 on the 1st via Venmo"},{"say":"make it 4750","match":"4750.00.*Omar Kim.*1st","outcome":"confirm"},{"say":"yes"},{"state":"standing.0.amount_cents","equals":475000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 4750

Upmore: Got it. Set up rent: $4,750.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,750.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"4750.00.*Omar Kim.*1st","actual":{"thread_id":"215e5405-2b4a-4dea-8081-2f13bb3ddec2","reply":"Got it. Set up rent: $4,750.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 4750

Upmore: Got it. Set up rent: $4,750.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,750.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"4750.00.*Omar Kim.*1st","actual":{"thread_id":"f786b9b5-0d57-48b9-ae26-2a4ed15268cf","reply":"Got it. Set up rent: $4,750.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 4750

Upmore: Got it. Set up rent: $4,750.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,750.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"4750.00.*Omar Kim.*1st","actual":{"thread_id":"604b78a5-75ab-4435-a012-1c00db849368","reply":"Got it. Set up rent: $4,750.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

## C00711 · M11 · Details refers to the pending payment · PASS

Expected: [{"say":"send omar 100"},{"say":"details","match":"100.00.*Omar Kim","outcome":"details"}]

### Trial 1

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $100.00 to Omar Kim on Venmo $100.00 to Omar Kim (@omark) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

### Trial 2

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $100.00 to Omar Kim on Venmo $100.00 to Omar Kim (@omark) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

### Trial 3

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $100.00 to Omar Kim on Venmo $100.00 to Omar Kim (@omark) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

## C00712 · M12 · A short yes resumes a serialized split · PASS

Expected: [{"say":"split 300 with omar and finn"},{"say":"yes","match":"Omar Kim.*100.00.*Finn Rao.*100.00","outcome":"staged"}]

### Trial 1

User: split 300 with omar and finn

Upmore: Request $100.00 each from Omar Kim (@omark) and Finn Rao (@finnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Omar Kim (@omark) $100.00 in Venmo, Finn Rao (@finnr) $100.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 300 with omar and finn

Upmore: Request $100.00 each from Omar Kim (@omark) and Finn Rao (@finnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Omar Kim (@omark) $100.00 in Venmo, Finn Rao (@finnr) $100.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 300 with omar and finn

Upmore: Request $100.00 each from Omar Kim (@omark) and Finn Rao (@finnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Omar Kim (@omark) $100.00 in Venmo, Finn Rao (@finnr) $100.00 in Venmo. I'll mark each one paid when the money lands.

## C00713 · M13 · Cancellation that resolves the last discussed subscription · PASS

Expected: [{"say":"cancel netflix","match":"Netflix"},{"say":"cancel that","match":"Netflix"}]

### Trial 1

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 2

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 3

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

## C00714 · M14 · Stop rent refers to the confirmed standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"omar $4500 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent","match":"Rent is off","outcome":"rent_stopped"},{"state":"standing.0.status","equals":"stopped"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Omar Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Omar Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Omar Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

## C00715 · M15 · A contextual fee question retains payment identity and asks before acting · PASS

Expected: [{"say":"send omar 100"},{"say":"what's the fee on that","match":"100.00.*Omar Kim"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $100.00 to Omar Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $100.00 to Omar Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $100.00 to Omar Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00716 · M16 · Rent setup answers retain the original goal · FAIL

Expected: [{"say":"pay my rent","match":"Who"},{"say":"omar $4500 on the 1st via Venmo","match":"4500.00.*Omar Kim","outcome":"confirm"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"standing.0.payee_handle","equals":"@omark"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"4500.00.*Omar Kim","actual":{"thread_id":"045cc181-f825-4a01-922b-390a4b26c187","reply":"Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"4500.00.*Omar Kim","actual":{"thread_id":"9bb5dd7e-8503-4942-9489-075dd7c78f5b","reply":"Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"4500.00.*Omar Kim","actual":{"thread_id":"2ea9b3b1-e708-4926-9cf9-db1301af3432","reply":"Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

## C00717 · M17 · New recipient handle and rail answers retain amount · PASS

Expected: [{"say":"send Dana 125"},{"say":"@danak"},{"say":"@danak"},{"say":"Venmo"},{"say":"@danak","match":"125.00.*Dana","outcome":"confirm"}]

### Trial 1

User: send Dana 125

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $125.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: send Dana 125

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $125.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: send Dana 125

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $125.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00718 · M18 · Split remembers total while asking who participated · PASS

Expected: [{"say":"split 300 with 2 friends"},{"say":"omar and finn","match":"100.00 each.*300.00","outcome":"confirm"}]

### Trial 1

User: split 300 with 2 friends

Upmore: That's $100.00 each across 3 people. Who are the 2? I'll request $100.00 from each.

User: omar and finn

Upmore: Request $100.00 each from Omar Kim (@omark) and Finn Rao (@finnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: split 300 with 2 friends

Upmore: That's $100.00 each across 3 people. Who are the 2? I'll request $100.00 from each.

User: omar and finn

Upmore: Request $100.00 each from Omar Kim (@omark) and Finn Rao (@finnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: split 300 with 2 friends

Upmore: That's $100.00 each across 3 people. Who are the 2? I'll request $100.00 from each.

User: omar and finn

Upmore: Request $100.00 each from Omar Kim (@omark) and Finn Rao (@finnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

## C00719 · M19 · Rent is remembered on the next independent invocation · FAIL

Expected: [{"say":"pay my rent"},{"say":"omar $4500 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent","match":"4500.00.*Omar Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Omar Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"4500.00.*Omar Kim","actual":{"thread_id":"a4225969-4c6b-4f52-bceb-81ed43d48c70","reply":"Rent for November: $4,500.00 to Omar Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Omar Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"4500.00.*Omar Kim","actual":{"thread_id":"444dfc6e-0baf-4a9e-bef8-78338b63297a","reply":"Rent for November: $4,500.00 to Omar Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Omar Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"4500.00.*Omar Kim","actual":{"thread_id":"e8dae026-1827-4cf3-8102-5eb2a273cb6b","reply":"Rent for November: $4,500.00 to Omar Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

## C00720 · M20 · An interrupted alias goal remains unconfirmed · PASS

Expected: [{"say":"save omar as brother"},{"say":"no"},{"state":"recipients.0.nickname","equals":null},{"say":"send brother 100","match":"handle","outcome":"ask"}]

### Trial 1

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 100

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 2

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 100

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 3

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 100

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

## C00721 · M21 · A staged payment is remembered without claiming completion · PASS

Expected: [{"say":"send omar 100"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Omar Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $100.00 to Omar Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 2

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Omar Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $100.00 to Omar Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 3

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Omar Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $100.00 to Omar Kim for you to send in Venmo. A second yes doesn't stage it again.

## C00722 · M22 · A staged split is remembered without duplicating it · PASS

Expected: [{"say":"split 300 with omar and finn"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 300 with omar and finn

Upmore: Request $100.00 each from Omar Kim (@omark) and Finn Rao (@finnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Omar Kim (@omark) $100.00 in Venmo, Finn Rao (@finnr) $100.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 300 with omar and finn

Upmore: Request $100.00 each from Omar Kim (@omark) and Finn Rao (@finnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Omar Kim (@omark) $100.00 in Venmo, Finn Rao (@finnr) $100.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 300 with omar and finn

Upmore: Request $100.00 each from Omar Kim (@omark) and Finn Rao (@finnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Omar Kim (@omark) $100.00 in Venmo, Finn Rao (@finnr) $100.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C00723 · M23 · A declined payment cannot be resurrected by yes · PASS

Expected: [{"say":"send omar 100"},{"say":"no","match":"Nothing","outcome":"declined"},{"say":"yes","not":"^Staged, not sent"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 2

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 3

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

## C00724 · M24 · Stopping rent prevents the next turn from claiming an active rule · PASS

Expected: [{"say":"pay my rent"},{"say":"omar $4500 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Omar Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Omar Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Omar Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C00725 · M25 · Status follow-up recalls staged versus sent · PASS

Expected: [{"say":"send omar 100"},{"say":"yes"},{"say":"did it go through","match":"(?:not (?:yet )?(?:sent|posted)|staged|have not seen|waiting for.*post)"}]

### Trial 1

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Omar Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $100.00 to Omar Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

### Trial 2

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Omar Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $100.00 to Omar Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

### Trial 3

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Omar Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $100.00 to Omar Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

## C00726 · M26 · Unapproved nickname does not become a known fact · PASS

Expected: [{"say":"save omar as brother"},{"state":"recipients.0.nickname","equals":null},{"say":"no"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 2

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 3

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

## C00727 · M27 · Unapproved rent terms are not durable instructions · PASS

Expected: [{"say":"pay my rent"},{"say":"omar $4500 on the 1st via Venmo"},{"state":"standing.length","equals":0},{"say":"no"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

## C00728 · M28 · An expired payment card is restated and requires a fresh yes · PASS

Expected: [{"say":"send omar 100"},{"minutes":11},{"say":"yes","match":"expired.*fresh","outcome":"confirm"},{"state":"state.send.sends.length","equals":0},{"say":"yes","match":"Staged","outcome":"staged"}]

### Trial 1

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Omar Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Omar Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Omar Kim posts; if it hasn't by tonight, I'll ask.

## C00729 · M29 · An expired nickname card never writes a fact · PASS

Expected: [{"say":"save omar as brother"},{"minutes":11},{"say":"yes","match":"expired"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 2

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 3

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

## C00730 · M30 · A question containing yes does not approve a payment · PASS

Expected: [{"say":"send omar 100"},{"say":"yes but is there a fee"},{"state":"state.send.sends.length","equals":0},{"say":"no"}]

### Trial 1

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

### Trial 2

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

### Trial 3

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

## C00731 · M31 · Moving to small talk explicitly drops the old payment · PASS

Expected: [{"say":"send omar 100"},{"say":"what's a good movie","match":"dropped.*100.00"},{"say":"yes","not":"^Staged"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $100.00 to Omar Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $100.00 to Omar Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $100.00 to Omar Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00732 · M32 · Switching recipients makes the latest request authoritative · PASS

Expected: [{"say":"send omar 100"},{"say":"send finn 150","match":"150.00.*Finn Rao","outcome":"confirm"},{"say":"yes","match":"150.00.*Finn Rao","outcome":"staged"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send finn 150

Upmore: I dropped the earlier card. Set up $150.00 to Finn Rao (@finnr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnr; 3. Enter $150.00; 4. Keep it private, then Pay. I'll confirm when $150.00 to Finn Rao posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send finn 150

Upmore: I dropped the earlier card. Set up $150.00 to Finn Rao (@finnr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnr; 3. Enter $150.00; 4. Keep it private, then Pay. I'll confirm when $150.00 to Finn Rao posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send finn 150

Upmore: I dropped the earlier card. Set up $150.00 to Finn Rao (@finnr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @finnr; 3. Enter $150.00; 4. Keep it private, then Pay. I'll confirm when $150.00 to Finn Rao posts; if it hasn't by tonight, I'll ask.

## C00733 · M33 · A payment supersedes a pending split rather than approving both · PASS

Expected: [{"say":"split 300 with omar and finn"},{"say":"send omar 100","match":"100.00.*Omar Kim","outcome":"confirm"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"state":"state.split.staged.length","equals":0}]

### Trial 1

User: split 300 with omar and finn

Upmore: Request $100.00 each from Omar Kim (@omark) and Finn Rao (@finnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send omar 100

Upmore: I dropped the earlier card. Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Omar Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: split 300 with omar and finn

Upmore: Request $100.00 each from Omar Kim (@omark) and Finn Rao (@finnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send omar 100

Upmore: I dropped the earlier card. Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Omar Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: split 300 with omar and finn

Upmore: Request $100.00 each from Omar Kim (@omark) and Finn Rao (@finnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send omar 100

Upmore: I dropped the earlier card. Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Omar Kim posts; if it hasn't by tonight, I'll ask.

## C00734 · M34 · Switching from payment to rent keeps the new goal · PASS

Expected: [{"say":"send omar 100"},{"say":"pay my rent","match":"Who","outcome":"ask"},{"say":"omar $4500 on the 1st via Venmo"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 2

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 3

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

## C00735 · M35 · Never mind cancels an alias confirmation without saving · PASS

Expected: [{"say":"save omar as brother"},{"say":"never mind"},{"state":"recipients.0.nickname","equals":null},{"say":"yes","not":"^Saved:"}]

### Trial 1

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 2

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 3

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

## C00736 · M36 · Confirmed aliases survive a new conversation · PASS

Expected: [{"say":"save omar as brother"},{"say":"yes"},{"thread":"B"},{"say":"send brother 100","match":"Omar Kim","outcome":"confirm"}]

### Trial 1

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Omar Kim (brother, @omark).

User: send brother 100

Upmore: Set up $100.00 to Omar Kim (brother, @omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Omar Kim (brother, @omark).

User: send brother 100

Upmore: Set up $100.00 to Omar Kim (brother, @omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Omar Kim (brother, @omark).

User: send brother 100

Upmore: Set up $100.00 to Omar Kim (brother, @omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00737 · M37 · Standing rent survives a new conversation · FAIL

Expected: [{"say":"pay my rent"},{"say":"omar $4500 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"pay my rent","match":"4500.00.*Omar Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Omar Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"4500.00.*Omar Kim","actual":{"thread_id":"0609f864-4ebe-4f40-bf92-1a720c3d4981","reply":"Rent for November: $4,500.00 to Omar Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Omar Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"4500.00.*Omar Kim","actual":{"thread_id":"318b6764-905b-4d39-ae52-7c6100572d40","reply":"Rent for November: $4,500.00 to Omar Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Omar Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"4500.00.*Omar Kim","actual":{"thread_id":"a4edb0f7-98f5-4dfe-a240-064b3b631b36","reply":"Rent for November: $4,500.00 to Omar Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

## C00738 · M38 · Unapproved thread A card cannot be approved in thread B · PASS

Expected: [{"say":"send omar 100"},{"thread":"B"},{"say":"yes","not":"^Staged"},{"thread":"A"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00739 · M39 · A nickname correction in another session supersedes the old meaning · PASS

Expected: [{"say":"save omar as brother"},{"say":"yes"},{"thread":"B"},{"say":"brother is Finn Rao"},{"say":"yes"},{"thread":"C"},{"say":"send brother 100","match":"Finn Rao","outcome":"confirm"}]

### Trial 1

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Omar Kim (brother, @omark).

User: brother is Finn Rao

Upmore: Save "brother" as your name for Finn Rao (@finnr)? Then "send brother 20" goes to Finn Rao. "brother" means Omar Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Finn Rao (brother, @finnr).

User: send brother 100

Upmore: Set up $100.00 to Finn Rao (brother, @finnr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Omar Kim (brother, @omark).

User: brother is Finn Rao

Upmore: Save "brother" as your name for Finn Rao (@finnr)? Then "send brother 20" goes to Finn Rao. "brother" means Omar Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Finn Rao (brother, @finnr).

User: send brother 100

Upmore: Set up $100.00 to Finn Rao (brother, @finnr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Omar Kim (brother, @omark).

User: brother is Finn Rao

Upmore: Save "brother" as your name for Finn Rao (@finnr)? Then "send brother 20" goes to Finn Rao. "brother" means Omar Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Finn Rao (brother, @finnr).

User: send brother 100

Upmore: Set up $100.00 to Finn Rao (brother, @finnr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00740 · M40 · Stopping rent in another session prevents future offers · PASS

Expected: [{"say":"pay my rent"},{"say":"omar $4500 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"stop rent"},{"thread":"C"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Omar Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Omar Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Omar Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C00741 · M41 · Repeating a staged approval does not stage twice after restore · PASS

Expected: [{"say":"send omar 100"},{"say":"yes"},{"say":"yes","match":"already staged","outcome":"already_done"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Omar Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $100.00 to Omar Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $100.00 to Omar Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 2

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Omar Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $100.00 to Omar Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $100.00 to Omar Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 3

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Omar Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $100.00 to Omar Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $100.00 to Omar Kim for you to send in Venmo. A second yes doesn't stage it again.

## C00742 · M42 · Rent setup retry leaves exactly one standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"omar $4500 on the 1st via Venmo"},{"say":"yes"},{"say":"yes","not":"^Rent is set up"},{"state":"standing.length","equals":1}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00743 · M43 · Confirmed alias repeated is recognized as already known · PASS

Expected: [{"say":"save omar as brother"},{"say":"yes"},{"say":"save omar as brother","match":"already|Already|already means","outcome":"already_done"},{"state":"ops.length","equals":1}]

### Trial 1

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Omar Kim (brother, @omark).

User: save omar as brother

Upmore: "brother" already means Omar Kim (brother, @omark). Nothing changed.

### Trial 2

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Omar Kim (brother, @omark).

User: save omar as brother

Upmore: "brother" already means Omar Kim (brother, @omark). Nothing changed.

### Trial 3

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Omar Kim (brother, @omark).

User: save omar as brother

Upmore: "brother" already means Omar Kim (brother, @omark). Nothing changed.

## C00744 · M44 · The same month rent is staged once across restored sessions · PASS

Expected: [{"say":"pay my rent"},{"say":"omar $4500 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"pay my rent","match":"already staged","outcome":"already_done"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Omar Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $4,500.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $4,500.00 to Omar Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $4,500.00 to Omar Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Omar Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $4,500.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $4,500.00 to Omar Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $4,500.00 to Omar Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $4,500.00 to Omar Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @omark; 3. Enter $4,500.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $4,500.00 to Omar Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $4,500.00 to Omar Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

## C00745 · M45 · Retried split approval preserves one set of requests · PASS

Expected: [{"say":"split 300 with omar and finn"},{"say":"yes"},{"say":"yes"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 300 with omar and finn

Upmore: Request $100.00 each from Omar Kim (@omark) and Finn Rao (@finnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Omar Kim (@omark) $100.00 in Venmo, Finn Rao (@finnr) $100.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 300 with omar and finn

Upmore: Request $100.00 each from Omar Kim (@omark) and Finn Rao (@finnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Omar Kim (@omark) $100.00 in Venmo, Finn Rao (@finnr) $100.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 300 with omar and finn

Upmore: Request $100.00 each from Omar Kim (@omark) and Finn Rao (@finnr) in Venmo: $300.00 split 3 ways, yours $100.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Omar Kim (@omark) $100.00 in Venmo, Finn Rao (@finnr) $100.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C00746 · M46 · Nickname save failure is never reported as remembered · PASS

Expected: [{"say":"save omar as brother"},{"set":{"failRecipients":true}},{"say":"yes","match":"couldn't save"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 2

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 3

User: save omar as brother

Upmore: Save "brother" as your name for Omar Kim (@omark)? Then "send brother 20" goes to Omar Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

## C00747 · M47 · Rent save failure is never reported as a stored rule · PASS

Expected: [{"say":"pay my rent"},{"say":"omar $4500 on the 1st via Venmo"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*set|nothing was set up"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

## C00748 · M48 · A failed state write yields no approval card and retry is recoverable · PASS

Expected: [{"set":{"failState":true}},{"say":"send omar 100","error":"state storage unavailable"},{"set":{"failState":false}},{"say":"send omar 100","match":"100.00.*Omar Kim","outcome":"confirm"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send omar 100

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: send omar 100

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: send omar 100

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00749 · M49 · Unavailable facts cause an honest blocker and preserve the old card · PASS

Expected: [{"say":"send omar 100"},{"set":{"unreadable":true}},{"say":"yes","match":"can't read.*Nothing was changed","outcome":"unavailable"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

### Trial 2

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

### Trial 3

User: send omar 100

Upmore: Set up $100.00 to Omar Kim (@omark) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

## C00750 · M50 · A failed rent correction retains the prior confirmed terms · PASS

Expected: [{"say":"pay my rent"},{"say":"omar $4500 on the 1st via Venmo"},{"say":"yes"},{"say":"rent is 4750 now"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*change|rent stays as it was"},{"state":"standing.0.amount_cents","equals":450000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 4750 now

Upmore: Change rent (amount $4,500.00 to $4,750.00): $4,750.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 4750 now

Upmore: Change rent (amount $4,500.00 to $4,750.00): $4,750.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: omar $4500 on the 1st via Venmo

Upmore: Set up rent: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $4,500.00 to Omar Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 4750 now

Upmore: Change rent (amount $4,500.00 to $4,750.00): $4,750.00 to Omar Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

