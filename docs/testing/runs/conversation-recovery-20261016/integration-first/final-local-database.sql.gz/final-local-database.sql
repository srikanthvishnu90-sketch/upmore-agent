--
-- PostgreSQL database dump
--

\restrict dvZ3aCneHINm9ikzzNb5Lm57uoH4SawnpQH16r3wnbX0UF66OO3NMTpZns6hW3s

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg13+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- Name: career_host_commit(uuid, uuid, text, text, bigint, bigint, jsonb, jsonb, text, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_host_commit(p_user uuid, p_thread uuid, p_key text, p_hash text, p_revision bigint, p_account_version bigint, p_snapshot jsonb, p_patch jsonb, p_input text, p_response jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $_$
declare a jsonb; old_snapshot jsonb; receipt jsonb; wp jsonb; epoch bigint; next_snapshot jsonb; patch_key text;
begin
 if p_user is null or p_thread is null or p_key is null or p_hash is null or p_key !~ '^[A-Za-z0-9_-]{1,128}$' or p_hash !~ '^[a-f0-9]{64}$' or p_snapshot is null or jsonb_typeof(p_snapshot)<>'object' or octet_length(p_snapshot::text)>1048576
  or p_input is null or length(p_input)>20000 or p_response is null or jsonb_typeof(p_response->'reply') is distinct from 'string' or octet_length(p_response::text)>1048576 or jsonb_typeof(coalesce(p_patch,'{}'::jsonb))<>'object' or p_snapshot#>>'{scope,userId}' is distinct from p_user::text or jsonb_typeof(p_response)<>'object' or p_response->>'thread_id' is distinct from p_thread::text then raise exception 'invalid host commit';end if;
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 perform 1 from agent_threads where id=p_thread and user_id=p_user for update;
 if not found or exists(select 1 from agent_flow_state where thread_id=p_thread and user_id is distinct from p_user) then return jsonb_build_object('error','owned_thread_missing');end if;
 select value into a from career_watch_kv where user_id=p_user and key='career:account';a:=coalesce(a,'{"version":0,"epoch":0}'::jsonb);epoch:=coalesce((a->>'epoch')::bigint,0);
 select value into receipt from career_watch_kv where user_id=p_user and key='career:turn:'||p_thread||':'||p_key;
 if receipt is not null then
  if receipt->>'hash'<>p_hash then return jsonb_build_object('error','turn_key_conflict');end if;
  if coalesce((receipt->>'epoch')::bigint,0)<>epoch or (receipt->'response' is null or receipt->'response'='null'::jsonb) then return jsonb_build_object('error','privacy_epoch_changed');end if;
  return jsonb_build_object('response',receipt->'response','replay',true);
 end if;
 if coalesce((a->>'version')::bigint,0)<>p_account_version then return jsonb_build_object('error','revision_conflict');end if;
 select state->'career' into old_snapshot from agent_flow_state where thread_id=p_thread and user_id=p_user for update;
 if coalesce((old_snapshot->>'revision')::bigint,0)<>p_revision then return jsonb_build_object('error','revision_conflict');end if;
 for patch_key in select jsonb_object_keys(coalesce(p_patch,'{}'::jsonb)) loop
  if patch_key not in ('paused','preferred_locations','erase') then raise exception 'invalid account patch';end if;
 end loop;
 if p_patch ? 'preferred_locations' and (jsonb_typeof(p_patch->'preferred_locations')<>'array' or jsonb_array_length(p_patch->'preferred_locations')<>1 or length(p_patch#>>'{preferred_locations,0}') not between 1 and 100) then raise exception 'invalid location';end if;
 if p_patch ? 'paused' and jsonb_typeof(p_patch->'paused')<>'boolean' then raise exception 'invalid pause';end if;
 if p_patch ? 'erase' and p_patch->'erase'<>'true'::jsonb then raise exception 'invalid erasure';end if;
 if p_patch->'erase'='true'::jsonb then
  epoch:=epoch+1;
  update agent_flow_state set state=jsonb_set(coalesce(state,'{}'::jsonb),'{career}',jsonb_build_object('v',1,'scope',jsonb_build_object('userId',p_user),'revision',coalesce((state#>>'{career,revision}')::bigint,0)+1,'stores',jsonb_build_object('globalPause',jsonb_build_object('set',true,'source','account_control')))),updated_at=now() where user_id=p_user;
  delete from career_watch_kv where user_id=p_user and key not like 'career:turn:%';
  update career_watch_kv set value=jsonb_set(value,'{response}','null'::jsonb),updated_at=now() where user_id=p_user and key like 'career:turn:%';
  update career_reminder_outbox set payload=null,record=null,status='cancelled',updated_at=now() where user_id=p_user;
  a:=jsonb_build_object('epoch',epoch,'paused',true,'version',p_account_version);
 end if;
 a:=a||coalesce(p_patch-'erase','{}'::jsonb)||jsonb_build_object('version',p_account_version+1,'epoch',epoch);
 insert into career_watch_kv(user_id,key,value)values(p_user,'career:account',a)on conflict(user_id,key)do update set value=excluded.value,updated_at=now();
 if a->'paused'='true'::jsonb then update career_reminder_outbox set status='cancelled',updated_at=now() where user_id=p_user and status in ('pending','claimed','uncertain');end if;
 next_snapshot:=(case when p_patch->'erase'='true'::jsonb then jsonb_build_object('v',1,'scope',jsonb_build_object('userId',p_user),'stores',jsonb_build_object('globalPause',jsonb_build_object('set',true,'source','account_control'))) else p_snapshot end)||jsonb_build_object('revision',p_revision+1,'privacy_epoch',epoch);
 wp:=next_snapshot#>array['stores','alertWatchState','career:watch-profile:'||p_user];
 if wp is not null then
  if wp->>'user_id' is distinct from p_user::text then raise exception 'watch owner mismatch';end if;
  insert into career_watch_kv(user_id,key,value)values(p_user,'career:watch-profile:'||p_user,wp)on conflict(user_id,key)do update set value=excluded.value,updated_at=now();
 end if;
 insert into agent_flow_state(thread_id,user_id,state,updated_at)values(p_thread,p_user,jsonb_build_object('career',next_snapshot),now())
 on conflict(thread_id)do update set state=jsonb_set(coalesce(agent_flow_state.state,'{}'::jsonb),'{career}',next_snapshot),updated_at=now() where agent_flow_state.user_id=p_user;
 insert into agent_messages(thread_id,role,content)values(p_thread,'user',p_input);
 insert into agent_messages(thread_id,role,content,meta)values(p_thread,'assistant',p_response->>'reply',coalesce(p_response->'meta','{}'::jsonb)||jsonb_build_object('career',true,'career_turn_key',p_key));
 update career_reminder_outbox set seen_at=now() where user_id=p_user and status='delivered' and reminder_id in(select x->>'reminder_id' from jsonb_array_elements(coalesce(p_response->'reminders','[]'::jsonb))x);
 insert into career_watch_kv(user_id,key,value)values(p_user,'career:turn:'||p_thread||':'||p_key,jsonb_build_object('hash',p_hash,'epoch',epoch,'response',p_response));
 return jsonb_build_object('response',p_response);
end $_$;


--
-- Name: career_host_load(uuid, uuid, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_host_load(p_user uuid, p_thread uuid, p_key text, p_hash text) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $_$
declare f jsonb; a jsonb; r jsonb; w jsonb; legacy_count integer; reminders jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 if p_user is null or p_thread is null or p_key is null or p_hash is null or p_key !~ '^[A-Za-z0-9_-]{1,128}$' or p_hash !~ '^[a-f0-9]{64}$' then return jsonb_build_object('error','invalid_turn_key');end if;
 if exists(select 1 from agent_flow_state where thread_id=p_thread and user_id is distinct from p_user) or not exists(select 1 from agent_threads where id=p_thread and user_id=p_user) then return jsonb_build_object('error','owned_thread_missing');end if;
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 a:=coalesce(a,'{"version":0,"epoch":0}'::jsonb);
 select value into r from career_watch_kv where user_id=p_user and key='career:turn:'||p_thread||':'||p_key;
 if r is not null then
  if r->>'hash'<>p_hash then return jsonb_build_object('error','turn_key_conflict');end if;
  if coalesce((r->>'epoch')::bigint,0)<>coalesce((a->>'epoch')::bigint,0) or r->'response' is null or r->'response'='null'::jsonb then return jsonb_build_object('error','privacy_epoch_changed');end if;
  return jsonb_build_object('replay',r->'response');
 end if;
 select state->'career' into f from agent_flow_state where thread_id=p_thread and user_id=p_user;
 select value into w from career_watch_kv where user_id=p_user and key='career:watch-profile:'||p_user;
 if w is null and coalesce((a->>'epoch')::bigint,0)=0 then
  select count(distinct state#>array['career','stores','alertWatchState','career:watch-profile:'||p_user]) into legacy_count
   from agent_flow_state where user_id=p_user and state#>>array['career','stores','alertWatchState','career:watch-profile:'||p_user,'user_id']=p_user::text;
  if legacy_count>1 then return jsonb_build_object('error','watch_profile_conflict');end if;
  select state#>array['career','stores','alertWatchState','career:watch-profile:'||p_user] into w from agent_flow_state
   where user_id=p_user and state#>>array['career','stores','alertWatchState','career:watch-profile:'||p_user,'user_id']=p_user::text limit 1;
 end if;
 if w is not null and w->>'user_id' is distinct from p_user::text then return jsonb_build_object('error','watch_profile_conflict');end if;
 select coalesce(jsonb_agg(record),'[]'::jsonb) into reminders from (select record from career_reminder_outbox where user_id=p_user and status='delivered' and seen_at is null order by delivered_at,reminder_id limit 5) q;
 return jsonb_build_object('snapshot',f,'revision',coalesce((f->>'revision')::bigint,0),'accountVersion',coalesce((a->>'version')::bigint,0),'account',a,
  'watchState',case when w is null then '{}'::jsonb else jsonb_build_object('career:watch-profile:'||p_user,w) end,'reminders',reminders);
end $_$;


--
-- Name: career_reminder_ack(uuid, text, uuid, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_reminder_ack(p_user uuid, p_id text, p_lease uuid, p_record jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare r career_reminder_outbox; a jsonb; ledger jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 select * into r from career_reminder_outbox where user_id=p_user and reminder_id=p_id for update;
 if not found then raise exception 'missing reminder';end if;
 if r.status='delivered' and r.lease_token=p_lease then return jsonb_build_object('status','delivered','record',r.record);end if;
 if r.lease_token is distinct from p_lease or r.status not in ('claimed','uncertain') or a->'paused'='true'::jsonb or not career_reminder_allowed(p_user,r.payload) then raise exception 'reminder acknowledgement unavailable';end if;
 if p_record->>'user_id' is distinct from p_user::text or p_record->>'reminder_id' is distinct from p_id or p_record->>'channel' is distinct from 'product_inbox' or p_record->'deadline' is distinct from r.payload->'deadline' or p_record->>'url' is distinct from r.payload->>'url' or p_record->>'job_id' is distinct from r.payload->>'job_id' or p_record->>'title' is distinct from r.payload->>'title' or p_record->>'company' is distinct from r.payload->>'company' or p_record->'fit_lines' is distinct from coalesce(r.payload#>'{fit,lines}','[]'::jsonb) or p_record->'matched_fact_ids' is distinct from coalesce(r.payload#>'{fit,matched_fact_ids}','[]'::jsonb) then raise exception 'reminder evidence mismatch';end if;
 p_record:=p_record||jsonb_build_object('provenance',jsonb_build_object('kind','career_reminder_outbox','version',1,'payload_sha256',encode(sha256(convert_to(r.payload::text,'UTF8')),'hex')));
 update career_reminder_outbox set status='delivered',record=p_record,delivered_at=now(),updated_at=now() where user_id=p_user and reminder_id=p_id;
 select value into ledger from career_watch_kv where user_id=p_user and key='career:delivery-ledger:'||p_user;
 ledger:=coalesce(ledger,jsonb_build_object('user_id',p_user,'delivered_ids','[]'::jsonb,'records','[]'::jsonb));
 ledger:=ledger||jsonb_build_object('delivered_ids',coalesce(ledger->'delivered_ids','[]'::jsonb)||jsonb_build_array(p_id),'records',coalesce(ledger->'records','[]'::jsonb)||jsonb_build_array(p_record));
 insert into career_watch_kv(user_id,key,value)values(p_user,'career:delivery-ledger:'||p_user,ledger)on conflict(user_id,key)do update set value=excluded.value,updated_at=now();
 return jsonb_build_object('status','delivered','record',p_record);
end $$;


--
-- Name: career_reminder_allowed(uuid, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_reminder_allowed(p_user uuid, p_reminder jsonb) RETURNS boolean
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select exists(select 1 from career_watch_kv w where user_id=p_user and key='career:watch-profile:'||p_user
 and w.value->>'user_id'=p_user::text and coalesce(w.value#>'{opt_out,global}','false'::jsonb)<>'true'::jsonb
 and exists(select 1 from jsonb_array_elements(coalesce(w.value->'interests','[]'::jsonb)) i where i->>'interest_id'=p_reminder->>'interest_id')
 and not exists(select 1 from jsonb_array_elements_text(coalesce(w.value#>'{opt_out,companies}','[]'::jsonb)) c where lower(c)=lower(p_reminder->>'company')));
$$;


--
-- Name: career_reminder_claim(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_reminder_claim(p_user uuid, p_id text) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare r career_reminder_outbox; a jsonb; token uuid;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 select * into r from career_reminder_outbox where user_id=p_user and reminder_id=p_id for update;
 if not found then return jsonb_build_object('status','missing','claimed',false);end if;
 if (a->'paused'='true'::jsonb or not career_reminder_allowed(p_user,r.payload)) and r.status in ('pending','claimed','uncertain') then update career_reminder_outbox set status='cancelled',updated_at=now() where user_id=p_user and reminder_id=p_id;return jsonb_build_object('status','cancelled','claimed',false);end if;
 if r.status='claimed' and r.lease_until<now() then update career_reminder_outbox set status='uncertain',updated_at=now() where user_id=p_user and reminder_id=p_id;return jsonb_build_object('status','uncertain','claimed',false);end if;
 if r.status<>'pending' then return jsonb_build_object('status',r.status,'claimed',false,'record',r.record);end if;
 token:=gen_random_uuid();update career_reminder_outbox set status='claimed',lease_token=token,lease_until=now()+interval '1 minute',attempts=attempts+1,updated_at=now() where user_id=p_user and reminder_id=p_id;
 return jsonb_build_object('status','claimed','claimed',true,'leaseToken',token,'reminder',r.payload);
end $$;


--
-- Name: career_reminder_enqueue(uuid, jsonb, bigint, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_reminder_enqueue(p_user uuid, p_reminder jsonb, p_version bigint, p_epoch bigint) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare a jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 if coalesce((a->>'version')::bigint,0) is distinct from p_version or coalesce((a->>'epoch')::bigint,0) is distinct from p_epoch or a->'paused'='true'::jsonb then raise exception 'stale or paused career worker';end if;
 if p_user is null or p_reminder is null or jsonb_typeof(p_reminder)<>'object' or p_reminder->>'user_id' is distinct from p_user::text or coalesce(length(p_reminder->>'reminder_id'),0) not between 1 and 200 or octet_length(p_reminder::text)>100000 then raise exception 'invalid reminder owner';end if;
 if exists(select 1 from career_reminder_outbox where user_id=p_user and reminder_id=p_reminder->>'reminder_id') then return jsonb_build_object('stored',true);end if;
 if not career_reminder_allowed(p_user,p_reminder) then raise exception 'inactive reminder interest';end if;
 insert into career_reminder_outbox(user_id,reminder_id,payload)values(p_user,p_reminder->>'reminder_id',p_reminder)on conflict(user_id,reminder_id)do nothing;
 return jsonb_build_object('stored',true);
end $$;


--
-- Name: career_reminder_list(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_reminder_list(p_user uuid) RETURNS jsonb
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select jsonb_build_object('reminders',coalesce(jsonb_agg(payload),'[]'::jsonb)) from (select payload from career_reminder_outbox where user_id=p_user and status in ('pending','claimed','uncertain') and payload is not null order by created_at,reminder_id limit 100) q;
$$;


--
-- Name: career_reminder_status(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_reminder_status(p_user uuid, p_id text) RETURNS jsonb
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select jsonb_build_object('status',status,'record',record,'leaseToken',lease_token,'reminder',payload) from career_reminder_outbox where user_id=p_user and reminder_id=p_id;
$$;


--
-- Name: career_watch_cycle_commit(uuid, bigint, bigint, jsonb, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_watch_cycle_commit(p_user uuid, p_version bigint, p_epoch bigint, p_writes jsonb, p_reminders jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare a jsonb; entry record; reminder jsonb; saved jsonb; version bigint:=p_version;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select value into a from career_watch_kv where user_id=p_user and key='career:account';
 if coalesce((a->>'version')::bigint,0) is distinct from p_version or coalesce((a->>'epoch')::bigint,0) is distinct from p_epoch or a->'paused'='true'::jsonb then raise exception 'stale or paused career worker';end if;
 if p_writes is null or jsonb_typeof(p_writes)<>'object' or p_reminders is null or jsonb_typeof(p_reminders)<>'array' or octet_length(p_writes::text)>4194304 or jsonb_array_length(p_reminders)>1000 then raise exception 'invalid career cycle';end if;
 for entry in select key,value from jsonb_each(p_writes) loop
  saved:=career_watch_write(p_user,entry.key,entry.value,version,p_epoch);version:=(saved->>'version')::bigint;
 end loop;
 for reminder in select value from jsonb_array_elements(p_reminders) loop perform career_reminder_enqueue(p_user,reminder,version,p_epoch);end loop;
 return jsonb_build_object('version',version,'epoch',p_epoch);
end $$;


--
-- Name: career_watch_read(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_watch_read(p_user uuid, p_key text) RETURNS jsonb
    LANGUAGE sql
    SET search_path TO 'public', 'pg_temp'
    AS $$
 select jsonb_build_object('value',(select value from career_watch_kv where user_id=p_user and key=p_key),'version',coalesce((a.value->>'version')::bigint,0),'epoch',coalesce((a.value->>'epoch')::bigint,0),'paused',coalesce((a.value->>'paused')::boolean,false))
 from (select (select value from career_watch_kv where user_id=p_user and key='career:account') value) a;
$$;


--
-- Name: career_watch_write(uuid, text, jsonb, bigint, bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.career_watch_write(p_user uuid, p_key text, p_value jsonb, p_version bigint, p_epoch bigint) RETURNS jsonb
    LANGUAGE plpgsql
    SET search_path TO 'public', 'pg_temp'
    AS $$
declare a jsonb;
begin
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,0));
 select value into a from career_watch_kv where user_id=p_user and key='career:account';a:=coalesce(a,'{"version":0,"epoch":0}'::jsonb);
 if (a->>'version')::bigint is distinct from p_version or (a->>'epoch')::bigint is distinct from p_epoch or a->'paused'='true'::jsonb then raise exception 'stale or paused career worker';end if;
 if p_user is null or p_key is null or not (p_key in ('career:watch-profile:'||p_user,'career:reminder-queue:'||p_user,'career:reminder-history:'||p_user) or (p_key like 'career:jobs:snapshot:board:%' and right(p_key,37)=':'||p_user)) or p_value is null or octet_length(p_value::text)>1048576 then raise exception 'invalid watch state';end if;
 if p_key='career:watch-profile:'||p_user and p_value->>'user_id' is distinct from p_user::text then raise exception 'watch owner mismatch';end if;
 insert into career_watch_kv(user_id,key,value) values(p_user,p_key,p_value) on conflict(user_id,key) do update set value=excluded.value,updated_at=now();
 a:=a||jsonb_build_object('version',p_version+1);
 insert into career_watch_kv(user_id,key,value) values(p_user,'career:account',a) on conflict(user_id,key) do update set value=excluded.value,updated_at=now();
 return jsonb_build_object('version',p_version+1,'epoch',p_epoch);
end $$;


--
-- Name: recovery_reject_save(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.recovery_reject_save() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ begin if current_setting('recovery.fail_save',true)='1' then raise exception 'FROZEN RECOVERY SAVE FAULT';end if;return NEW;end $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    id uuid NOT NULL
);


--
-- Name: agent_flow_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_flow_state (
    thread_id uuid NOT NULL,
    user_id uuid NOT NULL,
    state jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_flow_state_state_check CHECK ((jsonb_typeof(state) = 'object'::text)),
    CONSTRAINT agent_flow_state_state_check1 CHECK ((pg_column_size(state) < 524288)),
    CONSTRAINT agent_flow_state_state_check2 CHECK ((NOT ((state)::text ~* '"(otp|one_time_code|password|passcode|card_number|pan|cvv|ssn)"\s*:'::text)))
);


--
-- Name: agent_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    thread_id uuid NOT NULL,
    role text,
    content text,
    meta jsonb,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT agent_messages_role_check CHECK ((role = ANY (ARRAY['user'::text, 'assistant'::text, 'system'::text])))
);


--
-- Name: agent_threads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_threads (
    id uuid NOT NULL,
    user_id uuid NOT NULL
);


--
-- Name: career_reminder_outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.career_reminder_outbox (
    user_id uuid NOT NULL,
    reminder_id text NOT NULL,
    payload jsonb,
    record jsonb,
    status text DEFAULT 'pending'::text NOT NULL,
    lease_token uuid,
    lease_until timestamp with time zone,
    attempts integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    delivered_at timestamp with time zone,
    seen_at timestamp with time zone,
    CONSTRAINT career_reminder_outbox_reminder_id_check CHECK (((length(reminder_id) >= 1) AND (length(reminder_id) <= 200))),
    CONSTRAINT career_reminder_outbox_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'claimed'::text, 'uncertain'::text, 'delivered'::text, 'cancelled'::text])))
);


--
-- Name: career_watch_kv; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.career_watch_kv (
    user_id uuid NOT NULL,
    key text NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE career_watch_kv; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.career_watch_kv IS 'MI-032 alerts host wiring: generic per-user KV for the career watch/assign state (152 watch profiles, reminder queues, seat history; 151 per-board snapshots; host delivery ledger). Written/read by scripts/career/alerts-host.mjs createSupabaseStore via the service role. Design: docs/career/alerts-host-wiring.md.';


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profiles (
    id uuid NOT NULL
);


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (id) FROM stdin;
00000000-0000-4000-8000-000000000001
\.


--
-- Data for Name: agent_flow_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_flow_state (thread_id, user_id, state, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000113	00000000-0000-4000-8000-000000000001	{"career": {"v": 1, "scope": {"userId": "00000000-0000-4000-8000-000000000001"}, "stores": {"plan": {"at": "2026-10-16T00:48:28.234Z", "days": 0, "kind": "campaign_plan", "count": 40, "firms": ["Quartz Studio"], "target": {"count": 40, "firms": ["Quartz Studio"], "vague": false, "firm_set": null, "industry": "investment_banking", "geography": "Austin", "exclusions": ["geo:EU_UK"], "firms_named": true, "role_family": "investment_banking", "role_phrase": null, "count_source": "default", "firms_source": "named", "school_filter": null, "seniority_band": null, "proposed_default": null, "background_filters": {}}, "lastAsk": "I want to network into Quartz Studio in Austin.", "purpose": null, "deferred": [], "firm_set": null, "scheduled": 0, "firms_named": true, "role_family": "investment_banking", "firms_source": "named"}, "profile": {"facts": [{"end": "2028-05", "org": "Synthetic University", "kind": "education", "text": "Junior B.A. Economics at Synthetic University, graduating May 2028", "title": "B.A. Economics", "fact_id": "REC-E1", "evidence": ["synthetic fixture supplied education"], "unproven": false}, {"kind": "skill", "name": "Python", "text": "Class Python CSV parser", "fact_id": "REC-S1", "evidence": ["synthetic class project"], "unproven": false}], "basics": {"name": "Synthetic Recovery Learner", "location": "Chicago, IL"}, "constraints": {}, "preferences": {"locations": ["Denver"], "starredCompanies": []}, "_careerTrackStore": {"rows": [], "_careerThread": {"plan": {"at": "2026-10-16T00:48:28.234Z", "days": 0, "kind": "campaign_plan", "count": 40, "firms": ["Quartz Studio"], "target": {"count": 40, "firms": ["Quartz Studio"], "vague": false, "firm_set": null, "industry": "investment_banking", "geography": "Austin", "exclusions": ["geo:EU_UK"], "firms_named": true, "role_family": "investment_banking", "role_phrase": null, "count_source": "default", "firms_source": "named", "school_filter": null, "seniority_band": null, "proposed_default": null, "background_filters": {}}, "lastAsk": "I want to network into Quartz Studio in Austin.", "purpose": null, "deferred": [], "firm_set": null, "scheduled": 0, "firms_named": true, "role_family": "investment_banking", "firms_source": "named"}, "facts": {"facts": [{"at": "2026-10-16T00:48:28.234Z", "kind": "geography", "value": "Austin", "evidence": "in Austin"}, {"at": "2026-10-16T00:48:28.234Z", "kind": "target_firm", "value": "Quartz Studio", "evidence": "network into Quartz Studio"}], "updatedAt": "2026-10-16T00:48:28.234Z"}}}}, "trackStore": {"rows": [], "_careerThread": {"plan": {"at": "2026-10-16T00:48:28.234Z", "days": 0, "kind": "campaign_plan", "count": 40, "firms": ["Quartz Studio"], "target": {"count": 40, "firms": ["Quartz Studio"], "vague": false, "firm_set": null, "industry": "investment_banking", "geography": "Austin", "exclusions": ["geo:EU_UK"], "firms_named": true, "role_family": "investment_banking", "role_phrase": null, "count_source": "default", "firms_source": "named", "school_filter": null, "seniority_band": null, "proposed_default": null, "background_filters": {}}, "lastAsk": "I want to network into Quartz Studio in Austin.", "purpose": null, "deferred": [], "firm_set": null, "scheduled": 0, "firms_named": true, "role_family": "investment_banking", "firms_source": "named"}, "facts": {"facts": [{"at": "2026-10-16T00:48:28.234Z", "kind": "geography", "value": "Austin", "evidence": "in Austin"}, {"at": "2026-10-16T00:48:28.234Z", "kind": "target_firm", "value": "Quartz Studio", "evidence": "network into Quartz Studio"}], "updatedAt": "2026-10-16T00:48:28.234Z"}}}, "statedFacts": {"facts": [{"at": "2026-10-16T00:48:28.234Z", "kind": "geography", "value": "Austin", "evidence": "in Austin"}, {"at": "2026-10-16T00:48:28.234Z", "kind": "target_firm", "value": "Quartz Studio", "evidence": "network into Quartz Studio"}], "updatedAt": "2026-10-16T00:48:28.234Z"}}, "revision": 3, "privacy_epoch": 0}}	2026-10-16 00:48:32.132344+00
\.


--
-- Data for Name: agent_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_messages (id, thread_id, role, content, meta, created_at) FROM stdin;
0ddbc445-9551-47a1-b6b7-435beaac0b55	00000000-0000-4000-8000-000000000113	user	I want to network into Quartz Studio in Austin.	\N	2026-10-16 00:48:28.367509+00
53fa899d-0c88-4599-a860-04c80ce1b1a7	00000000-0000-4000-8000-000000000113	assistant	Building the list now: investment bankers at Quartz Studio in Austin — sized by what the sources yield, not by a number invented here.\nOne firm, so the per-firm cap shapes the waves: at most 15 first emails to Quartz Studio in any 30 days — the rest run in later monthly waves, planned that way from the start. Sources, in order: your own LinkedIn export, names you paste, your school's alumni directory, and firm team pages — every name carries its source, and nobody is emailed on a guessed address. The found, trustworthy, and sendable counts come back here before a single draft exists, and drafting starts only when you approve the whole plan.	{"career": true, "intent": "outreach_clarification", "contained": false, "result_status": "awaiting_user", "career_turn_key": "C12-1"}	2026-10-16 00:48:28.367509+00
d799661f-7d59-4002-933f-cca5709a7095	00000000-0000-4000-8000-000000000113	user	Actually, my preferred location is Denver.	\N	2026-10-16 00:48:30.090196+00
85fc8e7f-e08a-4c8e-b1bb-38206c5fefd2	00000000-0000-4000-8000-000000000113	assistant	I saved your preferred location as Denver. Existing application approvals and watch locations were not silently rewritten; review those separately.	{"career": true, "intent": "career_preference_corrected", "contained": false, "career_turn_key": "save-fault"}	2026-10-16 00:48:30.090196+00
af517d2c-9ea3-4904-8e70-8312f9521ba6	00000000-0000-4000-8000-000000000113	user	Recap my target city after the failed save and the successful retry.	\N	2026-10-16 00:48:32.132344+00
4eedec1c-5e18-4c1b-9fa9-6a1b8bb5cd9f	00000000-0000-4000-8000-000000000113	assistant	Where we landed, from this thread's own record.\nThe outreach plan stands targeting Quartz Studio in Austin — no list built yet, no sends, everything waits on your approval of the whole plan. Your facts on record: you're targeting Austin; your target firm is Quartz Studio. Name the piece to move next and it runs from exactly this state.	{"career": true, "intent": "career_guidance", "contained": false, "result_status": "awaiting_user", "career_turn_key": "C12-6"}	2026-10-16 00:48:32.132344+00
\.


--
-- Data for Name: agent_threads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_threads (id, user_id) FROM stdin;
00000000-0000-4000-8000-000000000113	00000000-0000-4000-8000-000000000001
\.


--
-- Data for Name: career_reminder_outbox; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.career_reminder_outbox (user_id, reminder_id, payload, record, status, lease_token, lease_until, attempts, created_at, updated_at, delivered_at, seen_at) FROM stdin;
\.


--
-- Data for Name: career_watch_kv; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.career_watch_kv (user_id, key, value, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000001	career:turn:00000000-0000-4000-8000-000000000113:C12-1	{"hash": "e1605cc69bd485d8b66365ff23191151efacce66792949236850a7e2f29a9e2c", "epoch": 0, "response": {"meta": {"career": true, "intent": "outreach_clarification", "contained": false, "result_status": "awaiting_user"}, "reply": "Building the list now: investment bankers at Quartz Studio in Austin — sized by what the sources yield, not by a number invented here.\\nOne firm, so the per-firm cap shapes the waves: at most 15 first emails to Quartz Studio in any 30 days — the rest run in later monthly waves, planned that way from the start. Sources, in order: your own LinkedIn export, names you paste, your school's alumni directory, and firm team pages — every name carries its source, and nobody is emailed on a guessed address. The found, trustworthy, and sendable counts come back here before a single draft exists, and drafting starts only when you approve the whole plan.", "action": null, "turn_key": "C12-1", "reminders": [], "thread_id": "00000000-0000-4000-8000-000000000113", "capabilities": {"portal_browser": {"reason": "The Node browser worker is not connected to this Edge handler.", "status": "NOT_WIRED"}, "job_alert_delivery": {"reason": "No alert scheduler or delivery worker is connected to this Edge handler. Saving a watch does not start polling or deliver reminders.", "status": "NOT_WIRED"}}}}	2026-10-16 00:48:28.367509+00
00000000-0000-4000-8000-000000000001	career:turn:00000000-0000-4000-8000-000000000113:save-fault	{"hash": "e11510216e60ac779d106d25051b430860f4732bc12f5531735460e1f718f8a5", "epoch": 0, "response": {"meta": {"career": true, "intent": "career_preference_corrected", "contained": false}, "reply": "I saved your preferred location as Denver. Existing application approvals and watch locations were not silently rewritten; review those separately.", "action": null, "turn_key": "save-fault", "reminders": [], "thread_id": "00000000-0000-4000-8000-000000000113", "capabilities": {"portal_browser": {"reason": "The Node browser worker is not connected to this Edge handler.", "status": "NOT_WIRED"}, "job_alert_delivery": {"reason": "No alert scheduler or delivery worker is connected to this Edge handler. Saving a watch does not start polling or deliver reminders.", "status": "NOT_WIRED"}}}}	2026-10-16 00:48:30.090196+00
00000000-0000-4000-8000-000000000001	career:account	{"epoch": 0, "version": 3, "preferred_locations": ["Denver"]}	2026-10-16 00:48:32.132344+00
00000000-0000-4000-8000-000000000001	career:turn:00000000-0000-4000-8000-000000000113:C12-6	{"hash": "77e05b26922dc392d3c00473e8fd733a87a648b51cc3a46ff5fca285068c3e13", "epoch": 0, "response": {"meta": {"career": true, "intent": "career_guidance", "contained": false, "result_status": "awaiting_user"}, "reply": "Where we landed, from this thread's own record.\\nThe outreach plan stands targeting Quartz Studio in Austin — no list built yet, no sends, everything waits on your approval of the whole plan. Your facts on record: you're targeting Austin; your target firm is Quartz Studio. Name the piece to move next and it runs from exactly this state.", "action": null, "turn_key": "C12-6", "reminders": [], "thread_id": "00000000-0000-4000-8000-000000000113", "capabilities": {"portal_browser": {"reason": "The Node browser worker is not connected to this Edge handler.", "status": "NOT_WIRED"}, "job_alert_delivery": {"reason": "No alert scheduler or delivery worker is connected to this Edge handler. Saving a watch does not start polling or deliver reminders.", "status": "NOT_WIRED"}}}}	2026-10-16 00:48:32.132344+00
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.profiles (id) FROM stdin;
00000000-0000-4000-8000-000000000001
\.


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: agent_flow_state agent_flow_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_flow_state
    ADD CONSTRAINT agent_flow_state_pkey PRIMARY KEY (thread_id);


--
-- Name: agent_messages agent_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_messages
    ADD CONSTRAINT agent_messages_pkey PRIMARY KEY (id);


--
-- Name: agent_threads agent_threads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_threads
    ADD CONSTRAINT agent_threads_pkey PRIMARY KEY (id);


--
-- Name: career_reminder_outbox career_reminder_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_reminder_outbox
    ADD CONSTRAINT career_reminder_outbox_pkey PRIMARY KEY (user_id, reminder_id);


--
-- Name: career_watch_kv career_watch_kv_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_watch_kv
    ADD CONSTRAINT career_watch_kv_pkey PRIMARY KEY (user_id, key);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: career_reminder_unseen; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX career_reminder_unseen ON public.career_reminder_outbox USING btree (user_id, delivered_at) WHERE ((status = 'delivered'::text) AND (seen_at IS NULL));


--
-- Name: agent_flow_state recovery_save_fault; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER recovery_save_fault BEFORE INSERT OR UPDATE ON public.agent_flow_state FOR EACH ROW EXECUTE FUNCTION public.recovery_reject_save();


--
-- Name: agent_flow_state agent_flow_state_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_flow_state
    ADD CONSTRAINT agent_flow_state_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.agent_threads(id) ON DELETE CASCADE;


--
-- Name: agent_flow_state agent_flow_state_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_flow_state
    ADD CONSTRAINT agent_flow_state_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: agent_messages agent_messages_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_messages
    ADD CONSTRAINT agent_messages_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.agent_threads(id);


--
-- Name: agent_threads agent_threads_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_threads
    ADD CONSTRAINT agent_threads_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id);


--
-- Name: career_reminder_outbox career_reminder_outbox_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_reminder_outbox
    ADD CONSTRAINT career_reminder_outbox_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: career_watch_kv career_watch_kv_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_watch_kv
    ADD CONSTRAINT career_watch_kv_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: profiles profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id);


--
-- Name: career_reminder_outbox career_reminder_backend; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY career_reminder_backend ON public.career_reminder_outbox TO service_role USING (true) WITH CHECK (true);


--
-- Name: career_reminder_outbox; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.career_reminder_outbox ENABLE ROW LEVEL SECURITY;

--
-- Name: career_watch_kv career_watch_backend; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY career_watch_backend ON public.career_watch_kv TO service_role USING (true) WITH CHECK (true);


--
-- Name: career_watch_kv; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.career_watch_kv ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict dvZ3aCneHINm9ikzzNb5Lm57uoH4SawnpQH16r3wnbX0UF66OO3NMTpZns6hW3s

