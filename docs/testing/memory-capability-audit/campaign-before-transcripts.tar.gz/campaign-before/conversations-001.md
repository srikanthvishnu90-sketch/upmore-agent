# conversations-001

All conversations are synthetic. Full production handler, mock authentication/PostgREST and disabled model; no real outbound messages or provider actions.

## C00001 · M01 · Confirmed nickname recalls the right person · PASS

Expected: [{"say":"save alex as brother"},{"say":"yes"},{"say":"send brother 20","match":"Alex Kim.*@alexk","outcome":"confirm"}]

### Trial 1

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Alex Kim (brother, @alexk).

User: send brother 20

Upmore: Set up $20.00 to Alex Kim (brother, @alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Alex Kim (brother, @alexk).

User: send brother 20

Upmore: Set up $20.00 to Alex Kim (brother, @alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Alex Kim (brother, @alexk).

User: send brother 20

Upmore: Set up $20.00 to Alex Kim (brother, @alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00002 · M02 · Explicit remember phrasing persists an alias · PASS

Expected: [{"say":"remember Rhea Rao as my sister"},{"say":"yes"},{"say":"send sister 25","match":"Rhea Rao.*@rhear","outcome":"confirm"}]

### Trial 1

User: remember Rhea Rao as my sister

Upmore: Save "sister" as your name for Rhea Rao (@rhear)? Then "send sister 20" goes to Rhea Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Rhea Rao (sister, @rhear).

User: send sister 25

Upmore: Set up $25.00 to Rhea Rao (sister, @rhear) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: remember Rhea Rao as my sister

Upmore: Save "sister" as your name for Rhea Rao (@rhear)? Then "send sister 20" goes to Rhea Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Rhea Rao (sister, @rhear).

User: send sister 25

Upmore: Set up $25.00 to Rhea Rao (sister, @rhear) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: remember Rhea Rao as my sister

Upmore: Save "sister" as your name for Rhea Rao (@rhear)? Then "send sister 20" goes to Rhea Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Rhea Rao (sister, @rhear).

User: send sister 25

Upmore: Set up $25.00 to Rhea Rao (sister, @rhear) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00003 · M03 · Natural relationship statement needs confirmation and persists · PASS

Expected: [{"say":"my dad is Alex Kim","match":"Save"},{"say":"yes"},{"say":"send dad 30","match":"Alex Kim","outcome":"confirm"}]

### Trial 1

User: my dad is Alex Kim

Upmore: Save "dad" as your name for Alex Kim (@alexk)? Then "send dad 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Alex Kim (dad, @alexk).

User: send dad 30

Upmore: Set up $30.00 to Alex Kim (dad, @alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: my dad is Alex Kim

Upmore: Save "dad" as your name for Alex Kim (@alexk)? Then "send dad 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Alex Kim (dad, @alexk).

User: send dad 30

Upmore: Set up $30.00 to Alex Kim (dad, @alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: my dad is Alex Kim

Upmore: Save "dad" as your name for Alex Kim (@alexk)? Then "send dad 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Alex Kim (dad, @alexk).

User: send dad 30

Upmore: Set up $30.00 to Alex Kim (dad, @alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00004 · M04 · An alias is moved only to the newly confirmed person · PASS

Expected: [{"say":"save alex as brother"},{"say":"yes"},{"say":"brother is Rhea Rao"},{"say":"yes"},{"say":"send brother 20","match":"Rhea Rao","outcome":"confirm"}]

### Trial 1

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Alex Kim (brother, @alexk).

User: brother is Rhea Rao

Upmore: Save "brother" as your name for Rhea Rao (@rhear)? Then "send brother 20" goes to Rhea Rao. "brother" means Alex Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Rhea Rao (brother, @rhear).

User: send brother 20

Upmore: Set up $20.00 to Rhea Rao (brother, @rhear) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Alex Kim (brother, @alexk).

User: brother is Rhea Rao

Upmore: Save "brother" as your name for Rhea Rao (@rhear)? Then "send brother 20" goes to Rhea Rao. "brother" means Alex Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Rhea Rao (brother, @rhear).

User: send brother 20

Upmore: Set up $20.00 to Rhea Rao (brother, @rhear) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Alex Kim (brother, @alexk).

User: brother is Rhea Rao

Upmore: Save "brother" as your name for Rhea Rao (@rhear)? Then "send brother 20" goes to Rhea Rao. "brother" means Alex Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Rhea Rao (brother, @rhear).

User: send brother 20

Upmore: Set up $20.00 to Rhea Rao (brother, @rhear) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00005 · M05 · Rejected alias preserves the previous confirmed fact · PASS

Expected: [{"say":"save alex as brother"},{"say":"yes"},{"say":"brother is Rhea Rao"},{"say":"no"},{"say":"send brother 20","match":"Alex Kim","outcome":"confirm"}]

### Trial 1

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Alex Kim (brother, @alexk).

User: brother is Rhea Rao

Upmore: Save "brother" as your name for Rhea Rao (@rhear)? Then "send brother 20" goes to Rhea Rao. "brother" means Alex Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 20

Upmore: Set up $20.00 to Alex Kim (brother, @alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Alex Kim (brother, @alexk).

User: brother is Rhea Rao

Upmore: Save "brother" as your name for Rhea Rao (@rhear)? Then "send brother 20" goes to Rhea Rao. "brother" means Alex Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 20

Upmore: Set up $20.00 to Alex Kim (brother, @alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Alex Kim (brother, @alexk).

User: brother is Rhea Rao

Upmore: Save "brother" as your name for Rhea Rao (@rhear)? Then "send brother 20" goes to Rhea Rao. "brother" means Alex Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 20

Upmore: Set up $20.00 to Alex Kim (brother, @alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00006 · M06 · Amount correction preserves payee and replaces the old card · PASS

Expected: [{"say":"send alex 20"},{"say":"make it 35","match":"35.00.*Alex Kim","outcome":"confirm"},{"say":"yes","match":"35.00","outcome":"staged"},{"state":"state.send.sends.0.amount_cents","equals":3500}]

### Trial 1

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 35

Upmore: Got it. Set up $35.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $35.00; 4. Keep it private, then Pay. I'll confirm when $35.00 to Alex Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 35

Upmore: Got it. Set up $35.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $35.00; 4. Keep it private, then Pay. I'll confirm when $35.00 to Alex Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 35

Upmore: Got it. Set up $35.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $35.00; 4. Keep it private, then Pay. I'll confirm when $35.00 to Alex Kim posts; if it hasn't by tonight, I'll ask.

## C00007 · M07 · Actually correction handles a different amount · PASS

Expected: [{"say":"send alex 20"},{"say":"actually make it 50","match":"50.00.*Alex Kim","outcome":"confirm"},{"say":"yes","match":"50.00","outcome":"staged"}]

### Trial 1

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 50

Upmore: Got it. Set up $50.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $50.00; 4. Keep it private, then Pay. I'll confirm when $50.00 to Alex Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 50

Upmore: Got it. Set up $50.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $50.00; 4. Keep it private, then Pay. I'll confirm when $50.00 to Alex Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 50

Upmore: Got it. Set up $50.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $50.00; 4. Keep it private, then Pay. I'll confirm when $50.00 to Alex Kim posts; if it hasn't by tonight, I'll ask.

## C00008 · M08 · Bare currency correction retains payment context · PASS

Expected: [{"say":"send alex 20"},{"say":"$12.50 instead","match":"12.50.*Alex Kim","outcome":"confirm"},{"say":"yes","match":"12.50","outcome":"staged"}]

### Trial 1

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $12.50 instead

Upmore: Got it. Set up $12.50 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $12.50; 4. Keep it private, then Pay. I'll confirm when $12.50 to Alex Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $12.50 instead

Upmore: Got it. Set up $12.50 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $12.50; 4. Keep it private, then Pay. I'll confirm when $12.50 to Alex Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $12.50 instead

Upmore: Got it. Set up $12.50 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $12.50; 4. Keep it private, then Pay. I'll confirm when $12.50 to Alex Kim posts; if it hasn't by tonight, I'll ask.

## C00009 · M09 · Split total correction recomputes every share before approval · PASS

Expected: [{"say":"split 60 with alex and rhea"},{"say":"make it 90","match":"30.00 each.*90.00","outcome":"confirm"},{"say":"yes","match":"30.00","outcome":"staged"}]

### Trial 1

User: split 60 with alex and rhea

Upmore: Request $20.00 each from Alex Kim (@alexk) and Rhea Rao (@rhear) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 90

Upmore: Got it. Request $30.00 each from Alex Kim (@alexk) and Rhea Rao (@rhear) in Venmo: $90.00 split 3 ways, yours $30.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Alex Kim (@alexk) $30.00 in Venmo, Rhea Rao (@rhear) $30.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 60 with alex and rhea

Upmore: Request $20.00 each from Alex Kim (@alexk) and Rhea Rao (@rhear) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 90

Upmore: Got it. Request $30.00 each from Alex Kim (@alexk) and Rhea Rao (@rhear) in Venmo: $90.00 split 3 ways, yours $30.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Alex Kim (@alexk) $30.00 in Venmo, Rhea Rao (@rhear) $30.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 60 with alex and rhea

Upmore: Request $20.00 each from Alex Kim (@alexk) and Rhea Rao (@rhear) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 90

Upmore: Got it. Request $30.00 each from Alex Kim (@alexk) and Rhea Rao (@rhear) in Venmo: $90.00 split 3 ways, yours $30.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Alex Kim (@alexk) $30.00 in Venmo, Rhea Rao (@rhear) $30.00 in Venmo. I'll mark each one paid when the money lands.

## C00010 · M10 · Rent setup correction retains recipient and due day · PASS

Expected: [{"say":"pay my rent"},{"say":"alex $900 on the 1st via Venmo"},{"say":"make it 950","match":"950.00.*Alex Kim.*1st","outcome":"confirm"},{"say":"yes"},{"state":"standing.0.amount_cents","equals":95000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 950

Upmore: Got it. Set up rent: $950.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $950.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 950

Upmore: Got it. Set up rent: $950.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $950.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 950

Upmore: Got it. Set up rent: $950.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $950.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

## C00011 · M11 · Details refers to the pending payment · PASS

Expected: [{"say":"send alex 20"},{"say":"details","match":"20.00.*Alex Kim","outcome":"details"}]

### Trial 1

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $20.00 to Alex Kim on Venmo $20.00 to Alex Kim (@alexk) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

### Trial 2

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $20.00 to Alex Kim on Venmo $20.00 to Alex Kim (@alexk) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

### Trial 3

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $20.00 to Alex Kim on Venmo $20.00 to Alex Kim (@alexk) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

## C00012 · M12 · A short yes resumes a serialized split · PASS

Expected: [{"say":"split 60 with alex and rhea"},{"say":"yes","match":"Alex Kim.*20.00.*Rhea Rao.*20.00","outcome":"staged"}]

### Trial 1

User: split 60 with alex and rhea

Upmore: Request $20.00 each from Alex Kim (@alexk) and Rhea Rao (@rhear) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Alex Kim (@alexk) $20.00 in Venmo, Rhea Rao (@rhear) $20.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 60 with alex and rhea

Upmore: Request $20.00 each from Alex Kim (@alexk) and Rhea Rao (@rhear) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Alex Kim (@alexk) $20.00 in Venmo, Rhea Rao (@rhear) $20.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 60 with alex and rhea

Upmore: Request $20.00 each from Alex Kim (@alexk) and Rhea Rao (@rhear) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Alex Kim (@alexk) $20.00 in Venmo, Rhea Rao (@rhear) $20.00 in Venmo. I'll mark each one paid when the money lands.

## C00013 · M13 · Cancellation that resolves the last discussed subscription · PASS

Expected: [{"say":"cancel netflix","match":"Netflix"},{"say":"cancel that","match":"Netflix"}]

### Trial 1

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 2

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 3

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

## C00014 · M14 · Stop rent refers to the confirmed standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"alex $900 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent","match":"Rent is off","outcome":"rent_stopped"},{"state":"standing.0.status","equals":"stopped"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Alex Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Alex Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Alex Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

## C00015 · M15 · A contextual fee question retains payment identity and asks before acting · PASS

Expected: [{"say":"send alex 20"},{"say":"what's the fee on that","match":"20.00.*Alex Kim"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $20.00 to Alex Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $20.00 to Alex Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $20.00 to Alex Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00016 · M16 · Rent setup answers retain the original goal · PASS

Expected: [{"say":"pay my rent","match":"Who"},{"say":"alex $900 on the 1st via Venmo","match":"900.00.*Alex Kim","outcome":"confirm"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"standing.0.payee_handle","equals":"@alexk"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

## C00017 · M17 · New recipient handle and rail answers retain amount · PASS

Expected: [{"say":"send Dana 25"},{"say":"@danak"},{"say":"@danak"},{"say":"Venmo"},{"say":"@danak","match":"25.00.*Dana","outcome":"confirm"}]

### Trial 1

User: send Dana 25

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $25.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: send Dana 25

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $25.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: send Dana 25

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $25.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00018 · M18 · Split remembers total while asking who participated · PASS

Expected: [{"say":"split 60 with 2 friends"},{"say":"alex and rhea","match":"20.00 each.*60.00","outcome":"confirm"}]

### Trial 1

User: split 60 with 2 friends

Upmore: That's $20.00 each across 3 people. Who are the 2? I'll request $20.00 from each.

User: alex and rhea

Upmore: Request $20.00 each from Alex Kim (@alexk) and Rhea Rao (@rhear) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: split 60 with 2 friends

Upmore: That's $20.00 each across 3 people. Who are the 2? I'll request $20.00 from each.

User: alex and rhea

Upmore: Request $20.00 each from Alex Kim (@alexk) and Rhea Rao (@rhear) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: split 60 with 2 friends

Upmore: That's $20.00 each across 3 people. Who are the 2? I'll request $20.00 from each.

User: alex and rhea

Upmore: Request $20.00 each from Alex Kim (@alexk) and Rhea Rao (@rhear) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

## C00019 · M19 · Rent is remembered on the next independent invocation · PASS

Expected: [{"say":"pay my rent"},{"say":"alex $900 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent","match":"900.00.*Alex Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $900.00 to Alex Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $900.00 to Alex Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $900.00 to Alex Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

## C00020 · M20 · An interrupted alias goal remains unconfirmed · PASS

Expected: [{"say":"save alex as brother"},{"say":"no"},{"state":"recipients.0.nickname","equals":null},{"say":"send brother 20","match":"handle","outcome":"ask"}]

### Trial 1

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 20

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 2

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 20

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 3

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 20

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

## C00021 · M21 · A staged payment is remembered without claiming completion · PASS

Expected: [{"say":"send alex 20"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Alex Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $20.00 to Alex Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 2

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Alex Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $20.00 to Alex Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 3

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Alex Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $20.00 to Alex Kim for you to send in Venmo. A second yes doesn't stage it again.

## C00022 · M22 · A staged split is remembered without duplicating it · PASS

Expected: [{"say":"split 60 with alex and rhea"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 60 with alex and rhea

Upmore: Request $20.00 each from Alex Kim (@alexk) and Rhea Rao (@rhear) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Alex Kim (@alexk) $20.00 in Venmo, Rhea Rao (@rhear) $20.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 60 with alex and rhea

Upmore: Request $20.00 each from Alex Kim (@alexk) and Rhea Rao (@rhear) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Alex Kim (@alexk) $20.00 in Venmo, Rhea Rao (@rhear) $20.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 60 with alex and rhea

Upmore: Request $20.00 each from Alex Kim (@alexk) and Rhea Rao (@rhear) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Alex Kim (@alexk) $20.00 in Venmo, Rhea Rao (@rhear) $20.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C00023 · M23 · A declined payment cannot be resurrected by yes · PASS

Expected: [{"say":"send alex 20"},{"say":"no","match":"Nothing","outcome":"declined"},{"say":"yes","not":"^Staged, not sent"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 2

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 3

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

## C00024 · M24 · Stopping rent prevents the next turn from claiming an active rule · PASS

Expected: [{"say":"pay my rent"},{"say":"alex $900 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Alex Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Alex Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Alex Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C00025 · M25 · Status follow-up recalls staged versus sent · PASS

Expected: [{"say":"send alex 20"},{"say":"yes"},{"say":"did it go through","match":"(?:not (?:yet )?(?:sent|posted)|staged|have not seen|waiting for.*post)"}]

### Trial 1

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Alex Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $20.00 to Alex Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

### Trial 2

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Alex Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $20.00 to Alex Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

### Trial 3

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Alex Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $20.00 to Alex Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

## C00026 · M26 · Unapproved nickname does not become a known fact · PASS

Expected: [{"say":"save alex as brother"},{"state":"recipients.0.nickname","equals":null},{"say":"no"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 2

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 3

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

## C00027 · M27 · Unapproved rent terms are not durable instructions · PASS

Expected: [{"say":"pay my rent"},{"say":"alex $900 on the 1st via Venmo"},{"state":"standing.length","equals":0},{"say":"no"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

## C00028 · M28 · An expired payment card is restated and requires a fresh yes · PASS

Expected: [{"say":"send alex 20"},{"minutes":11},{"say":"yes","match":"expired.*fresh","outcome":"confirm"},{"state":"state.send.sends.length","equals":0},{"say":"yes","match":"Staged","outcome":"staged"}]

### Trial 1

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Alex Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Alex Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Alex Kim posts; if it hasn't by tonight, I'll ask.

## C00029 · M29 · An expired nickname card never writes a fact · PASS

Expected: [{"say":"save alex as brother"},{"minutes":11},{"say":"yes","match":"expired"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 2

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 3

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

## C00030 · M30 · A question containing yes does not approve a payment · PASS

Expected: [{"say":"send alex 20"},{"say":"yes but is there a fee"},{"state":"state.send.sends.length","equals":0},{"say":"no"}]

### Trial 1

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

### Trial 2

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

### Trial 3

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

## C00031 · M31 · Moving to small talk explicitly drops the old payment · PASS

Expected: [{"say":"send alex 20"},{"say":"what's a good movie","match":"dropped.*20.00"},{"say":"yes","not":"^Staged"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $20.00 to Alex Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $20.00 to Alex Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $20.00 to Alex Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00032 · M32 · Switching recipients makes the latest request authoritative · PASS

Expected: [{"say":"send alex 20"},{"say":"send rhea 30","match":"30.00.*Rhea Rao","outcome":"confirm"},{"say":"yes","match":"30.00.*Rhea Rao","outcome":"staged"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send rhea 30

Upmore: I dropped the earlier card. Set up $30.00 to Rhea Rao (@rhear) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rhear; 3. Enter $30.00; 4. Keep it private, then Pay. I'll confirm when $30.00 to Rhea Rao posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send rhea 30

Upmore: I dropped the earlier card. Set up $30.00 to Rhea Rao (@rhear) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rhear; 3. Enter $30.00; 4. Keep it private, then Pay. I'll confirm when $30.00 to Rhea Rao posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send rhea 30

Upmore: I dropped the earlier card. Set up $30.00 to Rhea Rao (@rhear) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rhear; 3. Enter $30.00; 4. Keep it private, then Pay. I'll confirm when $30.00 to Rhea Rao posts; if it hasn't by tonight, I'll ask.

## C00033 · M33 · A payment supersedes a pending split rather than approving both · PASS

Expected: [{"say":"split 60 with alex and rhea"},{"say":"send alex 20","match":"20.00.*Alex Kim","outcome":"confirm"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"state":"state.split.staged.length","equals":0}]

### Trial 1

User: split 60 with alex and rhea

Upmore: Request $20.00 each from Alex Kim (@alexk) and Rhea Rao (@rhear) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send alex 20

Upmore: I dropped the earlier card. Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Alex Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: split 60 with alex and rhea

Upmore: Request $20.00 each from Alex Kim (@alexk) and Rhea Rao (@rhear) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send alex 20

Upmore: I dropped the earlier card. Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Alex Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: split 60 with alex and rhea

Upmore: Request $20.00 each from Alex Kim (@alexk) and Rhea Rao (@rhear) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send alex 20

Upmore: I dropped the earlier card. Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Alex Kim posts; if it hasn't by tonight, I'll ask.

## C00034 · M34 · Switching from payment to rent keeps the new goal · PASS

Expected: [{"say":"send alex 20"},{"say":"pay my rent","match":"Who","outcome":"ask"},{"say":"alex $900 on the 1st via Venmo"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 2

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 3

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

## C00035 · M35 · Never mind cancels an alias confirmation without saving · PASS

Expected: [{"say":"save alex as brother"},{"say":"never mind"},{"state":"recipients.0.nickname","equals":null},{"say":"yes","not":"^Saved:"}]

### Trial 1

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 2

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 3

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

## C00036 · M36 · Confirmed aliases survive a new conversation · PASS

Expected: [{"say":"save alex as brother"},{"say":"yes"},{"thread":"B"},{"say":"send brother 20","match":"Alex Kim","outcome":"confirm"}]

### Trial 1

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Alex Kim (brother, @alexk).

User: send brother 20

Upmore: Set up $20.00 to Alex Kim (brother, @alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Alex Kim (brother, @alexk).

User: send brother 20

Upmore: Set up $20.00 to Alex Kim (brother, @alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Alex Kim (brother, @alexk).

User: send brother 20

Upmore: Set up $20.00 to Alex Kim (brother, @alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00037 · M37 · Standing rent survives a new conversation · PASS

Expected: [{"say":"pay my rent"},{"say":"alex $900 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"pay my rent","match":"900.00.*Alex Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $900.00 to Alex Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $900.00 to Alex Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $900.00 to Alex Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

## C00038 · M38 · Unapproved thread A card cannot be approved in thread B · PASS

Expected: [{"say":"send alex 20"},{"thread":"B"},{"say":"yes","not":"^Staged"},{"thread":"A"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00039 · M39 · A nickname correction in another session supersedes the old meaning · PASS

Expected: [{"say":"save alex as brother"},{"say":"yes"},{"thread":"B"},{"say":"brother is Rhea Rao"},{"say":"yes"},{"thread":"C"},{"say":"send brother 20","match":"Rhea Rao","outcome":"confirm"}]

### Trial 1

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Alex Kim (brother, @alexk).

User: brother is Rhea Rao

Upmore: Save "brother" as your name for Rhea Rao (@rhear)? Then "send brother 20" goes to Rhea Rao. "brother" means Alex Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Rhea Rao (brother, @rhear).

User: send brother 20

Upmore: Set up $20.00 to Rhea Rao (brother, @rhear) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Alex Kim (brother, @alexk).

User: brother is Rhea Rao

Upmore: Save "brother" as your name for Rhea Rao (@rhear)? Then "send brother 20" goes to Rhea Rao. "brother" means Alex Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Rhea Rao (brother, @rhear).

User: send brother 20

Upmore: Set up $20.00 to Rhea Rao (brother, @rhear) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Alex Kim (brother, @alexk).

User: brother is Rhea Rao

Upmore: Save "brother" as your name for Rhea Rao (@rhear)? Then "send brother 20" goes to Rhea Rao. "brother" means Alex Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Rhea Rao (brother, @rhear).

User: send brother 20

Upmore: Set up $20.00 to Rhea Rao (brother, @rhear) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00040 · M40 · Stopping rent in another session prevents future offers · PASS

Expected: [{"say":"pay my rent"},{"say":"alex $900 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"stop rent"},{"thread":"C"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Alex Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Alex Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Alex Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C00041 · M41 · Repeating a staged approval does not stage twice after restore · PASS

Expected: [{"say":"send alex 20"},{"say":"yes"},{"say":"yes","match":"already staged","outcome":"already_done"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Alex Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $20.00 to Alex Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $20.00 to Alex Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 2

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Alex Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $20.00 to Alex Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $20.00 to Alex Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 3

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Alex Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $20.00 to Alex Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $20.00 to Alex Kim for you to send in Venmo. A second yes doesn't stage it again.

## C00042 · M42 · Rent setup retry leaves exactly one standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"alex $900 on the 1st via Venmo"},{"say":"yes"},{"say":"yes","not":"^Rent is set up"},{"state":"standing.length","equals":1}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00043 · M43 · Confirmed alias repeated is recognized as already known · PASS

Expected: [{"say":"save alex as brother"},{"say":"yes"},{"say":"save alex as brother","match":"already|Already|already means","outcome":"already_done"},{"state":"ops.length","equals":1}]

### Trial 1

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Alex Kim (brother, @alexk).

User: save alex as brother

Upmore: "brother" already means Alex Kim (brother, @alexk). Nothing changed.

### Trial 2

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Alex Kim (brother, @alexk).

User: save alex as brother

Upmore: "brother" already means Alex Kim (brother, @alexk). Nothing changed.

### Trial 3

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Alex Kim (brother, @alexk).

User: save alex as brother

Upmore: "brother" already means Alex Kim (brother, @alexk). Nothing changed.

## C00044 · M44 · The same month rent is staged once across restored sessions · PASS

Expected: [{"say":"pay my rent"},{"say":"alex $900 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"pay my rent","match":"already staged","outcome":"already_done"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $900.00 to Alex Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $900.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $900.00 to Alex Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $900.00 to Alex Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $900.00 to Alex Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $900.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $900.00 to Alex Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $900.00 to Alex Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $900.00 to Alex Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexk; 3. Enter $900.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $900.00 to Alex Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $900.00 to Alex Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

## C00045 · M45 · Retried split approval preserves one set of requests · PASS

Expected: [{"say":"split 60 with alex and rhea"},{"say":"yes"},{"say":"yes"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 60 with alex and rhea

Upmore: Request $20.00 each from Alex Kim (@alexk) and Rhea Rao (@rhear) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Alex Kim (@alexk) $20.00 in Venmo, Rhea Rao (@rhear) $20.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 60 with alex and rhea

Upmore: Request $20.00 each from Alex Kim (@alexk) and Rhea Rao (@rhear) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Alex Kim (@alexk) $20.00 in Venmo, Rhea Rao (@rhear) $20.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 60 with alex and rhea

Upmore: Request $20.00 each from Alex Kim (@alexk) and Rhea Rao (@rhear) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Alex Kim (@alexk) $20.00 in Venmo, Rhea Rao (@rhear) $20.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C00046 · M46 · Nickname save failure is never reported as remembered · PASS

Expected: [{"say":"save alex as brother"},{"set":{"failRecipients":true}},{"say":"yes","match":"couldn't save"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 2

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 3

User: save alex as brother

Upmore: Save "brother" as your name for Alex Kim (@alexk)? Then "send brother 20" goes to Alex Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

## C00047 · M47 · Rent save failure is never reported as a stored rule · PASS

Expected: [{"say":"pay my rent"},{"say":"alex $900 on the 1st via Venmo"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*set|nothing was set up"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

## C00048 · M48 · A failed state write yields no approval card and retry is recoverable · PASS

Expected: [{"set":{"failState":true}},{"say":"send alex 20","error":"state storage unavailable"},{"set":{"failState":false}},{"say":"send alex 20","match":"20.00.*Alex Kim","outcome":"confirm"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send alex 20

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: send alex 20

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: send alex 20

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00049 · M49 · Unavailable facts cause an honest blocker and preserve the old card · PASS

Expected: [{"say":"send alex 20"},{"set":{"unreadable":true}},{"say":"yes","match":"can't read.*Nothing was changed","outcome":"unavailable"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

### Trial 2

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

### Trial 3

User: send alex 20

Upmore: Set up $20.00 to Alex Kim (@alexk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

## C00050 · M50 · A failed rent correction retains the prior confirmed terms · PASS

Expected: [{"say":"pay my rent"},{"say":"alex $900 on the 1st via Venmo"},{"say":"yes"},{"say":"rent is 950 now"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*change|rent stays as it was"},{"state":"standing.0.amount_cents","equals":90000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 950 now

Upmore: Change rent (amount $900.00 to $950.00): $950.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 950 now

Upmore: Change rent (amount $900.00 to $950.00): $950.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: alex $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Alex Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 950 now

Upmore: Change rent (amount $900.00 to $950.00): $950.00 to Alex Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

