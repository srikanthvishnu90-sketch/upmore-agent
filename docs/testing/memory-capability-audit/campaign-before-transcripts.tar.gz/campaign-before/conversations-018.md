# conversations-018

All conversations are synthetic. Full production handler, mock authentication/PostgREST and disabled model; no real outbound messages or provider actions.

## C00851 · M01 · Confirmed nickname recalls the right person · PASS

Expected: [{"say":"save rhea as brother"},{"say":"yes"},{"say":"send brother 60","match":"Rhea Kim.*@rheak","outcome":"confirm"}]

### Trial 1

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Rhea Kim (brother, @rheak).

User: send brother 60

Upmore: Set up $60.00 to Rhea Kim (brother, @rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Rhea Kim (brother, @rheak).

User: send brother 60

Upmore: Set up $60.00 to Rhea Kim (brother, @rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Rhea Kim (brother, @rheak).

User: send brother 60

Upmore: Set up $60.00 to Rhea Kim (brother, @rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00852 · M02 · Explicit remember phrasing persists an alias · PASS

Expected: [{"say":"remember Inez Rao as my sister"},{"say":"yes"},{"say":"send sister 75","match":"Inez Rao.*@inezr","outcome":"confirm"}]

### Trial 1

User: remember Inez Rao as my sister

Upmore: Save "sister" as your name for Inez Rao (@inezr)? Then "send sister 20" goes to Inez Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Inez Rao (sister, @inezr).

User: send sister 75

Upmore: Set up $75.00 to Inez Rao (sister, @inezr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: remember Inez Rao as my sister

Upmore: Save "sister" as your name for Inez Rao (@inezr)? Then "send sister 20" goes to Inez Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Inez Rao (sister, @inezr).

User: send sister 75

Upmore: Set up $75.00 to Inez Rao (sister, @inezr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: remember Inez Rao as my sister

Upmore: Save "sister" as your name for Inez Rao (@inezr)? Then "send sister 20" goes to Inez Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Inez Rao (sister, @inezr).

User: send sister 75

Upmore: Set up $75.00 to Inez Rao (sister, @inezr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00853 · M03 · Natural relationship statement needs confirmation and persists · PASS

Expected: [{"say":"my dad is Rhea Kim","match":"Save"},{"say":"yes"},{"say":"send dad 90","match":"Rhea Kim","outcome":"confirm"}]

### Trial 1

User: my dad is Rhea Kim

Upmore: Save "dad" as your name for Rhea Kim (@rheak)? Then "send dad 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Rhea Kim (dad, @rheak).

User: send dad 90

Upmore: Set up $90.00 to Rhea Kim (dad, @rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: my dad is Rhea Kim

Upmore: Save "dad" as your name for Rhea Kim (@rheak)? Then "send dad 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Rhea Kim (dad, @rheak).

User: send dad 90

Upmore: Set up $90.00 to Rhea Kim (dad, @rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: my dad is Rhea Kim

Upmore: Save "dad" as your name for Rhea Kim (@rheak)? Then "send dad 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Rhea Kim (dad, @rheak).

User: send dad 90

Upmore: Set up $90.00 to Rhea Kim (dad, @rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00854 · M04 · An alias is moved only to the newly confirmed person · PASS

Expected: [{"say":"save rhea as brother"},{"say":"yes"},{"say":"brother is Inez Rao"},{"say":"yes"},{"say":"send brother 60","match":"Inez Rao","outcome":"confirm"}]

### Trial 1

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Rhea Kim (brother, @rheak).

User: brother is Inez Rao

Upmore: Save "brother" as your name for Inez Rao (@inezr)? Then "send brother 20" goes to Inez Rao. "brother" means Rhea Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Inez Rao (brother, @inezr).

User: send brother 60

Upmore: Set up $60.00 to Inez Rao (brother, @inezr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Rhea Kim (brother, @rheak).

User: brother is Inez Rao

Upmore: Save "brother" as your name for Inez Rao (@inezr)? Then "send brother 20" goes to Inez Rao. "brother" means Rhea Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Inez Rao (brother, @inezr).

User: send brother 60

Upmore: Set up $60.00 to Inez Rao (brother, @inezr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Rhea Kim (brother, @rheak).

User: brother is Inez Rao

Upmore: Save "brother" as your name for Inez Rao (@inezr)? Then "send brother 20" goes to Inez Rao. "brother" means Rhea Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Inez Rao (brother, @inezr).

User: send brother 60

Upmore: Set up $60.00 to Inez Rao (brother, @inezr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00855 · M05 · Rejected alias preserves the previous confirmed fact · PASS

Expected: [{"say":"save rhea as brother"},{"say":"yes"},{"say":"brother is Inez Rao"},{"say":"no"},{"say":"send brother 60","match":"Rhea Kim","outcome":"confirm"}]

### Trial 1

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Rhea Kim (brother, @rheak).

User: brother is Inez Rao

Upmore: Save "brother" as your name for Inez Rao (@inezr)? Then "send brother 20" goes to Inez Rao. "brother" means Rhea Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 60

Upmore: Set up $60.00 to Rhea Kim (brother, @rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Rhea Kim (brother, @rheak).

User: brother is Inez Rao

Upmore: Save "brother" as your name for Inez Rao (@inezr)? Then "send brother 20" goes to Inez Rao. "brother" means Rhea Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 60

Upmore: Set up $60.00 to Rhea Kim (brother, @rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Rhea Kim (brother, @rheak).

User: brother is Inez Rao

Upmore: Save "brother" as your name for Inez Rao (@inezr)? Then "send brother 20" goes to Inez Rao. "brother" means Rhea Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 60

Upmore: Set up $60.00 to Rhea Kim (brother, @rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00856 · M06 · Amount correction preserves payee and replaces the old card · PASS

Expected: [{"say":"send rhea 60"},{"say":"make it 105","match":"105.00.*Rhea Kim","outcome":"confirm"},{"say":"yes","match":"105.00","outcome":"staged"},{"state":"state.send.sends.0.amount_cents","equals":10500}]

### Trial 1

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 105

Upmore: Got it. Set up $105.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $105.00; 4. Keep it private, then Pay. I'll confirm when $105.00 to Rhea Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 105

Upmore: Got it. Set up $105.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $105.00; 4. Keep it private, then Pay. I'll confirm when $105.00 to Rhea Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 105

Upmore: Got it. Set up $105.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $105.00; 4. Keep it private, then Pay. I'll confirm when $105.00 to Rhea Kim posts; if it hasn't by tonight, I'll ask.

## C00857 · M07 · Actually correction handles a different amount · PASS

Expected: [{"say":"send rhea 60"},{"say":"actually make it 150","match":"150.00.*Rhea Kim","outcome":"confirm"},{"say":"yes","match":"150.00","outcome":"staged"}]

### Trial 1

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 150

Upmore: Got it. Set up $150.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $150.00; 4. Keep it private, then Pay. I'll confirm when $150.00 to Rhea Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 150

Upmore: Got it. Set up $150.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $150.00; 4. Keep it private, then Pay. I'll confirm when $150.00 to Rhea Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 150

Upmore: Got it. Set up $150.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $150.00; 4. Keep it private, then Pay. I'll confirm when $150.00 to Rhea Kim posts; if it hasn't by tonight, I'll ask.

## C00858 · M08 · Bare currency correction retains payment context · PASS

Expected: [{"say":"send rhea 60"},{"say":"$37.50 instead","match":"37.50.*Rhea Kim","outcome":"confirm"},{"say":"yes","match":"37.50","outcome":"staged"}]

### Trial 1

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $37.50 instead

Upmore: Got it. Set up $37.50 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $37.50; 4. Keep it private, then Pay. I'll confirm when $37.50 to Rhea Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $37.50 instead

Upmore: Got it. Set up $37.50 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $37.50; 4. Keep it private, then Pay. I'll confirm when $37.50 to Rhea Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $37.50 instead

Upmore: Got it. Set up $37.50 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $37.50; 4. Keep it private, then Pay. I'll confirm when $37.50 to Rhea Kim posts; if it hasn't by tonight, I'll ask.

## C00859 · M09 · Split total correction recomputes every share before approval · PASS

Expected: [{"say":"split 180 with rhea and inez"},{"say":"make it 270","match":"90.00 each.*270.00","outcome":"confirm"},{"say":"yes","match":"90.00","outcome":"staged"}]

### Trial 1

User: split 180 with rhea and inez

Upmore: Request $60.00 each from Rhea Kim (@rheak) and Inez Rao (@inezr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 270

Upmore: Got it. Request $90.00 each from Rhea Kim (@rheak) and Inez Rao (@inezr) in Venmo: $270.00 split 3 ways, yours $90.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Rhea Kim (@rheak) $90.00 in Venmo, Inez Rao (@inezr) $90.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 180 with rhea and inez

Upmore: Request $60.00 each from Rhea Kim (@rheak) and Inez Rao (@inezr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 270

Upmore: Got it. Request $90.00 each from Rhea Kim (@rheak) and Inez Rao (@inezr) in Venmo: $270.00 split 3 ways, yours $90.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Rhea Kim (@rheak) $90.00 in Venmo, Inez Rao (@inezr) $90.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 180 with rhea and inez

Upmore: Request $60.00 each from Rhea Kim (@rheak) and Inez Rao (@inezr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 270

Upmore: Got it. Request $90.00 each from Rhea Kim (@rheak) and Inez Rao (@inezr) in Venmo: $270.00 split 3 ways, yours $90.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Rhea Kim (@rheak) $90.00 in Venmo, Inez Rao (@inezr) $90.00 in Venmo. I'll mark each one paid when the money lands.

## C00860 · M10 · Rent setup correction retains recipient and due day · FAIL

Expected: [{"say":"pay my rent"},{"say":"rhea $2700 on the 1st via Venmo"},{"say":"make it 2850","match":"2850.00.*Rhea Kim.*1st","outcome":"confirm"},{"say":"yes"},{"state":"standing.0.amount_cents","equals":285000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 2850

Upmore: Got it. Set up rent: $2,850.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,850.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"2850.00.*Rhea Kim.*1st","actual":{"thread_id":"5dc739ec-c3ec-4200-a8bc-26b4ab905c8d","reply":"Got it. Set up rent: $2,850.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 2850

Upmore: Got it. Set up rent: $2,850.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,850.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"2850.00.*Rhea Kim.*1st","actual":{"thread_id":"62db7ea4-f00c-425c-a616-a6dcadd99eaf","reply":"Got it. Set up rent: $2,850.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 2850

Upmore: Got it. Set up rent: $2,850.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,850.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"2850.00.*Rhea Kim.*1st","actual":{"thread_id":"a34e9212-d431-4531-b874-b065a13960d5","reply":"Got it. Set up rent: $2,850.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

## C00861 · M11 · Details refers to the pending payment · PASS

Expected: [{"say":"send rhea 60"},{"say":"details","match":"60.00.*Rhea Kim","outcome":"details"}]

### Trial 1

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $60.00 to Rhea Kim on Venmo $60.00 to Rhea Kim (@rheak) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

### Trial 2

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $60.00 to Rhea Kim on Venmo $60.00 to Rhea Kim (@rheak) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

### Trial 3

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $60.00 to Rhea Kim on Venmo $60.00 to Rhea Kim (@rheak) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

## C00862 · M12 · A short yes resumes a serialized split · PASS

Expected: [{"say":"split 180 with rhea and inez"},{"say":"yes","match":"Rhea Kim.*60.00.*Inez Rao.*60.00","outcome":"staged"}]

### Trial 1

User: split 180 with rhea and inez

Upmore: Request $60.00 each from Rhea Kim (@rheak) and Inez Rao (@inezr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Rhea Kim (@rheak) $60.00 in Venmo, Inez Rao (@inezr) $60.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 180 with rhea and inez

Upmore: Request $60.00 each from Rhea Kim (@rheak) and Inez Rao (@inezr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Rhea Kim (@rheak) $60.00 in Venmo, Inez Rao (@inezr) $60.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 180 with rhea and inez

Upmore: Request $60.00 each from Rhea Kim (@rheak) and Inez Rao (@inezr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Rhea Kim (@rheak) $60.00 in Venmo, Inez Rao (@inezr) $60.00 in Venmo. I'll mark each one paid when the money lands.

## C00863 · M13 · Cancellation that resolves the last discussed subscription · PASS

Expected: [{"say":"cancel netflix","match":"Netflix"},{"say":"cancel that","match":"Netflix"}]

### Trial 1

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 2

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 3

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

## C00864 · M14 · Stop rent refers to the confirmed standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"rhea $2700 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent","match":"Rent is off","outcome":"rent_stopped"},{"state":"standing.0.status","equals":"stopped"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Rhea Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Rhea Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Rhea Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

## C00865 · M15 · A contextual fee question retains payment identity and asks before acting · PASS

Expected: [{"say":"send rhea 60"},{"say":"what's the fee on that","match":"60.00.*Rhea Kim"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $60.00 to Rhea Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $60.00 to Rhea Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $60.00 to Rhea Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00866 · M16 · Rent setup answers retain the original goal · FAIL

Expected: [{"say":"pay my rent","match":"Who"},{"say":"rhea $2700 on the 1st via Venmo","match":"2700.00.*Rhea Kim","outcome":"confirm"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"standing.0.payee_handle","equals":"@rheak"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"2700.00.*Rhea Kim","actual":{"thread_id":"c2637d0a-d926-430d-a8f3-ac4bb00dc644","reply":"Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"2700.00.*Rhea Kim","actual":{"thread_id":"a8bab3fb-bb1b-4e06-9452-c34229be09f0","reply":"Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"2700.00.*Rhea Kim","actual":{"thread_id":"98cf2035-2ed5-4675-88ee-7c5d35098dd9","reply":"Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

## C00867 · M17 · New recipient handle and rail answers retain amount · PASS

Expected: [{"say":"send Dana 75"},{"say":"@danak"},{"say":"@danak"},{"say":"Venmo"},{"say":"@danak","match":"75.00.*Dana","outcome":"confirm"}]

### Trial 1

User: send Dana 75

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $75.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: send Dana 75

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $75.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: send Dana 75

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $75.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00868 · M18 · Split remembers total while asking who participated · PASS

Expected: [{"say":"split 180 with 2 friends"},{"say":"rhea and inez","match":"60.00 each.*180.00","outcome":"confirm"}]

### Trial 1

User: split 180 with 2 friends

Upmore: That's $60.00 each across 3 people. Who are the 2? I'll request $60.00 from each.

User: rhea and inez

Upmore: Request $60.00 each from Rhea Kim (@rheak) and Inez Rao (@inezr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: split 180 with 2 friends

Upmore: That's $60.00 each across 3 people. Who are the 2? I'll request $60.00 from each.

User: rhea and inez

Upmore: Request $60.00 each from Rhea Kim (@rheak) and Inez Rao (@inezr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: split 180 with 2 friends

Upmore: That's $60.00 each across 3 people. Who are the 2? I'll request $60.00 from each.

User: rhea and inez

Upmore: Request $60.00 each from Rhea Kim (@rheak) and Inez Rao (@inezr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

## C00869 · M19 · Rent is remembered on the next independent invocation · FAIL

Expected: [{"say":"pay my rent"},{"say":"rhea $2700 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent","match":"2700.00.*Rhea Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Rhea Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"2700.00.*Rhea Kim","actual":{"thread_id":"db90e19c-ff89-4ca0-af39-185d9464df0e","reply":"Rent for November: $2,700.00 to Rhea Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Rhea Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"2700.00.*Rhea Kim","actual":{"thread_id":"6aeabe8d-a522-4349-8a3a-b5eb6722984a","reply":"Rent for November: $2,700.00 to Rhea Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Rhea Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"2700.00.*Rhea Kim","actual":{"thread_id":"559841c9-32de-4cb3-8eec-d67eaa519e14","reply":"Rent for November: $2,700.00 to Rhea Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

## C00870 · M20 · An interrupted alias goal remains unconfirmed · PASS

Expected: [{"say":"save rhea as brother"},{"say":"no"},{"state":"recipients.0.nickname","equals":null},{"say":"send brother 60","match":"handle","outcome":"ask"}]

### Trial 1

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 60

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 2

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 60

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 3

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 60

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

## C00871 · M21 · A staged payment is remembered without claiming completion · PASS

Expected: [{"say":"send rhea 60"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Rhea Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $60.00 to Rhea Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 2

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Rhea Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $60.00 to Rhea Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 3

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Rhea Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $60.00 to Rhea Kim for you to send in Venmo. A second yes doesn't stage it again.

## C00872 · M22 · A staged split is remembered without duplicating it · PASS

Expected: [{"say":"split 180 with rhea and inez"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 180 with rhea and inez

Upmore: Request $60.00 each from Rhea Kim (@rheak) and Inez Rao (@inezr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Rhea Kim (@rheak) $60.00 in Venmo, Inez Rao (@inezr) $60.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 180 with rhea and inez

Upmore: Request $60.00 each from Rhea Kim (@rheak) and Inez Rao (@inezr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Rhea Kim (@rheak) $60.00 in Venmo, Inez Rao (@inezr) $60.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 180 with rhea and inez

Upmore: Request $60.00 each from Rhea Kim (@rheak) and Inez Rao (@inezr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Rhea Kim (@rheak) $60.00 in Venmo, Inez Rao (@inezr) $60.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C00873 · M23 · A declined payment cannot be resurrected by yes · PASS

Expected: [{"say":"send rhea 60"},{"say":"no","match":"Nothing","outcome":"declined"},{"say":"yes","not":"^Staged, not sent"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 2

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 3

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

## C00874 · M24 · Stopping rent prevents the next turn from claiming an active rule · PASS

Expected: [{"say":"pay my rent"},{"say":"rhea $2700 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Rhea Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Rhea Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Rhea Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C00875 · M25 · Status follow-up recalls staged versus sent · PASS

Expected: [{"say":"send rhea 60"},{"say":"yes"},{"say":"did it go through","match":"(?:not (?:yet )?(?:sent|posted)|staged|have not seen|waiting for.*post)"}]

### Trial 1

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Rhea Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $60.00 to Rhea Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

### Trial 2

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Rhea Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $60.00 to Rhea Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

### Trial 3

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Rhea Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $60.00 to Rhea Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

## C00876 · M26 · Unapproved nickname does not become a known fact · PASS

Expected: [{"say":"save rhea as brother"},{"state":"recipients.0.nickname","equals":null},{"say":"no"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 2

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 3

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

## C00877 · M27 · Unapproved rent terms are not durable instructions · PASS

Expected: [{"say":"pay my rent"},{"say":"rhea $2700 on the 1st via Venmo"},{"state":"standing.length","equals":0},{"say":"no"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

## C00878 · M28 · An expired payment card is restated and requires a fresh yes · PASS

Expected: [{"say":"send rhea 60"},{"minutes":11},{"say":"yes","match":"expired.*fresh","outcome":"confirm"},{"state":"state.send.sends.length","equals":0},{"say":"yes","match":"Staged","outcome":"staged"}]

### Trial 1

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Rhea Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Rhea Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Rhea Kim posts; if it hasn't by tonight, I'll ask.

## C00879 · M29 · An expired nickname card never writes a fact · PASS

Expected: [{"say":"save rhea as brother"},{"minutes":11},{"say":"yes","match":"expired"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 2

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 3

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

## C00880 · M30 · A question containing yes does not approve a payment · PASS

Expected: [{"say":"send rhea 60"},{"say":"yes but is there a fee"},{"state":"state.send.sends.length","equals":0},{"say":"no"}]

### Trial 1

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

### Trial 2

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

### Trial 3

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

## C00881 · M31 · Moving to small talk explicitly drops the old payment · PASS

Expected: [{"say":"send rhea 60"},{"say":"what's a good movie","match":"dropped.*60.00"},{"say":"yes","not":"^Staged"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $60.00 to Rhea Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $60.00 to Rhea Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $60.00 to Rhea Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00882 · M32 · Switching recipients makes the latest request authoritative · PASS

Expected: [{"say":"send rhea 60"},{"say":"send inez 90","match":"90.00.*Inez Rao","outcome":"confirm"},{"say":"yes","match":"90.00.*Inez Rao","outcome":"staged"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send inez 90

Upmore: I dropped the earlier card. Set up $90.00 to Inez Rao (@inezr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @inezr; 3. Enter $90.00; 4. Keep it private, then Pay. I'll confirm when $90.00 to Inez Rao posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send inez 90

Upmore: I dropped the earlier card. Set up $90.00 to Inez Rao (@inezr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @inezr; 3. Enter $90.00; 4. Keep it private, then Pay. I'll confirm when $90.00 to Inez Rao posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send inez 90

Upmore: I dropped the earlier card. Set up $90.00 to Inez Rao (@inezr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @inezr; 3. Enter $90.00; 4. Keep it private, then Pay. I'll confirm when $90.00 to Inez Rao posts; if it hasn't by tonight, I'll ask.

## C00883 · M33 · A payment supersedes a pending split rather than approving both · PASS

Expected: [{"say":"split 180 with rhea and inez"},{"say":"send rhea 60","match":"60.00.*Rhea Kim","outcome":"confirm"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"state":"state.split.staged.length","equals":0}]

### Trial 1

User: split 180 with rhea and inez

Upmore: Request $60.00 each from Rhea Kim (@rheak) and Inez Rao (@inezr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send rhea 60

Upmore: I dropped the earlier card. Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Rhea Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: split 180 with rhea and inez

Upmore: Request $60.00 each from Rhea Kim (@rheak) and Inez Rao (@inezr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send rhea 60

Upmore: I dropped the earlier card. Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Rhea Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: split 180 with rhea and inez

Upmore: Request $60.00 each from Rhea Kim (@rheak) and Inez Rao (@inezr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send rhea 60

Upmore: I dropped the earlier card. Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Rhea Kim posts; if it hasn't by tonight, I'll ask.

## C00884 · M34 · Switching from payment to rent keeps the new goal · PASS

Expected: [{"say":"send rhea 60"},{"say":"pay my rent","match":"Who","outcome":"ask"},{"say":"rhea $2700 on the 1st via Venmo"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 2

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 3

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

## C00885 · M35 · Never mind cancels an alias confirmation without saving · PASS

Expected: [{"say":"save rhea as brother"},{"say":"never mind"},{"state":"recipients.0.nickname","equals":null},{"say":"yes","not":"^Saved:"}]

### Trial 1

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 2

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 3

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

## C00886 · M36 · Confirmed aliases survive a new conversation · PASS

Expected: [{"say":"save rhea as brother"},{"say":"yes"},{"thread":"B"},{"say":"send brother 60","match":"Rhea Kim","outcome":"confirm"}]

### Trial 1

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Rhea Kim (brother, @rheak).

User: send brother 60

Upmore: Set up $60.00 to Rhea Kim (brother, @rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Rhea Kim (brother, @rheak).

User: send brother 60

Upmore: Set up $60.00 to Rhea Kim (brother, @rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Rhea Kim (brother, @rheak).

User: send brother 60

Upmore: Set up $60.00 to Rhea Kim (brother, @rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00887 · M37 · Standing rent survives a new conversation · FAIL

Expected: [{"say":"pay my rent"},{"say":"rhea $2700 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"pay my rent","match":"2700.00.*Rhea Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Rhea Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"2700.00.*Rhea Kim","actual":{"thread_id":"48dd81e6-921f-44c4-8f01-a427691000b6","reply":"Rent for November: $2,700.00 to Rhea Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Rhea Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"2700.00.*Rhea Kim","actual":{"thread_id":"d127f8a1-672b-4260-aa2e-4b1d63fdb91b","reply":"Rent for November: $2,700.00 to Rhea Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Rhea Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"2700.00.*Rhea Kim","actual":{"thread_id":"029c9a5a-fe76-4b40-b258-94f8d51e9976","reply":"Rent for November: $2,700.00 to Rhea Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

## C00888 · M38 · Unapproved thread A card cannot be approved in thread B · PASS

Expected: [{"say":"send rhea 60"},{"thread":"B"},{"say":"yes","not":"^Staged"},{"thread":"A"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00889 · M39 · A nickname correction in another session supersedes the old meaning · PASS

Expected: [{"say":"save rhea as brother"},{"say":"yes"},{"thread":"B"},{"say":"brother is Inez Rao"},{"say":"yes"},{"thread":"C"},{"say":"send brother 60","match":"Inez Rao","outcome":"confirm"}]

### Trial 1

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Rhea Kim (brother, @rheak).

User: brother is Inez Rao

Upmore: Save "brother" as your name for Inez Rao (@inezr)? Then "send brother 20" goes to Inez Rao. "brother" means Rhea Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Inez Rao (brother, @inezr).

User: send brother 60

Upmore: Set up $60.00 to Inez Rao (brother, @inezr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Rhea Kim (brother, @rheak).

User: brother is Inez Rao

Upmore: Save "brother" as your name for Inez Rao (@inezr)? Then "send brother 20" goes to Inez Rao. "brother" means Rhea Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Inez Rao (brother, @inezr).

User: send brother 60

Upmore: Set up $60.00 to Inez Rao (brother, @inezr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Rhea Kim (brother, @rheak).

User: brother is Inez Rao

Upmore: Save "brother" as your name for Inez Rao (@inezr)? Then "send brother 20" goes to Inez Rao. "brother" means Rhea Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Inez Rao (brother, @inezr).

User: send brother 60

Upmore: Set up $60.00 to Inez Rao (brother, @inezr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00890 · M40 · Stopping rent in another session prevents future offers · PASS

Expected: [{"say":"pay my rent"},{"say":"rhea $2700 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"stop rent"},{"thread":"C"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Rhea Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Rhea Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Rhea Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C00891 · M41 · Repeating a staged approval does not stage twice after restore · PASS

Expected: [{"say":"send rhea 60"},{"say":"yes"},{"say":"yes","match":"already staged","outcome":"already_done"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Rhea Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $60.00 to Rhea Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $60.00 to Rhea Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 2

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Rhea Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $60.00 to Rhea Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $60.00 to Rhea Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 3

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Rhea Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $60.00 to Rhea Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $60.00 to Rhea Kim for you to send in Venmo. A second yes doesn't stage it again.

## C00892 · M42 · Rent setup retry leaves exactly one standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"rhea $2700 on the 1st via Venmo"},{"say":"yes"},{"say":"yes","not":"^Rent is set up"},{"state":"standing.length","equals":1}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00893 · M43 · Confirmed alias repeated is recognized as already known · PASS

Expected: [{"say":"save rhea as brother"},{"say":"yes"},{"say":"save rhea as brother","match":"already|Already|already means","outcome":"already_done"},{"state":"ops.length","equals":1}]

### Trial 1

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Rhea Kim (brother, @rheak).

User: save rhea as brother

Upmore: "brother" already means Rhea Kim (brother, @rheak). Nothing changed.

### Trial 2

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Rhea Kim (brother, @rheak).

User: save rhea as brother

Upmore: "brother" already means Rhea Kim (brother, @rheak). Nothing changed.

### Trial 3

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Rhea Kim (brother, @rheak).

User: save rhea as brother

Upmore: "brother" already means Rhea Kim (brother, @rheak). Nothing changed.

## C00894 · M44 · The same month rent is staged once across restored sessions · PASS

Expected: [{"say":"pay my rent"},{"say":"rhea $2700 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"pay my rent","match":"already staged","outcome":"already_done"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Rhea Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $2,700.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $2,700.00 to Rhea Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $2,700.00 to Rhea Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Rhea Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $2,700.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $2,700.00 to Rhea Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $2,700.00 to Rhea Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $2,700.00 to Rhea Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @rheak; 3. Enter $2,700.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $2,700.00 to Rhea Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $2,700.00 to Rhea Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

## C00895 · M45 · Retried split approval preserves one set of requests · PASS

Expected: [{"say":"split 180 with rhea and inez"},{"say":"yes"},{"say":"yes"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 180 with rhea and inez

Upmore: Request $60.00 each from Rhea Kim (@rheak) and Inez Rao (@inezr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Rhea Kim (@rheak) $60.00 in Venmo, Inez Rao (@inezr) $60.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 180 with rhea and inez

Upmore: Request $60.00 each from Rhea Kim (@rheak) and Inez Rao (@inezr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Rhea Kim (@rheak) $60.00 in Venmo, Inez Rao (@inezr) $60.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 180 with rhea and inez

Upmore: Request $60.00 each from Rhea Kim (@rheak) and Inez Rao (@inezr) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Rhea Kim (@rheak) $60.00 in Venmo, Inez Rao (@inezr) $60.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C00896 · M46 · Nickname save failure is never reported as remembered · PASS

Expected: [{"say":"save rhea as brother"},{"set":{"failRecipients":true}},{"say":"yes","match":"couldn't save"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 2

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 3

User: save rhea as brother

Upmore: Save "brother" as your name for Rhea Kim (@rheak)? Then "send brother 20" goes to Rhea Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

## C00897 · M47 · Rent save failure is never reported as a stored rule · PASS

Expected: [{"say":"pay my rent"},{"say":"rhea $2700 on the 1st via Venmo"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*set|nothing was set up"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

## C00898 · M48 · A failed state write yields no approval card and retry is recoverable · PASS

Expected: [{"set":{"failState":true}},{"say":"send rhea 60","error":"state storage unavailable"},{"set":{"failState":false}},{"say":"send rhea 60","match":"60.00.*Rhea Kim","outcome":"confirm"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send rhea 60

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: send rhea 60

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: send rhea 60

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00899 · M49 · Unavailable facts cause an honest blocker and preserve the old card · PASS

Expected: [{"say":"send rhea 60"},{"set":{"unreadable":true}},{"say":"yes","match":"can't read.*Nothing was changed","outcome":"unavailable"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

### Trial 2

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

### Trial 3

User: send rhea 60

Upmore: Set up $60.00 to Rhea Kim (@rheak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

## C00900 · M50 · A failed rent correction retains the prior confirmed terms · PASS

Expected: [{"say":"pay my rent"},{"say":"rhea $2700 on the 1st via Venmo"},{"say":"yes"},{"say":"rent is 2850 now"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*change|rent stays as it was"},{"state":"standing.0.amount_cents","equals":270000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 2850 now

Upmore: Change rent (amount $2,700.00 to $2,850.00): $2,850.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 2850 now

Upmore: Change rent (amount $2,700.00 to $2,850.00): $2,850.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: rhea $2700 on the 1st via Venmo

Upmore: Set up rent: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $2,700.00 to Rhea Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 2850 now

Upmore: Change rent (amount $2,700.00 to $2,850.00): $2,850.00 to Rhea Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

