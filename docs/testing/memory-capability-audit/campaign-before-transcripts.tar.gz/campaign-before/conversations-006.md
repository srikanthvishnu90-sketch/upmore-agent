# conversations-006

All conversations are synthetic. Full production handler, mock authentication/PostgREST and disabled model; no real outbound messages or provider actions.

## C00251 · M01 · Confirmed nickname recalls the right person · PASS

Expected: [{"say":"save freya as brother"},{"say":"yes"},{"say":"send brother 20","match":"Freya Kim.*@freyak","outcome":"confirm"}]

### Trial 1

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Freya Kim (brother, @freyak).

User: send brother 20

Upmore: Set up $20.00 to Freya Kim (brother, @freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Freya Kim (brother, @freyak).

User: send brother 20

Upmore: Set up $20.00 to Freya Kim (brother, @freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Freya Kim (brother, @freyak).

User: send brother 20

Upmore: Set up $20.00 to Freya Kim (brother, @freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00252 · M02 · Explicit remember phrasing persists an alias · PASS

Expected: [{"say":"remember Wren Rao as my sister"},{"say":"yes"},{"say":"send sister 25","match":"Wren Rao.*@wrenr","outcome":"confirm"}]

### Trial 1

User: remember Wren Rao as my sister

Upmore: Save "sister" as your name for Wren Rao (@wrenr)? Then "send sister 20" goes to Wren Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Wren Rao (sister, @wrenr).

User: send sister 25

Upmore: Set up $25.00 to Wren Rao (sister, @wrenr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: remember Wren Rao as my sister

Upmore: Save "sister" as your name for Wren Rao (@wrenr)? Then "send sister 20" goes to Wren Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Wren Rao (sister, @wrenr).

User: send sister 25

Upmore: Set up $25.00 to Wren Rao (sister, @wrenr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: remember Wren Rao as my sister

Upmore: Save "sister" as your name for Wren Rao (@wrenr)? Then "send sister 20" goes to Wren Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Wren Rao (sister, @wrenr).

User: send sister 25

Upmore: Set up $25.00 to Wren Rao (sister, @wrenr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00253 · M03 · Natural relationship statement needs confirmation and persists · PASS

Expected: [{"say":"my dad is Freya Kim","match":"Save"},{"say":"yes"},{"say":"send dad 30","match":"Freya Kim","outcome":"confirm"}]

### Trial 1

User: my dad is Freya Kim

Upmore: Save "dad" as your name for Freya Kim (@freyak)? Then "send dad 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Freya Kim (dad, @freyak).

User: send dad 30

Upmore: Set up $30.00 to Freya Kim (dad, @freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: my dad is Freya Kim

Upmore: Save "dad" as your name for Freya Kim (@freyak)? Then "send dad 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Freya Kim (dad, @freyak).

User: send dad 30

Upmore: Set up $30.00 to Freya Kim (dad, @freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: my dad is Freya Kim

Upmore: Save "dad" as your name for Freya Kim (@freyak)? Then "send dad 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Freya Kim (dad, @freyak).

User: send dad 30

Upmore: Set up $30.00 to Freya Kim (dad, @freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00254 · M04 · An alias is moved only to the newly confirmed person · PASS

Expected: [{"say":"save freya as brother"},{"say":"yes"},{"say":"brother is Wren Rao"},{"say":"yes"},{"say":"send brother 20","match":"Wren Rao","outcome":"confirm"}]

### Trial 1

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Freya Kim (brother, @freyak).

User: brother is Wren Rao

Upmore: Save "brother" as your name for Wren Rao (@wrenr)? Then "send brother 20" goes to Wren Rao. "brother" means Freya Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Wren Rao (brother, @wrenr).

User: send brother 20

Upmore: Set up $20.00 to Wren Rao (brother, @wrenr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Freya Kim (brother, @freyak).

User: brother is Wren Rao

Upmore: Save "brother" as your name for Wren Rao (@wrenr)? Then "send brother 20" goes to Wren Rao. "brother" means Freya Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Wren Rao (brother, @wrenr).

User: send brother 20

Upmore: Set up $20.00 to Wren Rao (brother, @wrenr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Freya Kim (brother, @freyak).

User: brother is Wren Rao

Upmore: Save "brother" as your name for Wren Rao (@wrenr)? Then "send brother 20" goes to Wren Rao. "brother" means Freya Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Wren Rao (brother, @wrenr).

User: send brother 20

Upmore: Set up $20.00 to Wren Rao (brother, @wrenr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00255 · M05 · Rejected alias preserves the previous confirmed fact · PASS

Expected: [{"say":"save freya as brother"},{"say":"yes"},{"say":"brother is Wren Rao"},{"say":"no"},{"say":"send brother 20","match":"Freya Kim","outcome":"confirm"}]

### Trial 1

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Freya Kim (brother, @freyak).

User: brother is Wren Rao

Upmore: Save "brother" as your name for Wren Rao (@wrenr)? Then "send brother 20" goes to Wren Rao. "brother" means Freya Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 20

Upmore: Set up $20.00 to Freya Kim (brother, @freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Freya Kim (brother, @freyak).

User: brother is Wren Rao

Upmore: Save "brother" as your name for Wren Rao (@wrenr)? Then "send brother 20" goes to Wren Rao. "brother" means Freya Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 20

Upmore: Set up $20.00 to Freya Kim (brother, @freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Freya Kim (brother, @freyak).

User: brother is Wren Rao

Upmore: Save "brother" as your name for Wren Rao (@wrenr)? Then "send brother 20" goes to Wren Rao. "brother" means Freya Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 20

Upmore: Set up $20.00 to Freya Kim (brother, @freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00256 · M06 · Amount correction preserves payee and replaces the old card · PASS

Expected: [{"say":"send freya 20"},{"say":"make it 35","match":"35.00.*Freya Kim","outcome":"confirm"},{"say":"yes","match":"35.00","outcome":"staged"},{"state":"state.send.sends.0.amount_cents","equals":3500}]

### Trial 1

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 35

Upmore: Got it. Set up $35.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $35.00; 4. Keep it private, then Pay. I'll confirm when $35.00 to Freya Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 35

Upmore: Got it. Set up $35.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $35.00; 4. Keep it private, then Pay. I'll confirm when $35.00 to Freya Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 35

Upmore: Got it. Set up $35.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $35.00; 4. Keep it private, then Pay. I'll confirm when $35.00 to Freya Kim posts; if it hasn't by tonight, I'll ask.

## C00257 · M07 · Actually correction handles a different amount · PASS

Expected: [{"say":"send freya 20"},{"say":"actually make it 50","match":"50.00.*Freya Kim","outcome":"confirm"},{"say":"yes","match":"50.00","outcome":"staged"}]

### Trial 1

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 50

Upmore: Got it. Set up $50.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $50.00; 4. Keep it private, then Pay. I'll confirm when $50.00 to Freya Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 50

Upmore: Got it. Set up $50.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $50.00; 4. Keep it private, then Pay. I'll confirm when $50.00 to Freya Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 50

Upmore: Got it. Set up $50.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $50.00; 4. Keep it private, then Pay. I'll confirm when $50.00 to Freya Kim posts; if it hasn't by tonight, I'll ask.

## C00258 · M08 · Bare currency correction retains payment context · PASS

Expected: [{"say":"send freya 20"},{"say":"$12.50 instead","match":"12.50.*Freya Kim","outcome":"confirm"},{"say":"yes","match":"12.50","outcome":"staged"}]

### Trial 1

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $12.50 instead

Upmore: Got it. Set up $12.50 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $12.50; 4. Keep it private, then Pay. I'll confirm when $12.50 to Freya Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $12.50 instead

Upmore: Got it. Set up $12.50 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $12.50; 4. Keep it private, then Pay. I'll confirm when $12.50 to Freya Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $12.50 instead

Upmore: Got it. Set up $12.50 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $12.50; 4. Keep it private, then Pay. I'll confirm when $12.50 to Freya Kim posts; if it hasn't by tonight, I'll ask.

## C00259 · M09 · Split total correction recomputes every share before approval · PASS

Expected: [{"say":"split 60 with freya and wren"},{"say":"make it 90","match":"30.00 each.*90.00","outcome":"confirm"},{"say":"yes","match":"30.00","outcome":"staged"}]

### Trial 1

User: split 60 with freya and wren

Upmore: Request $20.00 each from Freya Kim (@freyak) and Wren Rao (@wrenr) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 90

Upmore: Got it. Request $30.00 each from Freya Kim (@freyak) and Wren Rao (@wrenr) in Venmo: $90.00 split 3 ways, yours $30.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Freya Kim (@freyak) $30.00 in Venmo, Wren Rao (@wrenr) $30.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 60 with freya and wren

Upmore: Request $20.00 each from Freya Kim (@freyak) and Wren Rao (@wrenr) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 90

Upmore: Got it. Request $30.00 each from Freya Kim (@freyak) and Wren Rao (@wrenr) in Venmo: $90.00 split 3 ways, yours $30.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Freya Kim (@freyak) $30.00 in Venmo, Wren Rao (@wrenr) $30.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 60 with freya and wren

Upmore: Request $20.00 each from Freya Kim (@freyak) and Wren Rao (@wrenr) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 90

Upmore: Got it. Request $30.00 each from Freya Kim (@freyak) and Wren Rao (@wrenr) in Venmo: $90.00 split 3 ways, yours $30.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Freya Kim (@freyak) $30.00 in Venmo, Wren Rao (@wrenr) $30.00 in Venmo. I'll mark each one paid when the money lands.

## C00260 · M10 · Rent setup correction retains recipient and due day · PASS

Expected: [{"say":"pay my rent"},{"say":"freya $900 on the 1st via Venmo"},{"say":"make it 950","match":"950.00.*Freya Kim.*1st","outcome":"confirm"},{"say":"yes"},{"state":"standing.0.amount_cents","equals":95000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 950

Upmore: Got it. Set up rent: $950.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $950.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 950

Upmore: Got it. Set up rent: $950.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $950.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 950

Upmore: Got it. Set up rent: $950.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $950.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

## C00261 · M11 · Details refers to the pending payment · PASS

Expected: [{"say":"send freya 20"},{"say":"details","match":"20.00.*Freya Kim","outcome":"details"}]

### Trial 1

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $20.00 to Freya Kim on Venmo $20.00 to Freya Kim (@freyak) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

### Trial 2

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $20.00 to Freya Kim on Venmo $20.00 to Freya Kim (@freyak) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

### Trial 3

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $20.00 to Freya Kim on Venmo $20.00 to Freya Kim (@freyak) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

## C00262 · M12 · A short yes resumes a serialized split · PASS

Expected: [{"say":"split 60 with freya and wren"},{"say":"yes","match":"Freya Kim.*20.00.*Wren Rao.*20.00","outcome":"staged"}]

### Trial 1

User: split 60 with freya and wren

Upmore: Request $20.00 each from Freya Kim (@freyak) and Wren Rao (@wrenr) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Freya Kim (@freyak) $20.00 in Venmo, Wren Rao (@wrenr) $20.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 60 with freya and wren

Upmore: Request $20.00 each from Freya Kim (@freyak) and Wren Rao (@wrenr) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Freya Kim (@freyak) $20.00 in Venmo, Wren Rao (@wrenr) $20.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 60 with freya and wren

Upmore: Request $20.00 each from Freya Kim (@freyak) and Wren Rao (@wrenr) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Freya Kim (@freyak) $20.00 in Venmo, Wren Rao (@wrenr) $20.00 in Venmo. I'll mark each one paid when the money lands.

## C00263 · M13 · Cancellation that resolves the last discussed subscription · PASS

Expected: [{"say":"cancel netflix","match":"Netflix"},{"say":"cancel that","match":"Netflix"}]

### Trial 1

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 2

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 3

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

## C00264 · M14 · Stop rent refers to the confirmed standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"freya $900 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent","match":"Rent is off","outcome":"rent_stopped"},{"state":"standing.0.status","equals":"stopped"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Freya Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Freya Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Freya Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

## C00265 · M15 · A contextual fee question retains payment identity and asks before acting · PASS

Expected: [{"say":"send freya 20"},{"say":"what's the fee on that","match":"20.00.*Freya Kim"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $20.00 to Freya Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $20.00 to Freya Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $20.00 to Freya Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00266 · M16 · Rent setup answers retain the original goal · PASS

Expected: [{"say":"pay my rent","match":"Who"},{"say":"freya $900 on the 1st via Venmo","match":"900.00.*Freya Kim","outcome":"confirm"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"standing.0.payee_handle","equals":"@freyak"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

## C00267 · M17 · New recipient handle and rail answers retain amount · PASS

Expected: [{"say":"send Dana 25"},{"say":"@danak"},{"say":"@danak"},{"say":"Venmo"},{"say":"@danak","match":"25.00.*Dana","outcome":"confirm"}]

### Trial 1

User: send Dana 25

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $25.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: send Dana 25

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $25.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: send Dana 25

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $25.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00268 · M18 · Split remembers total while asking who participated · PASS

Expected: [{"say":"split 60 with 2 friends"},{"say":"freya and wren","match":"20.00 each.*60.00","outcome":"confirm"}]

### Trial 1

User: split 60 with 2 friends

Upmore: That's $20.00 each across 3 people. Who are the 2? I'll request $20.00 from each.

User: freya and wren

Upmore: Request $20.00 each from Freya Kim (@freyak) and Wren Rao (@wrenr) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: split 60 with 2 friends

Upmore: That's $20.00 each across 3 people. Who are the 2? I'll request $20.00 from each.

User: freya and wren

Upmore: Request $20.00 each from Freya Kim (@freyak) and Wren Rao (@wrenr) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: split 60 with 2 friends

Upmore: That's $20.00 each across 3 people. Who are the 2? I'll request $20.00 from each.

User: freya and wren

Upmore: Request $20.00 each from Freya Kim (@freyak) and Wren Rao (@wrenr) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

## C00269 · M19 · Rent is remembered on the next independent invocation · PASS

Expected: [{"say":"pay my rent"},{"say":"freya $900 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent","match":"900.00.*Freya Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $900.00 to Freya Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $900.00 to Freya Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $900.00 to Freya Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

## C00270 · M20 · An interrupted alias goal remains unconfirmed · PASS

Expected: [{"say":"save freya as brother"},{"say":"no"},{"state":"recipients.0.nickname","equals":null},{"say":"send brother 20","match":"handle","outcome":"ask"}]

### Trial 1

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 20

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 2

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 20

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 3

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 20

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

## C00271 · M21 · A staged payment is remembered without claiming completion · PASS

Expected: [{"say":"send freya 20"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Freya Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $20.00 to Freya Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 2

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Freya Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $20.00 to Freya Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 3

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Freya Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $20.00 to Freya Kim for you to send in Venmo. A second yes doesn't stage it again.

## C00272 · M22 · A staged split is remembered without duplicating it · PASS

Expected: [{"say":"split 60 with freya and wren"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 60 with freya and wren

Upmore: Request $20.00 each from Freya Kim (@freyak) and Wren Rao (@wrenr) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Freya Kim (@freyak) $20.00 in Venmo, Wren Rao (@wrenr) $20.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 60 with freya and wren

Upmore: Request $20.00 each from Freya Kim (@freyak) and Wren Rao (@wrenr) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Freya Kim (@freyak) $20.00 in Venmo, Wren Rao (@wrenr) $20.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 60 with freya and wren

Upmore: Request $20.00 each from Freya Kim (@freyak) and Wren Rao (@wrenr) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Freya Kim (@freyak) $20.00 in Venmo, Wren Rao (@wrenr) $20.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C00273 · M23 · A declined payment cannot be resurrected by yes · PASS

Expected: [{"say":"send freya 20"},{"say":"no","match":"Nothing","outcome":"declined"},{"say":"yes","not":"^Staged, not sent"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 2

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 3

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

## C00274 · M24 · Stopping rent prevents the next turn from claiming an active rule · PASS

Expected: [{"say":"pay my rent"},{"say":"freya $900 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Freya Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Freya Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Freya Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C00275 · M25 · Status follow-up recalls staged versus sent · PASS

Expected: [{"say":"send freya 20"},{"say":"yes"},{"say":"did it go through","match":"(?:not (?:yet )?(?:sent|posted)|staged|have not seen|waiting for.*post)"}]

### Trial 1

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Freya Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $20.00 to Freya Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

### Trial 2

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Freya Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $20.00 to Freya Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

### Trial 3

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Freya Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $20.00 to Freya Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

## C00276 · M26 · Unapproved nickname does not become a known fact · PASS

Expected: [{"say":"save freya as brother"},{"state":"recipients.0.nickname","equals":null},{"say":"no"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 2

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 3

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

## C00277 · M27 · Unapproved rent terms are not durable instructions · PASS

Expected: [{"say":"pay my rent"},{"say":"freya $900 on the 1st via Venmo"},{"state":"standing.length","equals":0},{"say":"no"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

## C00278 · M28 · An expired payment card is restated and requires a fresh yes · PASS

Expected: [{"say":"send freya 20"},{"minutes":11},{"say":"yes","match":"expired.*fresh","outcome":"confirm"},{"state":"state.send.sends.length","equals":0},{"say":"yes","match":"Staged","outcome":"staged"}]

### Trial 1

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Freya Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Freya Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Freya Kim posts; if it hasn't by tonight, I'll ask.

## C00279 · M29 · An expired nickname card never writes a fact · PASS

Expected: [{"say":"save freya as brother"},{"minutes":11},{"say":"yes","match":"expired"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 2

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 3

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

## C00280 · M30 · A question containing yes does not approve a payment · PASS

Expected: [{"say":"send freya 20"},{"say":"yes but is there a fee"},{"state":"state.send.sends.length","equals":0},{"say":"no"}]

### Trial 1

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

### Trial 2

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

### Trial 3

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

## C00281 · M31 · Moving to small talk explicitly drops the old payment · PASS

Expected: [{"say":"send freya 20"},{"say":"what's a good movie","match":"dropped.*20.00"},{"say":"yes","not":"^Staged"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $20.00 to Freya Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $20.00 to Freya Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $20.00 to Freya Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00282 · M32 · Switching recipients makes the latest request authoritative · PASS

Expected: [{"say":"send freya 20"},{"say":"send wren 30","match":"30.00.*Wren Rao","outcome":"confirm"},{"say":"yes","match":"30.00.*Wren Rao","outcome":"staged"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send wren 30

Upmore: I dropped the earlier card. Set up $30.00 to Wren Rao (@wrenr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @wrenr; 3. Enter $30.00; 4. Keep it private, then Pay. I'll confirm when $30.00 to Wren Rao posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send wren 30

Upmore: I dropped the earlier card. Set up $30.00 to Wren Rao (@wrenr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @wrenr; 3. Enter $30.00; 4. Keep it private, then Pay. I'll confirm when $30.00 to Wren Rao posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send wren 30

Upmore: I dropped the earlier card. Set up $30.00 to Wren Rao (@wrenr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @wrenr; 3. Enter $30.00; 4. Keep it private, then Pay. I'll confirm when $30.00 to Wren Rao posts; if it hasn't by tonight, I'll ask.

## C00283 · M33 · A payment supersedes a pending split rather than approving both · PASS

Expected: [{"say":"split 60 with freya and wren"},{"say":"send freya 20","match":"20.00.*Freya Kim","outcome":"confirm"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"state":"state.split.staged.length","equals":0}]

### Trial 1

User: split 60 with freya and wren

Upmore: Request $20.00 each from Freya Kim (@freyak) and Wren Rao (@wrenr) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send freya 20

Upmore: I dropped the earlier card. Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Freya Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: split 60 with freya and wren

Upmore: Request $20.00 each from Freya Kim (@freyak) and Wren Rao (@wrenr) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send freya 20

Upmore: I dropped the earlier card. Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Freya Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: split 60 with freya and wren

Upmore: Request $20.00 each from Freya Kim (@freyak) and Wren Rao (@wrenr) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send freya 20

Upmore: I dropped the earlier card. Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Freya Kim posts; if it hasn't by tonight, I'll ask.

## C00284 · M34 · Switching from payment to rent keeps the new goal · PASS

Expected: [{"say":"send freya 20"},{"say":"pay my rent","match":"Who","outcome":"ask"},{"say":"freya $900 on the 1st via Venmo"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 2

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 3

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

## C00285 · M35 · Never mind cancels an alias confirmation without saving · PASS

Expected: [{"say":"save freya as brother"},{"say":"never mind"},{"state":"recipients.0.nickname","equals":null},{"say":"yes","not":"^Saved:"}]

### Trial 1

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 2

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 3

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

## C00286 · M36 · Confirmed aliases survive a new conversation · PASS

Expected: [{"say":"save freya as brother"},{"say":"yes"},{"thread":"B"},{"say":"send brother 20","match":"Freya Kim","outcome":"confirm"}]

### Trial 1

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Freya Kim (brother, @freyak).

User: send brother 20

Upmore: Set up $20.00 to Freya Kim (brother, @freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Freya Kim (brother, @freyak).

User: send brother 20

Upmore: Set up $20.00 to Freya Kim (brother, @freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Freya Kim (brother, @freyak).

User: send brother 20

Upmore: Set up $20.00 to Freya Kim (brother, @freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00287 · M37 · Standing rent survives a new conversation · PASS

Expected: [{"say":"pay my rent"},{"say":"freya $900 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"pay my rent","match":"900.00.*Freya Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $900.00 to Freya Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $900.00 to Freya Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $900.00 to Freya Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

## C00288 · M38 · Unapproved thread A card cannot be approved in thread B · PASS

Expected: [{"say":"send freya 20"},{"thread":"B"},{"say":"yes","not":"^Staged"},{"thread":"A"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00289 · M39 · A nickname correction in another session supersedes the old meaning · PASS

Expected: [{"say":"save freya as brother"},{"say":"yes"},{"thread":"B"},{"say":"brother is Wren Rao"},{"say":"yes"},{"thread":"C"},{"say":"send brother 20","match":"Wren Rao","outcome":"confirm"}]

### Trial 1

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Freya Kim (brother, @freyak).

User: brother is Wren Rao

Upmore: Save "brother" as your name for Wren Rao (@wrenr)? Then "send brother 20" goes to Wren Rao. "brother" means Freya Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Wren Rao (brother, @wrenr).

User: send brother 20

Upmore: Set up $20.00 to Wren Rao (brother, @wrenr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Freya Kim (brother, @freyak).

User: brother is Wren Rao

Upmore: Save "brother" as your name for Wren Rao (@wrenr)? Then "send brother 20" goes to Wren Rao. "brother" means Freya Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Wren Rao (brother, @wrenr).

User: send brother 20

Upmore: Set up $20.00 to Wren Rao (brother, @wrenr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Freya Kim (brother, @freyak).

User: brother is Wren Rao

Upmore: Save "brother" as your name for Wren Rao (@wrenr)? Then "send brother 20" goes to Wren Rao. "brother" means Freya Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Wren Rao (brother, @wrenr).

User: send brother 20

Upmore: Set up $20.00 to Wren Rao (brother, @wrenr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00290 · M40 · Stopping rent in another session prevents future offers · PASS

Expected: [{"say":"pay my rent"},{"say":"freya $900 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"stop rent"},{"thread":"C"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Freya Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Freya Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Freya Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C00291 · M41 · Repeating a staged approval does not stage twice after restore · PASS

Expected: [{"say":"send freya 20"},{"say":"yes"},{"say":"yes","match":"already staged","outcome":"already_done"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Freya Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $20.00 to Freya Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $20.00 to Freya Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 2

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Freya Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $20.00 to Freya Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $20.00 to Freya Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 3

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $20.00; 4. Keep it private, then Pay. I'll confirm when $20.00 to Freya Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $20.00 to Freya Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $20.00 to Freya Kim for you to send in Venmo. A second yes doesn't stage it again.

## C00292 · M42 · Rent setup retry leaves exactly one standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"freya $900 on the 1st via Venmo"},{"say":"yes"},{"say":"yes","not":"^Rent is set up"},{"state":"standing.length","equals":1}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00293 · M43 · Confirmed alias repeated is recognized as already known · PASS

Expected: [{"say":"save freya as brother"},{"say":"yes"},{"say":"save freya as brother","match":"already|Already|already means","outcome":"already_done"},{"state":"ops.length","equals":1}]

### Trial 1

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Freya Kim (brother, @freyak).

User: save freya as brother

Upmore: "brother" already means Freya Kim (brother, @freyak). Nothing changed.

### Trial 2

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Freya Kim (brother, @freyak).

User: save freya as brother

Upmore: "brother" already means Freya Kim (brother, @freyak). Nothing changed.

### Trial 3

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Freya Kim (brother, @freyak).

User: save freya as brother

Upmore: "brother" already means Freya Kim (brother, @freyak). Nothing changed.

## C00294 · M44 · The same month rent is staged once across restored sessions · PASS

Expected: [{"say":"pay my rent"},{"say":"freya $900 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"pay my rent","match":"already staged","outcome":"already_done"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $900.00 to Freya Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $900.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $900.00 to Freya Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $900.00 to Freya Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $900.00 to Freya Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $900.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $900.00 to Freya Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $900.00 to Freya Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $900.00 to Freya Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @freyak; 3. Enter $900.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $900.00 to Freya Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $900.00 to Freya Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

## C00295 · M45 · Retried split approval preserves one set of requests · PASS

Expected: [{"say":"split 60 with freya and wren"},{"say":"yes"},{"say":"yes"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 60 with freya and wren

Upmore: Request $20.00 each from Freya Kim (@freyak) and Wren Rao (@wrenr) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Freya Kim (@freyak) $20.00 in Venmo, Wren Rao (@wrenr) $20.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 60 with freya and wren

Upmore: Request $20.00 each from Freya Kim (@freyak) and Wren Rao (@wrenr) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Freya Kim (@freyak) $20.00 in Venmo, Wren Rao (@wrenr) $20.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 60 with freya and wren

Upmore: Request $20.00 each from Freya Kim (@freyak) and Wren Rao (@wrenr) in Venmo: $60.00 split 3 ways, yours $20.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Freya Kim (@freyak) $20.00 in Venmo, Wren Rao (@wrenr) $20.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C00296 · M46 · Nickname save failure is never reported as remembered · PASS

Expected: [{"say":"save freya as brother"},{"set":{"failRecipients":true}},{"say":"yes","match":"couldn't save"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 2

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 3

User: save freya as brother

Upmore: Save "brother" as your name for Freya Kim (@freyak)? Then "send brother 20" goes to Freya Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

## C00297 · M47 · Rent save failure is never reported as a stored rule · PASS

Expected: [{"say":"pay my rent"},{"say":"freya $900 on the 1st via Venmo"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*set|nothing was set up"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

## C00298 · M48 · A failed state write yields no approval card and retry is recoverable · PASS

Expected: [{"set":{"failState":true}},{"say":"send freya 20","error":"state storage unavailable"},{"set":{"failState":false}},{"say":"send freya 20","match":"20.00.*Freya Kim","outcome":"confirm"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send freya 20

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: send freya 20

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: send freya 20

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00299 · M49 · Unavailable facts cause an honest blocker and preserve the old card · PASS

Expected: [{"say":"send freya 20"},{"set":{"unreadable":true}},{"say":"yes","match":"can't read.*Nothing was changed","outcome":"unavailable"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

### Trial 2

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

### Trial 3

User: send freya 20

Upmore: Set up $20.00 to Freya Kim (@freyak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

## C00300 · M50 · A failed rent correction retains the prior confirmed terms · PASS

Expected: [{"say":"pay my rent"},{"say":"freya $900 on the 1st via Venmo"},{"say":"yes"},{"say":"rent is 950 now"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*change|rent stays as it was"},{"state":"standing.0.amount_cents","equals":90000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 950 now

Upmore: Change rent (amount $900.00 to $950.00): $950.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 950 now

Upmore: Change rent (amount $900.00 to $950.00): $950.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: freya $900 on the 1st via Venmo

Upmore: Set up rent: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $900.00 to Freya Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 950 now

Upmore: Change rent (amount $900.00 to $950.00): $950.00 to Freya Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

