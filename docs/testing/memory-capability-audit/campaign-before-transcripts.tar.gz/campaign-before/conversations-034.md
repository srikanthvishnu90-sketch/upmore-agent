# conversations-034

All conversations are synthetic. Full production handler, mock authentication/PostgREST and disabled model; no real outbound messages or provider actions.

## C01651 · M01 · Confirmed nickname recalls the right person · PASS

Expected: [{"say":"save hugo as brother"},{"say":"yes"},{"say":"send brother 80","match":"Hugo Kim.*@hugok","outcome":"confirm"}]

### Trial 1

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Hugo Kim (brother, @hugok).

User: send brother 80

Upmore: Set up $80.00 to Hugo Kim (brother, @hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Hugo Kim (brother, @hugok).

User: send brother 80

Upmore: Set up $80.00 to Hugo Kim (brother, @hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Hugo Kim (brother, @hugok).

User: send brother 80

Upmore: Set up $80.00 to Hugo Kim (brother, @hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01652 · M02 · Explicit remember phrasing persists an alias · PASS

Expected: [{"say":"remember Alex Rao as my sister"},{"say":"yes"},{"say":"send sister 100","match":"Alex Rao.*@alexr","outcome":"confirm"}]

### Trial 1

User: remember Alex Rao as my sister

Upmore: Save "sister" as your name for Alex Rao (@alexr)? Then "send sister 20" goes to Alex Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Alex Rao (sister, @alexr).

User: send sister 100

Upmore: Set up $100.00 to Alex Rao (sister, @alexr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: remember Alex Rao as my sister

Upmore: Save "sister" as your name for Alex Rao (@alexr)? Then "send sister 20" goes to Alex Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Alex Rao (sister, @alexr).

User: send sister 100

Upmore: Set up $100.00 to Alex Rao (sister, @alexr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: remember Alex Rao as my sister

Upmore: Save "sister" as your name for Alex Rao (@alexr)? Then "send sister 20" goes to Alex Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Alex Rao (sister, @alexr).

User: send sister 100

Upmore: Set up $100.00 to Alex Rao (sister, @alexr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01653 · M03 · Natural relationship statement needs confirmation and persists · PASS

Expected: [{"say":"my dad is Hugo Kim","match":"Save"},{"say":"yes"},{"say":"send dad 120","match":"Hugo Kim","outcome":"confirm"}]

### Trial 1

User: my dad is Hugo Kim

Upmore: Save "dad" as your name for Hugo Kim (@hugok)? Then "send dad 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Hugo Kim (dad, @hugok).

User: send dad 120

Upmore: Set up $120.00 to Hugo Kim (dad, @hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: my dad is Hugo Kim

Upmore: Save "dad" as your name for Hugo Kim (@hugok)? Then "send dad 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Hugo Kim (dad, @hugok).

User: send dad 120

Upmore: Set up $120.00 to Hugo Kim (dad, @hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: my dad is Hugo Kim

Upmore: Save "dad" as your name for Hugo Kim (@hugok)? Then "send dad 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Hugo Kim (dad, @hugok).

User: send dad 120

Upmore: Set up $120.00 to Hugo Kim (dad, @hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01654 · M04 · An alias is moved only to the newly confirmed person · PASS

Expected: [{"say":"save hugo as brother"},{"say":"yes"},{"say":"brother is Alex Rao"},{"say":"yes"},{"say":"send brother 80","match":"Alex Rao","outcome":"confirm"}]

### Trial 1

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Hugo Kim (brother, @hugok).

User: brother is Alex Rao

Upmore: Save "brother" as your name for Alex Rao (@alexr)? Then "send brother 20" goes to Alex Rao. "brother" means Hugo Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Alex Rao (brother, @alexr).

User: send brother 80

Upmore: Set up $80.00 to Alex Rao (brother, @alexr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Hugo Kim (brother, @hugok).

User: brother is Alex Rao

Upmore: Save "brother" as your name for Alex Rao (@alexr)? Then "send brother 20" goes to Alex Rao. "brother" means Hugo Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Alex Rao (brother, @alexr).

User: send brother 80

Upmore: Set up $80.00 to Alex Rao (brother, @alexr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Hugo Kim (brother, @hugok).

User: brother is Alex Rao

Upmore: Save "brother" as your name for Alex Rao (@alexr)? Then "send brother 20" goes to Alex Rao. "brother" means Hugo Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Alex Rao (brother, @alexr).

User: send brother 80

Upmore: Set up $80.00 to Alex Rao (brother, @alexr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01655 · M05 · Rejected alias preserves the previous confirmed fact · PASS

Expected: [{"say":"save hugo as brother"},{"say":"yes"},{"say":"brother is Alex Rao"},{"say":"no"},{"say":"send brother 80","match":"Hugo Kim","outcome":"confirm"}]

### Trial 1

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Hugo Kim (brother, @hugok).

User: brother is Alex Rao

Upmore: Save "brother" as your name for Alex Rao (@alexr)? Then "send brother 20" goes to Alex Rao. "brother" means Hugo Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 80

Upmore: Set up $80.00 to Hugo Kim (brother, @hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Hugo Kim (brother, @hugok).

User: brother is Alex Rao

Upmore: Save "brother" as your name for Alex Rao (@alexr)? Then "send brother 20" goes to Alex Rao. "brother" means Hugo Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 80

Upmore: Set up $80.00 to Hugo Kim (brother, @hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Hugo Kim (brother, @hugok).

User: brother is Alex Rao

Upmore: Save "brother" as your name for Alex Rao (@alexr)? Then "send brother 20" goes to Alex Rao. "brother" means Hugo Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 80

Upmore: Set up $80.00 to Hugo Kim (brother, @hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01656 · M06 · Amount correction preserves payee and replaces the old card · PASS

Expected: [{"say":"send hugo 80"},{"say":"make it 140","match":"140.00.*Hugo Kim","outcome":"confirm"},{"say":"yes","match":"140.00","outcome":"staged"},{"state":"state.send.sends.0.amount_cents","equals":14000}]

### Trial 1

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 140

Upmore: Got it. Set up $140.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $140.00; 4. Keep it private, then Pay. I'll confirm when $140.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 140

Upmore: Got it. Set up $140.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $140.00; 4. Keep it private, then Pay. I'll confirm when $140.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 140

Upmore: Got it. Set up $140.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $140.00; 4. Keep it private, then Pay. I'll confirm when $140.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask.

## C01657 · M07 · Actually correction handles a different amount · PASS

Expected: [{"say":"send hugo 80"},{"say":"actually make it 200","match":"200.00.*Hugo Kim","outcome":"confirm"},{"say":"yes","match":"200.00","outcome":"staged"}]

### Trial 1

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 200

Upmore: Got it. Set up $200.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $200.00; 4. Keep it private, then Pay. I'll confirm when $200.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 200

Upmore: Got it. Set up $200.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $200.00; 4. Keep it private, then Pay. I'll confirm when $200.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 200

Upmore: Got it. Set up $200.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $200.00; 4. Keep it private, then Pay. I'll confirm when $200.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask.

## C01658 · M08 · Bare currency correction retains payment context · PASS

Expected: [{"say":"send hugo 80"},{"say":"$50.00 instead","match":"50.00.*Hugo Kim","outcome":"confirm"},{"say":"yes","match":"50.00","outcome":"staged"}]

### Trial 1

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $50.00 instead

Upmore: Got it. Set up $50.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $50.00; 4. Keep it private, then Pay. I'll confirm when $50.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $50.00 instead

Upmore: Got it. Set up $50.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $50.00; 4. Keep it private, then Pay. I'll confirm when $50.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $50.00 instead

Upmore: Got it. Set up $50.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $50.00; 4. Keep it private, then Pay. I'll confirm when $50.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask.

## C01659 · M09 · Split total correction recomputes every share before approval · PASS

Expected: [{"say":"split 240 with hugo and alex"},{"say":"make it 360","match":"120.00 each.*360.00","outcome":"confirm"},{"say":"yes","match":"120.00","outcome":"staged"}]

### Trial 1

User: split 240 with hugo and alex

Upmore: Request $80.00 each from Hugo Kim (@hugok) and Alex Rao (@alexr) in Venmo: $240.00 split 3 ways, yours $80.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 360

Upmore: Got it. Request $120.00 each from Hugo Kim (@hugok) and Alex Rao (@alexr) in Venmo: $360.00 split 3 ways, yours $120.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Hugo Kim (@hugok) $120.00 in Venmo, Alex Rao (@alexr) $120.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 240 with hugo and alex

Upmore: Request $80.00 each from Hugo Kim (@hugok) and Alex Rao (@alexr) in Venmo: $240.00 split 3 ways, yours $80.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 360

Upmore: Got it. Request $120.00 each from Hugo Kim (@hugok) and Alex Rao (@alexr) in Venmo: $360.00 split 3 ways, yours $120.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Hugo Kim (@hugok) $120.00 in Venmo, Alex Rao (@alexr) $120.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 240 with hugo and alex

Upmore: Request $80.00 each from Hugo Kim (@hugok) and Alex Rao (@alexr) in Venmo: $240.00 split 3 ways, yours $80.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 360

Upmore: Got it. Request $120.00 each from Hugo Kim (@hugok) and Alex Rao (@alexr) in Venmo: $360.00 split 3 ways, yours $120.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Hugo Kim (@hugok) $120.00 in Venmo, Alex Rao (@alexr) $120.00 in Venmo. I'll mark each one paid when the money lands.

## C01660 · M10 · Rent setup correction retains recipient and due day · FAIL

Expected: [{"say":"pay my rent"},{"say":"hugo $3600 on the 1st via Venmo"},{"say":"make it 3800","match":"3800.00.*Hugo Kim.*1st","outcome":"confirm"},{"say":"yes"},{"state":"standing.0.amount_cents","equals":380000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 3800

Upmore: Got it. Set up rent: $3,800.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,800.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"3800.00.*Hugo Kim.*1st","actual":{"thread_id":"ce41e1fa-968c-44ca-b2ab-513f34d69b15","reply":"Got it. Set up rent: $3,800.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 3800

Upmore: Got it. Set up rent: $3,800.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,800.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"3800.00.*Hugo Kim.*1st","actual":{"thread_id":"a90b83f0-370e-461e-b006-df35dd94a4b2","reply":"Got it. Set up rent: $3,800.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 3800

Upmore: Got it. Set up rent: $3,800.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,800.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"3800.00.*Hugo Kim.*1st","actual":{"thread_id":"ce810b96-89e2-4472-a8a3-eedf42433203","reply":"Got it. Set up rent: $3,800.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

## C01661 · M11 · Details refers to the pending payment · PASS

Expected: [{"say":"send hugo 80"},{"say":"details","match":"80.00.*Hugo Kim","outcome":"details"}]

### Trial 1

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $80.00 to Hugo Kim on Venmo $80.00 to Hugo Kim (@hugok) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

### Trial 2

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $80.00 to Hugo Kim on Venmo $80.00 to Hugo Kim (@hugok) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

### Trial 3

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $80.00 to Hugo Kim on Venmo $80.00 to Hugo Kim (@hugok) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

## C01662 · M12 · A short yes resumes a serialized split · PASS

Expected: [{"say":"split 240 with hugo and alex"},{"say":"yes","match":"Hugo Kim.*80.00.*Alex Rao.*80.00","outcome":"staged"}]

### Trial 1

User: split 240 with hugo and alex

Upmore: Request $80.00 each from Hugo Kim (@hugok) and Alex Rao (@alexr) in Venmo: $240.00 split 3 ways, yours $80.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Hugo Kim (@hugok) $80.00 in Venmo, Alex Rao (@alexr) $80.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 240 with hugo and alex

Upmore: Request $80.00 each from Hugo Kim (@hugok) and Alex Rao (@alexr) in Venmo: $240.00 split 3 ways, yours $80.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Hugo Kim (@hugok) $80.00 in Venmo, Alex Rao (@alexr) $80.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 240 with hugo and alex

Upmore: Request $80.00 each from Hugo Kim (@hugok) and Alex Rao (@alexr) in Venmo: $240.00 split 3 ways, yours $80.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Hugo Kim (@hugok) $80.00 in Venmo, Alex Rao (@alexr) $80.00 in Venmo. I'll mark each one paid when the money lands.

## C01663 · M13 · Cancellation that resolves the last discussed subscription · PASS

Expected: [{"say":"cancel netflix","match":"Netflix"},{"say":"cancel that","match":"Netflix"}]

### Trial 1

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 2

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 3

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

## C01664 · M14 · Stop rent refers to the confirmed standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"hugo $3600 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent","match":"Rent is off","outcome":"rent_stopped"},{"state":"standing.0.status","equals":"stopped"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Hugo Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Hugo Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Hugo Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

## C01665 · M15 · A contextual fee question retains payment identity and asks before acting · PASS

Expected: [{"say":"send hugo 80"},{"say":"what's the fee on that","match":"80.00.*Hugo Kim"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $80.00 to Hugo Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $80.00 to Hugo Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $80.00 to Hugo Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C01666 · M16 · Rent setup answers retain the original goal · FAIL

Expected: [{"say":"pay my rent","match":"Who"},{"say":"hugo $3600 on the 1st via Venmo","match":"3600.00.*Hugo Kim","outcome":"confirm"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"standing.0.payee_handle","equals":"@hugok"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"3600.00.*Hugo Kim","actual":{"thread_id":"86ead3ce-94dd-45e5-b357-2b3c32dc1895","reply":"Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"3600.00.*Hugo Kim","actual":{"thread_id":"9a932738-8f13-4e1b-bb83-e6edb0041b7d","reply":"Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"3600.00.*Hugo Kim","actual":{"thread_id":"c5f4e1a5-b1e7-4b5c-9ac4-d55afb76f5ea","reply":"Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

## C01667 · M17 · New recipient handle and rail answers retain amount · PASS

Expected: [{"say":"send Dana 100"},{"say":"@danak"},{"say":"@danak"},{"say":"Venmo"},{"say":"@danak","match":"100.00.*Dana","outcome":"confirm"}]

### Trial 1

User: send Dana 100

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $100.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: send Dana 100

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $100.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: send Dana 100

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $100.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01668 · M18 · Split remembers total while asking who participated · PASS

Expected: [{"say":"split 240 with 2 friends"},{"say":"hugo and alex","match":"80.00 each.*240.00","outcome":"confirm"}]

### Trial 1

User: split 240 with 2 friends

Upmore: That's $80.00 each across 3 people. Who are the 2? I'll request $80.00 from each.

User: hugo and alex

Upmore: Request $80.00 each from Hugo Kim (@hugok) and Alex Rao (@alexr) in Venmo: $240.00 split 3 ways, yours $80.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: split 240 with 2 friends

Upmore: That's $80.00 each across 3 people. Who are the 2? I'll request $80.00 from each.

User: hugo and alex

Upmore: Request $80.00 each from Hugo Kim (@hugok) and Alex Rao (@alexr) in Venmo: $240.00 split 3 ways, yours $80.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: split 240 with 2 friends

Upmore: That's $80.00 each across 3 people. Who are the 2? I'll request $80.00 from each.

User: hugo and alex

Upmore: Request $80.00 each from Hugo Kim (@hugok) and Alex Rao (@alexr) in Venmo: $240.00 split 3 ways, yours $80.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

## C01669 · M19 · Rent is remembered on the next independent invocation · FAIL

Expected: [{"say":"pay my rent"},{"say":"hugo $3600 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent","match":"3600.00.*Hugo Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $3,600.00 to Hugo Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"3600.00.*Hugo Kim","actual":{"thread_id":"53a33d2a-05c7-4bea-91c7-e9b81bfecb71","reply":"Rent for November: $3,600.00 to Hugo Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $3,600.00 to Hugo Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"3600.00.*Hugo Kim","actual":{"thread_id":"28f3b27a-57ca-4ba9-bd28-f36f8f48ba80","reply":"Rent for November: $3,600.00 to Hugo Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $3,600.00 to Hugo Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"3600.00.*Hugo Kim","actual":{"thread_id":"6a044acc-9bee-43e1-83d0-6cdd446b0e95","reply":"Rent for November: $3,600.00 to Hugo Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

## C01670 · M20 · An interrupted alias goal remains unconfirmed · PASS

Expected: [{"say":"save hugo as brother"},{"say":"no"},{"state":"recipients.0.nickname","equals":null},{"say":"send brother 80","match":"handle","outcome":"ask"}]

### Trial 1

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 80

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 2

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 80

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 3

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 80

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

## C01671 · M21 · A staged payment is remembered without claiming completion · PASS

Expected: [{"say":"send hugo 80"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $80.00; 4. Keep it private, then Pay. I'll confirm when $80.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $80.00 to Hugo Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 2

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $80.00; 4. Keep it private, then Pay. I'll confirm when $80.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $80.00 to Hugo Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 3

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $80.00; 4. Keep it private, then Pay. I'll confirm when $80.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $80.00 to Hugo Kim for you to send in Venmo. A second yes doesn't stage it again.

## C01672 · M22 · A staged split is remembered without duplicating it · PASS

Expected: [{"say":"split 240 with hugo and alex"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 240 with hugo and alex

Upmore: Request $80.00 each from Hugo Kim (@hugok) and Alex Rao (@alexr) in Venmo: $240.00 split 3 ways, yours $80.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Hugo Kim (@hugok) $80.00 in Venmo, Alex Rao (@alexr) $80.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 240 with hugo and alex

Upmore: Request $80.00 each from Hugo Kim (@hugok) and Alex Rao (@alexr) in Venmo: $240.00 split 3 ways, yours $80.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Hugo Kim (@hugok) $80.00 in Venmo, Alex Rao (@alexr) $80.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 240 with hugo and alex

Upmore: Request $80.00 each from Hugo Kim (@hugok) and Alex Rao (@alexr) in Venmo: $240.00 split 3 ways, yours $80.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Hugo Kim (@hugok) $80.00 in Venmo, Alex Rao (@alexr) $80.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C01673 · M23 · A declined payment cannot be resurrected by yes · PASS

Expected: [{"say":"send hugo 80"},{"say":"no","match":"Nothing","outcome":"declined"},{"say":"yes","not":"^Staged, not sent"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 2

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 3

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

## C01674 · M24 · Stopping rent prevents the next turn from claiming an active rule · PASS

Expected: [{"say":"pay my rent"},{"say":"hugo $3600 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Hugo Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Hugo Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Hugo Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C01675 · M25 · Status follow-up recalls staged versus sent · PASS

Expected: [{"say":"send hugo 80"},{"say":"yes"},{"say":"did it go through","match":"(?:not (?:yet )?(?:sent|posted)|staged|have not seen|waiting for.*post)"}]

### Trial 1

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $80.00; 4. Keep it private, then Pay. I'll confirm when $80.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $80.00 to Hugo Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

### Trial 2

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $80.00; 4. Keep it private, then Pay. I'll confirm when $80.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $80.00 to Hugo Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

### Trial 3

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $80.00; 4. Keep it private, then Pay. I'll confirm when $80.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $80.00 to Hugo Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

## C01676 · M26 · Unapproved nickname does not become a known fact · PASS

Expected: [{"say":"save hugo as brother"},{"state":"recipients.0.nickname","equals":null},{"say":"no"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 2

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 3

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

## C01677 · M27 · Unapproved rent terms are not durable instructions · PASS

Expected: [{"say":"pay my rent"},{"say":"hugo $3600 on the 1st via Venmo"},{"state":"standing.length","equals":0},{"say":"no"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

## C01678 · M28 · An expired payment card is restated and requires a fresh yes · PASS

Expected: [{"say":"send hugo 80"},{"minutes":11},{"say":"yes","match":"expired.*fresh","outcome":"confirm"},{"state":"state.send.sends.length","equals":0},{"say":"yes","match":"Staged","outcome":"staged"}]

### Trial 1

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $80.00; 4. Keep it private, then Pay. I'll confirm when $80.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $80.00; 4. Keep it private, then Pay. I'll confirm when $80.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $80.00; 4. Keep it private, then Pay. I'll confirm when $80.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask.

## C01679 · M29 · An expired nickname card never writes a fact · PASS

Expected: [{"say":"save hugo as brother"},{"minutes":11},{"say":"yes","match":"expired"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 2

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 3

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

## C01680 · M30 · A question containing yes does not approve a payment · PASS

Expected: [{"say":"send hugo 80"},{"say":"yes but is there a fee"},{"state":"state.send.sends.length","equals":0},{"say":"no"}]

### Trial 1

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

### Trial 2

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

### Trial 3

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

## C01681 · M31 · Moving to small talk explicitly drops the old payment · PASS

Expected: [{"say":"send hugo 80"},{"say":"what's a good movie","match":"dropped.*80.00"},{"say":"yes","not":"^Staged"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $80.00 to Hugo Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $80.00 to Hugo Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $80.00 to Hugo Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C01682 · M32 · Switching recipients makes the latest request authoritative · PASS

Expected: [{"say":"send hugo 80"},{"say":"send alex 120","match":"120.00.*Alex Rao","outcome":"confirm"},{"say":"yes","match":"120.00.*Alex Rao","outcome":"staged"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send alex 120

Upmore: I dropped the earlier card. Set up $120.00 to Alex Rao (@alexr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexr; 3. Enter $120.00; 4. Keep it private, then Pay. I'll confirm when $120.00 to Alex Rao posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send alex 120

Upmore: I dropped the earlier card. Set up $120.00 to Alex Rao (@alexr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexr; 3. Enter $120.00; 4. Keep it private, then Pay. I'll confirm when $120.00 to Alex Rao posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send alex 120

Upmore: I dropped the earlier card. Set up $120.00 to Alex Rao (@alexr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @alexr; 3. Enter $120.00; 4. Keep it private, then Pay. I'll confirm when $120.00 to Alex Rao posts; if it hasn't by tonight, I'll ask.

## C01683 · M33 · A payment supersedes a pending split rather than approving both · PASS

Expected: [{"say":"split 240 with hugo and alex"},{"say":"send hugo 80","match":"80.00.*Hugo Kim","outcome":"confirm"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"state":"state.split.staged.length","equals":0}]

### Trial 1

User: split 240 with hugo and alex

Upmore: Request $80.00 each from Hugo Kim (@hugok) and Alex Rao (@alexr) in Venmo: $240.00 split 3 ways, yours $80.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send hugo 80

Upmore: I dropped the earlier card. Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $80.00; 4. Keep it private, then Pay. I'll confirm when $80.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: split 240 with hugo and alex

Upmore: Request $80.00 each from Hugo Kim (@hugok) and Alex Rao (@alexr) in Venmo: $240.00 split 3 ways, yours $80.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send hugo 80

Upmore: I dropped the earlier card. Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $80.00; 4. Keep it private, then Pay. I'll confirm when $80.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: split 240 with hugo and alex

Upmore: Request $80.00 each from Hugo Kim (@hugok) and Alex Rao (@alexr) in Venmo: $240.00 split 3 ways, yours $80.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send hugo 80

Upmore: I dropped the earlier card. Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $80.00; 4. Keep it private, then Pay. I'll confirm when $80.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask.

## C01684 · M34 · Switching from payment to rent keeps the new goal · PASS

Expected: [{"say":"send hugo 80"},{"say":"pay my rent","match":"Who","outcome":"ask"},{"say":"hugo $3600 on the 1st via Venmo"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 2

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 3

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

## C01685 · M35 · Never mind cancels an alias confirmation without saving · PASS

Expected: [{"say":"save hugo as brother"},{"say":"never mind"},{"state":"recipients.0.nickname","equals":null},{"say":"yes","not":"^Saved:"}]

### Trial 1

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 2

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 3

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

## C01686 · M36 · Confirmed aliases survive a new conversation · PASS

Expected: [{"say":"save hugo as brother"},{"say":"yes"},{"thread":"B"},{"say":"send brother 80","match":"Hugo Kim","outcome":"confirm"}]

### Trial 1

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Hugo Kim (brother, @hugok).

User: send brother 80

Upmore: Set up $80.00 to Hugo Kim (brother, @hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Hugo Kim (brother, @hugok).

User: send brother 80

Upmore: Set up $80.00 to Hugo Kim (brother, @hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Hugo Kim (brother, @hugok).

User: send brother 80

Upmore: Set up $80.00 to Hugo Kim (brother, @hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01687 · M37 · Standing rent survives a new conversation · FAIL

Expected: [{"say":"pay my rent"},{"say":"hugo $3600 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"pay my rent","match":"3600.00.*Hugo Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $3,600.00 to Hugo Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"3600.00.*Hugo Kim","actual":{"thread_id":"e2afe99d-2f72-47df-b460-732f6d215d53","reply":"Rent for November: $3,600.00 to Hugo Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $3,600.00 to Hugo Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"3600.00.*Hugo Kim","actual":{"thread_id":"444d03ed-ebf3-4641-aab1-8acc909c9e5c","reply":"Rent for November: $3,600.00 to Hugo Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $3,600.00 to Hugo Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"3600.00.*Hugo Kim","actual":{"thread_id":"2dd907ae-7025-48ca-9798-958c5efd4117","reply":"Rent for November: $3,600.00 to Hugo Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

## C01688 · M38 · Unapproved thread A card cannot be approved in thread B · PASS

Expected: [{"say":"send hugo 80"},{"thread":"B"},{"say":"yes","not":"^Staged"},{"thread":"A"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C01689 · M39 · A nickname correction in another session supersedes the old meaning · PASS

Expected: [{"say":"save hugo as brother"},{"say":"yes"},{"thread":"B"},{"say":"brother is Alex Rao"},{"say":"yes"},{"thread":"C"},{"say":"send brother 80","match":"Alex Rao","outcome":"confirm"}]

### Trial 1

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Hugo Kim (brother, @hugok).

User: brother is Alex Rao

Upmore: Save "brother" as your name for Alex Rao (@alexr)? Then "send brother 20" goes to Alex Rao. "brother" means Hugo Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Alex Rao (brother, @alexr).

User: send brother 80

Upmore: Set up $80.00 to Alex Rao (brother, @alexr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Hugo Kim (brother, @hugok).

User: brother is Alex Rao

Upmore: Save "brother" as your name for Alex Rao (@alexr)? Then "send brother 20" goes to Alex Rao. "brother" means Hugo Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Alex Rao (brother, @alexr).

User: send brother 80

Upmore: Set up $80.00 to Alex Rao (brother, @alexr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Hugo Kim (brother, @hugok).

User: brother is Alex Rao

Upmore: Save "brother" as your name for Alex Rao (@alexr)? Then "send brother 20" goes to Alex Rao. "brother" means Hugo Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Alex Rao (brother, @alexr).

User: send brother 80

Upmore: Set up $80.00 to Alex Rao (brother, @alexr) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01690 · M40 · Stopping rent in another session prevents future offers · PASS

Expected: [{"say":"pay my rent"},{"say":"hugo $3600 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"stop rent"},{"thread":"C"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Hugo Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Hugo Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Hugo Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C01691 · M41 · Repeating a staged approval does not stage twice after restore · PASS

Expected: [{"say":"send hugo 80"},{"say":"yes"},{"say":"yes","match":"already staged","outcome":"already_done"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $80.00; 4. Keep it private, then Pay. I'll confirm when $80.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $80.00 to Hugo Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $80.00 to Hugo Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 2

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $80.00; 4. Keep it private, then Pay. I'll confirm when $80.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $80.00 to Hugo Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $80.00 to Hugo Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 3

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $80.00; 4. Keep it private, then Pay. I'll confirm when $80.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $80.00 to Hugo Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $80.00 to Hugo Kim for you to send in Venmo. A second yes doesn't stage it again.

## C01692 · M42 · Rent setup retry leaves exactly one standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"hugo $3600 on the 1st via Venmo"},{"say":"yes"},{"say":"yes","not":"^Rent is set up"},{"state":"standing.length","equals":1}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C01693 · M43 · Confirmed alias repeated is recognized as already known · PASS

Expected: [{"say":"save hugo as brother"},{"say":"yes"},{"say":"save hugo as brother","match":"already|Already|already means","outcome":"already_done"},{"state":"ops.length","equals":1}]

### Trial 1

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Hugo Kim (brother, @hugok).

User: save hugo as brother

Upmore: "brother" already means Hugo Kim (brother, @hugok). Nothing changed.

### Trial 2

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Hugo Kim (brother, @hugok).

User: save hugo as brother

Upmore: "brother" already means Hugo Kim (brother, @hugok). Nothing changed.

### Trial 3

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Hugo Kim (brother, @hugok).

User: save hugo as brother

Upmore: "brother" already means Hugo Kim (brother, @hugok). Nothing changed.

## C01694 · M44 · The same month rent is staged once across restored sessions · PASS

Expected: [{"say":"pay my rent"},{"say":"hugo $3600 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"pay my rent","match":"already staged","outcome":"already_done"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $3,600.00 to Hugo Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $3,600.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $3,600.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $3,600.00 to Hugo Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $3,600.00 to Hugo Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $3,600.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $3,600.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $3,600.00 to Hugo Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $3,600.00 to Hugo Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugok; 3. Enter $3,600.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $3,600.00 to Hugo Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $3,600.00 to Hugo Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

## C01695 · M45 · Retried split approval preserves one set of requests · PASS

Expected: [{"say":"split 240 with hugo and alex"},{"say":"yes"},{"say":"yes"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 240 with hugo and alex

Upmore: Request $80.00 each from Hugo Kim (@hugok) and Alex Rao (@alexr) in Venmo: $240.00 split 3 ways, yours $80.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Hugo Kim (@hugok) $80.00 in Venmo, Alex Rao (@alexr) $80.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 240 with hugo and alex

Upmore: Request $80.00 each from Hugo Kim (@hugok) and Alex Rao (@alexr) in Venmo: $240.00 split 3 ways, yours $80.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Hugo Kim (@hugok) $80.00 in Venmo, Alex Rao (@alexr) $80.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 240 with hugo and alex

Upmore: Request $80.00 each from Hugo Kim (@hugok) and Alex Rao (@alexr) in Venmo: $240.00 split 3 ways, yours $80.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Hugo Kim (@hugok) $80.00 in Venmo, Alex Rao (@alexr) $80.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C01696 · M46 · Nickname save failure is never reported as remembered · PASS

Expected: [{"say":"save hugo as brother"},{"set":{"failRecipients":true}},{"say":"yes","match":"couldn't save"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 2

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 3

User: save hugo as brother

Upmore: Save "brother" as your name for Hugo Kim (@hugok)? Then "send brother 20" goes to Hugo Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

## C01697 · M47 · Rent save failure is never reported as a stored rule · PASS

Expected: [{"say":"pay my rent"},{"say":"hugo $3600 on the 1st via Venmo"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*set|nothing was set up"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

## C01698 · M48 · A failed state write yields no approval card and retry is recoverable · PASS

Expected: [{"set":{"failState":true}},{"say":"send hugo 80","error":"state storage unavailable"},{"set":{"failState":false}},{"say":"send hugo 80","match":"80.00.*Hugo Kim","outcome":"confirm"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send hugo 80

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: send hugo 80

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: send hugo 80

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C01699 · M49 · Unavailable facts cause an honest blocker and preserve the old card · PASS

Expected: [{"say":"send hugo 80"},{"set":{"unreadable":true}},{"say":"yes","match":"can't read.*Nothing was changed","outcome":"unavailable"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

### Trial 2

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

### Trial 3

User: send hugo 80

Upmore: Set up $80.00 to Hugo Kim (@hugok) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

## C01700 · M50 · A failed rent correction retains the prior confirmed terms · PASS

Expected: [{"say":"pay my rent"},{"say":"hugo $3600 on the 1st via Venmo"},{"say":"yes"},{"say":"rent is 3800 now"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*change|rent stays as it was"},{"state":"standing.0.amount_cents","equals":360000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 3800 now

Upmore: Change rent (amount $3,600.00 to $3,800.00): $3,800.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 3800 now

Upmore: Change rent (amount $3,600.00 to $3,800.00): $3,800.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: hugo $3600 on the 1st via Venmo

Upmore: Set up rent: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $3,600.00 to Hugo Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 3800 now

Upmore: Change rent (amount $3,600.00 to $3,800.00): $3,800.00 to Hugo Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

