# conversations-017

All conversations are synthetic. Full production handler, mock authentication/PostgREST and disabled model; no real outbound messages or provider actions.

## C00801 · M01 · Confirmed nickname recalls the right person · PASS

Expected: [{"say":"save quinn as brother"},{"say":"yes"},{"say":"send brother 40","match":"Quinn Kim.*@quinnk","outcome":"confirm"}]

### Trial 1

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Quinn Kim (brother, @quinnk).

User: send brother 40

Upmore: Set up $40.00 to Quinn Kim (brother, @quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Quinn Kim (brother, @quinnk).

User: send brother 40

Upmore: Set up $40.00 to Quinn Kim (brother, @quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Quinn Kim (brother, @quinnk).

User: send brother 40

Upmore: Set up $40.00 to Quinn Kim (brother, @quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00802 · M02 · Explicit remember phrasing persists an alias · PASS

Expected: [{"say":"remember Hugo Rao as my sister"},{"say":"yes"},{"say":"send sister 50","match":"Hugo Rao.*@hugor","outcome":"confirm"}]

### Trial 1

User: remember Hugo Rao as my sister

Upmore: Save "sister" as your name for Hugo Rao (@hugor)? Then "send sister 20" goes to Hugo Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Hugo Rao (sister, @hugor).

User: send sister 50

Upmore: Set up $50.00 to Hugo Rao (sister, @hugor) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: remember Hugo Rao as my sister

Upmore: Save "sister" as your name for Hugo Rao (@hugor)? Then "send sister 20" goes to Hugo Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Hugo Rao (sister, @hugor).

User: send sister 50

Upmore: Set up $50.00 to Hugo Rao (sister, @hugor) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: remember Hugo Rao as my sister

Upmore: Save "sister" as your name for Hugo Rao (@hugor)? Then "send sister 20" goes to Hugo Rao. Reply YES to save it or NO.

User: yes

Upmore: Saved: "sister" is Hugo Rao (sister, @hugor).

User: send sister 50

Upmore: Set up $50.00 to Hugo Rao (sister, @hugor) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00803 · M03 · Natural relationship statement needs confirmation and persists · PASS

Expected: [{"say":"my dad is Quinn Kim","match":"Save"},{"say":"yes"},{"say":"send dad 60","match":"Quinn Kim","outcome":"confirm"}]

### Trial 1

User: my dad is Quinn Kim

Upmore: Save "dad" as your name for Quinn Kim (@quinnk)? Then "send dad 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Quinn Kim (dad, @quinnk).

User: send dad 60

Upmore: Set up $60.00 to Quinn Kim (dad, @quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: my dad is Quinn Kim

Upmore: Save "dad" as your name for Quinn Kim (@quinnk)? Then "send dad 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Quinn Kim (dad, @quinnk).

User: send dad 60

Upmore: Set up $60.00 to Quinn Kim (dad, @quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: my dad is Quinn Kim

Upmore: Save "dad" as your name for Quinn Kim (@quinnk)? Then "send dad 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "dad" is Quinn Kim (dad, @quinnk).

User: send dad 60

Upmore: Set up $60.00 to Quinn Kim (dad, @quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00804 · M04 · An alias is moved only to the newly confirmed person · PASS

Expected: [{"say":"save quinn as brother"},{"say":"yes"},{"say":"brother is Hugo Rao"},{"say":"yes"},{"say":"send brother 40","match":"Hugo Rao","outcome":"confirm"}]

### Trial 1

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Quinn Kim (brother, @quinnk).

User: brother is Hugo Rao

Upmore: Save "brother" as your name for Hugo Rao (@hugor)? Then "send brother 20" goes to Hugo Rao. "brother" means Quinn Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Hugo Rao (brother, @hugor).

User: send brother 40

Upmore: Set up $40.00 to Hugo Rao (brother, @hugor) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Quinn Kim (brother, @quinnk).

User: brother is Hugo Rao

Upmore: Save "brother" as your name for Hugo Rao (@hugor)? Then "send brother 20" goes to Hugo Rao. "brother" means Quinn Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Hugo Rao (brother, @hugor).

User: send brother 40

Upmore: Set up $40.00 to Hugo Rao (brother, @hugor) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Quinn Kim (brother, @quinnk).

User: brother is Hugo Rao

Upmore: Save "brother" as your name for Hugo Rao (@hugor)? Then "send brother 20" goes to Hugo Rao. "brother" means Quinn Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Hugo Rao (brother, @hugor).

User: send brother 40

Upmore: Set up $40.00 to Hugo Rao (brother, @hugor) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00805 · M05 · Rejected alias preserves the previous confirmed fact · PASS

Expected: [{"say":"save quinn as brother"},{"say":"yes"},{"say":"brother is Hugo Rao"},{"say":"no"},{"say":"send brother 40","match":"Quinn Kim","outcome":"confirm"}]

### Trial 1

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Quinn Kim (brother, @quinnk).

User: brother is Hugo Rao

Upmore: Save "brother" as your name for Hugo Rao (@hugor)? Then "send brother 20" goes to Hugo Rao. "brother" means Quinn Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 40

Upmore: Set up $40.00 to Quinn Kim (brother, @quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Quinn Kim (brother, @quinnk).

User: brother is Hugo Rao

Upmore: Save "brother" as your name for Hugo Rao (@hugor)? Then "send brother 20" goes to Hugo Rao. "brother" means Quinn Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 40

Upmore: Set up $40.00 to Quinn Kim (brother, @quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Quinn Kim (brother, @quinnk).

User: brother is Hugo Rao

Upmore: Save "brother" as your name for Hugo Rao (@hugor)? Then "send brother 20" goes to Hugo Rao. "brother" means Quinn Kim now; this moves it. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 40

Upmore: Set up $40.00 to Quinn Kim (brother, @quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00806 · M06 · Amount correction preserves payee and replaces the old card · PASS

Expected: [{"say":"send quinn 40"},{"say":"make it 70","match":"70.00.*Quinn Kim","outcome":"confirm"},{"say":"yes","match":"70.00","outcome":"staged"},{"state":"state.send.sends.0.amount_cents","equals":7000}]

### Trial 1

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 70

Upmore: Got it. Set up $70.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $70.00; 4. Keep it private, then Pay. I'll confirm when $70.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 70

Upmore: Got it. Set up $70.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $70.00; 4. Keep it private, then Pay. I'll confirm when $70.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: make it 70

Upmore: Got it. Set up $70.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $70.00; 4. Keep it private, then Pay. I'll confirm when $70.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask.

## C00807 · M07 · Actually correction handles a different amount · PASS

Expected: [{"say":"send quinn 40"},{"say":"actually make it 100","match":"100.00.*Quinn Kim","outcome":"confirm"},{"say":"yes","match":"100.00","outcome":"staged"}]

### Trial 1

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 100

Upmore: Got it. Set up $100.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 100

Upmore: Got it. Set up $100.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: actually make it 100

Upmore: Got it. Set up $100.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $100.00; 4. Keep it private, then Pay. I'll confirm when $100.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask.

## C00808 · M08 · Bare currency correction retains payment context · PASS

Expected: [{"say":"send quinn 40"},{"say":"$25.00 instead","match":"25.00.*Quinn Kim","outcome":"confirm"},{"say":"yes","match":"25.00","outcome":"staged"}]

### Trial 1

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $25.00 instead

Upmore: Got it. Set up $25.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $25.00; 4. Keep it private, then Pay. I'll confirm when $25.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $25.00 instead

Upmore: Got it. Set up $25.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $25.00; 4. Keep it private, then Pay. I'll confirm when $25.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: $25.00 instead

Upmore: Got it. Set up $25.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $25.00; 4. Keep it private, then Pay. I'll confirm when $25.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask.

## C00809 · M09 · Split total correction recomputes every share before approval · PASS

Expected: [{"say":"split 120 with quinn and hugo"},{"say":"make it 180","match":"60.00 each.*180.00","outcome":"confirm"},{"say":"yes","match":"60.00","outcome":"staged"}]

### Trial 1

User: split 120 with quinn and hugo

Upmore: Request $40.00 each from Quinn Kim (@quinnk) and Hugo Rao (@hugor) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 180

Upmore: Got it. Request $60.00 each from Quinn Kim (@quinnk) and Hugo Rao (@hugor) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Quinn Kim (@quinnk) $60.00 in Venmo, Hugo Rao (@hugor) $60.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 120 with quinn and hugo

Upmore: Request $40.00 each from Quinn Kim (@quinnk) and Hugo Rao (@hugor) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 180

Upmore: Got it. Request $60.00 each from Quinn Kim (@quinnk) and Hugo Rao (@hugor) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Quinn Kim (@quinnk) $60.00 in Venmo, Hugo Rao (@hugor) $60.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 120 with quinn and hugo

Upmore: Request $40.00 each from Quinn Kim (@quinnk) and Hugo Rao (@hugor) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: make it 180

Upmore: Got it. Request $60.00 each from Quinn Kim (@quinnk) and Hugo Rao (@hugor) in Venmo: $180.00 split 3 ways, yours $60.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Quinn Kim (@quinnk) $60.00 in Venmo, Hugo Rao (@hugor) $60.00 in Venmo. I'll mark each one paid when the money lands.

## C00810 · M10 · Rent setup correction retains recipient and due day · FAIL

Expected: [{"say":"pay my rent"},{"say":"quinn $1800 on the 1st via Venmo"},{"say":"make it 1900","match":"1900.00.*Quinn Kim.*1st","outcome":"confirm"},{"say":"yes"},{"state":"standing.0.amount_cents","equals":190000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 1900

Upmore: Got it. Set up rent: $1,900.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,900.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"1900.00.*Quinn Kim.*1st","actual":{"thread_id":"057160e1-4c8f-4b8d-859a-599bc4edf2ec","reply":"Got it. Set up rent: $1,900.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 1900

Upmore: Got it. Set up rent: $1,900.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,900.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"1900.00.*Quinn Kim.*1st","actual":{"thread_id":"d07d00d8-3db0-498c-9e46-81acf9653a77","reply":"Got it. Set up rent: $1,900.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: make it 1900

Upmore: Got it. Set up rent: $1,900.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,900.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":3,"kind":"reply","expected":"1900.00.*Quinn Kim.*1st","actual":{"thread_id":"f6db4f1a-e42b-4417-9ddc-71ff9d3346ec","reply":"Got it. Set up rent: $1,900.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

## C00811 · M11 · Details refers to the pending payment · PASS

Expected: [{"say":"send quinn 40"},{"say":"details","match":"40.00.*Quinn Kim","outcome":"details"}]

### Trial 1

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $40.00 to Quinn Kim on Venmo $40.00 to Quinn Kim (@quinnk) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

### Trial 2

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $40.00 to Quinn Kim on Venmo $40.00 to Quinn Kim (@quinnk) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

### Trial 3

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: details

Upmore: Stage $40.00 to Quinn Kim on Venmo $40.00 to Quinn Kim (@quinnk) from checking? No fee, lands in minutes (Venmo balance), 1-3 days to a bank. Irreversible once received; instant cash-out to a bank costs the recipient a fee. Reply yes or no.

## C00812 · M12 · A short yes resumes a serialized split · PASS

Expected: [{"say":"split 120 with quinn and hugo"},{"say":"yes","match":"Quinn Kim.*40.00.*Hugo Rao.*40.00","outcome":"staged"}]

### Trial 1

User: split 120 with quinn and hugo

Upmore: Request $40.00 each from Quinn Kim (@quinnk) and Hugo Rao (@hugor) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Quinn Kim (@quinnk) $40.00 in Venmo, Hugo Rao (@hugor) $40.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 2

User: split 120 with quinn and hugo

Upmore: Request $40.00 each from Quinn Kim (@quinnk) and Hugo Rao (@hugor) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Quinn Kim (@quinnk) $40.00 in Venmo, Hugo Rao (@hugor) $40.00 in Venmo. I'll mark each one paid when the money lands.

### Trial 3

User: split 120 with quinn and hugo

Upmore: Request $40.00 each from Quinn Kim (@quinnk) and Hugo Rao (@hugor) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Quinn Kim (@quinnk) $40.00 in Venmo, Hugo Rao (@hugor) $40.00 in Venmo. I'll mark each one paid when the money lands.

## C00813 · M13 · Cancellation that resolves the last discussed subscription · PASS

Expected: [{"say":"cancel netflix","match":"Netflix"},{"say":"cancel that","match":"Netflix"}]

### Trial 1

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 2

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

### Trial 3

User: cancel netflix

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

User: cancel that

Upmore: I can't read Netflix's account page from here yet, so I can't show you the cancellation terms or cancel it for you. Nothing was changed. You can cancel at https://netflix.com/YourAccount; tell me when it's done and I'll watch the 2026-11-03 charge.

## C00814 · M14 · Stop rent refers to the confirmed standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"quinn $1800 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent","match":"Rent is off","outcome":"rent_stopped"},{"state":"standing.0.status","equals":"stopped"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Quinn Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Quinn Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Quinn Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

## C00815 · M15 · A contextual fee question retains payment identity and asks before acting · PASS

Expected: [{"say":"send quinn 40"},{"say":"what's the fee on that","match":"40.00.*Quinn Kim"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $40.00 to Quinn Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $40.00 to Quinn Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's the fee on that

Upmore: (I dropped the $40.00 to Quinn Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00816 · M16 · Rent setup answers retain the original goal · FAIL

Expected: [{"say":"pay my rent","match":"Who"},{"say":"quinn $1800 on the 1st via Venmo","match":"1800.00.*Quinn Kim","outcome":"confirm"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"standing.0.payee_handle","equals":"@quinnk"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"1800.00.*Quinn Kim","actual":{"thread_id":"0bb8cc16-cb11-4f54-a6ae-7da41a954f7d","reply":"Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"1800.00.*Quinn Kim","actual":{"thread_id":"bdbcad01-f441-47ad-b672-d95226ec936a","reply":"Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

Failures: [{"step":2,"kind":"reply","expected":"1800.00.*Quinn Kim","actual":{"thread_id":"f07112d2-0443-4057-ab25-bc071959c3a7","reply":"Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.","action":null,"route":{"route":"card_reply","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":null,"ask_reason":null,"problems":[]},"http_status":200}}]

## C00817 · M17 · New recipient handle and rail answers retain amount · PASS

Expected: [{"say":"send Dana 50"},{"say":"@danak"},{"say":"@danak"},{"say":"Venmo"},{"say":"@danak","match":"50.00.*Dana","outcome":"confirm"}]

### Trial 1

User: send Dana 50

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $50.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: send Dana 50

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $50.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: send Dana 50

Upmore: I don't have Dana on file. New recipients are confirmed in full, every time. What's Dana's Venmo, Cash App, PayPal or Zelle (like "venmo @dana")?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: @danak

Upmore: Which app is @danak on: Venmo, Cash App or PayPal?

User: Venmo

Upmore: New recipient: Dana, Venmo @danak. I can't see who owns that account, so check the name and photo in Venmo first. Then type the handle back exactly to confirm it's them.

User: @danak

Upmore: New recipient, first send: set up $50.00 to Dana (@danak) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00818 · M18 · Split remembers total while asking who participated · PASS

Expected: [{"say":"split 120 with 2 friends"},{"say":"quinn and hugo","match":"40.00 each.*120.00","outcome":"confirm"}]

### Trial 1

User: split 120 with 2 friends

Upmore: That's $40.00 each across 3 people. Who are the 2? I'll request $40.00 from each.

User: quinn and hugo

Upmore: Request $40.00 each from Quinn Kim (@quinnk) and Hugo Rao (@hugor) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: split 120 with 2 friends

Upmore: That's $40.00 each across 3 people. Who are the 2? I'll request $40.00 from each.

User: quinn and hugo

Upmore: Request $40.00 each from Quinn Kim (@quinnk) and Hugo Rao (@hugor) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: split 120 with 2 friends

Upmore: That's $40.00 each across 3 people. Who are the 2? I'll request $40.00 from each.

User: quinn and hugo

Upmore: Request $40.00 each from Quinn Kim (@quinnk) and Hugo Rao (@hugor) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

## C00819 · M19 · Rent is remembered on the next independent invocation · FAIL

Expected: [{"say":"pay my rent"},{"say":"quinn $1800 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent","match":"1800.00.*Quinn Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Quinn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"1800.00.*Quinn Kim","actual":{"thread_id":"a47ca022-fd71-4c36-9db8-d45e46887200","reply":"Rent for November: $1,800.00 to Quinn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Quinn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"1800.00.*Quinn Kim","actual":{"thread_id":"c6273ddc-5e5c-4b0c-bc62-50ab89e9ec82","reply":"Rent for November: $1,800.00 to Quinn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Quinn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":4,"kind":"reply","expected":"1800.00.*Quinn Kim","actual":{"thread_id":"bfd1593c-4604-4d5a-9146-c5c2a638949d","reply":"Rent for November: $1,800.00 to Quinn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

## C00820 · M20 · An interrupted alias goal remains unconfirmed · PASS

Expected: [{"say":"save quinn as brother"},{"say":"no"},{"state":"recipients.0.nickname","equals":null},{"say":"send brother 40","match":"handle","outcome":"ask"}]

### Trial 1

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 40

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 2

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 40

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

### Trial 3

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

User: send brother 40

Upmore: I don't have brother saved. What's their Venmo, Cash App, PayPal or Zelle handle, or phone number?

## C00821 · M21 · A staged payment is remembered without claiming completion · PASS

Expected: [{"say":"send quinn 40"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $40.00 to Quinn Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 2

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $40.00 to Quinn Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 3

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $40.00 to Quinn Kim for you to send in Venmo. A second yes doesn't stage it again.

## C00822 · M22 · A staged split is remembered without duplicating it · PASS

Expected: [{"say":"split 120 with quinn and hugo"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 120 with quinn and hugo

Upmore: Request $40.00 each from Quinn Kim (@quinnk) and Hugo Rao (@hugor) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Quinn Kim (@quinnk) $40.00 in Venmo, Hugo Rao (@hugor) $40.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 120 with quinn and hugo

Upmore: Request $40.00 each from Quinn Kim (@quinnk) and Hugo Rao (@hugor) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Quinn Kim (@quinnk) $40.00 in Venmo, Hugo Rao (@hugor) $40.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 120 with quinn and hugo

Upmore: Request $40.00 each from Quinn Kim (@quinnk) and Hugo Rao (@hugor) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Quinn Kim (@quinnk) $40.00 in Venmo, Hugo Rao (@hugor) $40.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C00823 · M23 · A declined payment cannot be resurrected by yes · PASS

Expected: [{"say":"send quinn 40"},{"say":"no","match":"Nothing","outcome":"declined"},{"say":"yes","not":"^Staged, not sent"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 2

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 3

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

## C00824 · M24 · Stopping rent prevents the next turn from claiming an active rule · PASS

Expected: [{"say":"pay my rent"},{"say":"quinn $1800 on the 1st via Venmo"},{"say":"yes"},{"say":"stop rent"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Quinn Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Quinn Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Quinn Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C00825 · M25 · Status follow-up recalls staged versus sent · PASS

Expected: [{"say":"send quinn 40"},{"say":"yes"},{"say":"did it go through","match":"(?:not (?:yet )?(?:sent|posted)|staged|have not seen|waiting for.*post)"}]

### Trial 1

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $40.00 to Quinn Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

### Trial 2

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $40.00 to Quinn Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

### Trial 3

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask.

User: did it go through

Upmore: Still staged, not confirmed sent: $40.00 to Quinn Kim. I haven't seen it post in your linked transactions. Check Venmo before sending it again.

## C00826 · M26 · Unapproved nickname does not become a known fact · PASS

Expected: [{"say":"save quinn as brother"},{"state":"recipients.0.nickname","equals":null},{"say":"no"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 2

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

### Trial 3

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: no

Upmore: Okay, I didn't save "brother". Nothing changed.

## C00827 · M27 · Unapproved rent terms are not durable instructions · PASS

Expected: [{"say":"pay my rent"},{"say":"quinn $1800 on the 1st via Venmo"},{"state":"standing.length","equals":0},{"say":"no"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: no

Upmore: Okay, nothing was set up.

## C00828 · M28 · An expired payment card is restated and requires a fresh yes · PASS

Expected: [{"say":"send quinn 40"},{"minutes":11},{"say":"yes","match":"expired.*fresh","outcome":"confirm"},{"state":"state.send.sends.length","equals":0},{"say":"yes","match":"Staged","outcome":"staged"}]

### Trial 1

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: That card expired, so nothing was sent. Here's a fresh one: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask.

## C00829 · M29 · An expired nickname card never writes a fact · PASS

Expected: [{"say":"save quinn as brother"},{"minutes":11},{"say":"yes","match":"expired"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 2

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

### Trial 3

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: That expired, so "brother" wasn't saved. Nothing changed. Say it again to start over.

## C00830 · M30 · A question containing yes does not approve a payment · PASS

Expected: [{"say":"send quinn 40"},{"say":"yes but is there a fee"},{"state":"state.send.sends.length","equals":0},{"say":"no"}]

### Trial 1

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

### Trial 2

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

### Trial 3

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes but is there a fee

Upmore: Got it. Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: no

Upmore: Okay, not doing that. Nothing was changed.

## C00831 · M31 · Moving to small talk explicitly drops the old payment · PASS

Expected: [{"say":"send quinn 40"},{"say":"what's a good movie","match":"dropped.*40.00"},{"say":"yes","not":"^Staged"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $40.00 to Quinn Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $40.00 to Quinn Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: what's a good movie

Upmore: (I dropped the $40.00 to Quinn Kim since you moved on; nothing was sent. Say it again when you want it.) I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00832 · M32 · Switching recipients makes the latest request authoritative · PASS

Expected: [{"say":"send quinn 40"},{"say":"send hugo 60","match":"60.00.*Hugo Rao","outcome":"confirm"},{"say":"yes","match":"60.00.*Hugo Rao","outcome":"staged"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send hugo 60

Upmore: I dropped the earlier card. Set up $60.00 to Hugo Rao (@hugor) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugor; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Hugo Rao posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send hugo 60

Upmore: I dropped the earlier card. Set up $60.00 to Hugo Rao (@hugor) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugor; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Hugo Rao posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: send hugo 60

Upmore: I dropped the earlier card. Set up $60.00 to Hugo Rao (@hugor) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @hugor; 3. Enter $60.00; 4. Keep it private, then Pay. I'll confirm when $60.00 to Hugo Rao posts; if it hasn't by tonight, I'll ask.

## C00833 · M33 · A payment supersedes a pending split rather than approving both · PASS

Expected: [{"say":"split 120 with quinn and hugo"},{"say":"send quinn 40","match":"40.00.*Quinn Kim","outcome":"confirm"},{"say":"yes","match":"Staged, not sent","outcome":"staged"},{"state":"state.split.staged.length","equals":0}]

### Trial 1

User: split 120 with quinn and hugo

Upmore: Request $40.00 each from Quinn Kim (@quinnk) and Hugo Rao (@hugor) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send quinn 40

Upmore: I dropped the earlier card. Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask.

### Trial 2

User: split 120 with quinn and hugo

Upmore: Request $40.00 each from Quinn Kim (@quinnk) and Hugo Rao (@hugor) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send quinn 40

Upmore: I dropped the earlier card. Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask.

### Trial 3

User: split 120 with quinn and hugo

Upmore: Request $40.00 each from Quinn Kim (@quinnk) and Hugo Rao (@hugor) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: send quinn 40

Upmore: I dropped the earlier card. Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask.

## C00834 · M34 · Switching from payment to rent keeps the new goal · PASS

Expected: [{"say":"send quinn 40"},{"say":"pay my rent","match":"Who","outcome":"ask"},{"say":"quinn $1800 on the 1st via Venmo"},{"say":"yes","match":"Rent is set up","outcome":"rent_set"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 2

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

### Trial 3

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: pay my rent

Upmore: I dropped the earlier card. Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

## C00835 · M35 · Never mind cancels an alias confirmation without saving · PASS

Expected: [{"say":"save quinn as brother"},{"say":"never mind"},{"state":"recipients.0.nickname","equals":null},{"say":"yes","not":"^Saved:"}]

### Trial 1

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 2

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

### Trial 3

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: never mind

Upmore: Okay, I didn't save "brother". Nothing changed.

User: yes

Upmore: Nothing's waiting for a yes: that card was dropped, and nothing was sent.

## C00836 · M36 · Confirmed aliases survive a new conversation · PASS

Expected: [{"say":"save quinn as brother"},{"say":"yes"},{"thread":"B"},{"say":"send brother 40","match":"Quinn Kim","outcome":"confirm"}]

### Trial 1

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Quinn Kim (brother, @quinnk).

User: send brother 40

Upmore: Set up $40.00 to Quinn Kim (brother, @quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Quinn Kim (brother, @quinnk).

User: send brother 40

Upmore: Set up $40.00 to Quinn Kim (brother, @quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Quinn Kim (brother, @quinnk).

User: send brother 40

Upmore: Set up $40.00 to Quinn Kim (brother, @quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00837 · M37 · Standing rent survives a new conversation · FAIL

Expected: [{"say":"pay my rent"},{"say":"quinn $1800 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"pay my rent","match":"1800.00.*Quinn Kim","outcome":"confirm"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Quinn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"1800.00.*Quinn Kim","actual":{"thread_id":"2fc193d8-cf47-43f1-918e-515889241362","reply":"Rent for November: $1,800.00 to Quinn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Quinn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"1800.00.*Quinn Kim","actual":{"thread_id":"ece7ad87-27e4-4b77-97b4-2e0e0b52f484","reply":"Rent for November: $1,800.00 to Quinn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Quinn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

Failures: [{"step":5,"kind":"reply","expected":"1800.00.*Quinn Kim","actual":{"thread_id":"ce3e69e1-1095-4f77-9f78-e8f6ac6b558a","reply":"Rent for November: $1,800.00 to Quinn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.","action":null,"route":{"route":"pay_rent","flow":"rent","source":"deterministic","understood":true,"understood_first":true,"outcome":"confirm","canonical":"pay my rent","ask_reason":null,"problems":[]},"http_status":200}}]

## C00838 · M38 · Unapproved thread A card cannot be approved in thread B · PASS

Expected: [{"say":"send quinn 40"},{"thread":"B"},{"say":"yes","not":"^Staged"},{"thread":"A"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00839 · M39 · A nickname correction in another session supersedes the old meaning · PASS

Expected: [{"say":"save quinn as brother"},{"say":"yes"},{"thread":"B"},{"say":"brother is Hugo Rao"},{"say":"yes"},{"thread":"C"},{"say":"send brother 40","match":"Hugo Rao","outcome":"confirm"}]

### Trial 1

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Quinn Kim (brother, @quinnk).

User: brother is Hugo Rao

Upmore: Save "brother" as your name for Hugo Rao (@hugor)? Then "send brother 20" goes to Hugo Rao. "brother" means Quinn Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Hugo Rao (brother, @hugor).

User: send brother 40

Upmore: Set up $40.00 to Hugo Rao (brother, @hugor) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Quinn Kim (brother, @quinnk).

User: brother is Hugo Rao

Upmore: Save "brother" as your name for Hugo Rao (@hugor)? Then "send brother 20" goes to Hugo Rao. "brother" means Quinn Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Hugo Rao (brother, @hugor).

User: send brother 40

Upmore: Set up $40.00 to Hugo Rao (brother, @hugor) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Quinn Kim (brother, @quinnk).

User: brother is Hugo Rao

Upmore: Save "brother" as your name for Hugo Rao (@hugor)? Then "send brother 20" goes to Hugo Rao. "brother" means Quinn Kim now; this moves it. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Hugo Rao (brother, @hugor).

User: send brother 40

Upmore: Set up $40.00 to Hugo Rao (brother, @hugor) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00840 · M40 · Stopping rent in another session prevents future offers · PASS

Expected: [{"say":"pay my rent"},{"say":"quinn $1800 on the 1st via Venmo"},{"say":"yes"},{"thread":"B"},{"say":"stop rent"},{"thread":"C"},{"say":"pay my rent","match":"Who","outcome":"ask"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Quinn Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Quinn Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: stop rent

Upmore: Rent is off: no more monthly rent cards for Quinn Kim. Nothing was sent, and nothing else changed. Say 'pay my rent' to set it up again.

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

## C00841 · M41 · Repeating a staged approval does not stage twice after restore · PASS

Expected: [{"say":"send quinn 40"},{"say":"yes"},{"say":"yes","match":"already staged","outcome":"already_done"},{"say":"yes","match":"already staged","outcome":"already_done"},{"state":"state.send.sends.length","equals":1}]

### Trial 1

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $40.00 to Quinn Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $40.00 to Quinn Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 2

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $40.00 to Quinn Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $40.00 to Quinn Kim for you to send in Venmo. A second yes doesn't stage it again.

### Trial 3

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $40.00; 4. Keep it private, then Pay. I'll confirm when $40.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask.

User: yes

Upmore: That's already staged: $40.00 to Quinn Kim for you to send in Venmo. A second yes doesn't stage it again.

User: yes

Upmore: That's already staged: $40.00 to Quinn Kim for you to send in Venmo. A second yes doesn't stage it again.

## C00842 · M42 · Rent setup retry leaves exactly one standing instruction · PASS

Expected: [{"say":"pay my rent"},{"say":"quinn $1800 on the 1st via Venmo"},{"say":"yes"},{"say":"yes","not":"^Rent is set up"},{"state":"standing.length","equals":1}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: yes

Upmore: I can't answer that right now: the AI service Upmore uses isn't responding, so I didn't look anything up and nothing was changed. Try again in a few minutes.

## C00843 · M43 · Confirmed alias repeated is recognized as already known · PASS

Expected: [{"say":"save quinn as brother"},{"say":"yes"},{"say":"save quinn as brother","match":"already|Already|already means","outcome":"already_done"},{"state":"ops.length","equals":1}]

### Trial 1

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Quinn Kim (brother, @quinnk).

User: save quinn as brother

Upmore: "brother" already means Quinn Kim (brother, @quinnk). Nothing changed.

### Trial 2

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Quinn Kim (brother, @quinnk).

User: save quinn as brother

Upmore: "brother" already means Quinn Kim (brother, @quinnk). Nothing changed.

### Trial 3

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: Saved: "brother" is Quinn Kim (brother, @quinnk).

User: save quinn as brother

Upmore: "brother" already means Quinn Kim (brother, @quinnk). Nothing changed.

## C00844 · M44 · The same month rent is staged once across restored sessions · PASS

Expected: [{"say":"pay my rent"},{"say":"quinn $1800 on the 1st via Venmo"},{"say":"yes"},{"say":"pay my rent"},{"say":"yes","match":"Staged","outcome":"staged"},{"say":"pay my rent","match":"already staged","outcome":"already_done"}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Quinn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $1,800.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $1,800.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $1,800.00 to Quinn Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Quinn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $1,800.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $1,800.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $1,800.00 to Quinn Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: pay my rent

Upmore: Rent for November: $1,800.00 to Quinn Kim on Venmo, due Nov 1, from checking, for you to send. Reply YES to stage it or NO to skip this month, within 10 min.

User: yes

Upmore: Rent for November: Staged, not sent. In Venmo: 1. Open Venmo and tap Pay/Request; 2. Search @quinnk; 3. Enter $1,800.00 and the note "Rent November"; 4. Keep it private, then Pay. I'll confirm when $1,800.00 to Quinn Kim posts; if it hasn't by tonight, I'll ask. Upmore didn't move any money; you send it.

User: pay my rent

Upmore: November's rent is already staged: $1,800.00 to Quinn Kim in Venmo. I didn't stage it again. If you haven't sent it yet, send it from there; Upmore never sends it for you.

## C00845 · M45 · Retried split approval preserves one set of requests · PASS

Expected: [{"say":"split 120 with quinn and hugo"},{"say":"yes"},{"say":"yes"},{"state":"state.split.staged.length","equals":1}]

### Trial 1

User: split 120 with quinn and hugo

Upmore: Request $40.00 each from Quinn Kim (@quinnk) and Hugo Rao (@hugor) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Quinn Kim (@quinnk) $40.00 in Venmo, Hugo Rao (@hugor) $40.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 2

User: split 120 with quinn and hugo

Upmore: Request $40.00 each from Quinn Kim (@quinnk) and Hugo Rao (@hugor) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Quinn Kim (@quinnk) $40.00 in Venmo, Hugo Rao (@hugor) $40.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

### Trial 3

User: split 120 with quinn and hugo

Upmore: Request $40.00 each from Quinn Kim (@quinnk) and Hugo Rao (@hugor) in Venmo: $120.00 split 3 ways, yours $40.00. No fee. You tap Request in the app; nothing is sent from here. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: Staged. Tap Request for each: Quinn Kim (@quinnk) $40.00 in Venmo, Hugo Rao (@hugor) $40.00 in Venmo. I'll mark each one paid when the money lands.

User: yes

Upmore: That's already staged: those requests. A second yes doesn't stage it again.

## C00846 · M46 · Nickname save failure is never reported as remembered · PASS

Expected: [{"say":"save quinn as brother"},{"set":{"failRecipients":true}},{"say":"yes","match":"couldn't save"},{"state":"recipients.0.nickname","equals":null}]

### Trial 1

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 2

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

### Trial 3

User: save quinn as brother

Upmore: Save "brother" as your name for Quinn Kim (@quinnk)? Then "send brother 20" goes to Quinn Kim. Reply YES to save it or NO.

User: yes

Upmore: I couldn't save "brother" right now, so nothing was saved. Say it again in a moment.

## C00847 · M47 · Rent save failure is never reported as a stored rule · PASS

Expected: [{"say":"pay my rent"},{"say":"quinn $1800 on the 1st via Venmo"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*set|nothing was set up"},{"state":"standing.length","equals":0}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so nothing was set up. Nothing was sent. Try again in a moment.

## C00848 · M48 · A failed state write yields no approval card and retry is recoverable · PASS

Expected: [{"set":{"failState":true}},{"say":"send quinn 40","error":"state storage unavailable"},{"set":{"failState":false}},{"say":"send quinn 40","match":"40.00.*Quinn Kim","outcome":"confirm"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send quinn 40

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 2

User: send quinn 40

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

### Trial 3

User: send quinn 40

Upmore: Something went wrong reading this conversation's pending card or your accounts, so I did nothing. Nothing was changed. Try again in a moment.

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

## C00849 · M49 · Unavailable facts cause an honest blocker and preserve the old card · PASS

Expected: [{"say":"send quinn 40"},{"set":{"unreadable":true}},{"say":"yes","match":"can't read.*Nothing was changed","outcome":"unavailable"},{"state":"state.send.sends.length","equals":0}]

### Trial 1

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

### Trial 2

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

### Trial 3

User: send quinn 40

Upmore: Set up $40.00 to Quinn Kim (@quinnk) in Venmo from checking, for you to send. No fee. Can't be undone once received. Reply YES or NO within 10 min, or DETAILS.

User: yes

Upmore: I can't read your transactions right now, so I can't do that yet. Nothing was changed.

## C00850 · M50 · A failed rent correction retains the prior confirmed terms · PASS

Expected: [{"say":"pay my rent"},{"say":"quinn $1800 on the 1st via Venmo"},{"say":"yes"},{"say":"rent is 1900 now"},{"set":{"failStanding":true}},{"say":"yes","match":"couldn't.*save|couldn't.*change|rent stays as it was"},{"state":"standing.0.amount_cents","equals":180000}]

### Trial 1

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 1900 now

Upmore: Change rent (amount $1,800.00 to $1,900.00): $1,900.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 2

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 1900 now

Upmore: Change rent (amount $1,800.00 to $1,900.00): $1,900.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

### Trial 3

User: pay my rent

Upmore: Who do you pay rent to, how much, and which day of the month? e.g. 'Mike $1,450 on the 1st via Zelle'

User: quinn $1800 on the 1st via Venmo

Upmore: Set up rent: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll put up the card and wait for your yes; one message ('stop rent') turns it off. Reply YES or NO within 10 min.

User: yes

Upmore: Rent is set up: $1,800.00 to Quinn Kim on Venmo, monthly on the 1st, from checking. Nothing was sent. 3 days before each due date I'll put up that month's card for your yes; nothing is staged without it. Say 'stop rent' anytime.

User: rent is 1900 now

Upmore: Change rent (amount $1,800.00 to $1,900.00): $1,900.00 to Quinn Kim on Venmo, monthly on the 1st, from checking, for you to send each month. Each month I'll still put up the card and wait for your yes. Reply YES or NO within 10 min.

User: yes

Upmore: I couldn't save that right now, so your rent stays as it was. Nothing was sent. Try again in a moment.

